-- siikk-Auktionshaus · Einführung beim ersten Start (/ah intro)
local ADDON, NS = ...
local Y = "|cffffd100"
siikkIntro("siikk-Auktionshaus", "|cffe03030siikk|r-|cffffd100Auktionshaus|r", "Interface\\AddOns\\" .. ADDON .. "\\Media\\siikk_ah_icon", {
    { "Willkommen beim siikk-Auktionshaus",
      "Dein Helfer fürs Auktionshaus. Öffnest du das Auktionshaus, erscheint das siikk-Fenster " .. Y .. "rechts daneben|r – mit vier Reitern: Preise, Verkaufen, Kaufen und Übersicht.\n\n" ..
      "• Oben im Auktionshaus blendet der Knopf " .. Y .. "siikkAH|r das Fenster ein oder aus.\n\n" ..
      "• Der Minimap-Knopf (Edelsteine) öffnet es auch ohne Auktionshaus – dann kannst du Preise nachschlagen und deine Übersicht ansehen.\n\n" ..
      "• Tipp: Starte beim ersten Besuch gleich einen " .. Y .. "Komplett-Scan|r, dann kennt siikk die Preise." },
    { "Preise",
      "• " .. Y .. "Komplett-Scan|r: liest alle Angebote auf einmal. Blizzard erlaubt das nur alle 15 Minuten – ist er gesperrt, startet automatisch der " .. Y .. "Seiten-Scan|r (langsamer, Seite für Seite).\n\n" ..
      "• Gespeichert werden " .. Y .. "Marktwert|r (typischer Preis pro Stück) und " .. Y .. "günstigstes Angebot|r – für alle deine Charaktere auf diesem Realm.\n\n" ..
      "• Suchfeld: Gegenstand eintippen, schon siehst du Marktwert, günstigsten Preis und wie alt die Daten sind.\n\n" ..
      "• " .. Y .. "Tooltip|r: Maus über einen Gegenstand – überall im Spiel steht der Marktwert dabei.\n\n" ..
      "• " .. Y .. "In den Taschen|r steht oben rechts auf jedem Gegenstand der niedrigste Preis pro Stück vom letzten Scan (z. B. 12g, 3g50, 49s)." },
    { "Verkaufen",
      "• Links alle verkaufbaren Gegenstände aus deinen Taschen, die wertvollsten oben.\n\n" ..
      "• " .. Y .. "Anklicken|r: der Preis steht automatisch 1 Kupfer unter dem günstigsten Angebot. " .. Y .. "AH prüfen|r holt den aktuellen Preis direkt vom Auktionshaus.\n\n" ..
      "• Preis pro Stück, " .. Y .. "Stapelgröße|r, " .. Y .. "Anzahl Stapel|r (" .. Y .. "Max|r = alles) und " .. Y .. "Dauer|r (12 / 24 / 48 Std) wählen – Kaution und Gesamtpreis siehst du sofort.\n\n" ..
      "• " .. Y .. "Einstellen|r: ein Klick = ein Auftrag (Blizzard erlaubt keinen Automatik-Verkauf)." },
    { "Kaufen",
      "• Namen eingeben, " .. Y .. "Suchen|r – die Angebote stehen sortiert nach Preis pro Stück.\n\n" ..
      "• Die letzte Spalte vergleicht mit dem Marktwert: " .. "|cff33ff33grün|r = Schnäppchen (unter 80 %), |cffff6060rot|r = teuer.\n\n" ..
      "• Angebot anklicken, dann " .. Y .. "Kaufen|r – siikk prüft vorher, ob das Angebot noch da ist.\n\n" ..
      "• " .. Y .. "+ Liste|r merkt sich den Suchbegriff in deiner " .. Y .. "Einkaufsliste|r (bis 8). Klick = suchen, Rechtsklick = entfernen." },
    { "Übersicht & Befehle",
      "• " .. Y .. "Übersicht|r: Verkäufe von heute, 7 Tagen, 30 Tagen und gesamt – mit Umsatz und Gewinn nach 5 % Auktionshaus-Gebühr und Kaution. Darunter jeder einzelne Verkauf.\n" ..
      "  Erkannt werden Verkäufe, während du online bist.\n\n" ..
      Y .. "/ah|r – Fenster ein/aus\n" .. Y .. "/ah scan|r – Komplett-Scan\n" .. Y .. "/ah tooltip|r – Marktwert im Tooltip an/aus\n" .. Y .. "/ah taschen|r – Auktionspreis auf den Gegenständen in den Taschen an/aus\n" .. Y .. "/ah intro|r – diese Einführung · " .. Y .. "/ah neu|r – was ist neu\n\n" ..
      "Minimap-Knopf: " .. Y .. "Linksklick|r Fenster · " .. Y .. "Rechtsklick|r Komplett-Scan · " .. Y .. "Ziehen|r verschiebt den Knopf." },
}, function() return siikkAH_DB end, "/ah intro")
