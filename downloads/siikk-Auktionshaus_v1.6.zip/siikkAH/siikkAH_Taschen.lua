-- siikk-Auktionshaus · niedrigster Auktionspreis (letzter Scan) auf jedem Gegenstand in den Taschen
-- Funktioniert mit dem Taschenfenster der siikk-Oberfläche und mit den normalen Blizzard-Taschen. An/aus: /ah taschen
local ADDON, NS = ...

-- kurze Angabe für das kleine Feld: 12g · 3g50 · 49s · 5c
local function kurz(c)
    c = math.floor((c or 0) + 0.5)
    local g, s, k = math.floor(c / 10000), math.floor(c / 100) % 100, c % 100
    if g >= 10 then return "|cffffd100" .. g .. "g|r" end
    if g >= 1 then return "|cffffd100" .. g .. "g|r|cffd0d0d0" .. string.format("%02d", s) .. "|r" end
    if s >= 1 then return "|cffd0d0d0" .. s .. "s|r" end
    return "|cffe0a070" .. k .. "c|r"
end
local function itemId(bag, slot)
    if C_Container and C_Container.GetContainerItemID then return C_Container.GetContainerItemID(bag, slot) end
    if GetContainerItemID then return GetContainerItemID(bag, slot) end
    local link = GetContainerItemLink and GetContainerItemLink(bag, slot)
    return link and tonumber(link:match("item:(%d+)"))
end

function SiikkAH_FachPreis(b, bag, slot, id)
    if type(b) ~= "table" or not b.CreateFontString then return end
    local fs = b.siikkAHPreis
    local e = NS.Einst()
    id = id or (bag and slot and itemId(bag, slot))
    local p = id and NS.Preise()[id]
    if e.taschen == false or not p or not p.l then if fs then fs:Hide() end return end
    if not fs then
        fs = b:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmall")
        fs:SetPoint("TOPRIGHT", b, "TOPRIGHT", -1, -2); fs:SetJustifyH("RIGHT")
        local f, sz = fs:GetFont(); if f then fs:SetFont(f, math.max(8, (sz or 10) - 1), "OUTLINE") end
        b.siikkAHPreis = fs
    end
    fs:SetText(kurz(p.l)); fs:Show()
end

-- normale Blizzard-Taschen
local function blizzTasche(frame)
    if type(frame) ~= "table" or not frame.GetName then return end
    local name, bag = frame:GetName(), frame:GetID()
    for i = 1, (frame.size or 36) do
        local b = _G[name .. "Item" .. i]
        if b then SiikkAH_FachPreis(b, bag, b:GetID()) end
    end
end
if type(rawget(_G, "ContainerFrame_Update")) == "function" then hooksecurefunc("ContainerFrame_Update", blizzTasche) end

function NS.TaschenNeu()
    local s = rawget(_G, "SiikkUITaschenNeu"); if type(s) == "function" then pcall(s) end
    for i = 1, (NUM_CONTAINER_FRAMES or 13) do
        local f = _G["ContainerFrame" .. i]
        if f and f:IsShown() then pcall(blizzTasche, f) end
    end
end
