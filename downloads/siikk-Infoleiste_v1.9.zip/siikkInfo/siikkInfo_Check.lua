-- siikk-Infoleiste · Dungeon- & Raid-Check: Fläschchen, Elixier und Buff-Food beim Betreten und beim Bereitschaftscheck
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local GOLD = { .85, .65, .15 }

-- Erkennung --------------------------------------------------------------
local FLASK_IDS = {
    [17624] = true, [17626] = true, [17627] = true, [17628] = true, [17629] = true,   -- Classic
    [28518] = true, [28519] = true, [28520] = true, [28521] = true, [28540] = true, [42735] = true,   -- TBC
}
local ELIXIER_IDS = {
    [3593] = true, [11334] = true, [11348] = true, [11371] = true, [11390] = true, [11405] = true, [11474] = true,
    [17537] = true, [17538] = true, [17539] = true, [21920] = true, [24363] = true, [24382] = true, [26276] = true,
}
local FLASK_WORT = { "fläschchen", "flask", "фляг", "Фляг", "flacon", "frasco" }
local ELIXIER_WORT = { "elixier", "elixir", "эликсир", "Эликсир", "élixir" }
local function enthaelt(name, liste)
    if type(name) ~= "string" then return false end
    local n = name:lower()
    for _, w in ipairs(liste) do if n:find(w, 1, true) or name:find(w, 1, true) then return true end end
    return false
end
function NS.Verbrauch()
    local v = { elixiere = {} }
    for _, a in ipairs(NS.auren()) do
        if FLASK_IDS[a.id or 0] or enthaelt(a.name, FLASK_WORT) then
            if not v.flask or (NS.rest(a) or 1e9) < (NS.rest(v.flask) or 1e9) then v.flask = a end
        elseif ELIXIER_IDS[a.id or 0] or enthaelt(a.name, ELIXIER_WORT) then v.elixiere[#v.elixiere + 1] = a
        elseif NS.istSatt(a) then v.essen = a end
    end
    return v
end

-- Was fehlt? ---------------------------------------------------------------
local BALD = 300   -- unter 5 Minuten: „läuft bald ab“
local function zustand(a)
    if not a then return "fehlt" end
    local r = NS.rest(a); if r and r < BALD then return "bald", r end
    return "ok", r
end
function NS.CheckErgebnis(art)
    local db = NS.DB(); local v = NS.Verbrauch(); local zeilen = {}
    local raid = art == "raid"
    if (raid and db.chkRaidFlask) or (not raid and db.chkDungeonFlask) then
        local a = v.flask
        if not a then
            local kurz
            for _, e in ipairs(v.elixiere) do if not kurz or (NS.rest(e) or 1e9) < (NS.rest(kurz) or 1e9) then kurz = e end end
            a = kurz
        end
        local z, r = zustand(a)
        zeilen[#zeilen + 1] = { text = L"Fläschchen oder Elixier", z = z, r = r, name = a and a.name }
    end
    if (raid and db.chkRaidEssen) or (not raid and db.chkDungeonEssen) then
        local z, r = zustand(v.essen)
        zeilen[#zeilen + 1] = { text = L"Buff-Food (Satt)", z = z, r = r, name = v.essen and v.essen.name }
    end
    local alles = true
    for _, z in ipairs(zeilen) do if z.z ~= "ok" then alles = false end end
    return zeilen, alles
end

-- Fenster ------------------------------------------------------------------
local f
local function bauen()
    f = CreateFrame("Button", "siikkInfoCheck", UIParent, "BackdropTemplate")
    f:SetSize(380, 100); f:SetPoint("TOP", UIParent, "TOP", 0, -150); f:SetFrameStrata("HIGH")
    f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    f:SetBackdropColor(.03, .02, .05, .94)
    f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton"); f:SetClampedToScreen(true)
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); local p, _, rp, x, y = s:GetPoint(1); NS.DB().checkPunkt = { p, rp, x, y } end)
    f:RegisterForClicks("RightButtonUp"); f:SetScript("OnClick", function(s) s:Hide() end)
    local kopf = f:CreateTexture(nil, "BORDER"); kopf:SetPoint("TOPLEFT", 4, -4); kopf:SetPoint("TOPRIGHT", -4, -4); kopf:SetHeight(26); kopf:SetColorTexture(.315, .19, .45, .8)
    local ic = f:CreateTexture(nil, "OVERLAY"); ic:SetSize(20, 20); ic:SetPoint("LEFT", kopf, "LEFT", 6, 0); ic:SetTexture(NS.MEDIA .. "siikk_info_icon")
    f.titel = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); f.titel:SetPoint("LEFT", ic, "RIGHT", 6, 0)
    local zu = CreateFrame("Button", nil, f, "UIPanelCloseButton"); zu:SetPoint("TOPRIGHT", 0, 0); zu:SetSize(26, 26)
    f.z = {}
    for i = 1, 2 do
        local z = {}
        z.ic = f:CreateTexture(nil, "OVERLAY"); z.ic:SetSize(18, 18); z.ic:SetPoint("TOPLEFT", 14, -36 - (i - 1) * 26)
        z.t = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); z.t:SetPoint("LEFT", z.ic, "RIGHT", 8, 0); z.t:SetJustifyH("LEFT")
        z.r = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); z.r:SetPoint("RIGHT", f, "RIGHT", -14, 0); z.r:SetPoint("TOP", z.ic, "TOP", 0, -3)
        f.z[i] = z
    end
    f.fuss = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); f.fuss:SetPoint("BOTTOM", 0, 8)
    f.fuss:SetText(L"Rechtsklick schließt · ziehen verschiebt")
    f:SetScript("OnUpdate", function(s, el)
        s.zeit = (s.zeit or 0) + el
        if s.zeit > (s.dauer or 15) then s:Hide() end
    end)
    f:Hide()
end

local ART = { party = L"Dungeon-Check", raid = L"Raid-Check" }
function NS.Check(art, immer)
    if not art then
        local _, typ = IsInInstance and IsInInstance()
        art = (typ == "raid" or (IsInRaid and IsInRaid())) and "raid" or "party"
    end
    local zeilen, alles = NS.CheckErgebnis(art)
    if #zeilen == 0 then if immer then NS.msg(L"Im Check ist nichts angehakt – /il öffnet die Einstellungen.") end return end
    if alles and not immer and not NS.DB().chkAllesOk then return end
    if not f then bauen() end
    local db = NS.DB()
    f:ClearAllPoints()
    local pt = db.checkPunkt
    if type(pt) == "table" and pt[1] then f:SetPoint(pt[1], UIParent, pt[2], pt[3], pt[4]) else f:SetPoint("TOP", UIParent, "TOP", 0, -150) end
    f.titel:SetText("|cffffd100" .. ART[art] .. "|r  " .. (alles and ("|cff33ff33" .. L"alles da" .. "|r") or ("|cffff6060" .. L"da fehlt was!" .. "|r")))
    f:SetBackdropBorderColor(alles and .2 or 1, alles and 1 or .38, alles and .2 or .38, 1)
    for i = 1, 2 do
        local z, d = f.z[i], zeilen[i]
        if d then
            z.ic:SetTexture(d.z == "ok" and "Interface\\RaidFrame\\ReadyCheck-Ready" or d.z == "bald" and "Interface\\RaidFrame\\ReadyCheck-Waiting" or "Interface\\RaidFrame\\ReadyCheck-NotReady")
            z.t:SetText(d.text .. (d.name and ("  |cff999999" .. d.name .. "|r") or ""))
            if d.z == "fehlt" then z.r:SetText("|cffff6060" .. L"fehlt" .. "|r")
            elseif d.z == "bald" then z.r:SetText("|cffff8030" .. L"noch " .. NS.mmss(d.r) .. "|r")
            else z.r:SetText(d.r and ("|cff33ff33" .. NS.mmss(d.r) .. "|r") or ("|cff33ff33" .. L"aktiv" .. "|r")) end
            z.ic:Show(); z.t:Show(); z.r:Show()
        else z.ic:Hide(); z.t:Hide(); z.r:Hide() end
    end
    f:SetHeight(46 + #zeilen * 26 + 18)
    f.zeit = 0; f.dauer = alles and 6 or 20
    f:Show()
    if not alles then
        if PlaySound and SOUNDKIT then pcall(PlaySound, SOUNDKIT.RAID_WARNING or 8959) end
        local fehlt = {}
        for _, d in ipairs(zeilen) do if d.z ~= "ok" then fehlt[#fehlt + 1] = d.text .. (d.z == "bald" and (" (" .. L"läuft bald ab" .. ")") or "") end end
        NS.msg(ART[art] .. ": " .. table.concat(fehlt, ", "))
    end
end

-- Auslöser: Instanz betreten, Bereitschaftscheck ------------------------------
local letzte
local ev = CreateFrame("Frame")
for _, e in ipairs({ "PLAYER_ENTERING_WORLD", "ZONE_CHANGED_NEW_AREA", "READY_CHECK" }) do pcall(ev.RegisterEvent, ev, e) end
ev:SetScript("OnEvent", function(_, e)
    if e == "READY_CHECK" then
        if NS.DB().chkBereit then NS.Check() end
        return
    end
    local drin, typ = false, nil
    if IsInInstance then drin, typ = IsInInstance() end
    if not drin or (typ ~= "party" and typ ~= "raid") then letzte = nil return end
    local name, id = "", nil
    if GetInstanceInfo then name, _, _, _, _, _, _, id = GetInstanceInfo() end
    local schluessel = tostring(id or name)
    if letzte == schluessel then return end
    letzte = schluessel
    if C_Timer then C_Timer.After(3, function() NS.Check(typ) end) else NS.Check(typ) end
end)
