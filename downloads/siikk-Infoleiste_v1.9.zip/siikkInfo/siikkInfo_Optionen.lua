-- siikk-Infoleiste · Einstellungsfenster (/il)
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local GOLD = { .85, .65, .15 }
local f
local haken = {}

local function hakenNeu(par, x, y, text, get, set)
    local cb = CreateFrame("CheckButton", nil, par, "UICheckButtonTemplate")
    cb:SetSize(24, 24); cb:SetPoint("TOPLEFT", x, y)
    local l = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); l:SetPoint("LEFT", cb, "RIGHT", 4, 1); l:SetText(text)
    cb:SetScript("OnClick", function(s) set(s:GetChecked() and true or false); NS.Aussehen(); NS.Aktualisieren(); NS.OptAktualisieren() end)
    cb.get = get; haken[#haken + 1] = cb
    return cb
end

function NS.OptAktualisieren()
    if not f then return end
    for _, cb in ipairs(haken) do cb:SetChecked(cb.get() and true or false) end
    if f.regler then f.regler:SetValue(NS.DB().alpha * 100) end
    if f.groesse then f.groesse:SetValue((NS.DB().groesse or 1) * 100) end
end

local function bauen()
    f = CreateFrame("Frame", "siikkInfoOptionen", UIParent, "BackdropTemplate")
    f:SetSize(480, 710); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG")
    f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    f:SetBackdropColor(.03, .02, .05, .96); f:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
    f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton"); f:SetClampedToScreen(true)
    f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
    tinsert(UISpecialFrames, "siikkInfoOptionen")
    local kopf = f:CreateTexture(nil, "BORDER"); kopf:SetPoint("TOPLEFT", 4, -4); kopf:SetPoint("TOPRIGHT", -4, -4); kopf:SetHeight(28); kopf:SetColorTexture(.315, .19, .45, .8)
    local linie = f:CreateTexture(nil, "ARTWORK"); linie:SetPoint("TOPLEFT", kopf, "BOTTOMLEFT"); linie:SetPoint("TOPRIGHT", kopf, "BOTTOMRIGHT"); linie:SetHeight(1); linie:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], 1)
    local ic = f:CreateTexture(nil, "OVERLAY"); ic:SetSize(22, 22); ic:SetPoint("LEFT", kopf, "LEFT", 6, 0); ic:SetTexture(NS.MEDIA .. "siikk_info_icon")
    local tt = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); tt:SetPoint("LEFT", ic, "RIGHT", 6, 0); tt:SetText(L"|cffe03030siikk|r-|cffffd100Infoleiste|r  |cff999999v" .. NS.VERSION .. "|r")
    local zu = CreateFrame("Button", nil, f, "UIPanelCloseButton"); zu:SetPoint("TOPRIGHT", 0, 0)
    local db = NS.DB
    hakenNeu(f, 18, -44, L"Infoleiste anzeigen", function() return db().an end, function(v) db().an = v end)
    local h1 = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); h1:SetPoint("TOPLEFT", 20, -80); h1:SetText(L"Position")
    hakenNeu(f, 18, -98, L"Leiste sperren (Shift + Ziehen verschiebt trotzdem)", function() return db().gesperrt end, function(v) db().gesperrt = v end)
    local hp = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); hp:SetPoint("TOPLEFT", 22, -128); hp:SetText(L"Die Leiste einfach mit der Maus an ihren Platz ziehen.")
    local rb = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); rb:SetSize(160, 22); rb:SetPoint("TOPLEFT", 20, -146); rb:SetText(L"Position zurücksetzen")
    rb:SetScript("OnClick", function() db().punkt = nil; NS.Aussehen() end)
    local h2 = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); h2:SetPoint("TOPLEFT", 20, -186); h2:SetText(L"Anzeigen")
    for i, k in ipairs(NS.BLOECKE) do
        local sp, zl = (i - 1) % 2, math.floor((i - 1) / 2)
        hakenNeu(f, 18 + sp * 220, -204 - zl * 26, NS.NAMEN[k], function() return db().zeigen[k] end, function(v) db().zeigen[k] = v end)
    end
    local l = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); l:SetPoint("TOPLEFT", 20, -346); l:SetText(L"Deckkraft")
    local s = CreateFrame("Slider", nil, f, "BackdropTemplate")
    s:SetOrientation("HORIZONTAL"); s:SetSize(200, 12); s:SetPoint("LEFT", l, "RIGHT", 14, 0)
    s:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    s:SetBackdropColor(.12, .08, .16, 1); s:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .8)
    local th = s:CreateTexture(nil, "OVERLAY"); th:SetColorTexture(1, .82, .1, 1); th:SetSize(10, 16); s:SetThumbTexture(th)
    s:SetMinMaxValues(0, 100); s:SetValueStep(5); if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
    local w = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); w:SetPoint("LEFT", s, "RIGHT", 10, 0)
    s:SetScript("OnValueChanged", function(_, v) v = math.floor(v / 5 + .5) * 5; w:SetText(v .. " %"); db().alpha = v / 100; NS.Leiste:SetBackdropColor(.03, .02, .05, v / 100) end)
    f.regler = s
    -- Größe der Leiste (Skalierung 60–160 %)
    local lg = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); lg:SetPoint("TOPLEFT", 20, -376); lg:SetText(L"Größe")
    local g = CreateFrame("Slider", nil, f, "BackdropTemplate")
    g:SetOrientation("HORIZONTAL"); g:SetSize(200, 12); g:SetPoint("LEFT", s, "LEFT", 0, -30)
    g:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    g:SetBackdropColor(.12, .08, .16, 1); g:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .8)
    local gth = g:CreateTexture(nil, "OVERLAY"); gth:SetColorTexture(1, .82, .1, 1); gth:SetSize(10, 16); g:SetThumbTexture(gth)
    g:SetMinMaxValues(60, 160); g:SetValueStep(5); if g.SetObeyStepOnDrag then g:SetObeyStepOnDrag(true) end
    local gw = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); gw:SetPoint("LEFT", g, "RIGHT", 10, 0)
    g:SetScript("OnValueChanged", function(_, v) v = math.floor(v / 5 + .5) * 5; gw:SetText(v .. " %"); db().groesse = v / 100; NS.Leiste:SetScale(v / 100) end)
    f.groesse = g
    local h3 = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); h3:SetPoint("TOPLEFT", 20, -410); h3:SetText(L"XP-Boni")
    hakenNeu(f, 18, -428, L"Im Chat warnen: 1 Minute vor Ablauf und wenn abgelaufen", function() return db().bonusWarnen end, function(v) db().bonusWarnen = v end)
    hakenNeu(f, 18, -454, L"Ton in der letzten Minute", function() return db().bonusTon end, function(v) db().bonusTon = v end)
    local h4 = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); h4:SetPoint("TOPLEFT", 20, -492); h4:SetText(L"Dungeon- & Raid-Check")
    hakenNeu(f, 18, -510, L"Dungeon: Buff-Food", function() return db().chkDungeonEssen end, function(v) db().chkDungeonEssen = v end)
    hakenNeu(f, 238, -510, L"Dungeon: Fläschchen/Elixier", function() return db().chkDungeonFlask end, function(v) db().chkDungeonFlask = v end)
    hakenNeu(f, 18, -536, L"Raid: Buff-Food", function() return db().chkRaidEssen end, function(v) db().chkRaidEssen = v end)
    hakenNeu(f, 238, -536, L"Raid: Fläschchen/Elixier", function() return db().chkRaidFlask end, function(v) db().chkRaidFlask = v end)
    hakenNeu(f, 18, -562, L"Auch beim Bereitschaftscheck prüfen", function() return db().chkBereit end, function(v) db().chkBereit = v end)
    hakenNeu(f, 18, -588, L"Kurz grün anzeigen, wenn alles da ist", function() return db().chkAllesOk end, function(v) db().chkAllesOk = v end)
    local hc = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); hc:SetPoint("TOPLEFT", 22, -618); hc:SetWidth(440); hc:SetJustifyH("LEFT")
    hc:SetText(L"Kommt automatisch, sobald du einen Dungeon oder Raid betrittst. Unter 5 Minuten Restzeit gilt als „läuft bald ab“.")
    local cb = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); cb:SetSize(160, 22); cb:SetPoint("TOPLEFT", 20, -646); cb:SetText(L"Jetzt prüfen")
    cb:SetScript("OnClick", function() if NS.Check then NS.Check(nil, true) end end)
    local zb = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); zb:SetSize(140, 24); zb:SetPoint("BOTTOMRIGHT", -16, 14); zb:SetText(L"Schließen")
    zb:SetScript("OnClick", function() f:Hide() end)
end

function NS.Optionen()
    if not f then bauen() end
    if f:IsShown() then f:Hide() else NS.OptAktualisieren(); f:Show() end
end
