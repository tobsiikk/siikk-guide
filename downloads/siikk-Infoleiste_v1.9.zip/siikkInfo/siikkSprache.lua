-- siikk · gemeinsames Sprach-System (in jedem siikk-Addon enthalten, wird nur einmal aktiv)
-- Texte stehen im Code auf Deutsch: L"Text". siikkL schlägt die Übersetzung der gewählten Sprache nach.
-- Sprache: zuerst die des WoW-Clients, umschaltbar für ALLE siikk-Addons auf einmal mit /sprache.
-- Gespeichert in siikkSprache_DB des kleinen Addons „siikkSprache“. Alle siikk-Addons laden es zuerst (OptionalDeps),
-- damit die gewählte Sprache schon feststeht, wenn ihre Texte entstehen. Fehlt es, gilt die Sprache des Clients.
SIIKK_TEXTE = rawget(_G, "SIIKK_TEXTE") or { en = {}, ru = {}, fr = {}, es = {} }
if not rawget(_G, "siikkL") then
    local SPRACHEN = { "de", "en", "ru", "fr", "es" }
    local NAMEN = { de = "Deutsch", en = "English", ru = "Русский", fr = "Français", es = "Español" }
    local CLIENT = { deDE = "de", enUS = "en", enGB = "en", ruRU = "ru", frFR = "fr", esES = "es", esMX = "es" }
    local aktuell

    local function clientSprache() return CLIENT[GetLocale and GetLocale() or ""] or "en" end
    local function bestimmen()
        local sv = rawget(_G, "siikkSprache_DB")
        local w = type(sv) == "table" and sv.lang
        aktuell = (w and NAMEN[w]) and w or clientSprache()
    end
    function siikkSprache() if not aktuell then bestimmen() end return aktuell end
    function siikkSpracheName(c) return NAMEN[c or siikkSprache()] end
    function siikkL(s)
        if type(s) ~= "string" then return s end
        local c = aktuell or siikkSprache()
        if c == "de" then return s end
        local t = SIIKK_TEXTE[c]
        return (t and t[s]) or s
    end

    -- Russisch auf einem westlichen Client: Schriften mit kyrillischen Zeichen verwenden
    local CYR = "Fonts\\FRIZQT___CYR.TTF"
    local function kyrillisch()
        if siikkSprache() ~= "ru" or (GetLocale and GetLocale() == "ruRU") then return end
        for _, n in ipairs({ "GameFontNormal", "GameFontNormalSmall", "GameFontNormalLarge", "GameFontHighlight", "GameFontHighlightSmall",
            "GameFontHighlightLarge", "GameFontDisable", "GameFontDisableSmall", "GameFontRed", "GameFontGreen", "GameTooltipText",
            "GameTooltipTextSmall", "GameTooltipHeaderText", "GameFontWhite", "GameFontNormalHuge", "SystemFont_Shadow_Med1" }) do
            local f = rawget(_G, n)
            if type(f) == "table" and f.GetFont then
                local _, gr, fl = f:GetFont(); if gr then pcall(f.SetFont, f, CYR, gr, fl or "") end
            end
        end
    end
    function siikkSchrift(standard) if siikkSprache() == "ru" and not (GetLocale and GetLocale() == "ruRU") then return CYR end return standard end

    -- gespeicherte Wahl einlesen, sobald „siikkSprache“ geladen ist
    local ev = CreateFrame("Frame"); ev:RegisterEvent("ADDON_LOADED"); ev:RegisterEvent("PLAYER_LOGIN")
    ev:SetScript("OnEvent", function(_, e, name)
        if e == "ADDON_LOADED" and name == "siikkSprache" then bestimmen()
        elseif e == "PLAYER_LOGIN" then kyrillisch() end
    end)

    -- Auswahlfenster (/sprache)
    local fenster
    local function setzen(c)
        if type(rawget(_G, "siikkSprache_DB")) ~= "table" then siikkSprache_DB = {} end
        siikkSprache_DB.lang = c
        bestimmen()
    end
    local function oeffnen()
        if not fenster then
            local G = { .85, .65, .15 }
            local f = CreateFrame("Frame", "siikkSpracheFenster", UIParent, "BackdropTemplate"); fenster = f
            f:SetSize(300, 262); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG"); f:EnableMouse(true); f:SetMovable(true)
            f:RegisterForDrag("LeftButton"); f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
            f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
            f:SetBackdropColor(.03, .02, .05, .96); f:SetBackdropBorderColor(G[1], G[2], G[3], 1)
            tinsert(UISpecialFrames, "siikkSpracheFenster")
            local k = f:CreateTexture(nil, "BORDER"); k:SetPoint("TOPLEFT", 4, -4); k:SetPoint("TOPRIGHT", -4, -4); k:SetHeight(28); k:SetColorTexture(.315, .19, .45, .8)
            local t = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); t:SetPoint("LEFT", k, "LEFT", 10, 0)
            t:SetFont(CYR, 15, ""); t:SetText("|cffe03030siikk|r · Sprache / Language")
            local zu = CreateFrame("Button", nil, f, "UIPanelCloseButton"); zu:SetPoint("TOPRIGHT", 0, 0)
            f.knoepfe = {}
            for i, c in ipairs(SPRACHEN) do
                local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); b:SetSize(240, 28); b:SetPoint("TOP", 0, -40 - (i - 1) * 34)
                local fs = b:GetFontString(); if type(fs) == "table" then fs:SetFont(CYR, 13, "") end
                b:SetText(NAMEN[c]); b.code = c
                b:SetScript("OnClick", function()
                    setzen(c)
                    for _, x in ipairs(f.knoepfe) do x:SetText((x.code == c and "» " or "") .. NAMEN[x.code] .. (x.code == c and " «" or "")) end
                    if StaticPopup_Show then StaticPopup_Show("SIIKK_SPRACHE_NEU") end
                end)
                f.knoepfe[#f.knoepfe + 1] = b
            end
            if StaticPopupDialogs then
                StaticPopupDialogs["SIIKK_SPRACHE_NEU"] = { text = "siikk: Reload UI now to change the language? / Jetzt neu laden?", button1 = "Reload", button2 = "×",
                    OnAccept = function() ReloadUI() end, timeout = 0, whileDead = true, hideOnEscape = true }
            end
        end
        local c = siikkSprache()
        for _, x in ipairs(fenster.knoepfe) do x:SetText((x.code == c and "» " or "") .. NAMEN[x.code] .. (x.code == c and " «" or "")) end
        fenster:Show()
    end
    SiikkSpracheOeffnen = oeffnen
    SLASH_SIIKKSPRACHE1 = "/sprache"; SLASH_SIIKKSPRACHE2 = "/language"; SLASH_SIIKKSPRACHE3 = "/siikklang"
    SlashCmdList.SIIKKSPRACHE = function(m)
        m = (m or ""):lower():gsub("%s+", "")
        if NAMEN[m] then setzen(m); print("|cffe03030siikk|r: " .. NAMEN[m] .. " – /reload"); return end
        oeffnen()
    end
end

-- siikk · Schriftgröße für alle siikk-Addons (/schrift)
-- Regler „Alle“ plus je Addon einer. Gespeichert in siikkSprache_DB.schrift.
-- Funktionsweise: Die Fenster jedes Addons werden an ihrem Namen erkannt; alle Texte darin werden mit dem Faktor vergrößert.
-- Ändert ein Addon später selbst die Größe eines Textes, wird das als neue Grundgröße übernommen.
if not rawget(_G, "siikkSchriftGroesse") then
    local ADDONS = {
        { key = "oberflaeche", name = "siikk-Oberfläche", addon = "siikkUI", praefix = { "TobsiikkHelfer", "siikkUIAddonZentrale" } },
        { key = "damagemeter", name = "siikk-Damagemeter", addon = "siikkUI-Damagemeter", praefix = { "siikkUIDamagemeter" } },
        { key = "infoleiste", name = "siikk-Infoleiste", addon = "siikkInfo", praefix = { "siikkInfo" } },
        { key = "auktionshaus", name = "siikk-Auktionshaus", addon = "siikkAH", praefix = { "siikkAH" } },
        { key = "farmhelfer", name = "siikk-Farmhelfer", addon = "siikkFarm", praefix = { "siikkFarm" } },
        { key = "talentplaner", name = "siikk-Talentplaner", addon = "siikkTalent", praefix = { "siikkTalent" } },
        { key = "layer", name = "siikk-Layer", addon = "siikkLayer", praefix = { "siikkLayer" } },
        { key = "minimapsammler", name = "siikk-Minimapsammler", addon = "siikkMMS", praefix = { "siikkMMS" } },
        { key = "schadenszahlen", name = "siikk-Schadenszahlen (Einstellungen)", addon = "siikkSZ", praefix = { "siikkSZOptionen", "siikkSZListe" } },
        { key = "hexer", name = "siikk-Hexer", addon = "siikkHexer", praefix = { "siikkHexer" } },
        -- gemeinsame Fenster (Einführung, Was ist neu, Sprache, Minimap-Knöpfe) folgen nur dem Regler „Alle“
        { key = "_", name = nil, praefix = { "siikkIntro_", "siikkSpracheFenster", "siikkSchriftFenster", "siikkMM_" } },
    }
    local MIN, MAX = 70, 160
    local wurzeln = {}   -- [frame] = addon-Eintrag
    local function db()
        if type(rawget(_G, "siikkSprache_DB")) ~= "table" then siikkSprache_DB = {} end
        local d = siikkSprache_DB; d.schrift = type(d.schrift) == "table" and d.schrift or {}
        return d.schrift
    end
    local function faktor(e)
        local d = db(); local alle = tonumber(d.alle) or 100
        local eigen = (e and e.key ~= "_") and (tonumber(d[e.key]) or 100) or 100
        return alle / 100 * eigen / 100
    end
    siikkSchriftGroesse = function(key) for _, e in ipairs(ADDONS) do if e.key == key then return faktor(e) end end return faktor(nil) end

    local function geladen(e)
        if not e.addon then return true end
        local f = (C_AddOns and C_AddOns.IsAddOnLoaded) or rawget(_G, "IsAddOnLoaded")
        if not f then return true end
        local ok, r = pcall(f, e.addon); return ok and r and true or false
    end
    local function passend(name)
        if type(name) ~= "string" then return nil end
        for _, e in ipairs(ADDONS) do
            for _, p in ipairs(e.praefix) do if name:sub(1, #p) == p then return e end end
        end
    end
    local function textAnpassen(o, fk)
        local font, gr, fl = o:GetFont()
        if type(font) ~= "string" or type(gr) ~= "number" or gr <= 0 then return end
        local st = rawget(o, "siikkSG")
        if not st then st = {}; o.siikkSG = st end
        if not st.gesetzt or math.abs(gr - st.gesetzt) > .05 then st.basis = gr end -- Addon hat selbst eine Größe gesetzt
        local neu = math.floor(st.basis * fk * 10 + .5) / 10
        if math.abs(neu - gr) > .05 then pcall(o.SetFont, o, font, neu, fl or "") end
        st.gesetzt = neu
    end
    local function laufen(fr, fk, tiefe)
        if tiefe > 12 or type(fr) ~= "table" or (fr.IsForbidden and fr:IsForbidden()) then return end
        if fr.GetRegions then
            for _, r in ipairs({ fr:GetRegions() }) do
                if type(r) == "table" and r.GetObjectType and r:GetObjectType() == "FontString" then pcall(textAnpassen, r, fk) end
            end
        end
        local typ = fr.GetObjectType and fr:GetObjectType()
        if typ == "EditBox" or typ == "SimpleHTML" or typ == "MessageFrame" or typ == "ScrollingMessageFrame" then pcall(textAnpassen, fr, fk) end
        if fr.GetChildren then
            for _, c in ipairs({ fr:GetChildren() }) do laufen(c, fk, tiefe + 1) end
        end
    end
    local function anwenden(fr)
        local e = wurzeln[fr]; if not e then return end
        pcall(laufen, fr, faktor(e), 0)
    end
    local function alleAnwenden() for fr in pairs(wurzeln) do anwenden(fr) end end
    -- neue Fenster der siikk-Addons finden (nur Fenster, die direkt an UIParent hängen oder frei stehen)
    local function suchen()
        local EF = rawget(_G, "EnumerateFrames")
        if type(EF) ~= "function" then return end
        local f = EF()
        local n0 = 0
        while type(f) == "table" and n0 < 200000 do
            n0 = n0 + 1
            if not wurzeln[f] and not (f.IsForbidden and f:IsForbidden()) then
                local ok, n = pcall(f.GetName, f)
                local e = ok and passend(n)
                if e then
                    local p = f.GetParent and f:GetParent()
                    -- nur oberste siikk-Fenster merken: Kinder werden über ihr Elternfenster mit erfasst
                    if not (p and wurzeln[p]) and not (p and passend(select(2, pcall(p.GetName, p)))) then
                        wurzeln[f] = e
                        if f.HookScript then pcall(f.HookScript, f, "OnShow", function(self) anwenden(self) end) end
                        anwenden(f)
                    end
                end
            end
            local nf = EF(f); if nf == f then break end; f = nf
        end
    end
    siikkSchriftAnwenden = function() suchen(); alleAnwenden() end

    -- nach dem Einloggen suchen, danach alle 5 Sekunden (nicht im Kampf) nach neuen Fenstern und geänderten Texten sehen
    local ev = CreateFrame("Frame"); ev:RegisterEvent("PLAYER_LOGIN")
    local gestartet = false
    ev:SetScript("OnEvent", function(_, e)
        if e ~= "PLAYER_LOGIN" or gestartet then return end
        gestartet = true
        local drin = false
        local function takt()
            if drin then return end
            drin = true
            if not (InCombatLockdown and InCombatLockdown()) then pcall(suchen); pcall(alleAnwenden) end
            if C_Timer and C_Timer.After then C_Timer.After(5, takt) end
            drin = false
        end
        if C_Timer and C_Timer.After then C_Timer.After(2, takt) else pcall(suchen) end
    end)

    -- Fenster /schrift
    local fenster
    local function regler(f, y, text, key)
        local G = { .85, .65, .15 }
        local l = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); l:SetPoint("TOPLEFT", 18, y); l:SetText(text)
        l:SetFont((siikkSchrift and siikkSchrift("Fonts\\FRIZQT__.TTF")) or "Fonts\\FRIZQT__.TTF", 12, "")
        local s = CreateFrame("Slider", nil, f, "BackdropTemplate")
        s:SetOrientation("HORIZONTAL"); s:SetSize(150, 12); s:SetPoint("TOPLEFT", 230, y - 1)
        s:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
        s:SetBackdropColor(.12, .08, .16, 1); s:SetBackdropBorderColor(G[1], G[2], G[3], .8)
        local th = s:CreateTexture(nil, "OVERLAY"); th:SetColorTexture(1, .82, .1, 1); th:SetSize(10, 16); s:SetThumbTexture(th)
        s:SetMinMaxValues(MIN, MAX); s:SetValueStep(5); if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
        local w = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); w:SetPoint("LEFT", s, "RIGHT", 10, 0)
        s:SetValue(tonumber(db()[key]) or 100); w:SetText((tonumber(db()[key]) or 100) .. " %")
        s:SetScript("OnValueChanged", function(_, v)
            v = math.floor(v / 5 + .5) * 5; w:SetText(v .. " %")
            if db()[key] ~= v then db()[key] = (v ~= 100) and v or nil; alleAnwenden() end
        end)
        f.regler[#f.regler + 1] = { s = s, key = key }
    end
    local function oeffnen()
        if not fenster then
            local G = { .85, .65, .15 }
            local liste = {}
            for _, e in ipairs(ADDONS) do if e.name and geladen(e) then liste[#liste + 1] = e end end
            local f = CreateFrame("Frame", "siikkSchriftFenster", UIParent, "BackdropTemplate"); fenster = f; f.regler = {}
            f:SetSize(440, 110 + (#liste + 1) * 28); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG"); f:EnableMouse(true); f:SetMovable(true)
            f:RegisterForDrag("LeftButton"); f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
            f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
            f:SetBackdropColor(.03, .02, .05, .96); f:SetBackdropBorderColor(G[1], G[2], G[3], 1)
            tinsert(UISpecialFrames, "siikkSchriftFenster")
            local k = f:CreateTexture(nil, "BORDER"); k:SetPoint("TOPLEFT", 4, -4); k:SetPoint("TOPRIGHT", -4, -4); k:SetHeight(28); k:SetColorTexture(.315, .19, .45, .8)
            local t = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); t:SetPoint("LEFT", k, "LEFT", 10, 0)
            t:SetFont("Fonts\\FRIZQT___CYR.TTF", 15, ""); t:SetText("|cffe03030siikk|r · Schriftgröße / Font size")
            local zu = CreateFrame("Button", nil, f, "UIPanelCloseButton"); zu:SetPoint("TOPRIGHT", 0, 0)
            regler(f, -48, "|cffffd100Alle siikk-Addons / All|r", "alle")
            for i, e in ipairs(liste) do regler(f, -48 - i * 28, e.name, e.key) end
            local hinweis = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); hinweis:SetPoint("BOTTOMLEFT", 18, 44)
            hinweis:SetPoint("BOTTOMRIGHT", -18, 44); hinweis:SetJustifyH("LEFT")
            hinweis:SetText("Questhilfe & Schadenszahlen im Kampf haben eigene Regler (/qh, /sz).")
            local r = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); r:SetSize(160, 24); r:SetPoint("BOTTOM", 0, 12)
            r:SetText("Alles 100 % / Reset")
            r:SetScript("OnClick", function()
                local d = db(); for kk in pairs(d) do d[kk] = nil end
                for _, x in ipairs(f.regler) do x.s:SetValue(100) end
                alleAnwenden()
            end)
        end
        for _, x in ipairs(fenster.regler) do x.s:SetValue(tonumber(db()[x.key]) or 100) end
        fenster:Show()
    end
    SiikkSchriftOeffnen = oeffnen
    SLASH_SIIKKSCHRIFT1 = "/schrift"; SLASH_SIIKKSCHRIFT2 = "/fontsize"; SLASH_SIIKKSCHRIFT3 = "/siikkfont"
    SlashCmdList.SIIKKSCHRIFT = function(m)
        local n = tonumber((m or ""):match("(%d+)"))
        if n then
            n = math.max(MIN, math.min(MAX, math.floor(n / 5 + .5) * 5)); db().alle = (n ~= 100) and n or nil
            pcall(suchen); alleAnwenden(); print("|cffe03030siikk|r: Schriftgröße / font size " .. n .. " %"); return
        end
        oeffnen()
    end
end
