-- siikk-Infoleiste · Leiste am Bildschirmrand mit Ort, Gold, Haltbarkeit, Taschen, Ehre, Erfahrung, Leistung und Uhr
local ADDON, NS = ...
local L = siikkL or function(s) return s end
NS.VERSION = "4.0"
NS.MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\Media\\"
local Y, W, G, R, LILA = "|cffffd100", "|cffffffff", "|cff33ff33", "|cffff6060", "|cffb266ff"
local GOLD = { .85, .65, .15 }
function NS.msg(t) print(L"|cffe03030siikk|r-|cffffd100Infoleiste|r: " .. t) end

-- Einstellungen ------------------------------------------------------------
NS.BLOECKE = { "stufe", "taschen", "haltbarkeit", "gold", "ort", "ehre", "erfahrung", "uhr", "splitter", "bonus", "stein", "gstein", "fps", "latenz" }
NS.NAMEN = { ort = L"Ort & Koordinaten", gold = L"Gold", haltbarkeit = L"Haltbarkeit", taschen = L"Taschenplatz", ehre = L"Ehre",
    erfahrung = L"Erfahrung", bonus = L"XP-Boni (Schlafsack, Essen, Zelt)", uhr = L"Uhr",
    stufe = L"Stufe", fps = L"FPS (Bilder pro Sekunde)", latenz = L"Latenz (ms)", splitter = L"Seelensplitter (Hexenmeister)", stein = L"Seelenstein (Hexenmeister)", gstein = L"Gesundheitsstein (Hexenmeister)" }
local STANDARD = { xpBalken = true, an = true, alpha = .85, groesse = 1, gesperrt = false, bonusWarnen = true, bonusTon = true,
    chkDungeonEssen = true, chkDungeonFlask = false, chkRaidEssen = true, chkRaidFlask = true, chkBereit = true, chkAllesOk = true }
local AUS = { uhr = true }   -- die Uhr zeigt die siikk-Oberfläche schon – standardmäßig aus
NS.STANDARD = STANDARD
function NS.DB()
    local db = rawget(_G, "siikkInfo_DB")
    if type(db) ~= "table" then db = {}; siikkInfo_DB = db end
    for k, v in pairs(STANDARD) do if db[k] == nil then db[k] = v end end
    db.zeigen = db.zeigen or {}
    for _, k in ipairs(NS.BLOECKE) do if db.zeigen[k] == nil then db.zeigen[k] = not AUS[k] end end
    if (db.v or 1) < 2 then   -- Umstieg von 1.0: kompakte Leiste, FPS/Uhr aus
        db.v = 2; db.zeigen.leistung = false; db.zeigen.uhr = false; db.pos = nil; db.platz = nil
    end
    if (db.v or 2) < 3 then   -- 2.3: eigene Reiter für Stufe, FPS und Latenz
        db.v = 3; db.zeigen.stufe = true; db.zeigen.fps = true; db.zeigen.latenz = true; db.zeigen.leistung = nil
    end
    if db.v < 4 then db.v = 4; db.zeigen.splitter = true end   -- 2.8: Seelensplitter
    if db.v < 5 then db.v = 5; db.zeigen.stein = true end      -- 3.0: Seelenstein-Knopf
    if db.v < 6 then db.v = 6; db.zeigen.gstein = true end     -- 3.1: Gesundheitsstein-Knopf
    if db.v < 7 then db.v = 7; db.zeigen.ort = false; db.zeigen.ehre = false; db.zeigen.erfahrung = false end   -- 3.2
    db.chars = db.chars or {}
    return db
end

-- Formate ---------------------------------------------------------------
local function punkte(n)
    n = math.floor((n or 0) + .5)
    local neg = n < 0; if neg then n = -n end
    local s = tostring(n):reverse():gsub("(%d%d%d)", "%1."):reverse():gsub("^%.", "")
    return (neg and "-" or "") .. s
end
NS.punkte = punkte
local function prozent(a, b) if not b or b == 0 then return "0 %" end return (("%.1f"):format(a / b * 100):gsub("%.", ",")) .. " %" end
NS.prozent = prozent
local function zeit(s)
    if not s or s ~= s or s == math.huge or s < 0 then return "unbekannt" end
    s = math.floor(s)
    local t, h, m = math.floor(s / 86400), math.floor(s % 86400 / 3600), math.floor(s % 3600 / 60)
    local x = s % 60
    if t > 0 then return (L"%d T %d Std %d Min %d s"):format(t, h, m, x) end
    if h > 0 then return (L"%d Std %d Min %d s"):format(h, m, x) end
    if m > 0 then return (L"%d Min %d s"):format(m, x) end
    return x .. " s"
end
NS.zeit = zeit
local GI, SI, CI = "|TInterface\\MoneyFrame\\UI-GoldIcon:12:12:2:0|t", "|TInterface\\MoneyFrame\\UI-SilverIcon:12:12:2:0|t", "|TInterface\\MoneyFrame\\UI-CopperIcon:12:12:2:0|t"
local function geld(c, kurz)
    c = math.floor(c or 0); local neg = c < 0; if neg then c = -c end
    local g, s, k = math.floor(c / 10000), math.floor(c % 10000 / 100), c % 100
    local t
    if kurz == "voll" then t = punkte(g) .. GI .. " " .. s .. SI .. " " .. k .. CI   -- Leiste: immer alle drei
    elseif g > 0 then t = punkte(g) .. GI .. " " .. s .. SI .. (kurz and "" or (" " .. k .. CI))
    elseif s > 0 then t = s .. SI .. " " .. k .. CI
    else t = k .. CI end
    return (neg and "-" or "") .. t
end
NS.geld = geld
local function api(t, n) local tab = rawget(_G, t); return type(tab) == "table" and tab[n] or nil end

-- Leiste -----------------------------------------------------------------
local Leiste = CreateFrame("Frame", "siikkInfoLeiste", UIParent, "BackdropTemplate")
NS.Leiste = Leiste
Leiste:SetHeight(24); Leiste:SetFrameStrata("LOW"); Leiste:SetFrameLevel(5)
Leiste:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8" })
Leiste:SetMovable(true); Leiste:SetClampedToScreen(true); Leiste:EnableMouse(true); Leiste:RegisterForDrag("LeftButton")
local function ziehenStart() if not NS.DB().gesperrt or IsShiftKeyDown() then Leiste:StartMoving() end end
-- Die Leiste geht über die ganze Bildschirmbreite: nur hoch/runter verschieben, die Höhe wird gespeichert
local function ziehenEnde()
    Leiste:StopMovingOrSizing()
    local oben, s = UIParent:GetTop(), Leiste:GetEffectiveScale() / UIParent:GetEffectiveScale()
    local t = Leiste:GetTop()
    if oben and t then NS.DB().obenAbstand = math.max(0, oben - t * s) end
    if NS.Aussehen then NS.Aussehen() end
end
Leiste:SetScript("OnDragStart", ziehenStart); Leiste:SetScript("OnDragStop", ziehenEnde)
local B = {}   -- Blöcke nach Schlüssel
NS.B = B

-- Mitte: XP-Boni · rechts: FPS und Latenz · alles andere links
local MITTE = "bonus"
local RECHTS = { "fps", "latenz" }
local istRechts = { [MITTE] = true, splitter = true, stein = true, gstein = true }; for _, k in ipairs(RECHTS) do istRechts[k] = true end
local anordnen
anordnen = function()
    local db = NS.DB()
    local x = 8
    for _, k in ipairs(NS.BLOECKE) do
        local b = B[k]
        if b and not istRechts[k] then
            if db.zeigen[k] and not b.leer then b:ClearAllPoints(); b:SetPoint("LEFT", Leiste, "LEFT", x, 0); b:Show(); x = x + b:GetWidth() + 16 else b:Hide() end
        end
    end
    local m = B[MITTE]
    local mitteDa = m and db.zeigen[MITTE] and not m.leer
    if m then
        if mitteDa then m:ClearAllPoints(); m:SetPoint("CENTER", Leiste, "CENTER", 0, 0); m:Show() else m:Hide() end
    end
    -- Seelensplitter direkt links neben den XP-Boni (ohne Boni: links von der Mitte)
    local sp = B.splitter
    if sp then
        if db.zeigen.splitter and not sp.leer then
            sp:ClearAllPoints()
            if mitteDa then sp:SetPoint("RIGHT", m, "LEFT", -14, 0) else sp:SetPoint("RIGHT", Leiste, "CENTER", -7, 0) end
            sp:Show()
        else sp:Hide() end
    end
    -- Seelenstein direkt rechts neben den XP-Boni
    local st = B.stein
    if st then
        if db.zeigen.stein and not st.leer then
            st:ClearAllPoints()
            if mitteDa then st:SetPoint("LEFT", m, "RIGHT", 14, 0) else st:SetPoint("LEFT", Leiste, "CENTER", 7, 0) end
            st:Show()
        else st:Hide() end
    end
    -- Gesundheitsstein rechts neben dem Seelenstein
    local gs = B.gstein
    if gs then
        if db.zeigen.gstein and not gs.leer then
            gs:ClearAllPoints()
            if st and st:IsShown() then gs:SetPoint("LEFT", st, "RIGHT", 14, 0)
            elseif mitteDa then gs:SetPoint("LEFT", m, "RIGHT", 14, 0) else gs:SetPoint("LEFT", Leiste, "CENTER", 7, 0) end
            gs:Show()
        else gs:Hide() end
    end
    -- Klassen-Anzeige (4.0): rechts an Gesundheitsstein / Seelenstein / XP-Boni anschließen
    local vor = (gs and gs:IsShown() and gs) or (st and st:IsShown() and st) or (mitteDa and m) or nil
    for _, kb in ipairs(NS.KB or {}) do
        if kb.aktiv and not kb.leer then
            kb:ClearAllPoints()
            if vor then kb:SetPoint("LEFT", vor, "RIGHT", 14, 0) else kb:SetPoint("LEFT", Leiste, "CENTER", 7, 0) end
            kb:Show(); vor = kb
        else kb:Hide() end
    end
    if NS.SteinKnopfSetzen then NS.SteinKnopfSetzen() end
    if NS.KlassenKnoepfeSetzen then NS.KlassenKnoepfeSetzen() end
    local r = 8
    for i = #RECHTS, 1, -1 do
        local b = B[RECHTS[i]]
        if b then
            if db.zeigen[RECHTS[i]] and not b.leer then b:ClearAllPoints(); b:SetPoint("RIGHT", Leiste, "RIGHT", -r, 0); b:Show(); r = r + b:GetWidth() + 16 else b:Hide() end
        end
    end
end
NS.anordnen = anordnen

local function block(k, icon, tipp, klick, coords)
    local b = CreateFrame("Button", nil, Leiste); b:SetHeight(20); b:RegisterForClicks("AnyUp")
    b:RegisterForDrag("LeftButton"); b:SetScript("OnDragStart", ziehenStart); b:SetScript("OnDragStop", ziehenEnde)
    b.ic = b:CreateTexture(nil, "ARTWORK"); b.ic:SetSize(15, 15); b.ic:SetPoint("LEFT", 0, 0); b.ic:SetTexture(icon)
    if coords then b.ic:SetTexCoord(unpack(coords)) else b.ic:SetTexCoord(.08, .92, .08, .92) end
    b.t = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); b.t:SetPoint("LEFT", b.ic, "RIGHT", 4, 0)
    local hl = b:CreateTexture(nil, "HIGHLIGHT"); hl:SetAllPoints(); hl:SetColorTexture(1, .82, .1, .12)
    function b.setze(text)
        if b.alt == text then return end
        b.alt = text; b.t:SetText(text)
        local w = 0; local ok, sw = pcall(b.t.GetStringWidth, b.t); if ok and type(sw) == "number" then w = sw end
        local neu = math.floor(w + 21)
        if b.breite ~= neu then b.breite = neu; b:SetWidth(neu); anordnen() end
    end
    b:SetScript("OnEnter", function(s)
        local top = Leiste:GetTop(); local unten = top and UIParent:GetHeight() and top < UIParent:GetHeight() / 2
        GameTooltip:SetOwner(s, unten and "ANCHOR_TOP" or "ANCHOR_NONE")
        if not unten then GameTooltip:ClearAllPoints(); GameTooltip:SetPoint("TOPLEFT", s, "BOTTOMLEFT", 0, -6) end
        tipp(GameTooltip)
        GameTooltip:AddLine(NS.DB().gesperrt and L"Shift + Ziehen: Leiste verschieben" or L"Ziehen: Leiste verschieben", .45, .45, .45)
        GameTooltip:Show(); s.tippOffen = true
    end)
    b:SetScript("OnLeave", function(s) s.tippOffen = nil; GameTooltip:Hide() end)
    if klick then b:SetScript("OnClick", klick) end
    B[k] = b
    return b
end
NS.block = block
local function tipKopf(tt, titel) tt:AddLine(titel, 1, .82, 0) end
local function zeile(tt, a, b, r, g, bl) tt:AddDoubleLine(a, b, 1, .82, 0, r or 1, g or 1, bl or 1) end
NS.tipKopf, NS.zeile = tipKopf, zeile
NS.Anordnen = function() anordnen() end

-- Ort & Koordinaten
local function koordinaten()
    local mapF, posF = api("C_Map", "GetBestMapForUnit"), api("C_Map", "GetPlayerMapPosition")
    if not (mapF and posF) then return end
    local ok, m = pcall(mapF, "player"); if not ok or not m then return end
    local ok2, p = pcall(posF, m, "player"); if not ok2 or type(p) ~= "table" then return end
    local ok3, x, y = pcall(p.GetXY, p); if not ok3 or not x or (x == 0 and y == 0) then return end
    return x * 100, y * 100
end
local PVPFARBE = { sanctuary = "|cff69ccf0", friendly = "|cff33ff33", hostile = "|cffff4040", contested = "|cffffa040", arena = "|cffff4040", combat = "|cffff4040" }
local function ortText()
    local z = (GetMinimapZoneText and GetMinimapZoneText()) or (GetZoneText and GetZoneText()) or "?"
    local pv = GetZonePVPInfo and GetZonePVPInfo()
    local x, y = koordinaten()
    return (PVPFARBE[pv or ""] or Y) .. z .. "|r" .. (x and (W .. " (" .. math.floor(x) .. ", " .. math.floor(y) .. ")|r") or "")
end
block("ort", "Interface\\Icons\\INV_Misc_Map_01", function(tt)
    tipKopf(tt, L"Ort")
    zeile(tt, L"Gebiet", (GetZoneText and GetZoneText()) or "?")
    local sub = GetSubZoneText and GetSubZoneText(); if sub and sub ~= "" then zeile(tt, L"Ort", sub) end
    local x, y = koordinaten()
    local function k(v) return (("%.1f"):format(v):gsub("%.", ",")) end
    zeile(tt, L"Koordinaten", x and (k(x) .. " / " .. k(y)) or L"– (in Instanzen nicht verfügbar)")
    local pv = GetZonePVPInfo and GetZonePVPInfo()
    local art = ({ sanctuary = L"Zufluchtsort", friendly = "freundlich", hostile = "feindlich", contested = L"umkämpft", arena = "Arena", combat = L"Kampfgebiet" })[pv or ""]
    if art then zeile(tt, L"Gebietsart", art) end
    tt:AddLine(" "); tt:AddLine(L"Linksklick: Weltkarte", .6, .6, .6)
end, function()
    if ToggleWorldMap then ToggleWorldMap() elseif WorldMapFrame then if WorldMapFrame:IsShown() then HideUIPanel(WorldMapFrame) else ShowUIPanel(WorldMapFrame) end end
end)

-- Gold
local start = { geld = nil }
local function charKey() return (GetRealmName and GetRealmName() or "?") .. " · " .. (UnitName("player") or "?") end
NS.charKey = charKey
-- gewählte Klasse für diesen Charakter (beim 1. Start gefragt, änderbar unter /il) – sonst die echte Klasse
function NS.Klasse()
    local db = NS.DB(); db.klasseWahl = type(db.klasseWahl) == "table" and db.klasseWahl or {}
    local w = db.klasseWahl[charKey()]
    if w then return w end
    local _, kl = UnitClass("player"); return kl
end
local function geldMerken()
    local db = NS.DB(); local _, kl = UnitClass("player")
    db.chars[charKey()] = { geld = GetMoney(), klasse = kl, realm = GetRealmName and GetRealmName(), name = UnitName("player"), fraktion = UnitFactionGroup and UnitFactionGroup("player") }
end
block("gold", "Interface\\MoneyFrame\\UI-GoldIcon", function(tt)
    tipKopf(tt, L"Gold")
    local jetzt = GetMoney()
    zeile(tt, L"Dieser Charakter", geld(jetzt))
    if start.geld then
        local d = jetzt - start.geld
        zeile(tt, L"Diese Sitzung", (d >= 0 and "+" or "") .. geld(d), d >= 0 and .3 or 1, d >= 0 and 1 or .4, d >= 0 and .3 or .4)
    end
    local realm = GetRealmName and GetRealmName()
    local liste, summe = {}, 0
    for _, c in pairs(NS.DB().chars) do if c.realm == realm then liste[#liste + 1] = c; summe = summe + (c.geld or 0) end end
    if #liste > 1 then
        table.sort(liste, function(a, b) return (a.geld or 0) > (b.geld or 0) end)
        tt:AddLine(" "); tt:AddLine(L"Alle Charaktere auf " .. (realm or "?"), 1, .82, 0)
        for _, c in ipairs(liste) do
            local f = (rawget(_G, "RAID_CLASS_COLORS") or {})[c.klasse or ""]
            tt:AddDoubleLine(c.name or "?", geld(c.geld), f and f.r or 1, f and f.g or 1, f and f.b or 1, 1, 1, 1)
        end
        zeile(tt, L"Gesamt", geld(summe))
    end
    tt:AddLine(" "); tt:AddLine(L"Linksklick: Taschen öffnen", .6, .6, .6)
end, function() if ToggleAllBags then ToggleAllBags() elseif OpenAllBags then OpenAllBags() end end, { 0, 1, 0, 1 })

-- Haltbarkeit
local SLOTS = { { 1, L"Kopf" }, { 3, L"Schultern" }, { 5, L"Brust" }, { 6, L"Taille" }, { 7, L"Beine" }, { 8, L"Füße" }, { 9, L"Handgelenke" }, { 10, L"Hände" }, { 16, L"Waffenhand" }, { 17, L"Schildhand" }, { 18, L"Distanz" } }
local scan
local function reparatur(slot)
    if not scan then scan = CreateFrame("GameTooltip", "siikkInfoScan", UIParent, "GameTooltipTemplate"); scan:SetOwner(UIParent, "ANCHOR_NONE") end
    local ok, _, _, kosten = pcall(scan.SetInventoryItem, scan, "player", slot)
    if ok and type(kosten) == "number" then return kosten end
    return 0
end
local function haltbarkeit()
    local min, alle = nil, {}
    for _, s in ipairs(SLOTS) do
        local c, m = GetInventoryItemDurability(s[1])
        if c and m and m > 0 then local p = c / m * 100; alle[#alle + 1] = { s[2], p, s[1] }; if not min or p < min then min = p end end
    end
    return min, alle
end
local function pFarbe(p) if p < 25 then return R elseif p < 60 then return "|cffffa040" end return G end
block("haltbarkeit", "Interface\\Icons\\Trade_BlackSmithing", function(tt)
    tipKopf(tt, L"Haltbarkeit")
    local _, alle = haltbarkeit()
    local kosten = 0
    for _, a in ipairs(alle) do
        local r, g, b = 1, 1, 1; if a[2] < 25 then r, g, b = 1, .4, .4 elseif a[2] < 60 then r, g, b = 1, .63, .25 end
        tt:AddDoubleLine(a[1], math.floor(a[2] + .5) .. " %", 1, .82, 0, r, g, b)
        kosten = kosten + reparatur(a[3])
    end
    if #alle == 0 then tt:AddLine(L"Keine Ausrüstung mit Haltbarkeit angelegt.", .7, .7, .7) end
    if kosten > 0 then tt:AddLine(" "); zeile(tt, L"Reparatur ca.", geld(kosten)) end
end)

-- Taschen
local function frei()
    local f, gesamt = 0, 0
    for bag = 0, 4 do
        local n, typ
        if C_Container and C_Container.GetContainerNumFreeSlots then n, typ = C_Container.GetContainerNumFreeSlots(bag) else n, typ = GetContainerNumFreeSlots(bag) end
        local slots = (C_Container and C_Container.GetContainerNumSlots) and C_Container.GetContainerNumSlots(bag) or (GetContainerNumSlots and GetContainerNumSlots(bag)) or 0
        if (typ or 0) == 0 then f = f + (n or 0); gesamt = gesamt + (slots or 0) end
    end
    return f, gesamt
end
block("taschen", "Interface\\Icons\\INV_Misc_Bag_08", function(tt)
    tipKopf(tt, L"Taschen")
    local f, g = frei()
    zeile(tt, L"Freie Plätze", f .. " von " .. g)
    tt:AddLine(" "); tt:AddLine(L"Linksklick: Taschen öffnen", .6, .6, .6)
end, function() if ToggleAllBags then ToggleAllBags() elseif OpenAllBags then OpenAllBags() end end)

-- Ehre
local function waehrung(ids, namen)
    local ci = api("C_CurrencyInfo", "GetCurrencyInfo")
    if ci then for _, id in ipairs(ids) do local ok, t = pcall(ci, id); if ok and type(t) == "table" and t.name and t.name ~= "" then return t.quantity or 0 end end end
    -- Suche in der Währungsliste nach dem Namen
    local n = api("C_CurrencyInfo", "GetCurrencyListSize"); local li = api("C_CurrencyInfo", "GetCurrencyListInfo")
    if n and li then
        local ok, anz = pcall(n)
        for i = 1, (ok and anz or 0) do
            local ok2, t = pcall(li, i)
            if ok2 and type(t) == "table" and t.name and not t.isHeader then
                for _, nm in ipairs(namen) do if t.name == nm then return t.quantity or 0 end end
            end
        end
    end
end
local function ehre()
    if GetHonorCurrency then local ok, v = pcall(GetHonorCurrency); if ok and type(v) == "number" then return v end end
    local retail = WOW_PROJECT_ID and WOW_PROJECT_MAINLINE and WOW_PROJECT_ID == WOW_PROJECT_MAINLINE
    return waehrung(retail and { 1792 } or { 1901 }, { "Ehrenpunkte", "Ehre", "Honor Points", "Honor" })
end
local function arena()
    if GetArenaCurrency then local ok, v = pcall(GetArenaCurrency); if ok and type(v) == "number" then return v end end
    if WOW_PROJECT_ID and WOW_PROJECT_MAINLINE and WOW_PROJECT_ID == WOW_PROJECT_MAINLINE then return end
    return waehrung({ 1900 }, { "Arenapunkte", "Arena Points" })
end
local function pvpIcon() return (UnitFactionGroup and UnitFactionGroup("player") == "Alliance") and "Interface\\TargetingFrame\\UI-PVP-Alliance" or "Interface\\TargetingFrame\\UI-PVP-Horde" end
block("ehre", pvpIcon(), function(tt)
    tipKopf(tt, L"Ehre")
    local e = ehre(); zeile(tt, L"Ehrenpunkte", e and punkte(e) or "–")
    local a = arena(); if a then zeile(tt, L"Arenapunkte", punkte(a)) end
    if GetPVPSessionStats then local ok, hk = pcall(GetPVPSessionStats); if ok and hk then zeile(tt, L"Ehrenhafte Siege heute", punkte(hk)) end end
    if GetPVPLifetimeStats then local ok, hk = pcall(GetPVPLifetimeStats); if ok and hk then zeile(tt, L"Ehrenhafte Siege gesamt", punkte(hk)) end end
end, nil, { 0, .62, 0, .62 })

-- Erfahrung
local XP = { sitzungStart = GetTime(), sitzungEP = 0, letzteEP = nil, letzteMax = nil, kill = nil, quest = nil,
    gesamt = nil, stufe = nil, basis = nil }
NS.XP = XP
local function maxStufe()
    if IsXPUserDisabled and IsXPUserDisabled() then return true end
    local m = (GetMaxPlayerLevel and GetMaxPlayerLevel()) or rawget(_G, "MAX_PLAYER_LEVEL")
    return type(m) == "number" and UnitLevel("player") >= m
end
local function gespielt()   -- Gesamt, diese Stufe (Sekunden, laufend)
    if not XP.basis then return nil, nil end
    local d = GetTime() - XP.basis
    return XP.gesamt + d, XP.stufe + d
end
NS.gespielt = gespielt
local function erfahrungText()
    -- Ist der eigene Stufen-Reiter an, steht hier nur noch der Fortschritt
    local st = NS.DB().zeigen.stufe and "" or (Y .. L"Stufe " .. UnitLevel("player") .. "|r ")
    if maxStufe() then return st .. W .. L"(max)|r" end
    local cur, max = UnitXP("player"), UnitXPMax("player")
    local rest = GetXPExhaustion and GetXPExhaustion() or nil
    return st .. W .. prozent(cur, max) .. "|r" .. (rest and rest > 0 and (" " .. LILA .. "+" .. prozent(rest, max) .. " erholt|r") or "")
end
block("stufe", "Interface\\Icons\\Spell_ChargePositive", function(tt)
    tipKopf(tt, L"Stufe")
    zeile(tt, L"Aktuelle Stufe", tostring(UnitLevel("player")))
    local m = (GetMaxPlayerLevel and GetMaxPlayerLevel()) or rawget(_G, "MAX_PLAYER_LEVEL")
    if type(m) == "number" then zeile(tt, L"Höchststufe", tostring(m)) end
    if maxStufe() then tt:AddLine(" "); tt:AddLine(L"Du hast die höchste Stufe erreicht.", .6, 1, .6); return end
    local cur, max = UnitXP("player"), UnitXPMax("player")
    if type(cur) == "number" and type(max) == "number" and max > 0 then zeile(tt, L"Noch bis zur nächsten Stufe", punkte(max - cur) .. " EP") end
    local _, stufe = gespielt(); if stufe then zeile(tt, L"Spielzeit diese Stufe", zeit(stufe)) end
end)
local function proStunde(ep, sek) if not sek or sek < 60 then return 0 end return ep / sek * 3600 end
block("erfahrung", "Interface\\Icons\\Spell_Holy_HolyBolt", function(tt)
    tipKopf(tt, L"Erfahrung")
    local gesamt, stufe = gespielt()
    local sitzung = GetTime() - XP.sitzungStart
    zeile(tt, L"Spielzeit gesamt", gesamt and zeit(gesamt) or L"wird abgefragt …")
    zeile(tt, L"Spielzeit diese Stufe", stufe and zeit(stufe) or L"wird abgefragt …")
    zeile(tt, L"Spielzeit diese Sitzung", zeit(sitzung))
    if maxStufe() then tt:AddLine(" "); tt:AddLine(L"Du hast die höchste Stufe erreicht.", .6, 1, .6); return end
    local cur, max = UnitXP("player"), UnitXPMax("player")
    local rest = (GetXPExhaustion and GetXPExhaustion()) or 0
    local fehlt = max - cur
    tt:AddLine(" ")
    zeile(tt, L"EP für diese Stufe", punkte(max))
    zeile(tt, L"Erholt", punkte(rest) .. (rest > 0 and (" (" .. prozent(rest, max) .. ")") or ""), .7, .45, 1)
    zeile(tt, L"EP diese Stufe", punkte(cur) .. " (" .. prozent(cur, max) .. ")")
    zeile(tt, L"EP bis zur nächsten Stufe", punkte(fehlt) .. " (" .. prozent(fehlt, max) .. ")")
    zeile(tt, L"EP diese Sitzung", punkte(XP.sitzungEP))
    zeile(tt, L"Kills bis zur Stufe", XP.kill and (punkte(math.ceil(fehlt / XP.kill)) .. L"  |cff999999(letzter Kill " .. punkte(XP.kill) .. " EP)|r") or "unbekannt")
    zeile(tt, L"Quests bis zur Stufe", XP.quest and (punkte(math.ceil(fehlt / XP.quest)) .. L"  |cff999999(letzte Quest " .. punkte(XP.quest) .. " EP)|r") or "unbekannt")
    tt:AddLine(" ")
    local rStufe = stufe and proStunde(cur, stufe) or 0
    local rSitz = proStunde(XP.sitzungEP, sitzung)
    zeile(tt, L"EP pro Stunde (diese Stufe)", stufe and punkte(rStufe) or "–")
    zeile(tt, L"EP pro Stunde (diese Sitzung)", punkte(rSitz))
    zeile(tt, L"Zeit bis zur Stufe (Stufentempo)", rStufe > 0 and zeit(fehlt / rStufe * 3600) or "unbekannt", .3, 1, .3)
    zeile(tt, L"Zeit bis zur Stufe (Sitzungstempo)", rSitz > 0 and zeit(fehlt / rSitz * 3600) or "unbekannt", .3, 1, .3)
    -- aktive XP-Boni (Schlafsack, Essen, Zelt) gleich hier mit anzeigen
    if NS.Boni then
        local liste = NS.Boni()
        tt:AddLine(" ")
        tt:AddLine(L"Erfahrungs-Boni", 1, .82, 0)
        if #liste == 0 then tt:AddLine(L"Gerade kein Bonus aktiv (Schlafsack, Essen, Zelt).", .7, .7, .7) end
        local summe = 0
        for _, b in ipairs(liste) do
            summe = summe + (b.pct or 0)
            local r = b.rest and NS.mmss(b.rest) or "–"
            tt:AddDoubleLine(b.name .. "  |cff999999(" .. b.art .. ")|r", (b.pct and ("|cff33ff33+" .. b.pct .. " %|r  ") or "") .. ((b.rest and b.rest <= 60) and ("|cffff8030" .. r .. "|r") or r), 1, 1, 1, 1, 1, 1)
            if b.effekte then for _, e in ipairs(b.effekte) do tt:AddLine("   |cffff9933•|r " .. e, .9, .9, .9, true) end end
        end
        if summe > 0 then zeile(tt, L"Bonus gesamt", "|cff33ff33+" .. summe .. " %|r") end
    end
end)


-- XP-Boni (WoW Forever): Schlafsack, Satt (Kochen), Lagerzelt – mit Restzeit, Warnung in der letzten Minute
local function auren()
    local t, get = {}, api("C_UnitAuras", "GetAuraDataByIndex")
    for i = 1, 40 do
        local name, icon, anz, dauer, ablauf, id, inst
        if get then
            local ok, a = pcall(get, "player", i, "HELPFUL"); if not ok or type(a) ~= "table" then break end
            name, icon, anz, dauer, ablauf, id, inst = a.name, a.icon, a.applications, a.duration, a.expirationTime, a.spellId, a.auraInstanceID
        elseif UnitAura then
            local n, ic, c, _, d, x, _, _, _, sid = UnitAura("player", i, "HELPFUL"); if not n then break end
            name, icon, anz, dauer, ablauf, id = n, ic, c, d, x, sid
        else break end
        -- im Kampf liefert Forever die Buffs als geheime Werte: dann gelten die Daten als unlesbar
        if issecretvalue and (issecretvalue(name) or issecretvalue(id) or issecretvalue(ablauf) or issecretvalue(anz)) then t.unlesbar = true
        else
            if issecretvalue and issecretvalue(inst) then inst = nil end
            t[#t + 1] = { name = name, icon = icon, anz = anz or 0, dauer = dauer or 0, ablauf = ablauf or 0, id = id, inst = inst, idx = i }
        end
    end
    return t
end
NS.auren = auren
function NS.rest(a) if not a or (a.ablauf or 0) <= 0 then return nil end return math.max(0, a.ablauf - GetTime()) end
local SATT = { ["Satt"] = true, ["Well Fed"] = true, ["Сытость"] = true, ["Bien nourri"] = true, ["Bien alimentado"] = true, ["Bien alimentada"] = true }
function NS.istSatt(a) return a and (SATT[a.name or ""] or a.icon == 136000 or (type(a.icon) == "string" and a.icon:lower():find("spell_misc_food", 1, true))) and true or false end
local SCHLAFSACK, ZELT = 429959, 1307230
-- Nur echtes Retail (ab 10.0) hat keine dieser Boni. Forever läuft auf dem neuen Client und meldet sich dort ebenfalls
-- als „Mainline“ – darum nach der Spielversion unterscheiden (Forever: 1.60 = 16xxx).
local function retail() local b = select(4, GetBuildInfo()); return type(b) == "number" and b >= 100000 end
-- Namen als Rückfall, falls Blizzard die Zauber-IDs in Forever anders vergibt
local function hat(name, ...) if type(name) ~= "string" then return false end local n = name:lower(); for _, w in ipairs({ ... }) do if n:find(w, 1, true) then return true end end return false end
-- Feste Laufzeiten (Forever meldet sie nicht zuverlässig): Schlafsack 2 Std, Dämonenrüstung/-haut 30 Min.
-- Beginn wird beim ersten Sehen gemerkt (übersteht /reload); neu gezählt, wenn der Buff neu kommt oder sich die Stapel ändern.
local FEST = { schlafsack = 2 * 3600, ruestung = 30 * 60, satt = 15 * 60, seelenstein = 30 * 60 }
local SEELENSTEIN = { [20707] = true, [20762] = true, [20763] = true, [20764] = true, [20765] = true }
local RUESTUNG = { [687] = true, [696] = true, [706] = true, [1086] = true, [11733] = true, [11734] = true, [11735] = true }
local function festRest(key, a)
    local db = NS.DB(); db.bonusStart = type(db.bonusStart) == "table" and db.bonusStart or {}
    local st = db.bonusStart[key]
    local stapel = a.anz or 0
    local abl = (type(a.ablauf) == "number" and not (issecretvalue and issecretvalue(a.ablauf))) and a.ablauf or 0
    -- neu gezaubert? (Stapel geändert, neuer Buff, oder Blizzards Ablaufzeit springt nach oben)
    if not st or st.stapel ~= stapel or (a.inst and st.inst and a.inst ~= st.inst) or (abl > 0 and st.abl and abl > st.abl + 5) then
        st = { t = time(), stapel = stapel }; db.bonusStart[key] = st
    end
    st.abl = abl > 0 and abl or st.abl
    st.inst = a.inst or st.inst
    return math.max(0, (FEST[key] or FEST[key:match("^(%a+)")] or 0) - (time() - st.t))
end
-- Aufgefrischt? Blizzard meldet beim Erneuern eines laufenden Buffs „aktualisiert“ für genau diesen Buff –
-- dann beginnt die feste Laufzeit (z. B. 2 Std. Schlafsack) neu. Zusätzlich: eigener Zauber (Rüstung, Schlafsack) gewirkt.
-- Lager-Boni (Forever): „Camp Benefits“ fasst alle Lager-Gegenstände zusammen; welche Effekte drin stecken,
-- steht nur im Tooltip des Buffs – den lesen wir aus.
local LAGER = { [1229741] = true }
local function lagerEffekte(a)
    local zeilen = {}
    local d
    if C_TooltipInfo then
        if a.inst and C_TooltipInfo.GetUnitBuffByAuraInstanceID then local ok, x = pcall(C_TooltipInfo.GetUnitBuffByAuraInstanceID, "player", a.inst); if ok then d = x end end
        if not d and a.idx and C_TooltipInfo.GetUnitAura then local ok, x = pcall(C_TooltipInfo.GetUnitAura, "player", a.idx, "HELPFUL"); if ok then d = x end end
    end
    if type(d) == "table" and type(d.lines) == "table" then
        for i = 2, #d.lines do
            local t = d.lines[i] and d.lines[i].leftText
            if type(t) == "string" and not (issecretvalue and issecretvalue(t)) and t ~= "" then
                local l = t:lower()
                if not (l:find("verbleib") or l:find("remaining") or l:find("осталось") or l:find("restant") or l:find("restante")) then
                    for teil in t:gmatch("[^\n]+") do zeilen[#zeilen + 1] = teil end
                end
            end
        end
    end
    return zeilen
end
function NS.BonusAufgefrischt(info)
    local db = NS.DB(); if type(db.bonusStart) ~= "table" or type(info) ~= "table" then return end
    local ids = info.updatedAuraInstanceIDs
    if type(ids) ~= "table" then return end
    for _, id in ipairs(ids) do
        if not (issecretvalue and issecretvalue(id)) then
            for _, st in pairs(db.bonusStart) do if st.inst == id then st.t = time() end end
        end
    end
end
function NS.BonusNeuGezaubert(spellID)
    local db = NS.DB(); if type(db.bonusStart) ~= "table" then return end
    local n = C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(spellID)
    local istSack = spellID == SCHLAFSACK or (type(n) == "string" and not (issecretvalue and issecretvalue(n)) and hat(n, "schlafsack", "sleeping bag", "спальн", "sac de couchage", "saco de dormir"))
    if istSack and db.bonusStart.schlafsack then db.bonusStart.schlafsack.t = time() end
    if RUESTUNG and RUESTUNG[spellID] then if db.bonusStart.ruestung then db.bonusStart.ruestung.t = time() end end
end
local function festAufraeumen(aktiv)
    local db = NS.DB(); if type(db.bonusStart) ~= "table" then return end
    for k in pairs(db.bonusStart) do if not aktiv[k] then db.bonusStart[k] = nil end end
end
-- Seelenstein, den DU auf jemand anderen in deiner Gruppe gelegt hast
local zuletztTot = {}   -- [Name] = Zeit, zu der er zuletzt tot war
local function gruppenEinheiten()
    local t = {}
    if IsInRaid and IsInRaid() then for i = 1, 40 do t[#t + 1] = "raid" .. i end
    elseif IsInGroup and IsInGroup() then for i = 1, 4 do t[#t + 1] = "party" .. i end end
    return t
end
local function vonMir(src)
    if src == nil then return true end                      -- Quelle unbekannt: als eigenen zählen
    if issecretvalue and issecretvalue(src) then return true end
    if src == "player" then return true end
    local ok, gleich = pcall(UnitIsUnit, src, "player"); return ok and gleich == true
end
local function fremdeSteine(liste, aktiv)
    local get = api("C_UnitAuras", "GetAuraDataByIndex")
    for _, u in ipairs(gruppenEinheiten()) do
        local okN, name = pcall(UnitName, u)
        if okN and type(name) == "string" and not (issecretvalue and issecretvalue(name)) and not UnitIsUnit(u, "player") then
            local okT, tot = pcall(UnitIsDeadOrGhost, u)
            if okT and tot == true then zuletztTot[name] = GetTime() end
            for i = 1, 40 do
                local a
                if get then local ok, d = pcall(get, u, i, "HELPFUL"); if not ok or type(d) ~= "table" then break end; a = d
                elseif UnitAura then
                    local n, ic, c, _, d, x, src, _, _, sid = UnitAura(u, i, "HELPFUL"); if not n then break end
                    a = { name = n, icon = ic, applications = c, duration = d, expirationTime = x, sourceUnit = src, spellId = sid }
                else break end
                local id, an = a.spellId, a.name
                if issecretvalue and (issecretvalue(id) or issecretvalue(an)) then id, an = nil, nil end
                if (SEELENSTEIN[id] or hat(an, "seelenstein", "soulstone", "камень души", "pierre d'âme", "piedra de alma")) and vonMir(a.sourceUnit) then
                    local key = "seelenstein:" .. name
                    aktiv[key] = true
                    local x = { anz = 0, ablauf = a.expirationTime }
                    liste[#liste + 1] = { key = key, stein = name, name = (L"Seelenstein auf %s"):format(name), art = L"dein Seelenstein · 30 Min.",
                        rest = festRest(key, x), dauer = FEST.seelenstein, icon = a.icon, keinXP = true }
                    break
                end
            end
        end
    end
end
NS.ZuletztTot = zuletztTot
local boniLesen
-- Im Kampf (oder wenn die Buffs gerade nicht lesbar sind) die letzte bekannte Liste weiter herunterzählen,
-- statt sie verschwinden zu lassen – sonst gehen Anzeige und Timer im Kampf aus.
local letzteBoni, letzteZeit = nil, 0
function NS.Boni()
    local kampf = InCombatLockdown and InCombatLockdown()
    if kampf and letzteBoni then
        local vorbei = GetTime() - letzteZeit
        local t = {}
        for _, b in ipairs(letzteBoni) do
            local c = {}; for k, v in pairs(b) do c[k] = v end
            if c.rest then c.rest = math.max(0, c.rest - vorbei) end
            t[#t + 1] = c
        end
        return t
    end
    local liste, unlesbar = boniLesen()
    if unlesbar and letzteBoni then
        local vorbei = GetTime() - letzteZeit
        local t = {}
        for _, b in ipairs(letzteBoni) do local c = {}; for k, v in pairs(b) do c[k] = v end; if c.rest then c.rest = math.max(0, c.rest - vorbei) end; t[#t + 1] = c end
        return t
    end
    letzteBoni, letzteZeit = liste, GetTime()
    return liste
end
boniLesen = function()
    local liste = {}
    local aktiv = {}
    if retail() then return liste end
    local klasse; if UnitClass then klasse = select(2, UnitClass("player")) end
    local alle = auren()
    if alle.unlesbar then return liste, true end
    for _, a in ipairs(alle) do
        if klasse == "WARLOCK" and (RUESTUNG[a.id] or hat(a.name, "dämonenrüstung", "dämonenhaut", "demon armor", "demon skin", "демоническ", "armure démoniaque", "peau de démon", "armadura demoníaca", "piel demoníaca")) then
            aktiv.ruestung = true
            liste[#liste + 1] = { key = "ruestung", name = a.name or L"Dämonenrüstung", art = L"30 Min.", rest = festRest("ruestung", a), dauer = FEST.ruestung, icon = a.icon, keinXP = true }
        elseif LAGER[a.id] or hat(a.name, "camp benefits", "lagervorteile", "vorteile des lagers", "lagerboni", "преимущества лагеря", "avantages du camp", "beneficios del campamento") then
            aktiv.lager = true
            liste[#liste + 1] = { key = "lager", name = a.name or L"Lager-Boni", art = L"Lagerfeuer", rest = NS.rest(a), dauer = a.dauer, icon = a.icon,
                keinXP = true, imBalken = true, effekte = lagerEffekte(a) }
        elseif SEELENSTEIN[a.id] or hat(a.name, "seelenstein", "soulstone", "камень души", "pierre d'âme", "piedra de alma") then
            aktiv.seelenstein = true
            liste[#liste + 1] = { key = "seelenstein", name = L"Seelenstein", art = L"Wiederbelebung bereit · 30 Min.", rest = festRest("seelenstein", a), dauer = FEST.seelenstein, icon = a.icon, keinXP = true }
        elseif
a.id == SCHLAFSACK or hat(a.name, "schlafsack", "sleeping bag", "спальн", "sac de couchage", "saco de dormir") then
            local n = math.max(1, a.anz or 1)
            aktiv.schlafsack = true
            liste[#liste + 1] = { key = "schlafsack", name = L"Gemütlicher Schlafsack", pct = n, art = L"auf alle EP", rest = festRest("schlafsack", a), dauer = FEST.schlafsack, icon = a.icon }
        elseif a.id == ZELT or hat(a.name, "zelt", "tent", "палатк", "tente", "tienda") then
            liste[#liste + 1] = { key = "zelt", name = L"Lagerzelt", art = L"Erholung – doppelte Kill-EP", rest = NS.rest(a), dauer = a.dauer, icon = a.icon }
        elseif NS.istSatt(a) then
            aktiv.satt = true
            liste[#liste + 1] = { key = "satt", name = L"Satt (Essen)", pct = 5, art = L"auf Kill-EP", rest = NS.rest(a) or festRest("satt", a), dauer = (a.dauer and a.dauer > 0) and a.dauer or FEST.satt, icon = a.icon }
        end
    end
    if klasse == "WARLOCK" then pcall(fremdeSteine, liste, aktiv) end
    festAufraeumen(aktiv)
    return liste
end
local function mmss(s)
    s = math.floor(s or 0)
    if s >= 3600 then return ("%d:%02d:%02d"):format(math.floor(s / 3600), math.floor(s / 60) % 60, s % 60) end
    return ("%d:%02d"):format(math.floor(s / 60), s % 60)
end
NS.mmss = mmss
local bonusWarnung = false
-- Jeder XP-Bonus einzeln: Symbol, Prozent und eigener Timer. Läuft einer in der letzten Minute ab, blinkt seine Zeit rot.
local REIHE_BONUS = { schlafsack = 1, satt = 2, zelt = 3, lager = 4 }
local function bonusText()
    local liste = {}
    for _, b in ipairs(NS.Boni()) do if not b.keinXP or b.imBalken then liste[#liste + 1] = b end end
    if #liste == 0 then return nil end
    if maxStufe() then local t = {}; for _, b in ipairs(liste) do if b.imBalken then t[#t + 1] = b end end; liste = t; if #liste == 0 then return nil end end
    table.sort(liste, function(a, b) return (REIHE_BONUS[a.key] or 9) < (REIHE_BONUS[b.key] or 9) end)
    local an = math.floor(GetTime()) % 2 == 0   -- Blinken: jede Sekunde an/aus
    local teile = {}
    bonusWarnung = false
    for _, b in ipairs(liste) do
        local ic = (type(b.icon) == "number" or type(b.icon) == "string") and ("|T" .. b.icon .. ":14:14:0:0:64:64:5:59:5:59|t ") or ""
        local wert = b.pct and b.pct > 0 and (G .. "+" .. b.pct .. " %|r") or (b.key == "lager" and ("|cffff9933" .. L"Lager" .. "|r") or (LILA .. L"Zelt|r"))
        local z = ""
        if b.rest then
            local knapp = b.rest <= 60
            if knapp then bonusWarnung = true end
            z = " " .. (knapp and (an and "|cffff2020" or "|cff661010") or W) .. mmss(b.rest) .. "|r"
        end
        teile[#teile + 1] = ic .. wert .. z
    end
    return table.concat(teile, "|cff666666   ·   |r")
end
local bb = block("bonus", nil, function(tt)
    tipKopf(tt, L"Erfahrungs-Boni")
    local liste = NS.Boni()
    if #liste == 0 then tt:AddLine(L"Gerade kein Bonus aktiv.", .7, .7, .7) end
    for _, b in ipairs(liste) do
        local r = b.rest and mmss(b.rest) or "–"
        tt:AddDoubleLine(b.name .. "  |cff999999(" .. b.art .. ")|r", (b.pct and ("|cff33ff33+" .. b.pct .. " %|r  ") or "") .. ((b.rest and b.rest <= 60) and ("|cffff8030" .. r .. "|r") or r), 1, .82, 0, 1, 1, 1)
            if b.effekte then for _, e in ipairs(b.effekte) do tt:AddLine("   |cffff9933•|r " .. e, .9, .9, .9, true) end end
    end
    tt:AddLine(" ")
    tt:AddLine(L"Schlafsack: +1 % je Stapel (bis +3 %), 2 Stunden. Essen: +5 % auf Kill-EP. Zelt: Erholung für eine Stunde. Hexenmeister: Dämonenrüstung 30 Min., Seelenstein 30 Min. (auch auf anderen in deiner Gruppe). Essen-Buff 15 Min.", .6, .6, .6, true)
end)
bb.ic:SetSize(1, 15); bb.ic:SetAlpha(0)   -- Symbole stehen jetzt pro Bonus im Text
bb.glow = bb:CreateTexture(nil, "BACKGROUND"); bb.glow:SetPoint("TOPLEFT", -4, 2); bb.glow:SetPoint("BOTTOMRIGHT", 4, -2)
bb.glow:SetColorTexture(1, .42, .16, .35); bb.glow:Hide()
local gesehen, gewarnt = {}, {}
function NS.BonusPruefen()
    local db = NS.DB(); local jetzt = {}
    for _, b in ipairs(NS.Boni()) do
        jetzt[b.key] = b
        if b.rest and b.rest <= 60 and b.rest > 0 and not gewarnt[b.key] then
            gewarnt[b.key] = true
            if db.bonusWarnen then NS.msg((L"%s läuft in 1 Minute ab."):format(b.name)) end
            if db.bonusTon and PlaySound and SOUNDKIT then pcall(PlaySound, SOUNDKIT.RAID_WARNING or 8959) end
        elseif b.rest and b.rest > 60 then gewarnt[b.key] = nil end
    end
    for k, b in pairs(gesehen) do
        if not jetzt[k] and b.stein then
            -- Seelenstein auf einem anderen ist weg: benutzt, abgelaufen oder nicht mehr in der Gruppe?
            gewarnt[k] = nil
            local tot = zuletztTot[b.stein]
            if tot and GetTime() - tot < 60 then
                NS.msg((L"|cff33ff33%s hat deinen Seelenstein benutzt!|r Du kannst einen neuen machen."):format(b.stein))
                if db.bonusTon and PlaySound and SOUNDKIT then pcall(PlaySound, SOUNDKIT.READY_CHECK or 8960) end
            elseif (b.rest or 0) <= 5 then
                if db.bonusWarnen then NS.msg((L"Dein Seelenstein auf %s ist abgelaufen."):format(b.stein)) end
            elseif db.bonusWarnen then
                NS.msg((L"Dein Seelenstein auf %s ist nicht mehr zu sehen (Gruppe verlassen oder zu weit weg)."):format(b.stein))
            end
        elseif not jetzt[k] then
            gewarnt[k] = nil
            if db.bonusWarnen and (b.keinXP or k == "satt" or not maxStufe()) then NS.msg((L"%s abgelaufen."):format(b.name) .. (k == "schlafsack" and L" Hinlegen lohnt sich wieder." or "")) end
        end
    end
    gesehen = jetzt
end

-- Seelensplitter in den Taschen (nur Hexenmeister): Symbol + Zahl
local SPLITTER = 6265
local function splitterZahl()
    local f = (C_Item and C_Item.GetItemCount) or rawget(_G, "GetItemCount")
    local ok, n = pcall(f, SPLITTER); return (ok and type(n) == "number") and n or 0
end
local spIcon = (C_Item and C_Item.GetItemIconByID and select(2, pcall(C_Item.GetItemIconByID, SPLITTER))) or 134075
block("splitter", type(spIcon) == "number" and spIcon or 134075, function(tt)
    tipKopf(tt, L"Seelensplitter")
    zeile(tt, L"In den Taschen", tostring(splitterZahl()))
    tt:AddLine(L"Für Dämonen beschwören, Seelenstein, Gesundheitsstein und mehr.", .7, .7, .7, true)
end)

-- Seelenstein (nur Hexenmeister): Symbol (anklickbar) + auf wem + Timer
-- Linksklick = Seelenstein aus der Tasche auf dein Ziel legen (ohne Ziel: auf dich) · Rechtsklick = neuen Seelenstein herstellen
local STEIN_ITEMS = { 16896, 16895, 16893, 16892, 5232 }        -- erheblicher … schwacher Seelenstein
local STEIN_ZAUBER = { 20757, 20756, 20755, 20752, 693 }        -- Seelenstein herstellen (hoch → niedrig)
local STEIN_WIRKEN = { [20707] = true, [20762] = true, [20763] = true, [20764] = true, [20765] = true, [20770] = true }
local STEIN_DAUER = 30 * 60
local function steinImBeutel()
    local f = (C_Item and C_Item.GetItemCount) or rawget(_G, "GetItemCount")
    for _, id in ipairs(STEIN_ITEMS) do local ok, n = pcall(f, id); if ok and type(n) == "number" and n > 0 then return id end end
end
local function steinHerstellen()
    for _, id in ipairs(STEIN_ZAUBER) do
        local ok, bek = pcall(IsSpellKnown, id)
        if ok and bek then
            local n = (C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(id)) or (GetSpellInfo and GetSpellInfo(id))
            if type(n) == "string" then return n end
        end
    end
end
local steinIcon = (C_Item and C_Item.GetItemIconByID and select(2, pcall(C_Item.GetItemIconByID, 16893))) or 136210
block("stein", type(steinIcon) == "number" and steinIcon or 136210, function(tt)
    tipKopf(tt, L"Seelenstein")
    local s = NS.DB().stein
    if s and s.start and time() - s.start < STEIN_DAUER then
        zeile(tt, L"Liegt auf", s.wer or "?"); zeile(tt, L"Noch", zeit(STEIN_DAUER - (time() - s.start)))
    else tt:AddLine(L"Liegt gerade auf niemandem.", .7, .7, .7) end
    tt:AddLine(" ")
    tt:AddLine(steinImBeutel() and L"Klick aufs Symbol: Seelenstein auf dein Ziel legen (ohne Ziel: auf dich)" or L"Kein Seelenstein in der Tasche.", 1, 1, 1, true)
    tt:AddLine(L"Rechtsklick aufs Symbol: neuen Seelenstein herstellen", .7, .7, .7, true)
end)
-- Der eigentliche Klick-Knopf muss ein „sicherer“ Knopf sein (Gegenstand benutzen). Er hängt NICHT an der Leiste,
-- sonst dürfte die Leiste im Kampf nicht mehr umgestellt werden – er wird außerhalb des Kampfes über das Symbol gelegt.
local SK = CreateFrame("Button", "siikkInfoSteinKnopf", UIParent, "SecureActionButtonTemplate")
SK:SetSize(18, 18); SK:SetFrameStrata("MEDIUM"); SK:RegisterForClicks("AnyUp", "AnyDown"); SK:Hide()
SK:SetAttribute("type1", "item"); SK:SetAttribute("type2", "spell")
SK:SetScript("OnEnter", function(s) local b = B.stein; if b then local f = b:GetScript("OnEnter"); if f then f(b) end end end)
SK:SetScript("OnLeave", function() GameTooltip:Hide() end)
local function steinAttribute()
    if InCombatLockdown() then return end
    local id = steinImBeutel(); SK:SetAttribute("item1", id and ("item:" .. id) or nil)
    SK:SetAttribute("spell2", steinHerstellen())
end
-- Gesundheitsstein: Anzahl in der Tasche · Linksklick = benutzen · Rechtsklick = herstellen
local GS_ITEMS = { 19013, 19012, 9421, 19011, 19010, 5510, 19009, 19008, 5509, 19007, 19006, 5511, 19005, 19004, 5512 }
local GS_ZAUBER = { 11730, 11729, 5699, 6202, 6201 }
local function gsImBeutel()
    local f = (C_Item and C_Item.GetItemCount) or rawget(_G, "GetItemCount")
    local id0, n0 = nil, 0
    for _, id in ipairs(GS_ITEMS) do local ok, n = pcall(f, id); if ok and type(n) == "number" and n > 0 then id0 = id0 or id; n0 = n0 + n end end
    return id0, n0
end
local function gsHerstellen()
    for _, id in ipairs(GS_ZAUBER) do
        local ok, bek = pcall(IsSpellKnown, id)
        if ok and bek then
            local n = (C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(id)) or (GetSpellInfo and GetSpellInfo(id))
            if type(n) == "string" then return n end
        end
    end
end
local gsIcon = (C_Item and C_Item.GetItemIconByID and select(2, pcall(C_Item.GetItemIconByID, 5509))) or 135230
block("gstein", type(gsIcon) == "number" and gsIcon or 135230, function(tt)
    tipKopf(tt, L"Gesundheitsstein")
    local _, n = gsImBeutel(); zeile(tt, L"In den Taschen", tostring(n))
    tt:AddLine(" ")
    tt:AddLine(n > 0 and L"Klick aufs Symbol: Gesundheitsstein benutzen" or L"Kein Gesundheitsstein in der Tasche.", 1, 1, 1, true)
    tt:AddLine(L"Rechtsklick aufs Symbol: neuen Gesundheitsstein herstellen", .7, .7, .7, true)
end)
local GK = CreateFrame("Button", "siikkInfoGesundheitKnopf", UIParent, "SecureActionButtonTemplate")
GK:SetSize(18, 18); GK:SetFrameStrata("MEDIUM"); GK:RegisterForClicks("AnyUp", "AnyDown"); GK:Hide()
GK:SetAttribute("type1", "item"); GK:SetAttribute("type2", "spell")
GK:SetScript("OnEnter", function() local b = B.gstein; if b then local f = b:GetScript("OnEnter"); if f then f(b) end end end)
GK:SetScript("OnLeave", function() GameTooltip:Hide() end)
local altAttribute = steinAttribute
steinAttribute = function()
    altAttribute()
    if InCombatLockdown() then return end
    local id = gsImBeutel(); GK:SetAttribute("item1", id and ("item:" .. id) or nil)
    GK:SetAttribute("spell2", gsHerstellen())
end
local function ueberlegen(knopf, b)
    if not (b and b:IsVisible() and b.ic) then knopf:Hide() return end
    local x, y = b.ic:GetCenter(); if not x then knopf:Hide() return end
    local sk = b.ic:GetEffectiveScale() / UIParent:GetEffectiveScale()
    knopf:ClearAllPoints(); knopf:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x * sk, y * sk)
    knopf:SetSize(18 * sk, 18 * sk); knopf:Show()
end
function NS.SteinKnopfSetzen()
    if InCombatLockdown() then return end
    ueberlegen(SK, B.stein); ueberlegen(GK, B.gstein)
end
-- merken, auf wen du ihn legst
local steinZiel
local stEv = CreateFrame("Frame")
pcall(stEv.RegisterUnitEvent, stEv, "UNIT_SPELLCAST_SENT", "player"); pcall(stEv.RegisterUnitEvent, stEv, "UNIT_SPELLCAST_SUCCEEDED", "player")
stEv:RegisterEvent("PLAYER_REGEN_ENABLED"); stEv:RegisterEvent("BAG_UPDATE_DELAYED"); stEv:RegisterEvent("SPELLS_CHANGED")
local function geheim(v) return issecretvalue and issecretvalue(v) end
stEv:SetScript("OnEvent", function(_, e, a1, a2, a3, a4)
    if e == "UNIT_SPELLCAST_SENT" then
        if type(a4) == "number" and not geheim(a4) and STEIN_WIRKEN[a4] then
            steinZiel = (type(a2) == "string" and not geheim(a2) and a2 ~= "") and a2 or nil
            if not steinZiel then local ok, n = pcall(UnitName, "target"); steinZiel = (ok and type(n) == "string" and not geheim(n)) and n or nil end
        end
    elseif e == "UNIT_SPELLCAST_SUCCEEDED" then
        if type(a3) == "number" and not geheim(a3) then pcall(NS.BonusNeuGezaubert, a3) end
        if type(a3) == "number" and not geheim(a3) and STEIN_WIRKEN[a3] then
            local ich = UnitName("player")
            NS.DB().stein = { wer = (steinZiel and steinZiel ~= ich) and steinZiel or L"Du", start = time() }
            steinZiel = nil; NS.Aktualisieren("stein")
        end
    else
        steinAttribute(); NS.SteinKnopfSetzen()
    end
end)
NS.SteinAttribute = steinAttribute

-- XP-Balken an der Unterkante der Leiste (genauso breit wie die Leiste)
local XB = CreateFrame("StatusBar", "siikkInfoXPBalken", Leiste, "BackdropTemplate")
XB:SetPoint("TOPLEFT", Leiste, "BOTTOMLEFT", 0, 0); XB:SetPoint("TOPRIGHT", Leiste, "BOTTOMRIGHT", 0, 0); XB:SetHeight(8)
XB:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8"); XB:SetStatusBarColor(.30, .08, .42, .55)
XB:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
XB:SetBackdropColor(.04, .02, .07, .35); XB:SetBackdropBorderColor(.85, .65, .15, .25)
XB.erholt = XB:CreateTexture(nil, "ARTWORK", nil, -1); XB.erholt:SetColorTexture(.2, .35, .85, .3)
XB.erholt:SetPoint("TOP", 0, -1); XB.erholt:SetPoint("BOTTOM", 0, 1)
XB.t = XB:CreateFontString(nil, "OVERLAY"); XB.t:SetPoint("CENTER", 0, 0); XB.t:SetFont("Fonts\\FRIZQT__.TTF", 8, "OUTLINE"); XB.t:SetAlpha(.9)
XB:EnableMouse(true)
XB:SetScript("OnEnter", function(s) if B.erfahrung then local f = B.erfahrung:GetScript("OnEnter"); if f then f(s) end end end)
XB:SetScript("OnLeave", function() GameTooltip:Hide() end)
XB:Hide()
function NS.XPBalken()
    local db = NS.DB()
    if not db.xpBalken or not db.an or maxStufe() then XB:Hide() return end
    local cur, max = UnitXP("player"), UnitXPMax("player")
    if type(cur) ~= "number" or type(max) ~= "number" or max <= 0 then XB:Hide() return end
    XB:SetMinMaxValues(0, max); XB:SetValue(cur)
    local rest = GetXPExhaustion and GetXPExhaustion() or 0
    local w = XB:GetWidth() or 0
    if rest and rest > 0 and w > 0 then
        local von = cur / max * w; local bis = math.min(w, (cur + rest) / max * w)
        XB.erholt:ClearAllPoints(); XB.erholt:SetPoint("TOPLEFT", XB, "TOPLEFT", von, -1); XB.erholt:SetPoint("BOTTOMLEFT", XB, "BOTTOMLEFT", von, 1)
        XB.erholt:SetWidth(math.max(1, bis - von)); XB.erholt:Show()
    else XB.erholt:Hide() end
    XB.t:SetText(("%s / %s EP  ·  %s  ·  noch %s"):format(punkte(cur), punkte(max), prozent(cur, max), punkte(max - cur))
        .. ((rest and rest > 0) and ("  |cff8fb4ff(+" .. punkte(rest) .. L" erholt)|r") or ""))
    XB:Show()
end
XB:SetScript("OnSizeChanged", function() NS.XPBalken() end)

-- Leistung
local function speicherTop()
    local A = rawget(_G, "C_AddOns") or {}
    local upd = rawget(_G, "UpdateAddOnMemoryUsage"); local mem = rawget(_G, "GetAddOnMemoryUsage")
    local num = A.GetNumAddOns or rawget(_G, "GetNumAddOns"); local info = A.GetAddOnInfo or rawget(_G, "GetAddOnInfo")
    local loaded = A.IsAddOnLoaded or rawget(_G, "IsAddOnLoaded")
    if not (upd and mem and num and info) then return {}, 0 end
    pcall(upd)
    local t, summe = {}, 0
    for i = 1, num() do
        local n, titel = info(i)
        if n and (not loaded or loaded(i)) then local ok, kb = pcall(mem, i); if ok and type(kb) == "number" and kb > 0 then t[#t + 1] = { (titel and titel ~= "" and titel) or n, kb }; summe = summe + kb end end
    end
    table.sort(t, function(a, b) return a[2] > b[2] end)
    return t, summe
end
local function mb(kb) if kb >= 1024 then return (("%.1f"):format(kb / 1024):gsub("%.", ",")) .. " MB" end return math.floor(kb) .. " KB" end
local function msFarbe(ms) if ms > 300 then return R elseif ms > 150 then return "|cffffa040" end return G end
local function leistungTipp(tt)
    tipKopf(tt, L"Leistung")
    local _, _, heim, welt = GetNetStats()
    zeile(tt, L"Bilder pro Sekunde", math.floor(GetFramerate() + .5) .. " fps")
    zeile(tt, L"Latenz (Chat, Handel)", (heim or 0) .. " ms")
    zeile(tt, L"Latenz (Kampf, Welt)", (welt or heim or 0) .. " ms")
    local t, summe = speicherTop()
    if #t > 0 then
        tt:AddLine(" "); zeile(tt, L"Speicher aller Addons", mb(summe))
        for i = 1, math.min(8, #t) do tt:AddDoubleLine("   " .. t[i][1], mb(t[i][2]), .8, .8, .8, 1, 1, 1) end
    end
end
block("fps", "Interface\\Icons\\Spell_Nature_Lightning", leistungTipp)
block("latenz", "Interface\\Icons\\Spell_Holy_BorrowedTime", leistungTipp)

-- Uhr
local TAGE = { L"Sonntag", L"Montag", L"Dienstag", L"Mittwoch", L"Donnerstag", L"Freitag", L"Samstag" }
block("uhr", "Interface\\Icons\\INV_Misc_PocketWatch_01", function(tt)
    tipKopf(tt, L"Uhr")
    local d = date("*t")
    zeile(tt, L"Heute", TAGE[d.wday] .. ", " .. date("%d.%m.%Y"))
    zeile(tt, L"Ortszeit", date("%H:%M:%S"))
    if GetGameTime then local h, m = GetGameTime(); zeile(tt, L"Serverzeit", ("%02d:%02d"):format(h, m)) end
    if ToggleCalendar then tt:AddLine(" "); tt:AddLine(L"Linksklick: Kalender", .6, .6, .6) end
end, function() if ToggleCalendar then pcall(ToggleCalendar) end end)

-- Aktualisieren -----------------------------------------------------------
function NS.Aktualisieren(nur)
    local db = NS.DB()
    if (not nur or nur == "ort") and db.zeigen.ort then B.ort.setze(ortText()) end
    if (not nur or nur == "gold") and db.zeigen.gold then B.gold.setze(W .. geld(GetMoney(), "voll") .. "|r") end
    if (not nur or nur == "haltbarkeit") and db.zeigen.haltbarkeit then
        local m = haltbarkeit(); B.haltbarkeit.setze(m and (pFarbe(m) .. math.floor(m + .5) .. " %|r") or (W .. "–|r"))
    end
    if (not nur or nur == "taschen") and db.zeigen.taschen then
        local f, g = frei(); B.taschen.setze((f <= 3 and R or W) .. f .. "|r|cff999999/" .. g .. "|r")
    end
    if (not nur or nur == "ehre") and db.zeigen.ehre then local e = ehre(); B.ehre.setze(W .. (e and punkte(e) or "–") .. "|r") end
    if (not nur or nur == "erfahrung") and db.zeigen.erfahrung then B.erfahrung.setze(erfahrungText()) end
    if (not nur or nur == "bonus") and db.zeigen.bonus then
        local t = bonusText(); local leer = t == nil
        if leer ~= (B.bonus.leer or false) then B.bonus.leer = leer; anordnen() end
        if t then B.bonus.setze(t) end
        if not bonusWarnung then B.bonus.glow:Hide() end
    end
    if not nur or nur == "erfahrung" or nur == "stufe" then NS.XPBalken() end
    if (not nur or nur == "taschen" or nur == "stein" or nur == "leistung") and B.stein then
        local kl = NS.Klasse()
        if kl ~= "WARLOCK" then B.stein.leer = true; B.stein:Hide(); SK:Hide()
        elseif db.zeigen.stein then
            B.stein.leer = nil
            local s = db.stein
            local rest = s and s.start and (STEIN_DAUER - (time() - s.start))
            if rest and rest > 0 then
                B.stein.setze(LILA .. (s.wer or "?") .. "|r " .. (rest <= 60 and R or W) .. ("%d:%02d"):format(math.floor(rest / 60), math.floor(rest) % 60) .. "|r")
                B.stein.ic:SetDesaturated(false)
            else
                if s then db.stein = nil end
                B.stein.setze(steinImBeutel() and (G .. L"bereit" .. "|r") or ("|cff999999" .. L"kein Stein" .. "|r"))
                B.stein.ic:SetDesaturated(not steinImBeutel())
            end
        else SK:Hide() end
    end
    if (not nur or nur == "taschen" or nur == "gstein") and B.gstein then
        local kl = NS.Klasse()
        if kl ~= "WARLOCK" then B.gstein.leer = true; B.gstein:Hide()
        elseif db.zeigen.gstein then
            B.gstein.leer = nil
            local _, n = gsImBeutel()
            B.gstein.setze((n == 0 and R or W) .. n .. "|r"); B.gstein.ic:SetDesaturated(n == 0)
        end
    end
    if (not nur or nur == "taschen" or nur == "splitter") and B.splitter then
        local kl = NS.Klasse()
        if kl ~= "WARLOCK" then B.splitter.leer = true; B.splitter:Hide()
        elseif db.zeigen.splitter then
            local n = splitterZahl(); B.splitter.leer = nil
            B.splitter.setze((n == 0 and R or W) .. n .. "|r")
        end
    end
    if (not nur or nur == "erfahrung" or nur == "stufe") and db.zeigen.stufe then
        B.stufe.setze(Y .. L"Stufe " .. UnitLevel("player") .. "|r" .. (maxStufe() and (" " .. W .. L"(max)|r") or ""))
    end
    if (not nur or nur == "leistung") and db.zeigen.fps then
        local fps = math.floor(GetFramerate() + .5)
        B.fps.setze((fps < 20 and R or fps < 40 and "|cffffa040" or W) .. fps .. "|r|cff999999 fps|r")
    end
    if (not nur or nur == "leistung") and db.zeigen.latenz then
        local _, _, heim, welt = GetNetStats(); local ms = math.max(heim or 0, welt or 0)
        B.latenz.setze(msFarbe(ms) .. ms .. "|r|cff999999 ms|r")
    end
    if (not nur or nur == "uhr") and db.zeigen.uhr then B.uhr.setze(W .. date("%H:%M") .. "|r") end
end

-- Position und Aussehen
function NS.Aussehen()
    local db = NS.DB()
    Leiste:SetScale(math.max(.6, math.min(1.6, tonumber(db.groesse) or 1)))
    -- durchgehend von links nach rechts; alte Position (2.4 und früher) einmal übernehmen: nur die Höhe
    if db.obenAbstand == nil then
        local pt = db.punkt
        db.obenAbstand = (type(pt) == "table" and type(pt[4]) == "number" and tostring(pt[2] or ""):find("TOP")) and math.max(0, -pt[4]) or 0
    end
    local s = Leiste:GetScale()
    Leiste:ClearAllPoints()
    Leiste:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 0, -db.obenAbstand / s)
    Leiste:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", 0, -db.obenAbstand / s)
    Leiste:SetBackdropColor(.03, .02, .05, db.alpha)
    Leiste:SetShown(db.an)
    anordnen()
    if NS.XPBalken then NS.XPBalken() end
end
function NS.Umschalten(an)
    local db = NS.DB(); if an == nil then an = not db.an end
    db.an = an; NS.Aussehen()
    NS.msg(an and L"Leiste |cff33ff33an|r." or L"Leiste |cffff6060aus|r.")
    if NS.OptAktualisieren then NS.OptAktualisieren() end
end

-- Spielzeit leise abfragen (ohne die Chat-Meldung)
local leise = false
local function spielzeitAbfragen()
    if not RequestTimePlayed then return end
    leise = true
    local alt = rawget(_G, "ChatFrame_DisplayTimePlayed")
    if alt then ChatFrame_DisplayTimePlayed = function() end; NS.altDisplay = alt end
    RequestTimePlayed()
end

-- EP-Meldungen: letzter Kill / letzte Quest (aus den Blizzard-Texten, damit jede Sprache passt)
local function muster(fmt)
    if type(fmt) ~= "string" then return end
    local p = fmt:gsub("%%(%d?)%$?([sd])", "\001%2")
    p = p:gsub("[%(%)%.%+%-%*%?%[%]%^%$%%]", "%%%0")
    p = p:gsub("\001s", "(.-)"):gsub("\001d", "(%%d+)")
    return "^" .. p
end
local function zahlAus(text, fmt)
    local m = muster(fmt); if not m then return end
    local a, b, c = text:match(m)
    for _, v in ipairs({ a, b, c }) do local n = tonumber(v); if n then return n end end
end
function NS.EPMeldung(text)
    if type(text) ~= "string" then return end
    local n = zahlAus(text, rawget(_G, "COMBATLOG_XPGAIN_FIRSTPERSON")) or zahlAus(text, rawget(_G, "COMBATLOG_XPGAIN_EXHAUSTION1"))
    if n then XP.kill = n return end
    n = zahlAus(text, rawget(_G, "COMBATLOG_XPGAIN_FIRSTPERSON_UNNAMED")) or zahlAus(text, rawget(_G, "COMBATLOG_XPGAIN_QUEST"))
    if n then XP.quest = n end
end

local ev = CreateFrame("Frame")
for _, e in ipairs({ "PLAYER_LOGIN", "PLAYER_ENTERING_WORLD", "ZONE_CHANGED", "ZONE_CHANGED_INDOORS", "ZONE_CHANGED_NEW_AREA", "PLAYER_MONEY",
    "UPDATE_INVENTORY_DURABILITY", "BAG_UPDATE", "PLAYER_XP_UPDATE", "PLAYER_LEVEL_UP", "UPDATE_EXHAUSTION", "TIME_PLAYED_MSG",
    "CHAT_MSG_COMBAT_XP_GAIN", "UNIT_AURA", "HONOR_CURRENCY_UPDATE", "CURRENCY_DISPLAY_UPDATE", "PLAYER_PVP_KILLS_CHANGED" }) do
    pcall(ev.RegisterEvent, ev, e)
end
ev:SetScript("OnEvent", function(_, e, a1, a2)
    if e == "PLAYER_LOGIN" then
        start.geld = GetMoney(); XP.letzteEP, XP.letzteMax = UnitXP("player"), UnitXPMax("player")
        B.ehre.ic:SetTexture(pvpIcon())
        geldMerken(); NS.Aussehen(); NS.Aktualisieren()
        if C_Timer then C_Timer.After(3, spielzeitAbfragen) end
    elseif e == "PLAYER_ENTERING_WORLD" or e:find("^ZONE_") then NS.Aktualisieren("ort")
    elseif e == "PLAYER_MONEY" then geldMerken(); NS.Aktualisieren("gold")
    elseif e == "UPDATE_INVENTORY_DURABILITY" then NS.Aktualisieren("haltbarkeit")
    elseif e == "BAG_UPDATE" then NS.Aktualisieren("taschen")
    elseif e == "PLAYER_XP_UPDATE" then
        local cur, max = UnitXP("player"), UnitXPMax("player")
        if XP.letzteEP then
            local g = (cur >= XP.letzteEP) and (cur - XP.letzteEP) or ((XP.letzteMax or 0) - XP.letzteEP + cur)
            if g > 0 then XP.sitzungEP = XP.sitzungEP + g end
        end
        XP.letzteEP, XP.letzteMax = cur, max
        NS.Aktualisieren("erfahrung")
    elseif e == "PLAYER_LEVEL_UP" then
        if XP.basis then local g = gespielt(); XP.gesamt, XP.stufe, XP.basis = g, 0, GetTime() end
        NS.Aktualisieren("erfahrung")
    elseif e == "UPDATE_EXHAUSTION" then NS.Aktualisieren("erfahrung")
    elseif e == "TIME_PLAYED_MSG" then
        XP.gesamt, XP.stufe, XP.basis = a1 or 0, a2 or 0, GetTime()
        if leise then leise = false; if NS.altDisplay then local alt = NS.altDisplay; NS.altDisplay = nil; if C_Timer then C_Timer.After(0, function() ChatFrame_DisplayTimePlayed = alt end) else ChatFrame_DisplayTimePlayed = alt end end end
    elseif e == "CHAT_MSG_COMBAT_XP_GAIN" then NS.EPMeldung(a1)
    elseif e == "UNIT_AURA" then
        if a1 == "player" then pcall(NS.BonusAufgefrischt, a2) end
        if a1 == "player" or (type(a1) == "string" and (a1:find("^party") or a1:find("^raid"))) then NS.BonusPruefen(); NS.Aktualisieren("bonus") end
    else NS.Aktualisieren("ehre") end
end)

-- regelmäßig: Koordinaten (0,2 s), Uhr und Leistung (1 s); offene Tooltips frisch halten
local t1, t2 = 0, 0
Leiste:SetScript("OnUpdate", function(_, el)
    t1 = t1 + el; t2 = t2 + el
    -- kein Leuchten des ganzen Bereichs mehr: nur die Zeit des Buffs, der ausläuft, blinkt rot (siehe bonusText)
    B.bonus.glow:Hide()
    if t1 >= .2 then t1 = 0; if NS.DB().zeigen.ort then B.ort.setze(ortText()) end end
    if t2 >= 1 then
        t2 = 0; NS.Aktualisieren("leistung"); NS.Aktualisieren("uhr"); NS.BonusPruefen(); NS.Aktualisieren("bonus")
        for _, b in pairs(B) do if b.tippOffen and b:IsMouseOver() then local f = b:GetScript("OnEnter"); f(b) end end
    end
end)

-- Befehle -----------------------------------------------------------------
SLASH_SIIKKINFO1 = "/infoleiste"; SLASH_SIIKKINFO2 = "/il"
SlashCmdList.SIIKKINFO = function(m)
    m = (m or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    if m == "" then if NS.Optionen then NS.Optionen() end
    elseif m == "an" then NS.Umschalten(true)
    elseif m == "aus" then NS.Umschalten(false)
    elseif m == "reset" then NS.DB().punkt = nil; NS.Aussehen(); NS.msg(L"Leiste wieder oben links.")
    elseif m == "sperren" then local db = NS.DB(); db.gesperrt = not db.gesperrt; NS.msg(db.gesperrt and L"Leiste gesperrt (Shift + Ziehen verschiebt trotzdem)." or L"Leiste entsperrt – einfach ziehen."); if NS.OptAktualisieren then NS.OptAktualisieren() end
    elseif m:match("^gr[oö]e?ss?e") or m:match("^size") then
        local v = tonumber(m:match("(%d+)"))
        if v then NS.DB().groesse = math.max(60, math.min(160, v)) / 100; NS.Aussehen(); if NS.OptAktualisieren then NS.OptAktualisieren() end end
        NS.msg(L"Größe der Leiste: " .. math.floor(NS.DB().groesse * 100 + .5) .. " % (60–160, z. B. /il groesse 120)")
    elseif m == "klasse" then if NS.KlassenFenster then NS.KlassenFenster() end
    elseif m == "check" then if NS.Check then NS.Check(nil, true) end
    elseif m == "intro" then local f = SiikkIntroAPI and SiikkIntroAPI["siikk-Infoleiste"]; if f then f() end
    elseif m == "neu" then local f = SiikkNeuAPI and SiikkNeuAPI["siikk-Infoleiste"]; if f then f() end
    else
        NS.msg(L"Befehle:")
        print(Y .. L"/il|r – Einstellungen · " .. Y .. "/il an|r / " .. Y .. L"aus|r – Leiste an/aus · " .. Y .. L"/il sperren|r – festmachen · " .. Y .. L"/il reset|r – zurück nach oben links")
        print(Y .. L"/il check|r – Dungeon-/Raid-Check jetzt zeigen (Fläschchen, Elixier, Buff-Food)")
        print(Y .. L"/il klasse|r – Klasse wählen und Klassen-Anzeige einstellen")
        print(Y .. L"/il intro|r – Einführung · " .. Y .. L"/il neu|r – was ist neu")
    end
end
