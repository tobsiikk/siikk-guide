-- siikk-Infoleiste · Klassen-Anzeige (4.0)
-- In der Mitte der Leiste stehen – je nach gewählter Klasse – die wichtigen Klassen-Buffs mit Timer und Reagenzien mit Anzahl.
-- Die Klasse wird beim ersten Start gefragt und lässt sich unter /il → „Klasse“ ändern (pro Charakter).
-- Klick auf ein Symbol: Buff neu zaubern bzw. Gegenstand benutzen · Rechtsklick: herstellen (z. B. Wasser, Manaedelstein).
local ADDON, NS = ...
-- Nur für Classic-Spielversionen (Anniversary, Classic, Forever) – im echten Retail (Midnight) gibt es diese Buffs und Reagenzien nicht
do local b = select(4, GetBuildInfo()); if type(b) == "number" and b >= 100000 then NS.KB = {}; return end end
local L = siikkL or function(s) return s end
local Y, W, G, R, LILA, GRAU = "|cffffd100", "|cffffffff", "|cff33ff33", "|cffff6060", "|cffb266ff", "|cff999999"
local function geheim(v) return issecretvalue and issecretvalue(v) end
local function mmss(s) return NS.mmss and NS.mmss(s) or ("%d:%02d"):format(math.floor(s / 60), math.floor(s) % 60) end

-- Hilfen ------------------------------------------------------------------------------------------------
local namenCache = {}
local function zName(id)
    if namenCache[id] ~= nil then return namenCache[id] or nil end
    local n = (C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(id)) or (GetSpellInfo and GetSpellInfo(id))
    if type(n) ~= "string" or geheim(n) then namenCache[id] = false; return nil end
    namenCache[id] = n; return n
end
local function zIcon(id)
    local t = (C_Spell and C_Spell.GetSpellTexture and C_Spell.GetSpellTexture(id)) or (GetSpellTexture and GetSpellTexture(id))
    return (type(t) == "number" or type(t) == "string") and t or nil
end
local function iIcon(id)
    local ok, t = pcall(C_Item and C_Item.GetItemIconByID or GetItemIcon, id)
    return ok and (type(t) == "number" or type(t) == "string") and t or nil
end
local function kennt(id)
    local ok, k = pcall(IsSpellKnown, id); if ok and k then return true end
    local ok2, k2 = pcall(IsPlayerSpell or function() end, id); return ok2 and k2 and true or false
end
local function anzahl(ids)
    local f = (C_Item and C_Item.GetItemCount) or rawget(_G, "GetItemCount")
    local n, erst = 0, nil
    for _, id in ipairs(ids) do local ok, c = pcall(f, id); if ok and type(c) == "number" and c > 0 then n = n + c; erst = erst or id end end
    return n, erst
end
local function besterBekannt(ids) for _, id in ipairs(ids) do if kennt(id) then return id end end end
local function namensSet(ids)
    local t = {}
    for _, id in ipairs(ids) do local n = zName(id); if n then t[n:lower()] = id end end
    return t
end
-- Titel in der Spielsprache: Zaubername bzw. Gegenstandsname aus dem Spiel, sonst der deutsche Titel
function NS.ElementTitel(e)
    if (e.typ == "buff") and type(e.zauber) == "table" then local n = zName(e.zauber[1]); if n then return n end end
    if e.typ == "anzahl" and e.items and #e.items == 1 and C_Item and C_Item.GetItemNameByID then
        local ok, n = pcall(C_Item.GetItemNameByID, e.items[1]); if ok and type(n) == "string" then return n end
    end
    return e.titel
end
local function kurz(n, max) if type(n) ~= "string" then return "" end if #n > max then return n:sub(1, max - 1) .. "…" end return n end

-- Klassen-Daten -----------------------------------------------------------------------------------------
-- typ: buff (Timer), auswahl (welcher ist aktiv, optional Timer), anzahl, waffe, munition, tier, totems, ankh, haltung
local KLASSEN = {
    WARLOCK = {
        { key = "ruestung", typ = "buff", titel = L"Rüstung", zauber = { 28176, 706, 687 }, dauer = 1800 },
    },
    MAGE = {
        { key = "int", typ = "buff", titel = L"Arkane Intelligenz", zauber = { 1459, 23028 }, dauer = 1800 },
        { key = "ruestung", typ = "buff", titel = L"Rüstung", zauber = { 6117, 7302, 168 }, dauer = 1800 },
        { key = "wasser", typ = "anzahl", titel = L"Herbeigezaubertes Wasser", items = { 8079, 8078, 8077, 3772, 2136, 2288, 5350 }, benutzen = true, herstellen = { 5504 } },
        { key = "edelstein", typ = "anzahl", titel = L"Manaedelstein", items = { 8008, 8007, 5513, 5514 }, benutzen = true, herstellen = { 10054, 10053, 3552, 759 } },
        { key = "teleport", typ = "anzahl", titel = L"Rune der Teleportation", items = { 17031 } },
        { key = "portal", typ = "anzahl", titel = L"Rune der Portale", items = { 17032 }, nurAb = 40 },
    },
    PRIEST = {
        { key = "seele", typ = "buff", titel = L"Machtwort: Seelenstärke", zauber = { 1243, 21562 }, dauer = 1800 },
        { key = "feuer", typ = "buff", titel = L"Inneres Feuer", zauber = { 588 }, dauer = 600, ladungen = true },
        { key = "geist", typ = "buff", titel = L"Göttlicher Geist", zauber = { 14752, 27681 }, dauer = 1800, nurBekannt = true },
        { key = "schatten", typ = "buff", titel = L"Schattenschutz", zauber = { 976, 27683 }, dauer = 600, nurBekannt = true },
        { key = "kerzen", typ = "anzahl", titel = L"Kerzen (Gebet der Seelenstärke)", items = { 17029, 17028 }, nurAb = 48 },
    },
    DRUID = {
        { key = "mal", typ = "buff", titel = L"Mal der Wildnis", zauber = { 1126, 21849 }, dauer = 1800 },
        { key = "dornen", typ = "buff", titel = L"Dornen", zauber = { 467 }, dauer = 600 },
        { key = "omen", typ = "buff", titel = L"Omen der Klarheit", zauber = { 16864 }, dauer = 600, nurBekannt = true },
        { key = "reagenz", typ = "anzahl", titel = L"Wilde Beeren / Wilder Dornwurz (Gabe der Wildnis)", items = { 17026, 17021 }, nurAb = 50 },
        { key = "samen", typ = "anzahl", titel = L"Samen (Wiedergeburt)", items = { 17038, 17037, 17036, 17035, 17034 }, nurAb = 20 },
    },
    PALADIN = {
        { key = "aura", typ = "auswahl", titel = L"Aura", zauber = { 465, 7294, 19746, 19876, 19888, 19891, 20218 } },
        { key = "segen", typ = "auswahl", titel = L"Segen", zauber = { 19740, 19742, 20217, 1038, 19977, 20911, 25782, 25894, 25898, 25890, 25895, 25899 }, dauer = 300 },
        { key = "zorn", typ = "buff", titel = L"Zorn der Gerechtigkeit", zauber = { 25780 }, dauer = 1800, nurBekannt = true },
        { key = "symbole", typ = "anzahl", titel = L"Symbole der Könige / Göttlichkeit", items = { 21177, 17033 }, nurAb = 30 },
    },
    SHAMAN = {
        { key = "blitz", typ = "buff", titel = L"Blitzschlagschild", zauber = { 324 }, dauer = 600, ladungen = true },
        { key = "waffe", typ = "waffe", titel = L"Waffenverzauberung", hand = 1, zauber = { 8232, 8017, 8024, 8033 } },
        { key = "totems", typ = "totems", titel = L"Totems" },
        { key = "ankh", typ = "ankh", titel = L"Ankh / Reinkarnation", items = { 17030 }, zauber = 20608, nurAb = 30 },
    },
    HUNTER = {
        { key = "aspekt", typ = "auswahl", titel = L"Aspekt", zauber = { 13165, 13163, 5118, 13159, 20043, 13161 } },
        { key = "munition", typ = "munition", titel = L"Munition" },
        { key = "tier", typ = "tier", titel = L"Tier", rufen = 883, beleben = 982 },
        { key = "volltreffer", typ = "buff", titel = L"Aura des Volltreffers", zauber = { 19506 }, nurBekannt = true },
    },
    ROGUE = {
        { key = "giftR", typ = "waffe", titel = L"Gift rechte Hand", hand = 1 },
        { key = "giftL", typ = "waffe", titel = L"Gift linke Hand", hand = 2 },
        { key = "blitzpulver", typ = "anzahl", titel = L"Blitzpulver (Verschwinden)", items = { 5140 }, nurAb = 22 },
        { key = "blendpulver", typ = "anzahl", titel = L"Blendungspulver", items = { 5530 }, nurAb = 34 },
    },
    WARRIOR = {
        { key = "haltung", typ = "haltung", titel = L"Haltung" },
        { key = "ruf", typ = "buff", titel = L"Schlachtruf", zauber = { 6673 }, dauer = 120 },
    },
}
NS.KLASSEN = KLASSEN
local KLASSEN_REIHE = { "WARRIOR", "PALADIN", "HUNTER", "ROGUE", "PRIEST", "SHAMAN", "MAGE", "WARLOCK", "DRUID" }
NS.KLASSEN_REIHE = KLASSEN_REIHE

local function charDB()
    local db = NS.DB(); db.klassen = type(db.klassen) == "table" and db.klassen or {}
    local k = NS.charKey(); db.klassen[k] = db.klassen[k] or { aus = {}, start = {}, letzter = {} }
    local c = db.klassen[k]; c.aus = c.aus or {}; c.start = c.start or {}; c.letzter = c.letzter or {}
    return c
end
local function elemente()
    local kl = NS.Klasse(); local t = {}
    local c = charDB()
    for _, e in ipairs(KLASSEN[kl] or {}) do if not c.aus[e.key] then t[#t + 1] = e end end
    return t
end
NS.KlassenElemente = function(kl) return KLASSEN[kl or NS.Klasse()] or {} end

-- Blöcke (Pool) + sichere Klick-Knöpfe ----------------------------------------------------------------
local MAX = 7
NS.KB = {}
local knoepfe = {}
for i = 1, MAX do
    local b
    b = NS.block("k" .. i, 134400, function(tt)
        local e = b.e; if not e then return end
        NS.tipKopf(tt, NS.ElementTitel(e))
        if b.tipp then for _, z in ipairs(b.tipp) do tt:AddLine(z[1], z[2] or 1, z[3] or 1, z[4] or 1, true) end end
        local hinweise = {}
        if b.klick1 then hinweise[#hinweise + 1] = L"Klick: " .. b.klick1 end
        if b.klick2 then hinweise[#hinweise + 1] = L"Rechtsklick: " .. b.klick2 end
        if #hinweise > 0 then tt:AddLine(" "); for _, h in ipairs(hinweise) do tt:AddLine(h, .7, .7, .7, true) end end
    end)
    b.aktiv = false; b.leer = true; b:Hide()
    NS.KB[i] = b
    local k = CreateFrame("Button", "siikkInfoKlasseKnopf" .. i, UIParent, "SecureActionButtonTemplate")
    k:SetSize(18, 18); k:SetFrameStrata("MEDIUM"); k:RegisterForClicks("AnyUp", "AnyDown"); k:Hide()
    k:SetScript("OnEnter", function() local f = b:GetScript("OnEnter"); if f then f(b) end end)
    k:SetScript("OnLeave", function() GameTooltip:Hide() end)
    knoepfe[i] = k
end

-- Klick-Belegung (nur außerhalb des Kampfes änderbar)
local function belegen(i, e)
    local k, b = knoepfe[i], NS.KB[i]
    b.klick1, b.klick2 = nil, nil
    if InCombatLockdown() then return end
    k:SetAttribute("type1", nil); k:SetAttribute("spell1", nil); k:SetAttribute("item1", nil)
    k:SetAttribute("type2", nil); k:SetAttribute("spell2", nil)
    if not e then return end
    local c = charDB()
    if e.typ == "buff" or e.typ == "auswahl" or (e.typ == "waffe" and e.zauber) then
        local id = c.letzter[e.key]
        if not (id and kennt(id)) then id = besterBekannt(e.zauber or {}) end
        local n = id and zName(id)
        if n then k:SetAttribute("type1", "spell"); k:SetAttribute("spell1", n); b.klick1 = n .. L" zaubern" end
    elseif e.typ == "anzahl" then
        local _, erst = anzahl(e.items)
        if e.benutzen and erst then k:SetAttribute("type1", "item"); k:SetAttribute("item1", "item:" .. erst); b.klick1 = L"benutzen" end
        if e.herstellen then
            local id = besterBekannt(e.herstellen); local n = id and zName(id)
            if n then k:SetAttribute("type2", "spell"); k:SetAttribute("spell2", n); b.klick2 = n end
        end
    elseif e.typ == "tier" then
        local tot = UnitExists("pet") and UnitIsDead("pet")
        local id = (tot or not UnitExists("pet")) and (tot and e.beleben or e.rufen) or nil
        if id and not UnitExists("pet") then
            -- kein Tier da: erst rufen; ist es tot, beleben
            local n = zName(e.rufen); local n2 = zName(e.beleben)
            if n then k:SetAttribute("type1", "spell"); k:SetAttribute("spell1", n); b.klick1 = n end
            if n2 then k:SetAttribute("type2", "spell"); k:SetAttribute("spell2", n2); b.klick2 = n2 end
        elseif tot then
            local n2 = zName(e.beleben)
            if n2 then k:SetAttribute("type1", "spell"); k:SetAttribute("spell1", n2); b.klick1 = n2 end
        end
    end
end
local function allesBelegen()
    if InCombatLockdown() then return end
    local el = elemente()
    for i = 1, MAX do belegen(i, el[i]) end
end
NS.KlassenBelegen = allesBelegen

function NS.KlassenKnoepfeSetzen()
    if InCombatLockdown() then return end
    for i = 1, MAX do
        local b, k = NS.KB[i], knoepfe[i]
        local klickbar = b.klick1 or b.klick2
        if b:IsVisible() and b.ic and klickbar then
            local x, y = b.ic:GetCenter()
            if x then
                local sk = b.ic:GetEffectiveScale() / UIParent:GetEffectiveScale()
                k:ClearAllPoints(); k:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x * sk, y * sk); k:SetSize(18 * sk, 18 * sk); k:Show()
            else k:Hide() end
        else k:Hide() end
    end
end

-- Zustand der Buffs (im Kampf aus dem letzten bekannten Stand weiterzählen) -------------------------------
local zust = {}   -- [key] = { an = bool, ablauf = GetTime()-Wert oder nil, anz = Ladungen, icon, name }
local function buffSuchen(e, auren)
    local set = e._namen; if not set then set = namensSet(e.zauber or {}); e._namen = set end
    local ids = {}; for _, id in ipairs(e.zauber or {}) do ids[id] = true end
    for _, a in ipairs(auren) do
        if (a.id and ids[a.id]) or (a.name and set[a.name:lower()]) then return a end
    end
end
local function buffZustand(e, auren)
    local z = zust[e.key] or {}; zust[e.key] = z
    if auren.unlesbar then return z end
    local a = buffSuchen(e, auren)
    local c = charDB()
    if a then
        z.an, z.icon, z.name, z.anz = true, a.icon, a.name, a.anz
        z.ablauf = (type(a.ablauf) == "number" and a.ablauf > 0) and a.ablauf or nil
        if not z.ablauf and e.dauer and not c.start[e.key] then c.start[e.key] = time() end
    else
        z.an, z.ablauf, z.anz = false, nil, nil; c.start[e.key] = nil
    end
    return z
end
local function restVon(e, z)
    if not z.an then return nil end
    if z.ablauf then return z.ablauf - GetTime() end
    local st = charDB().start[e.key]; if st and e.dauer then return e.dauer - (time() - st) end
end
local function zeitText(rest, dauer)
    if not rest then return "" end
    local warn = rest <= math.min(60, (dauer or 600) / 8)
    local an = math.floor(GetTime()) % 2 == 0
    return (warn and (an and "|cffff2020" or "|cff661010") or W) .. mmss(math.max(0, rest)) .. "|r"
end

-- Anzeige je Element ------------------------------------------------------------------------------------
local function zeigeElement(b, e, auren)
    local text, icon, grau, tipp = "", nil, false, {}
    local stufe = UnitLevel("player") or 1
    if e.typ == "buff" then
        if e.nurBekannt and not besterBekannt(e.zauber) and not buffSuchen(e, auren) then return nil end
        local z = buffZustand(e, auren)
        icon = z.icon or zIcon(e.zauber[1])
        if z.an then
            local rest = restVon(e, z)
            text = zeitText(rest, e.dauer) .. ((e.ladungen and z.anz and z.anz > 1) and (GRAU .. " (" .. z.anz .. ")|r") or "")
            if text == "" then text = G .. L"an" .. "|r" end
            tipp[#tipp + 1] = { (z.name or e.titel) .. (rest and (": " .. mmss(math.max(0, rest))) or ""), 1, 1, 1 }
        else
            text = R .. L"fehlt" .. "|r"; grau = true
            tipp[#tipp + 1] = { L"Gerade nicht aktiv.", 1, .4, .4 }
        end
    elseif e.typ == "auswahl" then
        local z = buffZustand(e, auren)
        if z.an then
            icon = z.icon; local rest = e.dauer and restVon(e, z)
            text = LILA .. kurz(z.name, 18) .. "|r" .. (rest and (" " .. zeitText(rest, e.dauer)) or "")
            tipp[#tipp + 1] = { z.name or "", 1, 1, 1 }
        else
            local id = charDB().letzter[e.key] or besterBekannt(e.zauber); icon = id and zIcon(id) or zIcon(e.zauber[1])
            if not besterBekannt(e.zauber) then return nil end
            text = R .. L"keine" .. "|r"; grau = true
            tipp[#tipp + 1] = { L"Gerade nichts aktiv.", 1, .4, .4 }
        end
    elseif e.typ == "anzahl" then
        if e.nurAb and stufe < e.nurAb then return nil end
        local n, erst = anzahl(e.items)
        icon = iIcon(erst or e.items[1]) or 134400
        text = (n == 0 and R or W) .. n .. "|r"; grau = n == 0
        tipp[#tipp + 1] = { L"In den Taschen: " .. n, 1, 1, 1 }
    elseif e.typ == "waffe" then
        local w = { pcall(GetWeaponEnchantInfo) }
        local ok = table.remove(w, 1)
        local has, ms, lad
        if ok then if e.hand == 1 then has, ms, lad = w[1], w[2], w[3] else has, ms, lad = w[5], w[6], w[7] end end
        if geheim(has) or geheim(ms) then has = zust[e.key] and zust[e.key].has; ms = zust[e.key] and zust[e.key].ms end
        zust[e.key] = { has = has, ms = ms, t = GetTime() }
        local slot = e.hand == 1 and 16 or 17
        icon = (GetInventoryItemTexture and GetInventoryItemTexture("player", slot)) or (e.zauber and zIcon(e.zauber[1])) or 134400
        if e.hand == 2 and not (GetInventoryItemID and GetInventoryItemID("player", 17)) then return nil end
        if has then
            local rest = type(ms) == "number" and ms / 1000 or nil
            text = zeitText(rest, 1800) .. ((type(lad) == "number" and lad > 0) and (GRAU .. " (" .. lad .. ")|r") or "")
            tipp[#tipp + 1] = { L"Verzaubert/vergiftet" .. (rest and (": " .. mmss(rest)) or ""), 1, 1, 1 }
        else
            text = R .. L"fehlt" .. "|r"; grau = true
            tipp[#tipp + 1] = { e.zauber and L"Keine Waffenverzauberung aktiv." or L"Kein Gift auf der Waffe.", 1, .4, .4 }
        end
    elseif e.typ == "munition" then
        local n = (GetInventoryItemCount and GetInventoryItemCount("player", 0)) or 0
        if type(n) ~= "number" or geheim(n) then n = 0 end
        icon = (GetInventoryItemTexture and GetInventoryItemTexture("player", 0)) or 132382
        text = (n < 200 and R or W) .. n .. "|r"; grau = n == 0
        tipp[#tipp + 1] = { L"Munition im Köcher/Patronengurt: " .. n, 1, 1, 1 }
        if n < 200 then tipp[#tipp + 1] = { L"Wird knapp – beim Händler nachkaufen!", 1, .4, .4 } end
    elseif e.typ == "tier" then
        icon = zIcon(e.rufen) or 132161
        if not UnitExists("pet") then text = R .. L"kein Tier" .. "|r"; grau = true
        elseif UnitIsDead("pet") then text = R .. L"tot" .. "|r"; grau = true
        else
            local ok, h = pcall(GetPetHappiness)
            if ok and type(h) == "number" and not geheim(h) then
                text = (h == 3 and (G .. L"zufrieden") or h == 2 and (Y .. L"mittel") or (R .. L"unglücklich")) .. "|r"
            else text = G .. L"da" .. "|r" end
            tipp[#tipp + 1] = { UnitName("pet") or "", 1, 1, 1 }
        end
    elseif e.typ == "totems" then
        icon = 136232
        local teile = {}
        for i = 1, 4 do
            local ok, has, name, start, dur, ic = pcall(GetTotemInfo, i)
            if ok and has and not geheim(start) and type(start) == "number" and start > 0 and type(dur) == "number" then
                local rest = start + dur - GetTime()
                if rest > 0 then
                    teile[#teile + 1] = ((type(ic) == "number" or type(ic) == "string") and ("|T" .. ic .. ":14:14:0:0:64:64:5:59:5:59|t") or "") .. zeitText(rest, dur)
                    tipp[#tipp + 1] = { (name or "") .. ": " .. mmss(rest), 1, 1, 1 }
                end
            end
        end
        if #teile == 0 then text = GRAU .. L"keine" .. "|r"; grau = true else text = table.concat(teile, " ") end
    elseif e.typ == "ankh" then
        if e.nurAb and stufe < e.nurAb then return nil end
        local n = anzahl(e.items)
        icon = iIcon(e.items[1]) or 136080
        local cdText = ""
        local cd = C_Spell and C_Spell.GetSpellCooldown and C_Spell.GetSpellCooldown(e.zauber)
        local st, du
        if type(cd) == "table" then st, du = cd.startTime, cd.duration elseif GetSpellCooldown then st, du = GetSpellCooldown(e.zauber) end
        if kennt(e.zauber) and type(st) == "number" and not geheim(st) and st > 0 and type(du) == "number" and du > 2 then
            cdText = GRAU .. " · |r" .. "|cffff9933" .. mmss(st + du - GetTime()) .. "|r"
        elseif kennt(e.zauber) then cdText = GRAU .. " · |r" .. G .. L"bereit" .. "|r" end
        text = (n == 0 and R or W) .. n .. "|r" .. cdText; grau = n == 0
        tipp[#tipp + 1] = { L"Ankhs in den Taschen: " .. n, 1, 1, 1 }
    elseif e.typ == "haltung" then
        local ok, idx = pcall(GetShapeshiftForm)
        if ok and type(idx) == "number" and idx > 0 then
            local ic, aktiv, _, sid = GetShapeshiftFormInfo(idx)
            icon = ic; local n = sid and zName(sid); text = LILA .. ((n and kurz(n, 18)) or L"Haltung " .. idx) .. "|r"
        else icon = 132349; text = R .. L"keine" .. "|r"; grau = true end
    end
    b.tipp = tipp
    if icon then b.ic:SetTexture(icon) end
    b.ic:SetDesaturated(grau and true or false)
    return text
end

local function aktualisieren()
    local db = NS.DB()
    local el = elemente()
    local auren = NS.auren and NS.auren() or {}
    local an = db.zeigen.klasse ~= false
    for i = 1, MAX do
        local b, e = NS.KB[i], el[i]
        b.e = e
        local t = an and e and zeigeElement(b, e, auren)
        if t then b.aktiv, b.leer = true, nil; b.setze(t) else b.aktiv, b.leer = false, true; b:Hide() end
    end
    if NS.Anordnen then NS.Anordnen() end
end
NS.KlassenAktualisieren = aktualisieren

-- Ereignisse: eigene Zauber merken (für Klick + Timer), regelmäßig aktualisieren --------------------------
local ev = CreateFrame("Frame")
pcall(ev.RegisterUnitEvent, ev, "UNIT_SPELLCAST_SUCCEEDED", "player")
for _, e in ipairs({ "PLAYER_REGEN_ENABLED", "BAG_UPDATE_DELAYED", "SPELLS_CHANGED", "PLAYER_ENTERING_WORLD", "UNIT_PET", "PLAYER_LEVEL_UP" }) do pcall(ev.RegisterEvent, ev, e) end
ev:SetScript("OnEvent", function(_, e, a1, a2, a3)
    if e == "UNIT_SPELLCAST_SUCCEEDED" then
        if type(a3) ~= "number" or geheim(a3) then return end
        local n = zName(a3); if not n then return end
        local c = charDB()
        for _, el in ipairs(KLASSEN[NS.Klasse()] or {}) do
            if el.zauber and type(el.zauber) == "table" then
                local set = el._namen or namensSet(el.zauber); el._namen = set
                if set[n:lower()] then c.letzter[el.key] = a3; if el.dauer then c.start[el.key] = time() end end
            end
        end
        allesBelegen()
    elseif e == "UNIT_PET" and a1 ~= "player" then return
    else
        allesBelegen()
    end
    aktualisieren()
end)
local takt = 0
ev:SetScript("OnUpdate", function(_, el)
    takt = takt + el; if takt < .5 then return end; takt = 0
    if NS.DB then pcall(aktualisieren) end
end)

-- Klassen-Fenster (1. Start + /il klasse) ------------------------------------------------------------------
local fenster
local function farbe(kl)
    local c = (rawget(_G, "RAID_CLASS_COLORS") or {})[kl]
    return c and ("|c" .. (c.colorStr or "ffffffff")) or W
end
local function klassenName(kl) return (rawget(_G, "LOCALIZED_CLASS_NAMES_MALE") or {})[kl] or kl end
function NS.KlassenFenster()
    if not fenster then
        local f = CreateFrame("Frame", "siikkInfoKlassenFenster", UIParent, "BackdropTemplate"); fenster = f
        f:SetSize(420, 420); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG"); f:EnableMouse(true); f:SetMovable(true)
        f:RegisterForDrag("LeftButton"); f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
        f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
        f:SetBackdropColor(.03, .02, .05, .97); f:SetBackdropBorderColor(.85, .65, .15, 1)
        tinsert(UISpecialFrames, "siikkInfoKlassenFenster")
        local k = f:CreateTexture(nil, "BORDER"); k:SetPoint("TOPLEFT", 4, -4); k:SetPoint("TOPRIGHT", -4, -4); k:SetHeight(28); k:SetColorTexture(.315, .19, .45, .85)
        local t = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); t:SetPoint("LEFT", k, "LEFT", 10, 0)
        t:SetText(L"|cffe03030siikk|r-|cffffd100Infoleiste|r · Welche Klasse spielst du?")
        local zu = CreateFrame("Button", nil, f, "UIPanelCloseButton"); zu:SetPoint("TOPRIGHT", 0, 0)
        local h = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); h:SetPoint("TOPLEFT", 16, -42); h:SetPoint("TOPRIGHT", -16, -42); h:SetJustifyH("LEFT")
        h:SetText(L"Je nach Klasse zeigt die Leiste in der Mitte deine wichtigen Buffs mit Timer und Reagenzien. Gilt nur für diesen Charakter.")
        f.knoepfe = {}
        for i, kl in ipairs(KLASSEN_REIHE) do
            local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); b:SetSize(124, 24)
            b:SetPoint("TOPLEFT", 16 + ((i - 1) % 3) * 130, -76 - math.floor((i - 1) / 3) * 28)
            b.kl = kl
            b:SetScript("OnClick", function()
                local db = NS.DB(); db.klasseWahl = db.klasseWahl or {}; db.klasseWahl[NS.charKey()] = kl
                allesBelegen(); aktualisieren(); NS.KlassenFenster()
                if NS.Aktualisieren then NS.Aktualisieren() end
            end)
            f.knoepfe[i] = b
        end
        local auto = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); auto:SetSize(254, 22); auto:SetPoint("TOPLEFT", 16, -164)
        auto:SetText(L"Automatisch (Klasse dieses Charakters)")
        auto:SetScript("OnClick", function() local db = NS.DB(); if db.klasseWahl then db.klasseWahl[NS.charKey()] = nil end; allesBelegen(); aktualisieren(); NS.KlassenFenster() end)
        local u = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); u:SetPoint("TOPLEFT", 16, -198); f.unter = u
        f.haken = {}
        for i = 1, MAX do
            local c = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate"); c:SetSize(22, 22); c:SetPoint("TOPLEFT", 16, -218 - (i - 1) * 24)
            c.t = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); c.t:SetPoint("LEFT", c, "RIGHT", 2, 0)
            c:SetScript("OnClick", function(s) if not s.key then return end; charDB().aus[s.key] = not s:GetChecked() or nil; allesBelegen(); aktualisieren() end)
            f.haken[i] = c
        end
        local ok = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); ok:SetSize(120, 24); ok:SetPoint("BOTTOM", 0, 12); ok:SetText(L"Fertig")
        ok:SetScript("OnClick", function() f:Hide() end)
    end
    local f = fenster
    local wahl = NS.Klasse()
    for _, b in ipairs(f.knoepfe) do
        b:SetText((b.kl == wahl and "» " or "") .. farbe(b.kl) .. klassenName(b.kl) .. "|r" .. (b.kl == wahl and " «" or ""))
    end
    f.unter:SetText(L"Anzeigen für " .. farbe(wahl) .. klassenName(wahl) .. "|r:")
    local liste = KLASSEN[wahl] or {}
    local c = charDB()
    for i, h in ipairs(f.haken) do
        local e = liste[i]
        if e then h.key = e.key; h.t:SetText(NS.ElementTitel(e)); h:SetChecked(not c.aus[e.key]); h:Show() else h.key = nil; h:Hide() end
    end
    f:Show()
end

-- Beim ersten Start einmal fragen
local start = CreateFrame("Frame"); start:RegisterEvent("PLAYER_LOGIN")
start:SetScript("OnEvent", function()
    C_Timer.After(4, function()
        local db = NS.DB(); db.klasseGefragt = type(db.klasseGefragt) == "table" and db.klasseGefragt or {}
        if not db.klasseGefragt[NS.charKey()] then db.klasseGefragt[NS.charKey()] = true; NS.KlassenFenster() end
        allesBelegen(); aktualisieren()
    end)
end)
