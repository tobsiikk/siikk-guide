-- siikk-Infoleiste · Schattentrance-Proc (Einbruch der Nacht): großes Symbol + Ton, wenn der nächste Schattenblitz sofort wirkt
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local GOLD = { .85, .65, .15 }

local TRANCE = 17941          -- Schattentrance
local DAUER = 10              -- hält 10 Sekunden
local BLITZ = { [686] = true, [695] = true, [705] = true, [1088] = true, [1106] = true, [7641] = true, [11659] = true, [11660] = true, [11661] = true, [25307] = true, [27209] = true }
local KLAENGE = {
    { name = L"Raidwarnung (laut)", key = "RAID_WARNING", id = 8959 },
    { name = L"Wecker-Hinweis", key = "ALARM_CLOCK_WARNING_2", id = 12867 },
    { name = L"Karten-Ping", key = "MAP_PING", id = 3175 },
    { name = L"Quest fehlgeschlagen", key = "IG_QUEST_FAILED", id = 847 },
    { name = L"Flüstern (leise)", key = "TELL_MESSAGE", id = 3081 },
}
NS.PROC_KLAENGE = KLAENGE

local function geheim(v) return issecretvalue and issecretvalue(v) or false end
local function pdb()
    local db = NS.DB(); db.proc = db.proc or {}
    local p = db.proc
    if p.an == nil then p.an = true end
    if p.groesse == nil then p.groesse = 64 end
    if p.klang == nil then p.klang = 1 end   -- 0 = kein Ton
    return p
end
NS.ProcDB = pdb
local function istHexer() return NS.Klasse and NS.Klasse() == "WARLOCK" end

function NS.ProcKlang(i)
    local k = KLAENGE[i]; if not k or not PlaySound then return end
    local id = (SOUNDKIT and SOUNDKIT[k.key]) or k.id
    pcall(PlaySound, id, "Master")
    if C_Timer and C_Timer.After then C_Timer.After(.35, function() pcall(PlaySound, id, "Master") end) end
end

-- Symbol --------------------------------------------------------------------
local B = CreateFrame("Frame", "siikkInfoProc", UIParent, "BackdropTemplate")
B:SetFrameStrata("HIGH"); B:SetClampedToScreen(true); B:SetMovable(true); B:Hide()
B:SetBackdrop({ edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 2 }); B:SetBackdropBorderColor(.75, .3, 1, 1)
B.ic = B:CreateTexture(nil, "ARTWORK"); B.ic:SetPoint("TOPLEFT", 2, -2); B.ic:SetPoint("BOTTOMRIGHT", -2, 2); B.ic:SetTexCoord(.08, .92, .08, .92)
B.zeit = B:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge"); B.zeit:SetPoint("CENTER", 0, 0)
B.text = B:CreateFontString(nil, "OVERLAY", "GameFontNormal"); B.text:SetPoint("TOP", B, "BOTTOM", 0, -4)
B.text:SetText(L"|cffff66ffSofort-Schattenblitz!|r")
B:RegisterForDrag("LeftButton")
B:SetScript("OnDragStart", function(s) if s.platzieren then s:StartMoving() end end)
B:SetScript("OnDragStop", function(s)
    s:StopMovingOrSizing()
    local a, _, r, x, y = s:GetPoint(); pdb().punkt = { a, r, x, y }
end)

local function aussehen()
    local p = pdb()
    B:SetSize(p.groesse, p.groesse)
    local tex = (C_Spell and C_Spell.GetSpellTexture and C_Spell.GetSpellTexture(686)) or (GetSpellTexture and GetSpellTexture(686)) or 136197
    B.ic:SetTexture(tex)
    local f = B.zeit:GetFont(); if f then B.zeit:SetFont(f, math.max(12, math.floor(p.groesse * .4)), "OUTLINE") end
    B:ClearAllPoints()
    if p.punkt then B:SetPoint(p.punkt[1], UIParent, p.punkt[2], p.punkt[3], p.punkt[4]) else B:SetPoint("CENTER", UIParent, "CENTER", 0, 140) end
end
NS.ProcAussehen = aussehen

-- Erkennung ---------------------------------------------------------------------
-- Forever verrät Buffs im Kampf oft nur als geheime Werte. Deshalb drei Wege:
-- 1) Proc-Leuchten des Spiels (Schattenblitz leuchtet), 2) Buff direkt abfragen, wenn lesbar,
-- 3) Ende über den nächsten Schattenblitz oder nach 10 Sekunden.
local geladen = false
local seit -- Startzeit des aktuellen Procs (nil = keiner)
local function start(ab)
    if seit and GetTime() - seit < DAUER then if ab then seit = ab end return end
    seit = ab or GetTime(); B.t = 0
    local p = pdb()
    if p.an and istHexer() and (p.klang or 0) > 0 then NS.ProcKlang(p.klang) end
end
local function ende() seit = nil end

local function buffAbfragen()
    -- true = da, false = sicher nicht da, nil = Spiel verrät es gerade nicht
    if not (C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID) then return nil end
    local ok, a = pcall(C_UnitAuras.GetPlayerAuraBySpellID, TRANCE)
    if not ok or geheim(a) then return nil end
    if a == nil then
        if InCombatLockdown and InCombatLockdown() then return nil end -- im Kampf kann „nichts“ auch „geheim“ heißen
        return false
    end
    local x = a.expirationTime
    if x and not geheim(x) and x > 0 then return true, x - DAUER end
    return true
end
NS.ProcBuff = buffAbfragen

local function istBlitz(id)
    if geheim(id) then return false end
    if BLITZ[id] then return true end
    local n = C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(id)
    local b = C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(686)
    return n and b and not geheim(n) and n == b
end

local E = CreateFrame("Frame")
for _, ev in ipairs({ "PLAYER_LOGIN", "UNIT_AURA", "UNIT_SPELLCAST_SUCCEEDED", "SPELL_ACTIVATION_OVERLAY_SHOW", "SPELL_ACTIVATION_OVERLAY_HIDE",
    "SPELL_ACTIVATION_OVERLAY_GLOW_SHOW", "SPELL_ACTIVATION_OVERLAY_GLOW_HIDE", "PLAYER_REGEN_ENABLED" }) do pcall(E.RegisterEvent, E, ev) end
E:SetScript("OnEvent", function(_, ev, a1, a2, a3)
    if ev == "PLAYER_LOGIN" then geladen = true; aussehen(); return end
    if not geladen then return end
    if ev == "UNIT_AURA" then
        if a1 ~= "player" then return end
        local da, ab = buffAbfragen()
        if da == true then start(ab) elseif da == false then ende() end
    elseif ev == "SPELL_ACTIVATION_OVERLAY_SHOW" then
        if not geheim(a1) and a1 == TRANCE then start() end
    elseif ev == "SPELL_ACTIVATION_OVERLAY_HIDE" then
        if not geheim(a1) and a1 == TRANCE then ende() end
    elseif ev == "SPELL_ACTIVATION_OVERLAY_GLOW_SHOW" then
        if istBlitz(a1) then start() end
    elseif ev == "SPELL_ACTIVATION_OVERLAY_GLOW_HIDE" then
        if istBlitz(a1) and seit and GetTime() - seit > .3 then ende() end
    elseif ev == "UNIT_SPELLCAST_SUCCEEDED" then
        -- der nächste Schattenblitz verbraucht den Proc
        if a1 == "player" and seit and GetTime() - seit > .4 then
            if istBlitz(a3) then ende() end
        end
    elseif ev == "PLAYER_REGEN_ENABLED" then
        if buffAbfragen() == false then ende() end
    end
end)

B:SetScript("OnUpdate", function(s, el)
    local p = pdb()
    if s.platzieren then s:SetAlpha(1); s.zeit:SetText(""); return end
    if not seit or not p.an or not istHexer() then s:Hide(); return end
    local rest = DAUER - (GetTime() - seit)
    if rest <= 0 then ende(); s:Hide(); return end
    s.t = (s.t or 0) + el
    s:SetAlpha(.65 + .35 * math.abs(math.sin(s.t * 5)))
    s.zeit:SetText(("%d"):format(math.ceil(rest)))
    if rest <= 3 then s.zeit:SetTextColor(1, .15, .15) else s.zeit:SetTextColor(1, 1, 1) end
end)
-- Sichtbarkeit wird außerhalb von OnUpdate geprüft (verstecktes Fenster bekommt kein OnUpdate)
local W = CreateFrame("Frame")
W:SetScript("OnUpdate", function()
    if not geladen then return end
    local p = pdb()
    if B.platzieren or (seit and p.an and istHexer()) then if not B:IsShown() then B:Show() end end
end)

function NS.ProcPlatzieren(an)
    if an == nil then an = not B.platzieren end
    B.platzieren = an
    B:EnableMouse(an)
    if an then
        B.text:SetText(L"|cffffd100Ziehen zum Verschieben|r"); B:Show()
    else
        B.text:SetText(L"|cffff66ffSofort-Schattenblitz!|r"); if not seit then B:Hide() end
    end
    return an
end
function NS.ProcTest() start() end
NS.ProcSymbol = B

-- Einstellungen -----------------------------------------------------------------
local F
local function fensterBauen()
    F = CreateFrame("Frame", "siikkInfoProcOptionen", UIParent, "BackdropTemplate")
    F:SetSize(360, 330); F:SetPoint("CENTER", 0, 60); F:SetFrameStrata("DIALOG")
    F:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    F:SetBackdropColor(.03, .02, .05, .96); F:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
    F:SetMovable(true); F:EnableMouse(true); F:RegisterForDrag("LeftButton"); F:SetClampedToScreen(true)
    F:SetScript("OnDragStart", F.StartMoving); F:SetScript("OnDragStop", F.StopMovingOrSizing)
    F:SetScript("OnHide", function() NS.ProcPlatzieren(false) end)
    tinsert(UISpecialFrames, "siikkInfoProcOptionen")
    local kopf = F:CreateTexture(nil, "BORDER"); kopf:SetPoint("TOPLEFT", 4, -4); kopf:SetPoint("TOPRIGHT", -4, -4); kopf:SetHeight(28); kopf:SetColorTexture(.315, .19, .45, .8)
    local tt = F:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); tt:SetPoint("LEFT", kopf, "LEFT", 10, 0); tt:SetText(L"Schattentrance-Proc")
    local zu = CreateFrame("Button", nil, F, "UIPanelCloseButton"); zu:SetPoint("TOPRIGHT", 0, 0)
    local p = pdb()

    local an = CreateFrame("CheckButton", nil, F, "UICheckButtonTemplate"); an:SetSize(24, 24); an:SetPoint("TOPLEFT", 16, -42)
    local al = an:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); al:SetPoint("LEFT", an, "RIGHT", 4, 1); al:SetText(L"Symbol anzeigen, wenn Schattentrance auslöst")
    an:SetScript("OnClick", function(s) pdb().an = s:GetChecked() and true or false end)
    F.an = an
    local hin = F:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); hin:SetPoint("TOPLEFT", 20, -70); hin:SetWidth(320); hin:SetJustifyH("LEFT")
    hin:SetText(L"Nur für Hexenmeister mit dem Talent „Einbruch der Nacht“. Das Symbol verschwindet nach dem nächsten Schattenblitz oder nach 10 Sekunden.")

    local lg = F:CreateFontString(nil, "OVERLAY", "GameFontNormal"); lg:SetPoint("TOPLEFT", 20, -110); lg:SetText(L"Größe")
    local g = CreateFrame("Slider", nil, F, "BackdropTemplate")
    g:SetOrientation("HORIZONTAL"); g:SetSize(180, 12); g:SetPoint("LEFT", lg, "RIGHT", 14, 0)
    g:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    g:SetBackdropColor(.12, .08, .16, 1); g:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .8)
    local th = g:CreateTexture(nil, "OVERLAY"); th:SetColorTexture(1, .82, .1, 1); th:SetSize(10, 16); g:SetThumbTexture(th)
    g:SetMinMaxValues(32, 160); g:SetValueStep(4); if g.SetObeyStepOnDrag then g:SetObeyStepOnDrag(true) end
    local gw = F:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); gw:SetPoint("LEFT", g, "RIGHT", 10, 0)
    g:SetScript("OnValueChanged", function(_, v) v = math.floor(v / 4 + .5) * 4; gw:SetText(v .. " px"); pdb().groesse = v; aussehen() end)
    F.groesse = g

    local lk = F:CreateFontString(nil, "OVERLAY", "GameFontNormal"); lk:SetPoint("TOPLEFT", 20, -142); lk:SetText(L"Ton")
    F.klang = {}
    local namen = { [0] = L"Kein Ton" }
    for i, k in ipairs(KLAENGE) do namen[i] = k.name end
    for i = 0, #KLAENGE do
        local r = CreateFrame("CheckButton", nil, F, "UIRadioButtonTemplate")
        r:SetSize(18, 18); r:SetPoint("TOPLEFT", 22 + (i % 2) * 160, -162 - math.floor(i / 2) * 22)
        local t = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); t:SetPoint("LEFT", r, "RIGHT", 4, 0); t:SetText(namen[i])
        r:SetScript("OnClick", function()
            pdb().klang = i
            for j, rr in pairs(F.klang) do rr:SetChecked(j == i) end
            if i > 0 then NS.ProcKlang(i) end
        end)
        F.klang[i] = r
    end

    local vb = CreateFrame("Button", nil, F, "UIPanelButtonTemplate"); vb:SetSize(150, 22); vb:SetPoint("TOPLEFT", 20, -238); vb:SetText(L"Symbol verschieben")
    vb:SetScript("OnClick", function(s) local x = NS.ProcPlatzieren(); s:SetText(x and L"Fertig verschoben" or L"Symbol verschieben") end)
    F.verschieben = vb
    local tb = CreateFrame("Button", nil, F, "UIPanelButtonTemplate"); tb:SetSize(150, 22); tb:SetPoint("LEFT", vb, "RIGHT", 10, 0); tb:SetText(L"Testen")
    tb:SetScript("OnClick", function() NS.ProcPlatzieren(false); vb:SetText(L"Symbol verschieben"); seit = nil; start() end)
    local rb = CreateFrame("Button", nil, F, "UIPanelButtonTemplate"); rb:SetSize(150, 22); rb:SetPoint("TOPLEFT", 20, -266); rb:SetText(L"Position zurücksetzen")
    rb:SetScript("OnClick", function() pdb().punkt = nil; aussehen() end)
    local zb = CreateFrame("Button", nil, F, "UIPanelButtonTemplate"); zb:SetSize(120, 24); zb:SetPoint("BOTTOMRIGHT", -14, 12); zb:SetText(L"Schließen")
    zb:SetScript("OnClick", function() F:Hide() end)
end

function NS.ProcFenster()
    if not F then fensterBauen() end
    local p = pdb()
    F.an:SetChecked(p.an); F.groesse:SetValue(p.groesse)
    for j, r in pairs(F.klang) do r:SetChecked(j == (p.klang or 0)) end
    F.verschieben:SetText(L"Symbol verschieben")
    F:Show()
end
