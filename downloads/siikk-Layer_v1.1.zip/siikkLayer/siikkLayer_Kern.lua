-- siikk-Layer · erkennt, auf welchem Layer (welcher Kopie der Welt) du gerade bist
-- So geht es: Jeder NPC hat eine GUID wie Creature-0-<Server>-<Karte>-<Zonen-ID>-<NPC>-<Spawn>.
-- Die Zonen-ID ist für alle NPCs einer Zone auf demselben Layer gleich und auf jedem Layer anders.
-- Das Addon sammelt diese ID von NPCs in deiner Nähe (Ziel, Maus, Namensplaketten, Kampflog) und zeigt sie an,
-- sobald mindestens zwei verschiedene NPCs dieselbe ID liefern. Mit Gilde und Gruppe wird die ID geteilt.
local ADDON, NS = ...
local L = siikkL or function(s) return s end
NS.VERSION = "1.1"
-- Forever (Build 16xxx) und Midnight (ab 12.0) sperren das Kampflog: schon das Abonnieren löst „wurde geblockt“ aus
local BUILD = select(4, GetBuildInfo())
NS.OHNE_KAMPFLOG = type(BUILD) == "number" and (BUILD >= 120000 or (BUILD >= 16000 and BUILD < 20000))
NS.MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\Media\\"
local Y, G, R, GR, LILA = "|cffffd100", "|cff33ff33", "|cffff6060", "|cff999999", "|cffb98cff"
function NS.msg(t) print(L"|cffe03030siikk|r-|cffffd100Layer|r: " .. t) end

local STANDARD = { leiste = true, gesperrt = false, hinweis = true, ton = true, teilen = true }
function NS.DB()
    local db = rawget(_G, "siikkLayer_DB")
    if type(db) ~= "table" then db = {}; siikkLayer_DB = db end
    for k, v in pairs(STANDARD) do if db[k] == nil then db[k] = v end end
    return db
end

-- Beobachtungen ------------------------------------------------------------
local MAX_ALTER = 120            -- Sekunden, so lange zählt eine Beobachtung
local beob = {}                  -- [spawn] = { id = Zonen-ID, t = Zeit }
local aktuell, zoneName, zoneKarte = nil, nil, nil
NS.andere = {}                   -- [Name] = { karte = uiMapID, zone = Name, id = Zonen-ID, t = Zeit }
local verlauf = {}               -- letzte Layerwechsel { zeit, alt, neu, zone }
NS.verlauf = verlauf

local function jetzt() return GetTime and GetTime() or 0 end
local function inInstanz() local ok, drin = pcall(IsInInstance); return ok and drin and true or false end

-- zerlegt eine GUID; liefert Zonen-ID und Spawn-Kennung nur für echte NPCs der offenen Welt
function NS.Zerlegen(guid)
    if type(guid) ~= "string" then return nil end
    local typ, _, server, karte, zone, npc, spawn = strsplit("-", guid)
    if typ ~= "Creature" and typ ~= "Vehicle" then return nil end
    zone = tonumber(zone); if not zone or zone == 0 then return nil end
    return zone, (npc or "") .. ":" .. (spawn or ""), tonumber(karte), tonumber(server)
end

local function aufraeumen()
    local t = jetzt()
    for k, b in pairs(beob) do if t - b.t > MAX_ALTER then beob[k] = nil end end
    for n, a in pairs(NS.andere) do if t - a.t > 600 then NS.andere[n] = nil end end
end

-- Mehrheit der 4 neuesten Beobachtungen; mindestens 2 verschiedene NPCs müssen übereinstimmen.
-- So kippt ein einzelner Ausreißer nichts, ein echter Layerwechsel wird aber nach 2 NPCs erkannt.
local function bestimmen()
    aufraeumen()
    local liste = {}
    for _, b in pairs(beob) do liste[#liste + 1] = b end
    table.sort(liste, function(a, b) return a.t > b.t end)
    local zahl, best, bestN = {}, nil, 0
    for i = 1, math.min(4, #liste) do
        local id = liste[i].id
        zahl[id] = (zahl[id] or 0) + 1
        if zahl[id] > bestN then best, bestN = id, zahl[id] end
    end
    if bestN >= 2 then return best, #liste end
    return nil, #liste
end

local function zoneJetzt()
    local name = GetRealZoneText and GetRealZoneText() or ""
    local karte = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player") or nil
    return name, karte
end

local function sprechen(nachricht)
    if not NS.DB().teilen then return end
    local cc = C_ChatInfo; if not (cc and cc.SendAddonMessage) then return end
    if IsInGuild and IsInGuild() then pcall(cc.SendAddonMessage, "siikkLayer", nachricht, "GUILD") end
    if IsInRaid and IsInRaid() then pcall(cc.SendAddonMessage, "siikkLayer", nachricht, "RAID")
    elseif IsInGroup and IsInGroup() then pcall(cc.SendAddonMessage, "siikkLayer", nachricht, "PARTY") end
end
local zuletztGesendet, gesendetWas = 0, ""
local function melden(zwingen)
    if not aktuell then return end
    local n = "L:" .. (zoneKarte or 0) .. ":" .. aktuell .. ":" .. (zoneName or "")
    if not zwingen and n == gesendetWas and jetzt() - zuletztGesendet < 300 then return end
    if jetzt() - zuletztGesendet < 5 then return end
    zuletztGesendet, gesendetWas = jetzt(), n
    sprechen(n)
end
NS.Melden = melden

local function wechsel(alt, neu)
    verlauf[#verlauf + 1] = { zeit = date and date("%H:%M") or "", alt = alt, neu = neu, zone = zoneName }
    if #verlauf > 10 then table.remove(verlauf, 1) end
    local db = NS.DB()
    if db.hinweis then NS.msg((L"Layerwechsel in %s: %s → %s"):format(zoneName or "?", Y .. alt .. "|r", G .. neu .. "|r")) end
    if db.ton and PlaySound then pcall(PlaySound, 8959) end   -- Hinweiston
    if NS.Blinken then NS.Blinken() end
end

function NS.Beobachten(guid)
    if issecretvalue and issecretvalue(guid) then return end   -- Forever: geschützte Werte nie anfassen
    if type(guid) ~= "string" or inInstanz() then return end
    local id, spawn = NS.Zerlegen(guid)
    if not id then return end
    beob[spawn] = { id = id, t = jetzt() }
    local neu = bestimmen()
    if neu and neu ~= aktuell then
        local alt = aktuell
        aktuell = neu
        for k, b in pairs(beob) do if b.id ~= neu then beob[k] = nil end end   -- alte Messungen vom vorigen Layer verwerfen
        if alt then wechsel(alt, neu) end
        melden(true)
    end
    if NS.Anzeigen then NS.Anzeigen() end
end

-- alles vergessen (Ladebildschirm, neue Zone, Gruppenwechsel) – danach wird neu gemessen
function NS.Zuruecksetzen(grund)
    for k in pairs(beob) do beob[k] = nil end
    aktuell = nil
    zoneName, zoneKarte = zoneJetzt()
    if NS.Anzeigen then NS.Anzeigen() end
end

-- für die Anzeige
function NS.Stand()
    local _, n = bestimmen()
    return {
        id = aktuell, zone = zoneName, karte = zoneKarte, instanz = inInstanz(), beobachtet = n,
    }
end
-- Gildenmitglieder/Gruppe in derselben Zone
function NS.AndereHier()
    aufraeumen()
    local gleich, anders = {}, {}
    for name, a in pairs(NS.andere) do
        if a.karte == zoneKarte and zoneKarte then
            if aktuell and a.id == aktuell then gleich[#gleich + 1] = name else anders[#anders + 1] = { name = name, id = a.id } end
        end
    end
    table.sort(gleich); table.sort(anders, function(x, y) return x.id < y.id end)
    return gleich, anders
end
-- alle bekannten IDs dieser Zone (eigene + gemeldete) – ergibt die laufende Nummer „Layer 2 von 3“
function NS.Nummer()
    if not aktuell then return nil end
    local ids, s = { [aktuell] = true }, {}
    for _, a in pairs(NS.andere) do if a.karte == zoneKarte and zoneKarte then ids[a.id] = true end end
    for id in pairs(ids) do s[#s + 1] = id end
    table.sort(s)
    for i, id in ipairs(s) do if id == aktuell then return i, #s end end
end

-- Schnittstelle für andere Addons (z. B. Infoleiste)
SiikkLayerAPI = { Stand = function() return NS.Stand() end }

-- Ereignisse ---------------------------------------------------------------
local ev = CreateFrame("Frame")
local cleuZeit = 0
ev:SetScript("OnEvent", function(_, e, a1, a2, a3, a4)
    if e == "PLAYER_LOGIN" then
        NS.DB()
        if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then pcall(C_ChatInfo.RegisterAddonMessagePrefix, "siikkLayer") end
        NS.Zuruecksetzen("login")
        if C_Timer then C_Timer.After(8, function() sprechen("Q") end) end
    elseif e == "PLAYER_ENTERING_WORLD" or e == "ZONE_CHANGED_NEW_AREA" then
        NS.Zuruecksetzen(e)
    elseif e == "GROUP_JOINED" or e == "GROUP_LEFT" then
        -- beim Einladen schiebt das Spiel dich oft auf den Layer des Gruppenleiters – neu messen
        if C_Timer then C_Timer.After(3, function() NS.Zuruecksetzen(e) end) else NS.Zuruecksetzen(e) end
    elseif e == "PLAYER_TARGET_CHANGED" then NS.Beobachten(UnitGUID("target"))
    elseif e == "UPDATE_MOUSEOVER_UNIT" then NS.Beobachten(UnitGUID("mouseover"))
    elseif e == "NAME_PLATE_UNIT_ADDED" then if a1 then NS.Beobachten(UnitGUID(a1)) end
    elseif e == "COMBAT_LOG_EVENT_UNFILTERED" then
        local t = jetzt(); if t - cleuZeit < 0.5 then return end
        if not CombatLogGetCurrentEventInfo then return end
        local _, _, _, quelle, _, _, _, ziel = CombatLogGetCurrentEventInfo()
        if type(quelle) == "string" and quelle:find("^Creature") then cleuZeit = t; NS.Beobachten(quelle)
        elseif type(ziel) == "string" and ziel:find("^Creature") then cleuZeit = t; NS.Beobachten(ziel) end
    elseif e == "CHAT_MSG_ADDON" then
        local prefix, text, _, sender = a1, a2, a3, a4
        if prefix ~= "siikkLayer" or type(text) ~= "string" then return end
        local ich = UnitName("player")
        local kurz = type(sender) == "string" and sender:gsub("%-.*$", "") or "?"
        if kurz == ich then return end
        if text == "Q" then
            if aktuell and C_Timer then C_Timer.After(1 + math.random() * 4, function() melden(true) end) end
            return
        end
        local karte, id, zone = text:match("^L:(%d+):(%d+):(.*)$")
        if karte then
            NS.andere[kurz] = { karte = tonumber(karte), id = tonumber(id), zone = zone, t = jetzt() }
            if NS.Anzeigen then NS.Anzeigen() end
        end
    end
end)
for _, e in ipairs({ "PLAYER_LOGIN", "PLAYER_ENTERING_WORLD", "ZONE_CHANGED_NEW_AREA", "GROUP_JOINED", "GROUP_LEFT", "PLAYER_TARGET_CHANGED",
    "UPDATE_MOUSEOVER_UNIT", "NAME_PLATE_UNIT_ADDED", "CHAT_MSG_ADDON" }) do
    pcall(ev.RegisterEvent, ev, e)
end
if not NS.OHNE_KAMPFLOG and type(CombatLogGetCurrentEventInfo) == "function" then pcall(ev.RegisterEvent, ev, "COMBAT_LOG_EVENT_UNFILTERED") end

-- Befehle ------------------------------------------------------------------
local function infoAusgeben()
    local s = NS.Stand()
    if s.instanz then NS.msg(L"In Dungeons und Schlachtfeldern gibt es keine Layer.") return end
    if not s.id then NS.msg(L"Noch nicht erkannt – fahr mit der Maus über zwei NPCs oder nimm sie ins Ziel.") return end
    local nr, von = NS.Nummer()
    NS.msg((L"%s: Layer-ID %s"):format(s.zone or "?", G .. s.id .. "|r") .. (von and von > 1 and ("  " .. GR .. (L"(%d von %d bekannten)"):format(nr, von) .. "|r") or ""))
    local gleich, anders = NS.AndereHier()
    if #gleich > 0 then NS.msg(L"Auf deinem Layer: " .. table.concat(gleich, ", ")) end
    for _, a in ipairs(anders) do NS.msg((L"Anderer Layer (%s): %s"):format(a.id, a.name)) end
end
NS.Info = infoAusgeben

SLASH_SIIKKLAYER1 = "/layer"; SLASH_SIIKKLAYER2 = "/siikklayer"
SlashCmdList.SIIKKLAYER = function(m)
    m = (m or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    if m == "optionen" or m == "options" then if NS.Optionen then NS.Optionen() end
    elseif m == "leiste" then local db = NS.DB(); db.leiste = not db.leiste; if NS.Anzeigen then NS.Anzeigen() end
    elseif m == "sperren" then local db = NS.DB(); db.gesperrt = not db.gesperrt; NS.msg(db.gesperrt and L"Leiste gesperrt." or L"Leiste entsperrt – zum Verschieben ziehen.")
    elseif m == "reset" then NS.Zuruecksetzen("befehl"); NS.msg(L"Messung neu gestartet.")
    elseif m == "intro" then local api = rawget(_G, "SiikkIntroAPI"); if api and api["siikk-Layer"] then api["siikk-Layer"]() end
    elseif m == "neu" then local api = rawget(_G, "SiikkNeuAPI"); if api and api["siikk-Layer"] then api["siikk-Layer"]() end
    elseif m == "hilfe" or m == "help" then
        NS.msg(L"Befehle:")
        print(Y .. L"/layer|r – aktuellen Layer und Gildenmitglieder anzeigen")
        print(Y .. L"/layer optionen|r – Einstellungen · " .. Y .. L"/layer leiste|r – Leiste ein/aus · " .. Y .. L"/layer sperren|r")
        print(Y .. L"/layer reset|r – neu messen · " .. Y .. L"/layer intro|r · " .. Y .. L"/layer neu|r")
    else infoAusgeben() end
end
