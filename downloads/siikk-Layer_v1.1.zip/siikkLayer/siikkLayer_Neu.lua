-- siikk-Layer · „Was ist neu?“ – erzeugt aus tools/changelog.py (nicht von Hand ändern)
local L = siikkL or function(s) return s end
siikkNeu("siikk-Layer", "|cffe03030siikk|r-|cffffd100Layer|r", "Interface\\AddOns\\siikkLayer\\Media\\siikk_layer_icon", "1.1",
{
    { version = "1.1", datum = "05.11.2026", punkte = { L"Fehler behoben: In WoW Forever kam die Meldung „siikkLayer wurde geblockt“. Forever sperrt das Kampflog für Addons – der Layer wird dort nur noch über Ziel, Maus und Namensplaketten erkannt." } },
    { version = "1.0", datum = "02.11.2026", punkte = { L"Neues Addon: zeigt, auf welchem Layer (welcher Kopie der Welt) du gerade bist – kleine Anzeige unter der Minimap.", L"Erkennt den Layer an den NPCs in deiner Nähe (Ziel, Maus, Namensplaketten); sobald zwei NPCs übereinstimmen, steht er fest.", L"Hinweis, Ton und grünes Aufleuchten bei einem Layerwechsel, z. B. nach einer Gruppeneinladung.", L"Mit Gilde und Gruppe geteilt: Tooltip und /layer zeigen, wer in derselben Zone auf welchem Layer ist.", L"Einstellungen mit Rechtsklick oder /layer optionen." } }
}, function() return rawget(_G, "siikkLayer_DB") end, "/layer neu")
