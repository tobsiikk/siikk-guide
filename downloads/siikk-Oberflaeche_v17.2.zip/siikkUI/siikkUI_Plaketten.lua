-- siikkUI · Namensplaketten über Gegnern
-- Grüne Lebensleiste mit Goldrand, Lebenspunkte als Zahl, Schwächungen (deine DoTs zuerst) und Stärkungen
local ADDON, NS = ...
local L = siikkL or function(s) return s end
NS = NS or {}
local DB
local function msg(t) if NS.msg then NS.msg(t) else DEFAULT_CHAT_FRAME:AddMessage(L"|cffe03030siikk|r|cffffd100UI|r: " .. t) end end
local function pass(ok, ...) if ok then return ... end end
local function safe(fn, ...) if not fn then return nil end return pass(pcall(fn, ...)) end
local function secret(v) return issecretvalue and issecretvalue(v) end
local function num(v) return type(v) == "number" and not secret(v) end

local GOLD = NS.GOLD or { .85, .65, .15 }
local GRUEN = { .12, .78, .22 }
local W, H = 132, 13
local DEBUFF_MAX, BUFF_MAX, DEBUFF_SIZE, BUFF_SIZE = 6, 4, 22, 16
local FONT = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
local active = false     -- läuft nur, wenn kein anderes Plaketten-Addon (Plater ...) aktiv ist
local plates = {}        -- unit -> unser Rahmen
local BLOCKER = { "Plater", "Kui_Nameplates", "TidyPlates", "TidyPlates_ThreatPlates", "ElvUI", "NeatPlates" }

local function loaded(name)
  if C_AddOns and C_AddOns.IsAddOnLoaded then return safe(C_AddOns.IsAddOnLoaded, name) end
  if IsAddOnLoaded then return safe(IsAddOnLoaded, name) end
end
local function fmt(n)
  n = math.floor((n or 0) + .5)
  local r = tostring(n):reverse():gsub("(%d%d%d)", "%1."):reverse()
  return (r:gsub("^%.", ""))
end
local function setFont(fs, size) pcall(fs.SetFont, fs, FONT, size, "OUTLINE") end
-- Restzeit: letzte 3 Sekunden rot blinkend
local function blink(fs, left)
  if left < 3 then fs:SetTextColor(1, .15, .15); fs:SetAlpha((math.floor(GetTime() * 4) % 2 == 0) and 1 or .25)
  else fs:SetTextColor(1, 1, .8); fs:SetAlpha(1) end
end

local function getAura(unit, i, filter)
  if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
    local d = safe(C_UnitAuras.GetAuraDataByIndex, unit, i, filter)
    if type(d) ~= "table" then return end
    return d.name, d.icon, d.applications, d.dispelName, d.duration, d.expirationTime, d.sourceUnit
  end
  if UnitAura then return safe(UnitAura, unit, i, filter) end
end

---------------------------------------------------------------------------
-- Ein Rahmen pro Plakette
---------------------------------------------------------------------------
local function mkIcon(parent, size)
  local b = CreateFrame("Frame", nil, parent, "BackdropTemplate"); b:SetSize(size, size)
  if b.SetBackdrop then b:SetBackdrop({ edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 }); b:SetBackdropBorderColor(0, 0, 0, 1) end
  b.tex = b:CreateTexture(nil, "ARTWORK"); b.tex:SetPoint("TOPLEFT", 1, -1); b.tex:SetPoint("BOTTOMRIGHT", -1, 1); b.tex:SetTexCoord(.08, .92, .08, .92)
  b.cd = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate"); b.cd:SetAllPoints(b.tex)
  if b.cd.SetHideCountdownNumbers then b.cd:SetHideCountdownNumbers(true) end
  if b.cd.SetDrawEdge then b.cd:SetDrawEdge(false) end
  b.time = b:CreateFontString(nil, "OVERLAY"); b.time:SetPoint("CENTER", 0, 0); setFont(b.time, size >= 20 and 11 or 9)
  b.count = b:CreateFontString(nil, "OVERLAY"); b.count:SetPoint("BOTTOMRIGHT", 1, 0); setFont(b.count, size >= 20 and 10 or 8)
  b:Hide()
  return b
end
local function mkPlate(base)
  local f = CreateFrame("Frame", nil, base)
  f:SetSize(W, H); f:SetPoint("CENTER", base, "CENTER", 0, 0)
  f.hp = CreateFrame("StatusBar", nil, f, "BackdropTemplate"); f.hp:SetAllPoints()
  f.hp:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); f.hp:SetStatusBarColor(GRUEN[1], GRUEN[2], GRUEN[3])
  f.hp.bg = f.hp:CreateTexture(nil, "BACKGROUND"); f.hp.bg:SetAllPoints(); f.hp.bg:SetColorTexture(0, 0, 0, .65)
  f.edge = CreateFrame("Frame", nil, f, "BackdropTemplate"); f.edge:SetPoint("TOPLEFT", -1, 1); f.edge:SetPoint("BOTTOMRIGHT", 1, -1)
  if f.edge.SetBackdrop then f.edge:SetBackdrop({ edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 }) end
  f.edge:SetFrameLevel(f.hp:GetFrameLevel() + 2)
  f.hpText = f.edge:CreateFontString(nil, "OVERLAY"); f.hpText:SetPoint("CENTER", f.hp, "CENTER", 0, 0); setFont(f.hpText, 10)
  f.pct = f.edge:CreateFontString(nil, "OVERLAY"); f.pct:SetPoint("RIGHT", f.hp, "RIGHT", -2, 0); setFont(f.pct, 8)
  f.name = f:CreateFontString(nil, "OVERLAY"); f.name:SetPoint("BOTTOM", f, "TOP", 0, 3); setFont(f.name, 11)
  f.name:SetWidth(W + 40); if f.name.SetWordWrap then f.name:SetWordWrap(false) end
  f.level = f:CreateFontString(nil, "OVERLAY"); f.level:SetPoint("RIGHT", f, "LEFT", -3, 0); setFont(f.level, 10)
  f.debuffs, f.buffs = {}, {}
  for i = 1, DEBUFF_MAX do
    local b = mkIcon(f, DEBUFF_SIZE)
    if i == 1 then b:SetPoint("BOTTOMLEFT", f, "TOPLEFT", 0, 17) else b:SetPoint("LEFT", f.debuffs[i - 1], "RIGHT", 2, 0) end
    f.debuffs[i] = b
  end
  for i = 1, BUFF_MAX do
    local b = mkIcon(f, BUFF_SIZE)
    if i == 1 then b:SetPoint("LEFT", f, "RIGHT", 4, 0) else b:SetPoint("LEFT", f.buffs[i - 1], "RIGHT", 2, 0) end
    f.buffs[i] = b
  end
  local acc = 0
  f:SetScript("OnUpdate", function(s, el)
    acc = acc + (el or 0); if acc < .1 then return end; acc = 0
    local now = GetTime()
    for _, list in ipairs({ s.debuffs, s.buffs }) do
      for _, b in ipairs(list) do
        if b:IsShown() and b.exp then
          local left = b.exp - now
          if left > 0 then b.time:SetText(left >= 60 and (math.floor(left / 60 + .5) .. "m") or (left >= 10 and tostring(math.floor(left)) or string.format("%.1f", left)))
            blink(b.time, left)
          else b.time:SetText("") end
        end
      end
    end
  end)
  f:Hide()
  return f
end

local function hideBlizz(base)
  local uf = base and rawget(base, "UnitFrame")
  if type(uf) == "table" and uf.SetAlpha then pcall(uf.SetAlpha, uf, 0) end
  -- Forever/Midnight: Debuffs sind für Addons gesperrt – Blizzards eigene Debuff-Leiste der Plakette sichtbar lassen
  if NS.AURENSPERRE and type(uf) == "table" then
    for _, k in ipairs({ "AurasFrame", "BuffFrame" }) do
      local c = rawget(uf, k)
      if type(c) == "table" and c.SetIgnoreParentAlpha then pcall(c.SetIgnoreParentAlpha, c, true); pcall(c.SetAlpha, c, 1) end
    end
  end
end
local function updateHealth(f, unit)
  local cur, max = safe(UnitHealth, unit), safe(UnitHealthMax, unit)
  if num(cur) and num(max) and max > 0 then
    f.hp:SetMinMaxValues(0, max); f.hp:SetValue(cur)
    f.hpText:SetText(fmt(cur) .. " HP")
    f.pct:SetText(math.floor(cur / max * 100 + .5) .. "%")
  else
    pcall(f.hp.SetMinMaxValues, f.hp, 0, max or 1); pcall(f.hp.SetValue, f.hp, cur or 0)
    local ok = pcall(f.hpText.SetFormattedText, f.hpText, "%s HP", cur); if not ok then f.hpText:SetText("") end
    f.pct:SetText("")
  end
end
-- Forever/Midnight: Auren-Werte sind dort im Kampf „geschützt“ (secret). Dann die neue Schnittstelle nehmen:
-- GetUnitAuras + auraInstanceID; Symbol, Stapel und Laufzeit gehen direkt an Blizzards Anzeige-Funktionen.
local MODERN = C_UnitAuras and C_UnitAuras.GetUnitAuras and issecretvalue ~= nil
NS.PlakettenModern = MODERN
local function diag(schluessel, wert)
  if not DB then return end
  DB.diagAuren = DB.diagAuren or {}
  if DB.diagAuren[schluessel] == nil then DB.diagAuren[schluessel] = tostring(wert) end
end
local function sammleModern(unit, filter, mineFirst)
  local all, seen = {}, {}
  if mineFirst then
    local mine = safe(C_UnitAuras.GetUnitAuras, unit, filter .. "|PLAYER", 40)
    if type(mine) == "table" then
      for _, d in ipairs(mine) do all[#all + 1] = { d = d, mine = true }; if not secret(d.auraInstanceID) then seen[d.auraInstanceID] = true end end
    end
  end
  local alle = safe(C_UnitAuras.GetUnitAuras, unit, filter, 40)
  diag("GetUnitAuras_" .. filter, type(alle) == "table" and (#alle .. " Auren") or type(alle))
  if type(alle) == "table" then
    for _, d in ipairs(alle) do
      local id = d.auraInstanceID
      if secret(id) or not seen[id] then all[#all + 1] = { d = d } end
    end
  end
  return all
end
local function fillModern(list, unit, filter, mineFirst)
  local all = sammleModern(unit, filter, mineFirst)
  for i, b in ipairs(list) do
    local e = all[i]
    if e then
      local d, id = e.d, e.d.auraInstanceID
      if i == 1 then diag("icon_geheim", secret(d.icon)); diag("dauer_geheim", secret(d.duration)); diag("id_geheim", secret(id)) end
      pcall(b.tex.SetTexture, b.tex, d.icon)
      -- Stapel
      local st
      if C_UnitAuras.GetAuraApplicationDisplayCount and not secret(id) then st = safe(C_UnitAuras.GetAuraApplicationDisplayCount, unit, id, 2, 99) end
      if st == nil and num(d.applications) then st = d.applications > 1 and tostring(d.applications) or "" end
      pcall(b.count.SetText, b.count, st or "")
      -- Laufzeit: offene Zahlen selbst zeichnen, sonst Blizzards Countdown-Zahlen der Abklingspirale
      b.exp = nil; b.time:SetText("")
      if num(d.duration) and num(d.expirationTime) then
        if d.duration > 0 then b.cd:SetCooldown(d.expirationTime - d.duration, d.duration); b.cd:Show(); b.exp = d.expirationTime else b.cd:Hide() end
        if b.cd.SetHideCountdownNumbers then b.cd:SetHideCountdownNumbers(true) end
      else
        local dur = C_UnitAuras.GetAuraDuration and not secret(id) and safe(C_UnitAuras.GetAuraDuration, unit, id)
        if dur and b.cd.SetCooldownFromDurationObject and pcall(b.cd.SetCooldownFromDurationObject, b.cd, dur) then
          b.cd:Show(); if b.cd.SetHideCountdownNumbers then b.cd:SetHideCountdownNumbers(false) end
        else b.cd:Hide() end
      end
      if b.SetBackdropBorderColor then
        if e.mine then b:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1) else b:SetBackdropBorderColor(0, 0, 0, 1) end
      end
      b:Show()
    else b:Hide(); b.exp = nil end
  end
end
local function fillAuras(list, unit, filter, mineFirst)
  if MODERN then
    local ok, err = pcall(fillModern, list, unit, filter, mineFirst)
    if not ok then diag("fehler", err) end
    return
  end
  local mine, other = {}, {}
  for i = 1, 40 do
    local name, icon, count, dtype, dur, exp, src = getAura(unit, i, filter)
    if not name then break end
    local e = { icon = icon, count = count, dtype = dtype, dur = dur, exp = exp, mine = (src == "player" or src == "pet") }
    if mineFirst and e.mine then mine[#mine + 1] = e else other[#other + 1] = e end
  end
  local all = mine; for _, e in ipairs(other) do all[#all + 1] = e end
  for i, b in ipairs(list) do
    local e = all[i]
    if e then
      b.tex:SetTexture(e.icon)
      b.count:SetText((num(e.count) and e.count > 1) and tostring(e.count) or "")
      if num(e.dur) and num(e.exp) and e.dur > 0 then b.cd:SetCooldown(e.exp - e.dur, e.dur); b.cd:Show(); b.exp = e.exp
      else b.cd:Hide(); b.exp = nil; b.time:SetText("") end
      if b.SetBackdropBorderColor then
        if e.mine then b:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
        else
          local c = filter == "HARMFUL" and DebuffTypeColor and DebuffTypeColor[e.dtype or "none"]
          if c then b:SetBackdropBorderColor(c.r, c.g, c.b, 1) else b:SetBackdropBorderColor(0, 0, 0, 1) end
        end
      end
      b:Show()
    else b:Hide(); b.exp = nil end
  end
end
local function updateAuras(f, unit)
  if NS.AURENSPERRE then for _, b in ipairs(f.debuffs) do b:Hide() end else fillAuras(f.debuffs, unit, "HARMFUL", true) end
  fillAuras(f.buffs, unit, "HELPFUL", false)
end
local function updateTarget(f, unit)
  local isT = safe(UnitIsUnit, unit, "target")
  if f.edge.SetBackdropBorderColor then
    if isT == true then f.edge:SetBackdropBorderColor(1, .85, .3, 1) else f.edge:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .75) end
  end
  f:SetScale(isT == true and 1.12 or 1)
end
local function updateName(f, unit)
  local n = safe(UnitName, unit); pcall(f.name.SetText, f.name, n or "")
  local r, g, b = 1, 1, 1
  if UnitReaction then local re = safe(UnitReaction, unit, "player"); if num(re) then if re <= 3 then r, g, b = 1, .35, .3 elseif re == 4 then r, g, b = 1, .9, .3 end end end
  f.name:SetTextColor(r, g, b)
  local lv = safe(UnitLevel, unit)
  if num(lv) then f.level:SetText(lv < 0 and "??" or tostring(lv)) else f.level:SetText("") end
  local c = GetCreatureDifficultyColor and num(lv) and safe(GetCreatureDifficultyColor, lv)
  if type(c) == "table" then f.level:SetTextColor(c.r, c.g, c.b) else f.level:SetTextColor(1, .82, 0) end
end
local function fullUpdate(unit)
  local f = plates[unit]; if not f then return end
  updateName(f, unit); updateHealth(f, unit); updateAuras(f, unit); updateTarget(f, unit)
end

local function onAdded(unit)
  if not (C_NamePlate and C_NamePlate.GetNamePlateForUnit) then return end
  local base = safe(C_NamePlate.GetNamePlateForUnit, unit)
  if type(base) ~= "table" then return end -- z. B. verbotene Plaketten in Instanzen
  if not base.thPlate then local ok, fr = pcall(mkPlate, base); if not ok then return end; base.thPlate = fr end
  local f = base.thPlate
  f.unit = unit; plates[unit] = f
  hideBlizz(base)
  fullUpdate(unit)
  f:Show()
end
-- Blizzard setzt die Durchsichtigkeit seiner Plakette immer wieder selbst (Zielwechsel, Sichtlinie, Entfernung) –
-- dann schaute sie unter der siikk-Leiste hervor. Jedes Bild kurz nachsehen und wieder auf 0 stellen (kein Hook, kein Taint).
local waechter = CreateFrame("Frame")
waechter:SetScript("OnUpdate", function()
  if not active then return end
  for _, f in pairs(plates) do
    local base = f.unit and f:GetParent()
    local uf = type(base) == "table" and rawget(base, "UnitFrame")
    if type(uf) == "table" and uf.GetAlpha then
      local a = safe(uf.GetAlpha, uf)
      if num(a) and a > .01 then hideBlizz(base) end
    end
  end
end)
local function onRemoved(unit)
  local f = plates[unit]; if f then f:Hide(); f.unit = nil end
  plates[unit] = nil
end

---------------------------------------------------------------------------
-- Ereignisse
---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
for _, e in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN" }) do pcall(ev.RegisterEvent, ev, e) end
local function start()
  if active then return end
  for _, n in ipairs(BLOCKER) do
    if loaded(n) then
      msg("|cffffd100" .. n .. L"|r ist aktiv – meine Namensplaketten pausieren, damit sich nichts überschneidet. Willst du meine: " .. n .. L" in der AddOn-Liste ausschalten.")
      return
    end
  end
  active = true
  for _, e in ipairs({ "NAME_PLATE_UNIT_ADDED", "NAME_PLATE_UNIT_REMOVED", "UNIT_HEALTH", "UNIT_HEALTH_FREQUENT", "UNIT_MAXHEALTH", "UNIT_AURA",
    "PLAYER_TARGET_CHANGED", "UNIT_NAME_UPDATE", "UNIT_LEVEL", "UNIT_FACTION" }) do pcall(ev.RegisterEvent, ev, e) end
  if C_NamePlate and C_NamePlate.GetNamePlates then
    for _, base in ipairs(safe(C_NamePlate.GetNamePlates) or {}) do
      local u = rawget(base, "namePlateUnitToken") or (rawget(base, "UnitFrame") and rawget(base.UnitFrame, "unit"))
      if type(u) == "string" then onAdded(u) end
    end
  end
end
ev:SetScript("OnEvent", function(_, e, unit)
  if e == "ADDON_LOADED" then
    if unit == ADDON then
      TobsiikkHelferDB = TobsiikkHelferDB or {}; DB = TobsiikkHelferDB
      if DB.plaketten == nil then DB.plaketten = true end
    end
    return
  end
  if e == "PLAYER_LOGIN" then if DB and DB.plaketten then start() end return end
  if not active then return end
  if e == "NAME_PLATE_UNIT_ADDED" then onAdded(unit)
  elseif e == "NAME_PLATE_UNIT_REMOVED" then onRemoved(unit)
  elseif e == "PLAYER_TARGET_CHANGED" then for u, f in pairs(plates) do updateTarget(f, u) end
  elseif type(unit) == "string" and plates[unit] then
    local f = plates[unit]
    if e == "UNIT_AURA" then updateAuras(f, unit)
    elseif e == "UNIT_NAME_UPDATE" or e == "UNIT_LEVEL" or e == "UNIT_FACTION" then updateName(f, unit)
    else updateHealth(f, unit) end
    if f.unit and f:GetParent() then hideBlizz(f:GetParent()) end
  end
end)

---------------------------------------------------------------------------
-- Zielrahmen: deine DoTs + Stärkungen direkt darunter, dazu eine gut sichtbare Zauberleiste des Ziels
---------------------------------------------------------------------------
local ZT_DEBUFF, ZT_BUFF = 8, 8
local zt -- Behälter unter dem Zielrahmen
local function iconTimers(list, now)
  for _, b in ipairs(list) do
    if b:IsShown() and b.exp then
      local left = b.exp - now
      if left > 0 then b.time:SetText(left >= 60 and (math.floor(left / 60 + .5) .. "m") or (left >= 10 and tostring(math.floor(left)) or string.format("%.1f", left)))
        blink(b.time, left)
      else b.time:SetText("") end
    end
  end
end
local function buildTarget()
  local tf = rawget(_G, "TobsiikkHelferZiel")
  if zt or type(tf) ~= "table" then return end
  zt = CreateFrame("Frame", "TobsiikkHelferZielExtras", tf)
  zt:SetPoint("TOPLEFT", tf, "BOTTOMLEFT", 0, -4); zt:SetPoint("TOPRIGHT", tf, "BOTTOMRIGHT", 0, -4); zt:SetHeight(20)
  -- Zauberleiste des Ziels
  local cb = CreateFrame("StatusBar", "TobsiikkHelferZielZauber", zt, "BackdropTemplate")
  cb:SetPoint("TOPLEFT", 0, 0); cb:SetPoint("TOPRIGHT", 0, 0); cb:SetHeight(16)
  cb:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); cb:SetMinMaxValues(0, 1)
  cb.bg = cb:CreateTexture(nil, "BACKGROUND"); cb.bg:SetAllPoints(); cb.bg:SetColorTexture(0, 0, 0, .7)
  cb.edge = CreateFrame("Frame", nil, cb, "BackdropTemplate"); cb.edge:SetPoint("TOPLEFT", -1, 1); cb.edge:SetPoint("BOTTOMRIGHT", 1, -1)
  if cb.edge.SetBackdrop then cb.edge:SetBackdrop({ edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 }); cb.edge:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1) end
  cb.icon = cb:CreateTexture(nil, "ARTWORK"); cb.icon:SetSize(16, 16); cb.icon:SetPoint("RIGHT", cb, "LEFT", -3, 0); cb.icon:SetTexCoord(.08, .92, .08, .92)
  cb.name = cb.edge:CreateFontString(nil, "OVERLAY"); cb.name:SetPoint("LEFT", 4, 0); setFont(cb.name, 10)
  cb.time = cb.edge:CreateFontString(nil, "OVERLAY"); cb.time:SetPoint("RIGHT", -4, 0); setFont(cb.time, 10)
  cb:Hide(); zt.cb = cb
  -- Schwächungen (deine zuerst) und Stärkungen
  zt.debuffs, zt.buffs = {}, {}
  for i = 1, ZT_DEBUFF do
    local b = mkIcon(zt, 26)
    if i == 1 then b:SetPoint("BOTTOMLEFT", tf, "TOPLEFT", 0, 24) else b:SetPoint("LEFT", zt.debuffs[i - 1], "RIGHT", 3, 0) end -- über dem Namen
    zt.debuffs[i] = b
  end
  for i = 1, ZT_BUFF do
    local b = mkIcon(zt, 18)
    if i == 1 then b:SetPoint("BOTTOMLEFT", tf, "TOPLEFT", 0, 24 + 30) else b:SetPoint("LEFT", zt.buffs[i - 1], "RIGHT", 2, 0) end -- darüber
    zt.buffs[i] = b
  end
  local acc = 0
  zt:SetScript("OnUpdate", function(_, el)
    -- Zauberleiste jedes Bild, Restzeiten 10x pro Sekunde
    local now = GetTime()
    local name, _, tex, st, en, _, _, noInt = safe(UnitCastingInfo, "target")
    local chan = false
    if not name then name, _, tex, st, en, _, noInt = safe(UnitChannelInfo, "target"); chan = name ~= nil end
    if name then
      cb.icon:SetTexture(tex); pcall(cb.name.SetText, cb.name, name)
      local ok = pcall(function()
        local s0, e0 = st / 1000, en / 1000
        local p = (now - s0) / math.max(.001, e0 - s0)
        if chan then p = 1 - p end
        cb:SetValue(math.max(0, math.min(1, p)))
        cb.time:SetText(string.format("%.1f", math.max(0, e0 - now)))
      end)
      if not ok then cb:SetValue(1); cb.time:SetText("") end
      if not secret(noInt) and noInt == true then cb:SetStatusBarColor(.55, .55, .55) else cb:SetStatusBarColor(1, .7, .1) end -- grau = nicht unterbrechbar
      cb:Show()
    else cb:Hide() end
    acc = acc + (el or 0); if acc >= .1 then acc = 0; iconTimers(zt.debuffs, now); iconTimers(zt.buffs, now) end
  end)
end
local function updateTargetAuras()
  if not zt then buildTarget() end
  if not zt then return end
  if not safe(UnitExists, "target") then for _, b in ipairs(zt.debuffs) do b:Hide() end; for _, b in ipairs(zt.buffs) do b:Hide() end; return end
  if NS.AURENSPERRE then for _, b in ipairs(zt.debuffs) do b:Hide() end else fillAuras(zt.debuffs, "target", "HARMFUL", true) end
  fillAuras(zt.buffs, "target", "HELPFUL", false)
  -- ohne Debuffs rücken die Buffs nach unten an den Rahmen
  local tf = rawget(_G, "TobsiikkHelferZiel")
  if tf then zt.buffs[1]:ClearAllPoints(); zt.buffs[1]:SetPoint("BOTTOMLEFT", tf, "TOPLEFT", 0, (zt.debuffs[1]:IsShown() or (NS.AURENSPERRE and (NS.zielBlizzDebuffs or 0) > 0)) and (24 + 30) or 24) end
end
NS.ZielAurenNeu = function() pcall(updateTargetAuras) end
NS.updateTargetAuras = updateTargetAuras
local zev = CreateFrame("Frame")
for _, e in ipairs({ "PLAYER_LOGIN", "PLAYER_TARGET_CHANGED", "UNIT_AURA" }) do pcall(zev.RegisterEvent, zev, e) end
zev:SetScript("OnEvent", function(_, e, unit)
  if e == "UNIT_AURA" and unit ~= "target" then return end
  pcall(updateTargetAuras)
end)

---------------------------------------------------------------------------
-- Spielerrahmen: deine Buffs (eigene zuerst, z. B. Teufelsrüstung, Kochendes Blut) und Debuffs darüber
---------------------------------------------------------------------------
local SP_DEBUFF, SP_BUFF, SP_BUFF_ROW = 8, 20, 10
local sp
local function buildPlayer()
  local pf = rawget(_G, "TobsiikkHelferSpieler")
  if sp or type(pf) ~= "table" then return end
  sp = CreateFrame("Frame", "TobsiikkHelferSpielerAuren", pf)
  sp:SetPoint("BOTTOMLEFT", pf, "TOPLEFT", 0, 24); sp:SetPoint("BOTTOMRIGHT", pf, "TOPRIGHT", 0, 24); sp:SetHeight(90)
  sp.debuffs, sp.buffs = {}, {}
  -- Debuffs direkt über dem Namen (am wichtigsten, am nächsten am Rahmen)
  for i = 1, SP_DEBUFF do
    local b = mkIcon(sp, 26)
    if i == 1 then b:SetPoint("BOTTOMLEFT", sp, "BOTTOMLEFT", 0, 0) else b:SetPoint("LEFT", sp.debuffs[i - 1], "RIGHT", 3, 0) end
    sp.debuffs[i] = b
  end
  -- Buffs darüber, zwei Reihen à 10
  for i = 1, SP_BUFF do
    local b = mkIcon(sp, 22)
    if i == 1 then b:SetPoint("BOTTOMLEFT", sp, "BOTTOMLEFT", 0, 30)
    elseif (i - 1) % SP_BUFF_ROW == 0 then b:SetPoint("BOTTOMLEFT", sp.buffs[i - SP_BUFF_ROW], "TOPLEFT", 0, 2)
    else b:SetPoint("LEFT", sp.buffs[i - 1], "RIGHT", 2, 0) end
    sp.buffs[i] = b
  end
  local acc = 0
  sp:SetScript("OnUpdate", function(_, el)
    acc = acc + (el or 0); if acc < .1 then return end; acc = 0
    local now = GetTime(); iconTimers(sp.debuffs, now); iconTimers(sp.buffs, now)
  end)
end
local function updatePlayerAuras()
  if not (DB and DB.spielerAuren ~= false) then if sp then sp:Hide() end return end
  if not sp then buildPlayer() end
  if not sp then return end
  sp:Show()
  fillAuras(sp.debuffs, "player", "HARMFUL", false)
  fillAuras(sp.buffs, "player", "HELPFUL", true)
  -- ohne Debuffs rücken die Buffs nach unten an den Rahmen
  local hasDebuff = sp.debuffs[1]:IsShown()
  sp.buffs[1]:ClearAllPoints(); sp.buffs[1]:SetPoint("BOTTOMLEFT", sp, "BOTTOMLEFT", 0, hasDebuff and 30 or 0)
end
NS.updatePlayerAuras = updatePlayerAuras
local pev = CreateFrame("Frame")
pcall(pev.RegisterEvent, pev, "PLAYER_LOGIN"); pcall(pev.RegisterEvent, pev, "PLAYER_ENTERING_WORLD")
if not pcall(pev.RegisterUnitEvent, pev, "UNIT_AURA", "player") then pcall(pev.RegisterEvent, pev, "UNIT_AURA") end
pev:SetScript("OnEvent", function(_, e, unit)
  if e == "UNIT_AURA" and unit ~= "player" then return end
  pcall(updatePlayerAuras)
end)

-- Befehl: /th plaketten an|aus
local baseSlash = SlashCmdList.TOBSIIKKHELFER
if baseSlash then
  SlashCmdList.TOBSIIKKHELFER = function(input)
    local c, arg = (input or ""):lower():match("^(%S*)%s*(.-)$")
    if c == "buffs" or c == "auren" then
      DB.spielerAuren = (arg ~= "aus"); pcall(updatePlayerAuras)
      msg(L"Buffs/Debuffs am Spielerrahmen " .. (DB.spielerAuren and "an." or L"aus."))
    elseif c == "beruf" then
      if NS.BerufPruefen then pcall(NS.BerufPruefen, msg) else msg("Berufe-Fenster noch nicht geöffnet.") end
    elseif c == "maus" or c == "mouse" then
      -- Fehlersuche: Name und Eltern-Kette des Fensterteils unter der Maus
      local f = (GetMouseFoci and (GetMouseFoci() or {})[1]) or (GetMouseFocus and GetMouseFocus())
      local i = 0
      while f and i < 8 do
        local n = safe(f.GetName, f) or "?"
        local k = f.GetParentKey and safe(f.GetParentKey, f) or nil
        local w, h = safe(f.GetWidth, f), safe(f.GetHeight, f)
        msg(i .. ": " .. tostring(n) .. (k and (" [" .. k .. "]") or "") .. " " .. tostring(safe(f.GetObjectType, f)) .. " " .. (num(w) and math.floor(w) or "?") .. "x" .. (num(h) and math.floor(h) or "?"))
        f = safe(f.GetParent, f); i = i + 1
      end
    elseif c == "check" or c == "diag" then
      -- Prüfung: was liefert das Spiel an Auren für dein Ziel? (Fehlersuche Forever)
      local function t(v) if v == nil then return "nil" end; if secret(v) then return "geschützt" end; return tostring(v) end
      local u = "target"
      msg("Ziel: " .. t(safe(UnitName, u)) .. " | modern=" .. tostring(MODERN) .. " | GetUnitAuras=" .. type(C_UnitAuras and C_UnitAuras.GetUnitAuras)
        .. " | GetAuraDataByIndex=" .. type(C_UnitAuras and C_UnitAuras.GetAuraDataByIndex) .. " | UnitAura=" .. type(UnitAura) .. " | UnitDebuff=" .. type(UnitDebuff))
      for _, f in ipairs({ "HARMFUL", "HARMFUL|PLAYER" }) do
        local ok, r = pcall(function() return C_UnitAuras.GetUnitAuras(u, f, 40) end)
        msg(f .. ": GetUnitAuras ok=" .. tostring(ok) .. " -> " .. (type(r) == "table" and (#r .. " Auren") or tostring(r)))
        if ok and type(r) == "table" and r[1] then local d = r[1]
          msg("  1. Aura: id=" .. t(d.auraInstanceID) .. " icon=" .. t(d.icon) .. " dauer=" .. t(d.duration) .. " von=" .. t(d.sourceUnit)) end
      end
      local ok2, d2 = pcall(C_UnitAuras.GetAuraDataByIndex, u, 1, "HARMFUL")
      msg("GetAuraDataByIndex(1): ok=" .. tostring(ok2) .. " -> " .. (type(d2) == "table" and ("Tabelle, name=" .. t(d2.name)) or tostring(d2)))
      if UnitDebuff then local ok3, n3 = pcall(UnitDebuff, u, 1); msg("UnitDebuff(1): ok=" .. tostring(ok3) .. " -> " .. t(n3)) end
      local base = C_NamePlate and safe(C_NamePlate.GetNamePlateForUnit, u)
      msg("Plakette fürs Ziel: " .. type(base) .. " | siikk-Plakette: " .. tostring(type(base) == "table" and base.thPlate ~= nil) .. " | aktiv=" .. tostring(active))
      if DB and DB.diagAuren then for k, v in pairs(DB.diagAuren) do msg("  diag " .. k .. " = " .. v) end end
    elseif c == "plaketten" or c == "nameplates" or c == "namensplaketten" then
      if arg == "aus" then DB.plaketten = false; msg(L"Namensplaketten aus – zurück zu Blizzard nach |cffffd100/reload|r.")
      else DB.plaketten = true; start(); msg(L"Namensplaketten an.") end
    else
      baseSlash(input)
      if c == "hilfe" or c == "help" or c == "?" then msg(L"/th plaketten an|aus – eigene Namensplaketten über Gegnern"); msg(L"/th buffs an|aus – Buffs/Debuffs über deinem Spielerrahmen") end
    end
  end
end
NS.plateDebug = { plates = plates, onAdded = onAdded, isActive = function() return active end }
