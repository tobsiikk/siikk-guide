-- siikkUI · Questpfeil
-- Ein Pfeil auf dem Bildschirm führt dich zu deinen Quests:
--  · zum Questziel (wo du Gegner/Gegenstände für die Quest findest)
--  · ist die Quest fertig: zum Abgabe-NPC
-- Woher der Pfeil die Orte kennt:
--  · Midnight: von Blizzard (Wegpunkte im Questlog)
--  · Classic/TBC/Forever: siikkUI lernt beim Spielen – wo du eine Quest annimmst, wo Questziele hochzählen
--    und wo du abgibst. Gespeichert für alle Charaktere (HexenmeisterProfile.questOrte).
-- Bedienung: Shift+Klick auf eine Quest in der Questanzeige = Pfeil folgt ihr · /th pfeil
-- Kein Kampflog (in Midnight und Forever für Addons gesperrt).
local ADDON, NS = ...
local L = siikkL or function(s) return s end
NS = NS or {}
local DB
local function G(n) return rawget(_G, n) end
local function msg(t) if NS.msg then NS.msg(t) else DEFAULT_CHAT_FRAME:AddMessage(L"|cffe03030siikk|r|cffffd100UI|r: " .. t) end end
local function pass(ok, ...) if ok then return ... end end
local function safe(fn, ...) if type(fn) ~= "function" then return nil end return pass(pcall(fn, ...)) end
local function secret(v) local f = G("issecretvalue"); return f and f(v) end
local function str(v) return type(v) == "string" and not secret(v) and v ~= "" and v or nil end
local function num(v) return type(v) == "number" and not secret(v) and v or nil end
local function rund(v) return math.floor(v * 10000 + .5) / 10000 end
local GOLD = NS.GOLD or { .85, .65, .15 }
local LILA = { .70, .42, 1 }
local FONT = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
local PFEIL = "Interface\\AddOns\\" .. (ADDON or "siikkUI") .. "\\Media\\pfeil"
local ICON_FERTIG = "Interface\\RaidFrame\\ReadyCheck-Ready"

local function cfg()
  if not DB then return { an = true, auto = true, lernen = true } end
  if type(DB.questPfeil) ~= "table" then DB.questPfeil = { an = true, auto = true, lernen = true } end
  return DB.questPfeil
end
local function orte()
  local r = G("HexenmeisterProfile"); if type(r) ~= "table" then r = {}; HexenmeisterProfile = r end
  if type(r.questOrte) ~= "table" then r.questOrte = { v = 1, q = {} } end
  if type(r.questOrte.q) ~= "table" then r.questOrte.q = {} end
  return r.questOrte.q
end

---------------------------------------------------------------------------
-- Position und Weltkoordinaten
---------------------------------------------------------------------------
local function xy(v)
  if type(v) ~= "table" then return nil end
  local x, y
  if type(v.GetXY) == "function" then x, y = safe(v.GetXY, v) end
  if x == nil then x, y = v.x, v.y end
  return num(x), num(y)
end
local function spielerPos()
  local M = G("C_Map"); if type(M) ~= "table" then return nil end
  local m = num(safe(M.GetBestMapForUnit, "player")); if not m then return nil end
  local x, y = xy(safe(M.GetPlayerMapPosition, m, "player"))
  if not x or not y or (x == 0 and y == 0) then return nil end
  return m, x, y
end
local function welt(m, x, y)
  local M, V = G("C_Map"), G("CreateVector2D")
  if type(M) ~= "table" or type(V) ~= "function" then return nil end
  local c, w = safe(M.GetWorldPosFromMapPos, m, V(x, y))
  local wx, wy = xy(w)
  if not c or not wx or not wy then return nil end
  return c, wx, wy
end
local WC = setmetatable({}, { __mode = "k" })
local function punktWelt(p)
  local w = WC[p]
  if not w then local c, wx, wy = welt(p.m, p.x, p.y); w = c and { c, wx, wy } or { false }; WC[p] = w end
  if not w[1] then return nil end
  return w[1], w[2], w[3]
end
local achsen = {}
local function achse(m)
  local a = achsen[m]; if a ~= nil then return a end
  local _, x0, y0 = welt(m, 0, 0); local _, x1, y1 = welt(m, 1, 0); local _, x2, y2 = welt(m, 0, 1)
  if not (x0 and x1 and x2) then achsen[m] = false; return false end
  local ex, ey, sx, sy = x1 - x0, y1 - y0, x2 - x0, y2 - y0
  local le, ls = math.sqrt(ex * ex + ey * ey), math.sqrt(sx * sx + sy * sy)
  if le == 0 or ls == 0 then achsen[m] = false; return false end
  a = { ex / le, ey / le, sx / ls, sy / ls }; achsen[m] = a; return a
end
local function richtung(m, dx, dy)
  local a = achse(m); if not a then return nil end
  return dx * a[1] + dy * a[2], -(dx * a[3] + dy * a[4])
end

---------------------------------------------------------------------------
-- Quests (kommt aus der Questanzeige) und gelernte Orte
---------------------------------------------------------------------------
local QL, QBYID = {}, {}
local function questsNeu()
  QL, QBYID = {}, {}
  local list = NS.questLesen and select(1, NS.questLesen()) or {}
  for _, e in ipairs(list) do
    if not e.zone and num(e.id) then
      local q = { id = e.id, t = e.title, done = e.done, objs = {} }
      for j, o in ipairs(e.objs or {}) do
        local a = (o.text or ""):match("(%d+)%s*/%s*%d+")
        q.objs[#q.objs + 1] = { j = j, text = o.text, done = o.done, have = tonumber(a) or (o.done and 1 or 0) }
      end
      QL[#QL + 1] = q; QBYID[q.id] = q
    end
  end
end
local function hier(n)
  local m, x, y = spielerPos(); if not m then return nil end
  return { m = m, x = rund(x), y = rund(y), n = n }
end
local function qdat(id, t)
  local Q = orte(); local d = Q[id]
  if type(d) ~= "table" then d = { o = {} }; Q[id] = d end
  if type(d.o) ~= "table" then d.o = {} end
  if t then d.t = t end
  return d
end
local function nahe(list, p) for _, o in ipairs(list) do if o.m == p.m and math.abs(o.x - p.x) < .008 and math.abs(o.y - p.y) < .008 then return true end end end
local snap = {}
local function vergleiche()
  local frisch = {}
  for _, q in ipairs(QL) do
    local alt, neu = snap[q.id], {}
    for _, o in ipairs(q.objs) do
      neu[o.j] = o.have
      if cfg().lernen and alt and alt[o.j] ~= nil and o.have > alt[o.j] then
        local p = hier()
        if p then
          local d = qdat(q.id, q.t); local l = d.o[o.j]; if type(l) ~= "table" then l = {}; d.o[o.j] = l end
          if #l < 30 and not nahe(l, p) then l[#l + 1] = p end
        end
      end
    end
    frisch[q.id] = neu
  end
  snap = frisch
end

-- Blizzard-Wegpunkt (Midnight): Richtung Ziel bzw. Abgabe
local function blizzOrt(q)
  local C = G("C_QuestLog"); if type(C) ~= "table" then return nil end
  if C.GetNextWaypoint then
    local m, x, y = safe(C.GetNextWaypoint, q.id)
    m, x, y = num(m), num(x), num(y)
    if m and x and y then return { m = m, x = x, y = y } end
  end
  if C.GetQuestsOnMap then
    local m = num(safe(G("C_Map") and C_Map.GetBestMapForUnit, "player"))
    local l = m and safe(C.GetQuestsOnMap, m)
    if type(l) == "table" then for _, e in ipairs(l) do if e.questID == q.id and num(e.x) and num(e.y) then return { m = m, x = e.x, y = e.y } end end end
  end
  return nil
end

local function zieleVon(q)
  local pts = {}
  local b = blizzOrt(q)
  if b then pts[1] = { p = b, text = q.done and L"Abgeben (Blizzard-Wegpunkt)" or L"Nächstes Questziel", abgabe = q.done }; return pts end
  local d = orte()[q.id]; if type(d) ~= "table" then return pts end
  if q.done then
    local p = d.a or d.g
    if type(p) == "table" and p.m then
      pts[1] = { p = p, abgabe = true, text = d.a and (L"Abgeben bei " .. (d.a.n or L"Questgeber")) or (L"Abgeben – vermutlich bei " .. (d.g.n or L"Questgeber")) }
    end
  elseif type(d.o) == "table" then
    for _, o in ipairs(q.objs) do
      local l = d.o[o.j]
      if not o.done and type(l) == "table" then for _, p in ipairs(l) do pts[#pts + 1] = { p = p, text = o.text } end end
    end
  end
  return pts
end

local LAGE, ZIEL
local function lage()
  local m, mx, my = spielerPos(); if not m then LAGE = nil; return nil end
  local c, x, y = welt(m, mx, my); if not c then LAGE = nil; return nil end
  LAGE = { m = m, c = c, x = x, y = y }; return LAGE
end
local function messen(z)
  local ZL = LAGE; if not (ZL and z and z.p) then return nil end
  local c, wx, wy = punktWelt(z.p); if not c or c ~= ZL.c then return nil end
  local dx, dy = wx - ZL.x, wy - ZL.y
  return math.sqrt(dx * dx + dy * dy), dx, dy
end
local function bester(q)
  local best
  for _, z in ipairs(zieleVon(q)) do local d = messen(z); if d and (not best or d < best.dist) then best = { q = q, z = z, dist = d } end end
  return best
end
local function waehle()
  ZIEL = nil
  if not lage() then return end
  local c = cfg()
  local f = c.folge and QBYID[c.folge]
  if c.folge and not f and #QL > 0 then c.folge = nil end
  if f then ZIEL = bester(f) or { q = f, keine = true }; return end
  if c.auto then for _, q in ipairs(QL) do local b = bester(q); if b and (not ZIEL or b.dist < ZIEL.dist) then ZIEL = b end end end
end

---------------------------------------------------------------------------
-- Pfeil-Fenster
---------------------------------------------------------------------------
local pf = CreateFrame("Button", "TobsiikkHelferQuestPfeil", UIParent, "BackdropTemplate")
pf:SetSize(240, 66); pf:SetFrameStrata("MEDIUM"); pf:SetClampedToScreen(true); pf:SetMovable(true); pf:EnableMouse(true)
pf:RegisterForDrag("LeftButton"); pf:RegisterForClicks("LeftButtonUp", "RightButtonUp")
if pf.SetBackdrop then
  pf:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
  pf:SetBackdropColor(0, 0, 0, .45); pf:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .85)
end
local function zeile(size, r, g, b)
  local fs = pf:CreateFontString(nil, "OVERLAY"); fs:SetFont(FONT, size, "OUTLINE"); fs:SetJustifyH("LEFT")
  if fs.SetWordWrap then fs:SetWordWrap(false) end
  fs:SetTextColor(r, g, b); return fs
end
pf.pfeil = pf:CreateTexture(nil, "ARTWORK"); pf.pfeil:SetSize(50, 50); pf.pfeil:SetPoint("LEFT", 8, 0); pf.pfeil:SetTexture(PFEIL)
pf.titel = zeile(12, 1, .82, .2); pf.titel:SetPoint("TOPLEFT", 66, -8); pf.titel:SetPoint("RIGHT", pf, "RIGHT", -8, 0)
pf.ziel = zeile(11, .92, .92, .92); pf.ziel:SetPoint("TOPLEFT", 66, -26); pf.ziel:SetPoint("RIGHT", pf, "RIGHT", -8, 0)
pf.dist = zeile(13, LILA[1], LILA[2], LILA[3]); pf.dist:SetPoint("TOPLEFT", 66, -43); pf.dist:SetPoint("RIGHT", pf, "RIGHT", -8, 0)
pf:SetScript("OnDragStart", function(s) if DB and not DB.gesperrt then s:StartMoving() end end)
pf:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); if NS.savePos then NS.savePos(s, "questpfeil") end end)
if NS.makeScalable then NS.makeScalable(pf, "questpfeil") end
if NS.extraFrames then table.insert(NS.extraFrames, { frame = pf, key = "questpfeil", point = "TOP", x = 0, y = -140 }) end
pf:Hide()

local function meter(yards) local m = yards * .9144; if m >= 1000 then return string.format("%.1f km", m / 1000) end return math.floor(m + .5) .. " m" end
local function zeichne()
  if not ZIEL then
    pf.pfeil:Hide(); pf.titel:SetText(L"Questpfeil")
    if not LAGE then pf.ziel:SetText(L"|cffaaaaaaHier keine Position (Dungeon?)|r")
    elseif #QL == 0 then pf.ziel:SetText(L"|cffaaaaaaKeine Quests im Questlog|r")
    else pf.ziel:SetText(L"|cffaaaaaaNoch keine Orte bekannt|r") end
    pf.dist:SetText(L"|cff999999lernt beim Spielen|r"); return
  end
  pf.titel:SetText((cfg().folge and "" or L"|cff999999Auto ·|r ") .. (ZIEL.q.t or ""))
  if ZIEL.keine then pf.pfeil:Hide(); pf.ziel:SetText(L"|cffaaaaaaFür diese Quest noch keine Orte|r"); pf.dist:SetText(L"|cff999999Klick: nächste Quest|r"); return end
  local d, dx, dy = messen(ZIEL.z)
  pf.ziel:SetText(ZIEL.z.text or "")
  if not d then pf.pfeil:Hide(); pf.dist:SetText(L"|cffaaaaaaanderer Kontinent|r"); return end
  pf.pfeil:Show()
  if d < 12 then
    pf.pfeil:SetTexture(ICON_FERTIG); pf.pfeil:SetVertexColor(1, 1, 1); if pf.pfeil.SetRotation then pf.pfeil:SetRotation(0) end
    pf.dist:SetText(L"|cff33ff33Ziel erreicht|r"); return
  end
  pf.pfeil:SetTexture(PFEIL)
  local ost, nord = richtung(LAGE.m, dx, dy)
  local f = num(safe(G("GetPlayerFacing")))
  if ost and f then
    local rel = math.atan2(-ost, nord) - f
    if pf.pfeil.SetRotation then pf.pfeil:SetRotation(rel) end
    local a = math.abs(((rel + math.pi) % (2 * math.pi)) - math.pi)
    if a < .5 then pf.pfeil:SetVertexColor(1, 1, 1) elseif a < 1.8 then pf.pfeil:SetVertexColor(1, .75, .45) else pf.pfeil:SetVertexColor(1, .45, .4) end
  end
  pf.dist:SetText(meter(d))
end

local function anwenden()
  if not DB then return end
  if cfg().an and not (NS.questModus and NS.questModus() == "hilfe") then pf:Show(); waehle(); zeichne() elseif not (NS.isPlacing and NS.isPlacing()) then pf:Hide() end
end
local function folge(id)
  local c = cfg()
  if not id or c.folge == id then c.folge = nil; msg(L"Questpfeil folgt wieder automatisch der nächsten Quest.")
  else
    c.folge = id; if not c.an then c.an = true end
    if not QBYID[id] then questsNeu() end
    local q = QBYID[id]
    msg(L"Questpfeil folgt: |cffffd100" .. (q and q.t or (L"Quest " .. id)) .. "|r" .. ((q and #zieleVon(q) == 0) and L" |cffaaaaaa(Ort noch unbekannt – wird beim Spielen gelernt)|r" or ""))
  end
  anwenden(); if NS.questUpdate then NS.questUpdate() end
end
local function naechste()
  local n = #QL; if n == 0 then return end
  local cur, start = ZIEL and ZIEL.q and ZIEL.q.id, 0
  for i, q in ipairs(QL) do if q.id == cur then start = i end end
  for k = 1, n do
    local q = QL[(start + k - 1) % n + 1]
    if q.id ~= cur and #zieleVon(q) > 0 then cfg().folge = q.id; anwenden(); if NS.questUpdate then NS.questUpdate() end; return end
  end
  msg(L"Für keine andere Quest ist schon ein Ort bekannt.")
end
pf:SetScript("OnClick", function(_, btn)
  if btn == "RightButton" then cfg().an = false; pf:Hide(); msg(L"Questpfeil aus – |cffffd100/th pfeil|r zeigt ihn wieder.")
  elseif IsShiftKeyDown and IsShiftKeyDown() then folge(nil)
  else naechste() end
end)
pf:SetScript("OnEnter", function(s)
  GameTooltip:SetOwner(s, "ANCHOR_BOTTOM"); GameTooltip:AddLine(L"Questpfeil", 1, .82, 0)
  if ZIEL and ZIEL.q then GameTooltip:AddLine(ZIEL.q.t, 1, 1, 1) end
  GameTooltip:AddLine(L"Linksklick: nächste Quest · Shift+Klick: automatisch · Rechtsklick: ausblenden", .7, .7, .7, true)
  GameTooltip:AddLine(L"In der Questanzeige: Shift+Klick auf eine Quest = Pfeil folgt ihr.", .7, .42, 1, true)
  GameTooltip:Show()
end)
pf:SetScript("OnLeave", function() GameTooltip:Hide() end)

---------------------------------------------------------------------------
-- Ablauf
---------------------------------------------------------------------------
local dirty, t1, t2 = true, 0, 0
local uhr = CreateFrame("Frame")
uhr:SetScript("OnUpdate", function(_, el)
  if not DB then return end
  t1, t2 = t1 + el, t2 + el
  if t1 >= .05 then
    t1 = 0
    if dirty then dirty = false; questsNeu(); vergleiche() end
    if pf:IsShown() then lage(); zeichne() end
  end
  if t2 >= .5 then t2 = 0; if pf:IsShown() then waehle() end end
end)
local wartend = {}
local ev = CreateFrame("Frame")
for _, e in ipairs({ "ADDON_LOADED", "PLAYER_ENTERING_WORLD", "QUEST_LOG_UPDATE", "QUEST_REMOVED", "QUEST_DETAIL", "QUEST_ACCEPTED", "QUEST_COMPLETE", "QUEST_TURNED_IN", "ZONE_CHANGED_NEW_AREA" }) do pcall(ev.RegisterEvent, ev, e) end
ev:SetScript("OnEvent", function(_, e, a, b)
  if e == "ADDON_LOADED" then
    if a ~= ADDON then return end
    TobsiikkHelferDB = TobsiikkHelferDB or {}; DB = TobsiikkHelferDB; cfg(); orte()
    return
  end
  if not DB then return end
  if e == "PLAYER_ENTERING_WORLD" then dirty = true; anwenden()
  elseif e == "QUEST_LOG_UPDATE" or e == "QUEST_REMOVED" then dirty = true
  elseif e == "QUEST_DETAIL" then wartend.geber = { p = hier(str((safe(G("UnitName"), "npc")))), t = GetTime() }
  elseif e == "QUEST_ACCEPTED" then
    -- Classic: (Index, QuestID) · Midnight: (QuestID)
    local id
    if num(b) then id = b elseif type(G("GetQuestLogTitle")) ~= "function" then id = num(a)
    elseif num(a) then id = num(select(8, safe(G("GetQuestLogTitle"), a))) end
    if id and cfg().lernen then
      local w = wartend.geber; local p = (w and w.p and GetTime() - w.t < 60) and w.p or hier()
      if p then qdat(id).g = p end
    end
    wartend.geber = nil; dirty = true
  elseif e == "QUEST_COMPLETE" then
    wartend.abgabe = { p = hier(str((safe(G("UnitName"), "npc")))), titel = str((safe(G("GetTitleText")))), t = GetTime() }
  elseif e == "QUEST_TURNED_IN" then
    local id, w = num(a), wartend.abgabe
    if id and cfg().lernen and w and w.p and GetTime() - w.t < 60 then qdat(id, w.titel).a = w.p end
    wartend.abgabe = nil
    if id then snap[id] = nil; if cfg().folge == id then cfg().folge = nil end end
    dirty = true
  elseif e == "ZONE_CHANGED_NEW_AREA" then waehle() end
end)

-- Platzier-Modus: Pfeil zum Verschieben zeigen
do
  local prev = NS.onLayout
  NS.onLayout = function(on) if prev then pcall(prev, on) end; if on then pf:Show() else anwenden() end end
end

---------------------------------------------------------------------------
-- Schnittstelle für die Questanzeige und Befehle (/th pfeil …)
---------------------------------------------------------------------------
NS.questPfeilFolge = folge
NS.questPfeilAnwenden = anwenden
NS.questPfeilAktuell = function() local c = cfg(); if not c.an then return nil end return c.folge or (ZIEL and ZIEL.q and ZIEL.q.id) or nil end
local baseSlash = SlashCmdList.TOBSIIKKHELFER
if baseSlash then
  SlashCmdList.TOBSIIKKHELFER = function(input)
    local c, arg = (input or ""):lower():match("^(%S*)%s*(.-)$")
    if c == "pfeil" or c == "questpfeil" then
      local cc = cfg()
      if arg == "auto" then cc.auto = not cc.auto; msg(L"Questpfeil folgt automatisch der nächsten Quest: " .. (cc.auto and "an" or "aus"))
      elseif arg == "lernen" then cc.lernen = not cc.lernen; msg(L"Questpfeil lernt Orte beim Spielen: " .. (cc.lernen and "an" or "aus"))
      elseif arg == "naechste" then naechste()
      elseif arg == "info" then local n, p = 0, 0; for _, d in pairs(orte()) do n = n + 1; if d.g then p = p + 1 end; if d.a then p = p + 1 end; for _, l in pairs(d.o or {}) do p = p + #l end end; msg(L"Questpfeil kennt " .. n .. L" Quests mit " .. p .. L" Orten.")
      elseif arg == "vergessen" then HexenmeisterProfile.questOrte = nil; orte(); WC = setmetatable({}, { __mode = "k" }); msg(L"Alle gelernten Questorte gelöscht.")
      elseif arg == "an" then cc.an = true; msg(L"Questpfeil an.")
      elseif arg == "aus" then cc.an = false; msg(L"Questpfeil aus.")
      else cc.an = not cc.an; msg(L"Questpfeil " .. (cc.an and "an." or L"aus.") .. L" |cff999999(/th pfeil auto · naechste · lernen · info · vergessen)|r") end
      anwenden(); if NS.questUpdate then NS.questUpdate() end
    else
      baseSlash(input)
      if c == "hilfe" or c == "help" or c == "?" then msg(L"/th pfeil – Questpfeil an/aus · /th pfeil auto · /th pfeil naechste · /th pfeil info · Shift+Klick auf eine Quest in der Questanzeige = Pfeil folgt ihr") end
    end
  end
end
NS.questPfeilDebug = { frame = pf, waehle = waehle, zeichne = zeichne, ziel = function() return ZIEL end, quests = function() return QL end, neu = function() questsNeu(); vergleiche() end, lage = lage }
