-- siikk-Talentplaner · Plan-Auswahl (/tp): Guide-Pläne von siikk-guide.de + eigene Pläne
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local Y, G, R, GR = NS.Y, NS.G, NS.R, NS.GR
local GOLD = NS.GOLD
local LILA = "|cffb98cff"
local ZEILEN, ZH = 9, 30

local f, zeilen, auswahl, oben, liste = nil, {}, nil, 0, {}
local _ = { L"Leveln", L"Endspiel", L"PvP", L"Hybrid" }   -- Plantypen von siikk-guide.de (für die Übersetzung)

local function fensterBasis(name, w, h, titel)
    local fr = CreateFrame("Frame", name, UIParent, "BackdropTemplate")
    fr:SetSize(w, h); fr:SetPoint("CENTER"); fr:SetFrameStrata("DIALOG"); fr:SetClampedToScreen(true); fr:Hide()
    fr:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    fr:SetBackdropColor(.03, .02, .05, .96); fr:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
    fr:SetMovable(true); fr:EnableMouse(true); fr:RegisterForDrag("LeftButton")
    fr:SetScript("OnDragStart", fr.StartMoving); fr:SetScript("OnDragStop", fr.StopMovingOrSizing)
    if UISpecialFrames then tinsert(UISpecialFrames, name) end
    local kopf = fr:CreateTexture(nil, "BORDER"); kopf:SetPoint("TOPLEFT", 4, -4); kopf:SetPoint("TOPRIGHT", -4, -4); kopf:SetHeight(28); kopf:SetColorTexture(.315, .19, .45, .8)
    local linie = fr:CreateTexture(nil, "ARTWORK"); linie:SetPoint("TOPLEFT", kopf, "BOTTOMLEFT"); linie:SetPoint("TOPRIGHT", kopf, "BOTTOMRIGHT"); linie:SetHeight(1); linie:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], 1)
    local ic = fr:CreateTexture(nil, "OVERLAY"); ic:SetSize(22, 22); ic:SetPoint("LEFT", kopf, "LEFT", 6, 0); ic:SetTexture(NS.ICON)
    fr.titel = fr:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); fr.titel:SetPoint("LEFT", ic, "RIGHT", 6, 0); fr.titel:SetText(titel)
    local zu = CreateFrame("Button", nil, fr, "UIPanelCloseButton"); zu:SetPoint("TOPRIGHT", 0, 0)
    fr.zu = zu
    return fr
end
NS.FensterBasis = fensterBasis

local function knopf(eltern, text, w, fn)
    local b = CreateFrame("Button", nil, eltern, "UIPanelButtonTemplate"); b:SetSize(w, 22); b:SetText(text)
    b:SetScript("OnClick", fn)
    return b
end
NS.Knopf = knopf

local function gewaehlterPlan()
    for _, p in ipairs(liste) do if p.key == auswahl then return p end end
    return nil
end

local zeichnen
local function bauen()
    f = fensterBasis("siikkTalentAuswahl", 540, 456, NS.TITEL)
    f.info = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); f.info:SetPoint("TOPLEFT", 18, -42); f.info:SetWidth(504); f.info:SetJustifyH("LEFT")
    f.tbc = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.tbc:SetPoint("TOPLEFT", f.info, "BOTTOMLEFT", 0, -4); f.tbc:SetWidth(504); f.tbc:SetJustifyH("LEFT")
    local box = CreateFrame("Frame", nil, f, "BackdropTemplate")
    box:SetPoint("TOPLEFT", 14, -82); box:SetSize(512, ZEILEN * ZH + 8)
    box:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    box:SetBackdropColor(0, 0, 0, .35); box:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .35)
    box:EnableMouseWheel(true)
    box:SetScript("OnMouseWheel", function(_, d) oben = math.max(0, math.min(oben - d, math.max(0, #liste - ZEILEN))); zeichnen() end)
    f.box = box
    for i = 1, ZEILEN do
        local z = CreateFrame("Button", nil, box)
        z:SetSize(480, ZH - 2); z:SetPoint("TOPLEFT", 4, -4 - (i - 1) * ZH)
        z:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
        z.sel = z:CreateTexture(nil, "BACKGROUND"); z.sel:SetAllPoints(); z.sel:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], .22)
        z.quelle = z:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); z.quelle:SetPoint("LEFT", 6, 0); z.quelle:SetWidth(52); z.quelle:SetJustifyH("LEFT")
        z.name = z:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); z.name:SetPoint("TOPLEFT", 60, -2); z.name:SetWidth(300); z.name:SetJustifyH("LEFT")
        z.unter = z:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); z.unter:SetPoint("TOPLEFT", z.name, "BOTTOMLEFT", 0, -1); z.unter:SetWidth(300); z.unter:SetJustifyH("LEFT")
        z.status = z:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); z.status:SetPoint("RIGHT", -6, 0); z.status:SetWidth(150); z.status:SetJustifyH("RIGHT")
        z:SetScript("OnClick", function(s) auswahl = s.key; zeichnen() end)
        z:SetScript("OnDoubleClick", function(s) auswahl = s.key; NS.PlanAktivieren(s.key) end)
        z:SetScript("OnEnter", function(s)
            local p; for _, x in ipairs(liste) do if x.key == s.key then p = x end end
            if not p then return end
            GameTooltip:SetOwner(s, "ANCHOR_RIGHT"); GameTooltip:AddLine(p.name, 1, .82, 0)
            GameTooltip:AddLine((L"%s · %d Punkte · Verteilung %s"):format(p.typ or "", #p.seq, NS.PunkteJeBaum(p.seq)), .85, .85, .85)
            local ok, i, grund = NS.PlanStatus(p)
            if not ok then GameTooltip:AddLine((L"Passt nicht zum Spiel – Punkt %d: %s"):format(i or 0, grund or "?"), 1, .4, .4, true) end
            -- die ersten Talente des Plans
            local namen, gesehen = {}, {}
            for _, q in ipairs(p.seq) do
                local key = NS.Schluessel(q[1], q[2], q[3])
                if not gesehen[key] then
                    gesehen[key] = true
                    local t = NS.Talent(q[1], q[2], q[3])
                    namen[#namen + 1] = t and t.name or "?"
                    if #namen >= 6 then break end
                end
            end
            if #namen > 0 then GameTooltip:AddLine(L"Beginnt mit: " .. table.concat(namen, ", ") .. " ...", .7, .7, .7, true) end
            GameTooltip:AddLine(L"Doppelklick: aktivieren", .6, .6, .6)
            GameTooltip:Show()
        end)
        z:SetScript("OnLeave", function() GameTooltip:Hide() end)
        zeilen[i] = z
    end
    local function pfeil(template, ersatz)
        local ok, b = pcall(CreateFrame, "Button", nil, box, template)
        if ok and b then return b end
        b = CreateFrame("Button", nil, box, "UIPanelButtonTemplate"); b:SetSize(22, 20); b:SetText(ersatz)
        return b
    end
    local hoch = pfeil("UIPanelScrollUpButtonTemplate", "^"); hoch:SetPoint("TOPRIGHT", -4, -4)
    hoch:SetScript("OnClick", function() oben = math.max(0, oben - 1); zeichnen() end)
    local runter = pfeil("UIPanelScrollDownButtonTemplate", "v"); runter:SetPoint("BOTTOMRIGHT", -4, 4)
    runter:SetScript("OnClick", function() oben = math.min(math.max(0, #liste - ZEILEN), oben + 1); zeichnen() end)
    f.hoch, f.runter = hoch, runter

    f.detail = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); f.detail:SetPoint("TOPLEFT", box, "BOTTOMLEFT", 4, -6); f.detail:SetWidth(504); f.detail:SetJustifyH("LEFT")

    local w = 122
    f.aktivieren = knopf(f, L"Aktivieren", w, function() if auswahl then NS.PlanAktivieren(auswahl) end end)
    f.neu = knopf(f, L"Neu", w, function() if NS.Planer then NS.Planer(nil) end end)
    f.bearbeiten = knopf(f, L"Bearbeiten", w, function() local p = gewaehlterPlan(); if p and NS.Planer then NS.Planer(p) end end)
    f.loeschen = knopf(f, L"Löschen", w, function()
        local p = gewaehlterPlan(); if not (p and p.eigen) then return end
        if StaticPopup_Show and StaticPopupDialogs then
            StaticPopupDialogs.SIIKKTALENT_LOESCHEN = { text = L"Plan „%s“ wirklich löschen?", button1 = YES or "OK", button2 = NO or "X",
                OnAccept = function(_, key) NS.PlanLoeschen(key); auswahl = nil; zeichnen() end,
                timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3 }
            StaticPopup_Show("SIIKKTALENT_LOESCHEN", p.name, nil, p.key)
        else NS.PlanLoeschen(p.key); auswahl = nil; zeichnen() end
    end)
    f.import = knopf(f, L"Import", w, function() if NS.Import then NS.Import() end end)
    f.export = knopf(f, L"Export", w, function() local p = gewaehlterPlan(); if p and NS.Export then NS.Export(p) end end)
    f.optionen = knopf(f, L"Einstellungen", w, function() if NS.Optionen then NS.Optionen() end end)
    f.schliessen = knopf(f, L"Schließen", w, function() f:Hide() end)
    local reihe1 = { f.aktivieren, f.neu, f.bearbeiten, f.loeschen }
    local reihe2 = { f.import, f.export, f.optionen, f.schliessen }
    for i, b in ipairs(reihe1) do b:SetPoint("BOTTOMLEFT", 14 + (i - 1) * (w + 6), 40) end
    for i, b in ipairs(reihe2) do b:SetPoint("BOTTOMLEFT", 14 + (i - 1) * (w + 6), 12) end
end

zeichnen = function()
    if not f then return end
    liste = NS.Plaene()
    local aktivKey = NS.CharDB().aktiv
    local gefunden = false
    for _, p in ipairs(liste) do if p.key == auswahl then gefunden = true end end
    if not gefunden then auswahl = (NS.PlanHolen(aktivKey) and aktivKey) or (liste[1] and liste[1].key) or nil end
    oben = math.max(0, math.min(oben, #liste - ZEILEN))
    f.titel:SetText(NS.TITEL .. "  " .. GR .. "· " .. (L"Pläne für %s"):format(NS.KlassenName()) .. "|r")
    local aktiv = NS.AktiverPlan()
    local frei = NS.frei or 0
    local s = aktiv and ((L"Aktiver Plan: %s"):format(G .. aktiv.name .. "|r")) or (R .. L"Noch kein Plan aktiv – wähle einen aus und klicke „Aktivieren“." .. "|r")
    if aktiv and frei > 0 then s = s .. "  " .. Y .. "(" .. (L"%d freie Punkte"):format(frei) .. ")|r" end
    f.info:SetText(s)
    if not NS.GUIDE_AKTIV then
        f.tbc:SetText(L"Guide-Pläne von siikk-guide.de gibt es nur für WoW Forever. Hier kannst du eigene Pläne erstellen oder importieren.")
    elseif #liste == 0 then
        f.tbc:SetText(L"Für deine Klasse gibt es noch keine Pläne.")
    else
        f.tbc:SetText(GR .. L"Vorgeschlagene Pläne von siikk-guide.de und deine eigenen. Mausrad: blättern." .. "|r")
    end
    for i = 1, ZEILEN do
        local z, p = zeilen[i], liste[oben + i]
        if p then
            z.key = p.key
            z.quelle:SetText(p.eigen and (LILA .. L"Eigen" .. "|r") or (Y .. L"Guide" .. "|r"))
            z.name:SetText(p.name)
            z.unter:SetText((L(p.typ or "") ~= "" and (L(p.typ) .. " · ") or "") .. NS.PunkteJeBaum(p.seq) .. " · " .. (L"%d Punkte"):format(#p.seq))
            local ok = NS.PlanStatus(p)
            local st = ""
            if not ok then st = R .. L"passt nicht zum Spiel" .. "|r" end
            if p.key == aktivKey then st = "|TInterface\\RaidFrame\\ReadyCheck-Ready:14|t " .. G .. L"aktiv" .. "|r" .. (ok and "" or ("\n" .. st)) end
            z.status:SetText(st)
            z.sel:SetShown(p.key == auswahl)
            z:Show()
        else z.key = nil; z:Hide() end
    end
    f.hoch:SetShown(#liste > ZEILEN); f.runter:SetShown(#liste > ZEILEN)
    local p = gewaehlterPlan()
    f.aktivieren:SetEnabled(p ~= nil and p.key ~= aktivKey)
    f.bearbeiten:SetEnabled(p ~= nil)
    f.bearbeiten:SetText(p and not p.eigen and L"Als Kopie bearbeiten" or L"Bearbeiten")
    f.loeschen:SetEnabled(p ~= nil and p.eigen)
    f.export:SetEnabled(p ~= nil)
    if p then
        local ok, i, grund = NS.PlanStatus(p)
        if ok then f.detail:SetText(GR .. (L"Ausgewählt: %s · %d Punkte (bis Stufe %d)"):format(p.name, #p.seq, NS.StufeFuer(#p.seq)) .. "|r")
        else f.detail:SetText(R .. (L"Passt nicht zum Spiel – Punkt %d: %s"):format(i or 0, grund or "?") .. "|r") end
    else f.detail:SetText("") end
end

function NS.AuswahlNeu() if f and f:IsShown() then zeichnen() end end

function NS.Auswahl(erstesMal)
    if not f then bauen() end
    if f:IsShown() and not erstesMal then f:Hide() return end
    if InCombatLockdown and InCombatLockdown() and erstesMal then
        if SiikkIntroWarte then SiikkIntroWarte(function() NS.Auswahl(true) end) end
        return
    end
    NS.Karte()
    zeichnen()
    f:Show()
end
