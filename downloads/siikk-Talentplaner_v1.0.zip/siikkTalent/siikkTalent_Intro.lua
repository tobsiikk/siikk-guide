-- siikk-Talentplaner · Einführung beim ersten Start (/tp intro)
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local Y = "|cffffd100"
siikkIntro("siikk-Talentplaner", NS.TITEL, NS.ICON, {
    { L"Willkommen beim siikk-Talentplaner",
      L"Nie wieder überlegen, wohin der nächste Talentpunkt gehört.\n\n" ..
      L"Du wählst vor dem Leveln einen " .. Y .. L"Plan|r. Sobald du eine Stufe aufsteigst und einen freien Punkt hast, erscheint ein kleines Fenster mit dem Talent, das jetzt dran ist – mit Symbol, Baum und Rang.\n\n" ..
      L"• Ist das Talentfenster offen, leuchtet das passende Talent dort golden-grün.\n\n" ..
      L"• Sobald der Punkt verteilt ist, verschwindet die Erinnerung bis zum nächsten Punkt." },
    { L"Pläne wählen",
      L"Mit " .. Y .. "/tp|r " .. L"oder dem Minimap-Knopf öffnest du die Plan-Auswahl.\n\n" ..
      L"• " .. Y .. L"Guide-Pläne|r " .. L"sind die Skillungen von siikk-guide.de – zum Leveln, für Raids, PvP und Hybride.\n\n" ..
      L"• Zu Beginn ist der Leveln-Plan deiner Klasse vorgeschlagen. Für einen anderen wählst du ihn aus und klickst " .. Y .. L"Aktivieren|r.\n\n" ..
      L"• Hast du anders geskillt als der Plan, zeigt dir das Addon trotzdem den nächsten sinnvollen Schritt." },
    { L"Eigene Pläne",
      L"Im " .. Y .. L"Planer|r " .. L"baust du deinen eigenen Plan: Linksklick setzt den nächsten Punkt, Rechtsklick nimmt ihn wieder weg. Die Talentregeln werden dabei geprüft, und du siehst zu jedem Punkt die Stufe.\n\n" ..
      L"• " .. Y .. L"Import|r: " .. L"Auf siikk-guide.de bekommst du zu jeder Skillung einen Code (siikk1:...). Einfach einfügen, Namen geben, speichern.\n\n" ..
      L"• " .. Y .. L"Export|r: " .. L"Jeder Plan lässt sich als Code kopieren und an Freunde weitergeben." },
    { L"Befehle",
      Y .. "/tp|r " .. L"– Pläne wählen" .. "\n" .. Y .. "/tp planer|r " .. L"– neuen Plan erstellen" .. "\n" ..
      Y .. "/tp import|r · " .. Y .. "/tp export|r " .. L"– Code einfügen / kopieren" .. "\n" ..
      Y .. "/tp optionen|r " .. L"– Einstellungen" .. " · " .. Y .. "/tp an|r / " .. Y .. "/tp aus|r " .. L"– Erinnerung ein/aus" .. "\n" ..
      Y .. "/tp jetzt|r " .. L"– nächstes Talent anzeigen" .. "\n" ..
      Y .. "/tp intro|r " .. L"– diese Einführung" .. " · " .. Y .. "/tp neu|r " .. L"– was ist neu" .. "\n\n" ..
      L"Minimap-Knopf: " .. Y .. L"Linksklick|r " .. L"= Pläne, " .. Y .. L"Rechtsklick|r " .. L"= Einstellungen." },
}, function() return rawget(_G, "siikkTalent_DB") end, "/tp intro")
