-- siikk-Talentplaner · Minimap-Knopf
local ADDON, NS = ...
local L = siikkL or function(s) return s end
NS.MMKnopf = siikkMinimapKnopf("siikk-Talentplaner", NS.TITEL, NS.ICON,
    function() local db = NS.DB(); db.mm = db.mm or {}; return db.mm end,
    function() NS.Auswahl() end,
    function() NS.Optionen() end,
    { L"Linksklick: Pläne und Planer", L"Rechtsklick: Einstellungen" }, 230)
