-- siikk-Talentplaner · „Was ist neu?“
local ADDON, NS = ...
local L = siikkL or function(s) return s end
siikkNeu("siikk-Talentplaner", NS.TITEL, NS.ICON, "1.0",
{
    { version = "1.0", datum = "03.11.2026", punkte = {
        L"Neues Addon: erinnert dich bei jedem freien Talentpunkt, welches Talent laut deinem Plan jetzt dran ist.",
        L"Guide-Pläne von siikk-guide.de für alle 9 Klassen – Leveln, Raid, PvP und Hybride.",
        L"Eigener Planer mit Regelprüfung, Import- und Export-Code.",
        L"Das empfohlene Talent leuchtet im Talentfenster; Lernen per Knopfdruck, wo das Spiel es erlaubt.",
        L"Einstellungen mit Rechtsklick auf den Minimap-Knopf oder /tp optionen." } }
}, function() return rawget(_G, "siikkTalent_DB") end, "/tp neu")
