-- siikk-Talentplaner · Einstellungen (/tp optionen, Rechtsklick auf den Minimap-Knopf)
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local f

local function bauen()
    f = NS.FensterBasis("siikkTalentOptionen", 400, 268, NS.TITEL .. "  |cff999999v" .. NS.VERSION .. "|r")
    f.haken = {}
    local function haken(y, text, key)
        local cb = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate"); cb:SetSize(24, 24); cb:SetPoint("TOPLEFT", 18, y)
        cb.l = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); cb.l:SetPoint("LEFT", cb, "RIGHT", 4, 1); cb.l:SetText(text); cb.l:SetWidth(330); cb.l:SetJustifyH("LEFT")
        cb:SetScript("OnClick", function(s)
            NS.DB()[key] = s:GetChecked() and true or false
            if key == "erinnerung" then NS.weg = nil; NS.Aktualisieren(true) end
        end)
        cb.key = key; f.haken[#f.haken + 1] = cb
    end
    haken(-42, L"Erinnerung bei freien Talentpunkten", "erinnerung")
    haken(-70, L"Ton beim Erscheinen der Erinnerung", "ton")
    haken(-98, L"Hinweis im Chat beim Erscheinen", "chat")
    haken(-126, L"Empfohlenes Talent im Talentfenster hervorheben", "hervorheben")
    haken(-154, L"Erinnerungsfenster sperren (nicht verschiebbar)", "gesperrt")
    local r = NS.Knopf(f, L"Fenster zurücksetzen", 170, function() NS.FensterZuruecksetzen() end); r:SetPoint("BOTTOMLEFT", 14, 40)
    local s = NS.Knopf(f, L"Sprache", 120, function() if SiikkSpracheOeffnen then SiikkSpracheOeffnen() end end); s:SetPoint("BOTTOMRIGHT", -14, 40)
    local p = NS.Knopf(f, L"Pläne", 170, function() if NS.Auswahl then NS.Auswahl() end end); p:SetPoint("BOTTOMLEFT", 14, 12)
    local z = NS.Knopf(f, L"Schließen", 120, function() f:Hide() end); z:SetPoint("BOTTOMRIGHT", -14, 12)
end

function NS.FensterZuruecksetzen()
    NS.DB().pos = nil
    if NS.ErinnerungPosition then NS.ErinnerungPosition() end
    for _, n in ipairs({ "siikkTalentAuswahl", "siikkTalentPlaner", "siikkTalentImport", "siikkTalentOptionen" }) do
        local fr = rawget(_G, n)
        if fr and fr.ClearAllPoints then fr:ClearAllPoints(); fr:SetPoint("CENTER") end
    end
    NS.msg(L"Fensterpositionen zurückgesetzt.")
end

function NS.Optionen()
    if not f then bauen() end
    if f:IsShown() then f:Hide() return end
    local db = NS.DB()
    for _, cb in ipairs(f.haken) do cb:SetChecked(db[cb.key] and true or false) end
    f:Show()
end
