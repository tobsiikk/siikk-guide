-- siikk-Talentplaner · Planer: eigene Pläne Punkt für Punkt erstellen
-- Linksklick = nächsten Punkt setzen (mit Regelprüfung) · Rechtsklick = letzten Punkt dieses Talents entfernen
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local Y, G, R, GR = NS.Y, NS.G, NS.R, NS.GR
local GOLD = NS.GOLD
local ZELLE, KN, BAUM_B = 44, 34, 192
local FARBE = { "|cff9fc3ff", "|cffffb066", "|cff7ee08a" }

local f
local P = { seq = {}, name = "", id = nil }     -- Plan, der gerade bearbeitet wird
NS.PlanerPlan = P
local knoepfe, linien, baeume = {}, {}, {}

local function stand()
    local z = NS.LeererStand()
    for _, p in ipairs(P.seq) do NS.PunktSetzen(z, p[1], p[2], p[3]) end
    return z
end
NS.PlanerStand = stand

local function meldung(t) if f then f.meldung:SetText(t or "") end end

-- Talent hinzufügen / entfernen (auch für Tests aufrufbar) --------------------------
function NS.PlanerHinzufuegen(b, r, s)
    local ok, grund = NS.PunktErlaubt(stand(), b, r, s)
    if not ok then meldung(R .. grund .. "|r"); return false, grund end
    P.seq[#P.seq + 1] = { b, r, s }
    P.geaendert = true
    meldung("")
    if NS.PlanerZeichnen then NS.PlanerZeichnen() end
    return true
end

function NS.PlanerEntfernen(b, r, s)
    local key = NS.Schluessel(b, r, s)
    local j
    for i = #P.seq, 1, -1 do
        local p = P.seq[i]
        if NS.Schluessel(p[1], p[2], p[3]) == key then j = i break end
    end
    if not j then local g = L"Dieses Talent ist nicht im Plan."; meldung(R .. g .. "|r"); return false, g end
    local neu = {}
    for i, p in ipairs(P.seq) do if i ~= j then neu[#neu + 1] = p end end
    local ok, i, grund = NS.FolgePruefen(neu)
    if not ok then
        local g = (L"Geht nicht – Punkt %d baut darauf auf: %s"):format(i, grund or "?")
        meldung(R .. g .. "|r"); return false, g
    end
    P.seq = neu; P.geaendert = true
    meldung("")
    if NS.PlanerZeichnen then NS.PlanerZeichnen() end
    return true
end

function NS.PlanerLaden(plan)
    P.seq, P.id, P.geaendert, P.warnung = {}, nil, false, nil
    if plan then
        for i, p in ipairs(plan.seq) do P.seq[i] = { p[1], p[2], p[3] } end
        if plan.eigen then P.id = plan.id; P.name = plan.name
        else P.name = plan.name .. L" (Kopie)" end
        local ok, i, grund = NS.FolgePruefen(P.seq)
        if not ok then
            for k = #P.seq, i, -1 do P.seq[k] = nil end
            P.warnung = (L"Ab Punkt %d passt der Plan nicht zum Spiel (%s) – die Punkte danach wurden entfernt."):format(i, grund or "?")
            P.geaendert = true
        end
    else
        P.name = ""
    end
end

-- Fenster ------------------------------------------------------------------------------
local function zellePos(r, s) return 8 + (s - 1) * ZELLE + (ZELLE - KN) / 2, -(28 + (r - 1) * ZELLE) end

local function linie(baum, x1, y1, x2, y2)
    local t = baum:CreateTexture(nil, "BORDER")
    if x1 == x2 then t:SetPoint("TOPLEFT", baum, "TOPLEFT", x1 - 1.5, math.max(y1, y2)); t:SetSize(3, math.abs(y1 - y2))
    else t:SetPoint("TOPLEFT", baum, "TOPLEFT", math.min(x1, x2), y1 + 1.5); t:SetSize(math.abs(x1 - x2), 3) end
    t:SetColorTexture(.45, .45, .45, .9)
    return t
end

local function tooltip(b)
    local t = b.t
    GameTooltip:SetOwner(b, "ANCHOR_RIGHT")
    -- Talent-Tooltip vom Spiel holen; manche Clients liefern über SetTalent nichts (leerer Tooltip)
    local function leer()
        local l1 = _G["GameTooltipTextLeft1"]
        return GameTooltip:NumLines() == 0 or not l1 or (l1:GetText() or "") == ""
    end
    local link = GetTalentLink and select(2, pcall(GetTalentLink, t.b, t.index))
    if type(link) == "string" and link ~= "" then pcall(GameTooltip.SetHyperlink, GameTooltip, link) end
    if leer() then GameTooltip:ClearLines(); pcall(GameTooltip.SetTalent, GameTooltip, t.b, t.index) end
    if leer() then
        GameTooltip:ClearLines()
        GameTooltip:AddLine(t.name or "?", 1, .82, 0)
    else
        -- Titel sicher gut lesbar machen
        local l1 = _G["GameTooltipTextLeft1"]
        if l1 and (l1:GetText() or "") ~= "" then l1:SetTextColor(1, .82, 0) end
    end
    local z = stand()
    local n = z.rang[NS.Schluessel(t.b, t.r, t.s)] or 0
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine((L"Im Plan: %d/%d"):format(n, t.max), 1, .82, 0)
    local stufen = {}
    for i, p in ipairs(P.seq) do if p[1] == t.b and p[2] == t.r and p[3] == t.s then stufen[#stufen + 1] = NS.StufeFuer(i) end end
    if #stufen > 0 then GameTooltip:AddLine(L"Auf Stufe: " .. table.concat(stufen, ", "), .8, .8, .8, true) end
    local erlaubt, grund = NS.PunktErlaubt(z, t.b, t.r, t.s)
    if not erlaubt then GameTooltip:AddLine(grund, 1, .4, .4, true) end
    GameTooltip:AddLine(L"Linksklick: Punkt hinzufügen · Rechtsklick: letzten Punkt entfernen", .6, .6, .6, true)
    GameTooltip:Show()
end

local function baeumeBauen()
    local k = NS.Karte()
    if (k.anzahl or 0) == 0 then return false end
    local reihen = math.max(7, k.maxReihe or 7)
    f.reihen = reihen
    for b = 1, 3 do
        local baum = CreateFrame("Frame", nil, f, "BackdropTemplate")
        baum:SetSize(BAUM_B, 28 + reihen * ZELLE + 4)
        baum:SetPoint("TOPLEFT", 14 + (b - 1) * (BAUM_B + 8), -104)
        baum:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
        baum:SetBackdropColor(0, 0, 0, .45); baum:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .35)
        local tb = k.baum[b] or {}
        if type(tb.bild) == "string" and tb.bild ~= "" then
            local bg = baum:CreateTexture(nil, "BACKGROUND", nil, 1); bg:SetPoint("TOPLEFT", 1, -1); bg:SetPoint("BOTTOMRIGHT", -1, 1)
            local pfad = tb.bild:find("\\") and tb.bild or ("Interface\\TalentFrame\\" .. tb.bild .. "-TopLeft")
            bg:SetTexture(pfad); bg:SetAlpha(.3)
        end
        baum.kopf = baum:CreateFontString(nil, "OVERLAY", "GameFontNormal"); baum.kopf:SetPoint("TOP", 0, -6)
        baum.name = tb.name or ("Baum " .. b)
        baeume[b] = baum
        knoepfe[b] = {}
        for r, reihe in pairs(k[b] or {}) do
            for s, t in pairs(reihe) do
                local x, y = zellePos(r, s)
                local btn = CreateFrame("Button", nil, baum)
                btn:SetSize(KN, KN); btn:SetPoint("TOPLEFT", x, y); btn:SetFrameLevel(baum:GetFrameLevel() + 3)
                btn.rand = btn:CreateTexture(nil, "BACKGROUND"); btn.rand:SetPoint("TOPLEFT", -2, 2); btn.rand:SetPoint("BOTTOMRIGHT", 2, -2)
                btn.ic = btn:CreateTexture(nil, "ARTWORK"); btn.ic:SetAllPoints(); btn.ic:SetTexture(t.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
                btn.rbg = btn:CreateTexture(nil, "OVERLAY"); btn.rbg:SetSize(26, 13); btn.rbg:SetPoint("BOTTOMRIGHT", 5, -5); btn.rbg:SetColorTexture(0, 0, 0, .85)
                btn.rang = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); btn.rang:SetPoint("CENTER", btn.rbg, "CENTER", 0, 0)
                btn:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
                btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
                btn.t = t
                btn:SetScript("OnClick", function(s2, taste)
                    if taste == "RightButton" then NS.PlanerEntfernen(t.b, t.r, t.s) else NS.PlanerHinzufuegen(t.b, t.r, t.s) end
                    if GameTooltip:IsOwned(s2) then tooltip(s2) end
                end)
                btn:SetScript("OnEnter", tooltip)
                btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
                knoepfe[b][NS.Schluessel(b, r, s)] = btn
                -- Verbindungslinien zu Voraussetzungen
                for _, v in ipairs(t.vor) do
                    local vx, vy = zellePos(v[1], v[2])
                    local cx, cy, vcx, vcy = x + KN / 2, y - KN / 2, vx + KN / 2, vy - KN / 2
                    local teile = {}
                    if v[2] == s then teile[1] = linie(baum, cx, vy - KN, cx, y)
                    elseif v[1] == r then teile[1] = linie(baum, (v[2] < s) and (vx + KN) or vx, cy, (v[2] < s) and x or (x + KN), cy)
                    else
                        teile[1] = linie(baum, (v[2] < s) and (vx + KN) or vx, vcy, cx, vcy)
                        teile[2] = linie(baum, cx, vcy, cx, y)
                    end
                    linien[#linien + 1] = { teile = teile, b = b, vor = NS.Schluessel(b, v[1], v[2]) }
                end
            end
        end
    end
    -- Reihenfolge rechts
    local x0 = 14 + 3 * (BAUM_B + 8)
    local rahmen = CreateFrame("Frame", nil, f, "BackdropTemplate")
    rahmen:SetPoint("TOPLEFT", x0, -104); rahmen:SetSize(f:GetWidth() - x0 - 14, 28 + reihen * ZELLE + 4)
    rahmen:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    rahmen:SetBackdropColor(0, 0, 0, .45); rahmen:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .35)
    local kt = rahmen:CreateFontString(nil, "OVERLAY", "GameFontNormal"); kt:SetPoint("TOP", 0, -6); kt:SetText(L"Reihenfolge")
    local sf = CreateFrame("ScrollFrame", "siikkTalentPlanerListe", rahmen, "UIPanelScrollFrameTemplate")
    sf:SetPoint("TOPLEFT", 6, -26); sf:SetPoint("BOTTOMRIGHT", -26, 6)
    local kind = CreateFrame("Frame", nil, sf); kind:SetSize(rahmen:GetWidth() - 34, 10)
    sf:SetScrollChild(kind)
    f.liste = kind:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); f.liste:SetPoint("TOPLEFT", 0, 0); f.liste:SetWidth(rahmen:GetWidth() - 36)
    f.liste:SetJustifyH("LEFT"); f.liste:SetJustifyV("TOP")
    f.listeKind, f.scroll = kind, sf
    return true
end

local function bauen()
    local h = 104 + 28 + 9 * ZELLE + 4 + 48
    f = NS.FensterBasis("siikkTalentPlaner", 14 + 3 * (BAUM_B + 8) + 250 + 14, h, NS.TITEL .. "  " .. GR .. L"· Planer" .. "|r")
    local nl = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); nl:SetPoint("TOPLEFT", 18, -46); nl:SetText(L"Name:")
    local eb = CreateFrame("EditBox", "siikkTalentPlanerName", f, "InputBoxTemplate")
    eb:SetSize(240, 22); eb:SetPoint("LEFT", nl, "RIGHT", 12, 0); eb:SetAutoFocus(false); eb:SetMaxLetters(40)
    eb:SetScript("OnEscapePressed", function(s) s:ClearFocus() end); eb:SetScript("OnEnterPressed", function(s) s:ClearFocus() end)
    eb:SetScript("OnTextChanged", function(s, user) if user then P.name = s:GetText() or ""; P.geaendert = true end end)
    f.name = eb
    f.info = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); f.info:SetPoint("LEFT", eb, "RIGHT", 16, 0); f.info:SetWidth(400); f.info:SetJustifyH("LEFT")
    f.meldung = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.meldung:SetPoint("TOPLEFT", 18, -74); f.meldung:SetWidth(f:GetWidth() - 36); f.meldung:SetJustifyH("LEFT")
    f.warnung = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.warnung:SetPoint("TOPLEFT", 18, -88); f.warnung:SetWidth(f:GetWidth() - 36); f.warnung:SetJustifyH("LEFT")
    local w = 138
    local function k(text, fn) return NS.Knopf(f, text, w, fn) end
    f.k = {
        k(L"Letzten entfernen", function()
            local p = P.seq[#P.seq]; if p then P.seq[#P.seq] = nil; P.geaendert = true; meldung(""); NS.PlanerZeichnen() end
        end),
        k(L"Alles leeren", function() P.seq = {}; P.geaendert = true; meldung(""); NS.PlanerZeichnen() end),
        k(L"Export", function() if NS.Export then NS.Export({ name = P.name, seq = P.seq }) end end),
        k(L"Speichern", function() NS.PlanerSpeichern(false) end),
        k(L"Speichern + aktivieren", function() NS.PlanerSpeichern(true) end),
        k(L"Schließen", function() f:Hide() end),
    }
    for i, b in ipairs(f.k) do b:SetPoint("BOTTOMLEFT", 14 + (i - 1) * (w + 6), 14) end
    f:SetScript("OnHide", function() GameTooltip:Hide() end)
end

function NS.PlanerSpeichern(aktivieren)
    if #P.seq == 0 then meldung(R .. L"Der Plan ist noch leer." .. "|r") return nil end
    if f and f.name then P.name = f.name:GetText() or P.name end
    local key = NS.PlanSpeichern(P.name, P.seq, P.id)
    P.id = tonumber(key:match("^e:(%d+)$")); P.geaendert = false
    local plan = NS.PlanHolen(key)
    if plan then P.name = plan.name; if f and f.name then f.name:SetText(plan.name) end end
    meldung(G .. (L"Gespeichert: %s"):format(P.name) .. "|r")
    NS.msg((L"Plan gespeichert: %s"):format(Y .. P.name .. "|r"))
    if aktivieren then NS.PlanAktivieren(key) end
    if NS.AuswahlNeu then NS.AuswahlNeu() end
    if NS.PlanerZeichnen then NS.PlanerZeichnen() end
    return key
end

function NS.PlanerZeichnen()
    if not (f and f.reihen) then return end
    local z = stand()
    local n = #P.seq
    for b = 1, 3 do
        local baum = baeume[b]
        if baum then baum.kopf:SetText(FARBE[b] .. (baum.name or "") .. "|r  " .. Y .. (z.baum[b] or 0) .. "|r") end
        for key, btn in pairs(knoepfe[b] or {}) do
            local t = btn.t
            local hat = z.rang[key] or 0
            btn.rang:SetText(hat .. "/" .. t.max)
            local erlaubt = NS.PunktErlaubt(z, b, t.r, t.s)
            if hat >= t.max then btn.rand:SetColorTexture(1, .82, .1, 1); btn.ic:SetDesaturated(false); btn.ic:SetAlpha(1); btn.rang:SetTextColor(1, .82, .1)
            elseif hat > 0 then btn.rand:SetColorTexture(.2, 1, .3, 1); btn.ic:SetDesaturated(false); btn.ic:SetAlpha(1); btn.rang:SetTextColor(.2, 1, .3)
            elseif erlaubt then btn.rand:SetColorTexture(.5, .5, .5, 1); btn.ic:SetDesaturated(false); btn.ic:SetAlpha(1); btn.rang:SetTextColor(1, 1, 1)
            else btn.rand:SetColorTexture(.2, .2, .2, 1); btn.ic:SetDesaturated(true); btn.ic:SetAlpha(.55); btn.rang:SetTextColor(.6, .6, .6) end
        end
    end
    local k = NS.Karte()
    for _, l in ipairs(linien) do
        local v = l.vor
        local vb, vr, vs = math.floor(v / 100), math.floor(v / 10) % 10, v % 10
        local vt = k[vb] and k[vb][vr] and k[vb][vr][vs]
        local voll = vt and (z.rang[v] or 0) >= vt.max
        for _, t in ipairs(l.teile) do
            if voll then t:SetColorTexture(1, .82, .1, .95) else t:SetColorTexture(.45, .45, .45, .9) end
        end
    end
    -- Kopfzeile
    local info = (L"Punkte: %d/%d"):format(n, NS.MAX_PUNKTE) .. "  ·  " .. NS.PunkteJeBaum(P.seq)
    if n < NS.MAX_PUNKTE then info = info .. "  ·  " .. (L"nächster Punkt: Stufe %d"):format(NS.StufeFuer(n + 1)) end
    f.info:SetText(info .. (P.geaendert and (GR .. "  " .. L"(nicht gespeichert)" .. "|r") or ""))
    f.warnung:SetText(P.warnung and ("|cffff9933" .. P.warnung .. "|r") or "")
    -- Reihenfolge
    local zeilen = {}
    for i, p in ipairs(P.seq) do
        local t = NS.Talent(p[1], p[2], p[3])
        local bis = 0
        for j = 1, i do local q = P.seq[j]; if q[1] == p[1] and q[2] == p[2] and q[3] == p[3] then bis = bis + 1 end end
        zeilen[#zeilen + 1] = GR .. NS.StufeFuer(i) .. "|r  " .. FARBE[p[1]] .. (t and t.name or "?") .. "|r " .. GR .. bis .. "/" .. (t and t.max or "?") .. "|r"
    end
    if #zeilen == 0 then zeilen[1] = GR .. L"Noch leer – klicke links auf Talente." .. "|r" end
    f.liste:SetText(table.concat(zeilen, "\n"))
    local hoehe = f.liste.GetStringHeight and f.liste:GetStringHeight() or 10
    if type(hoehe) ~= "number" or hoehe < 10 then hoehe = 10 end
    f.listeKind:SetHeight(hoehe + 4)
    if f.k then
        f.k[1]:SetEnabled(n > 0); f.k[2]:SetEnabled(n > 0); f.k[3]:SetEnabled(n > 0); f.k[4]:SetEnabled(n > 0); f.k[5]:SetEnabled(n > 0)
    end
end

function NS.Planer(plan)
    if InCombatLockdown and InCombatLockdown() then NS.msg(L"Im Kampf nicht möglich.") return end
    if not f then bauen() end
    if not f.reihen then
        if not baeumeBauen() then NS.msg(L"Die Talentdaten sind noch nicht geladen – bitte gleich noch einmal versuchen.") return end
        f:SetHeight(104 + 28 + f.reihen * ZELLE + 4 + 50)
    end
    NS.PlanerLaden(plan)
    f.name:SetText(P.name or "")
    meldung("")
    NS.PlanerZeichnen()
    f:Show()
end
