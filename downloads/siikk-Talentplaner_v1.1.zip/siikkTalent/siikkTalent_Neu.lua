-- siikk-Talentplaner · „Was ist neu?“
local ADDON, NS = ...
local L = siikkL or function(s) return s end
siikkNeu("siikk-Talentplaner", NS.TITEL, NS.ICON, NS.VERSION,
{
    { version = "1.1", datum = "03.11.2026", punkte = {
        L"Neu: läuft jetzt auch im aktuellen WoW (Midnight) – mit Klassen-, Spezialisierungs- und Heldentalenten.",
        L"Retail: vorgeschlagene Builds für alle 40 Spezialisierungen (Raid und Mythisch+, Quelle im Tooltip).",
        L"Retail: eigene Pläne per Talent-Code – im Blizzard-Talentfenster planen, exportieren, hier importieren; oder „Aktuelle Skillung“ speichern.",
        L"TBC Anniversary: vorgeschlagene Pläne für alle 9 Klassen (Leveln und Endspiel, 61 Punkte).",
        L"Neuer Befehl: /tp speichern (Retail) – aktuelle Skillung als Plan." } },
    { version = "1.0", datum = "03.11.2026", punkte = {
        L"Neues Addon: erinnert dich bei jedem freien Talentpunkt, welches Talent laut deinem Plan jetzt dran ist.",
        L"Guide-Pläne von siikk-guide.de für alle 9 Klassen – Leveln, Raid, PvP und Hybride.",
        L"Eigener Planer mit Regelprüfung, Import- und Export-Code.",
        L"Das empfohlene Talent leuchtet im Talentfenster; Lernen per Knopfdruck, wo das Spiel es erlaubt.",
        L"Einstellungen mit Rechtsklick auf den Minimap-Knopf oder /tp optionen." } }
}, function() return rawget(_G, "siikkTalent_DB") end, "/tp neu")
