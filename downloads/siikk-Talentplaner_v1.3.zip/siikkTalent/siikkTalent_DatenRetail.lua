-- siikk-Talentplaner · Retail-Builds (WoW Midnight 12.1.5) – erzeugt aus tools/retail_daten_bauen.py (nicht von Hand ändern)
-- NS.GUIDE_RETAIL[specID] = { { id, held, fokus, zusatz, typ, code = Blizzard-Talent-Code, quelle = { name, url, stand } }, ... }
local ADDON, NS = ...
NS = NS or {}
NS.DATEN_RETAIL_STAND = "03.11.2026"
NS.DATEN_RETAIL_PATCH = "12.1.5"
NS.RETAIL_SPECS = {}
NS.GUIDE_RETAIL = {}
local S, G = NS.RETAIL_SPECS, NS.GUIDE_RETAIL
S[250] = { klasse = "DEATHKNIGHT", name = "Blut", en = "Blood" }
G[250] = {
    { id = "250-san-layn-einzelziel", held = "San'layn", fokus = "Einzelziel", typ = "Raid", code = "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMbzMz0MbGzMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDklBsBYGzAAAmZghB", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/blood-death-knight/talents", stand = "Patch 12.1.5" } },
    { id = "250-san-layn-mythisch", held = "San'layn", fokus = "Mythisch+", typ = "Mythisch+", code = "CoPAAAAAAAAAAAAAAAAAAAAAAwMzyMzMmxMzMMLzMz0MLGjxMGAAAAwMmZmZmZYGDAYmZmZGAAADMwMW0YZBklBsBYGzAAAmZghB", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/blood-death-knight/talents", stand = "Patch 12.1.5" } },
}
S[251] = { klasse = "DEATHKNIGHT", name = "Frost", en = "Frost" }
G[251] = {
    { id = "251-deathbringer-raid-breath-of-sindragosa", held = "Deathbringer", fokus = "Raid", zusatz = "Breath of Sindragosa", typ = "Raid", code = "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjZAz2MzMzMLzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBYmBD", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/frost-death-knight/talents", stand = "Patch 12.1.5" } },
    { id = "251-deathbringer-mythisch-frostbane", held = "Deathbringer", fokus = "Mythisch+", zusatz = "Frostbane", typ = "Mythisch+", code = "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMjZAz2MzMzMLzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBYmBD", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/frost-death-knight/talents", stand = "Patch 12.1.5" } },
}
S[252] = { klasse = "DEATHKNIGHT", name = "Unheilig", en = "Unholy" }
G[252] = {
    { id = "252-san-layn-einzelziel", held = "San'layn", fokus = "Einzelziel", typ = "Raid", code = "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMDDz2MzMTjZmxYGDAAAAAAAAzDMMGAsMDzsZmxMzYgBmxiGLbA2mYDAzAYmZmZMDmZwMzYA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/unholy-death-knight/talents", stand = "Patch 12.1.5" } },
    { id = "252-rider-of-the-apocalypse-mythisch", held = "Rider of the Apocalypse", fokus = "Mythisch+", typ = "Mythisch+", code = "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMDDz2MzMTzmxMzMjBAAAAAAAgZGzYAwyMmZ2MzYMDYzsZYIDMbM0YBDYGAGzMjZAmZmxYA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/unholy-death-knight/talents", stand = "Patch 12.1.5" } },
}
S[577] = { klasse = "DEMONHUNTER", name = "Verwüstung", en = "Havoc" }
G[577] = {
    { id = "577-fel-scarred-raid", held = "Fel-Scarred", fokus = "Raid", typ = "Raid", code = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxMzkxMDAAAAAAY2MmtZYmBPwMWmZegZYmxYWGYbWMjhZTTjZmxwGAAAAAAAAzMYAAAAYA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/havoc-demon-hunter/talents", stand = "Patch 12.1.5" } },
    { id = "577-fel-scarred-mythisch", held = "Fel-Scarred", fokus = "Mythisch+", typ = "Mythisch+", code = "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxMzkxMDAAAAAAY2MmtZYmBmxyMzDMDzMGzyAbziZMMbaaMzMG2AAAAGAAAAzMYAAAAYA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/havoc-demon-hunter/talents", stand = "Patch 12.1.5" } },
}
S[581] = { klasse = "DEMONHUNTER", name = "Rachsucht", en = "Vengeance" }
G[581] = {
    { id = "581-annihilator-raid", held = "Annihilator", fokus = "Raid", typ = "Raid", code = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMzMjMzMYWMzMjBjZGzYGzMDzMzM2MzsNGAAAAAAAIgZmxGAAAAGMmZmZ2abmZGAYAAAAMA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/vengeance-demon-hunter/talents", stand = "Patch 12.1.5" } },
    { id = "581-annihilator-mythisch", held = "Annihilator", fokus = "Mythisch+", typ = "Mythisch+", code = "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMMzkZmB2MjZwMjZGzMzMzYwMzM2YmtxwAAAAAAAIgZmZ2AAAAwAzMzMzWbzMzAADAAAgB", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/vengeance-demon-hunter/talents", stand = "Patch 12.1.5" } },
}
S[1480] = { klasse = "DEMONHUNTER", name = "Verschlinger", en = "Devourer" }
G[1480] = {
    { id = "1480-annihilator-einzelziel", held = "Annihilator", fokus = "Einzelziel", typ = "Raid", code = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWmxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMjZmZGzsYGjFtswMzMzWbzMzAYGDABegxghB", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/devourer-demon-hunter/talents", stand = "Patch 12.1.5" } },
    { id = "1480-annihilator-mythisch", held = "Annihilator", fokus = "Mythisch+", typ = "Mythisch+", code = "CgcBAAAAAAAAAAAAAAAAAAAAAAAWmxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAQgHYMDjZA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/devourer-demon-hunter/talents", stand = "Patch 12.1.5" } },
}
S[102] = { klasse = "DRUID", name = "Gleichgewicht", en = "Balance" }
G[102] = {
    { id = "102-elune-s-chosen-einzelziel", held = "Elune's Chosen", fokus = "Einzelziel", typ = "Raid", code = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMYYGjZWmhxMWYZmlZGjZ2wAgx2yMDGz2IwEAAAgFzMzMD2MMGzAAYmBLDA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/balance-druid/talents", stand = "Patch 12.1.5" } },
    { id = "102-elune-s-chosen-mythisch", held = "Elune's Chosen", fokus = "Mythisch+", typ = "Mythisch+", code = "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNMmZgxsMzMzMLMgxMLzsYMzswyMLjxMjNMAYstNzgxsNCMBAAAYhZmZGsZMjxAAwMDWGA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/balance-druid/talents", stand = "Patch 12.1.5" } },
}
S[103] = { klasse = "DRUID", name = "Wildheit", en = "Feral" }
G[103] = {
    { id = "103-druid-of-the-claw-einzelziel", held = "Druid of the Claw", fokus = "Einzelziel", typ = "Raid", code = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwghxYmZmxsxDsMz2MzMmZGAAAAWCmNYMzomxsMzMzMGzYGAAAAAAgBAAAQzsMLzMzACsAmZAWMDGAAAzshB", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/feral-druid/talents", stand = "Patch 12.1.5" } },
    { id = "103-wildstalker-mythisch", held = "Wildstalker", fokus = "Mythisch+", typ = "Mythisch+", code = "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2M2mZZGzMmZAAAAYJY2MMmZUzYWMzMzsMmhBAAAAAAYAAAAEAMLzs0sMzyGYmBYxMYAAMzAgB", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/feral-druid/talents", stand = "Patch 12.1.5" } },
}
S[104] = { klasse = "DRUID", name = "Wächter", en = "Guardian" }
G[104] = {
    { id = "104-elune-s-chosen-raid", held = "Elune's Chosen", fokus = "Raid", typ = "Raid", code = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmhFzYMzmZZGMLLDMbMGNRzMzyMzMzYMjZAAAAAAzYZGwy2MDGz2AYKAAAwGmxAWMDGwiltBYmBwA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/guardian-druid/talents", stand = "Patch 12.1.5" } },
    { id = "104-elune-s-chosen-mythisch", held = "Elune's Chosen", fokus = "Mythisch+", typ = "Mythisch+", code = "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJamZWmZmZmlxMMAAAAAgZsZALbzMYMLDgpAAAAbYmHAYxMYALWAYmBwA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/guardian-druid/talents", stand = "Patch 12.1.5" } },
}
S[105] = { klasse = "DRUID", name = "Wiederherstellung", en = "Restoration" }
G[105] = {
    { id = "105-wildstalker-raid", held = "Wildstalker", fokus = "Raid", typ = "Raid", code = "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthHYYmNjtxMAAAAAAAAAAYZQzmZMNzYYMLzMzMDDzAAAAAAAAAAIAAgZbmlmtZ2sxYmBmBoZAAmZAYA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/restoration-druid/talents", stand = "Patch 12.1.5" } },
    { id = "105-wildstalker-mythisch", held = "Wildstalker", fokus = "Mythisch+", typ = "Mythisch+", code = "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsN8ADzsYsZbGAAAAAAAAAAsMoZbGmmZMwsYmZmZZGegBAAAAgBAYGAACAAY2mZrZbmFbMzMwMzCoZAAmZAYA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/restoration-druid/talents", stand = "Patch 12.1.5" } },
}
S[1467] = { klasse = "EVOKER", name = "Verheerung", en = "Devastation" }
G[1467] = {
    { id = "1467-scalecommander-einzelziel", held = "Scalecommander", fokus = "Einzelziel", typ = "Raid", code = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzMDMDzwMgBjZaMzMNjx2wMzMzMzMzAmZmxYmZZmZgBGD2glxox2AYGA2wMYmBDD", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/devastation-evoker/talents", stand = "Patch 12.1.5" } },
    { id = "1467-scalecommander-mythisch", held = "Scalecommander", fokus = "Mythisch+", typ = "Mythisch+", code = "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZAMzwMwMYMTjZmpZmZ2mhZmZmZmZGwMzMGzMLzMDMwYwGsMGN2GAzAwGGYmBDD", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/devastation-evoker/talents", stand = "Patch 12.1.5" } },
}
S[1468] = { klasse = "EVOKER", name = "Bewahrung", en = "Preservation" }
G[1468] = {
    { id = "1468-flameshaper-raid", held = "Flameshaper", fokus = "Raid", typ = "Raid", code = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAgZMjZwYGZmZAAAAmZmJzYmxYmZAwMmBWALgZYCZzwmhBwMzYA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/preservation-evoker/talents", stand = "Patch 12.1.5" } },
    { id = "1468-flameshaper-mythisch", held = "Flameshaper", fokus = "Mythisch+", typ = "Mythisch+", code = "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZ2WGzYYMPwsZGw2wAAAzYGzYmhZiZmBAAAMzMTGzMjZZMDAMmBWAbgZYCZzM2MMDwMDD", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/preservation-evoker/talents", stand = "Patch 12.1.5" } },
}
S[1473] = { klasse = "EVOKER", name = "Verstärkung", en = "Augmentation" }
G[1473] = {
    { id = "1473-chronowarden-raid", held = "Chronowarden", fokus = "Raid", typ = "Raid", code = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAAAAYmhxMYM1YmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNwCGjZGAYA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/augmentation-evoker/talents", stand = "Patch 12.1.5" } },
    { id = "1473-chronowarden-mythisch", held = "Chronowarden", fokus = "Mythisch+", typ = "Mythisch+", code = "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAAAAYmhZGYM1YmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNwCGzMzAAD", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/augmentation-evoker/talents", stand = "Patch 12.1.5" } },
}
S[253] = { klasse = "HUNTER", name = "Tierherrschaft", en = "Beast Mastery" }
G[253] = {
    { id = "253-pack-leader-einzelziel", held = "Pack Leader", fokus = "Einzelziel", typ = "Raid", code = "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZYYmxYmxMzYmZGmxYGzgx0MAAAAgZAAAYMzMDYmNCDzCYbAYA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/beast-mastery-hunter/talents", stand = "Patch 12.1.5" } },
    { id = "253-dark-ranger-mythisch", held = "Dark Ranger", fokus = "Mythisch+", typ = "Mythisch+", code = "C0PAAAAAAAAAAAAAAAAAAAAAAYzsNwAGwMsBZsAAgZGzMziZYGmxMjZmZYGzMjZmZsNzMMmhlhmBAAAAMDAAAzDMmZYmBEwsA2GAA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/beast-mastery-hunter/talents", stand = "Patch 12.1.5" } },
}
S[254] = { klasse = "HUNTER", name = "Treffsicherheit", en = "Marksmanship" }
G[254] = {
    { id = "254-dark-ranger-mythisch", held = "Dark Ranger", fokus = "Mythisch+", typ = "Mythisch+", code = "C4PAAAAAAAAAAAAAAAAAAAAAAYzsMwAmgZYLwsAAAAAAAAAmxMzMMjZmxMYMNjBzymZMzMzMzMLMzywMAAAzDMmxMzMgsBDwGzsNjB", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/marksmanship-hunter/talents", stand = "Patch 12.1.5" } },
}
S[255] = { klasse = "HUNTER", name = "Überleben", en = "Survival" }
G[255] = {
    { id = "255-pack-leader-einzelziel", held = "Pack Leader", fokus = "Einzelziel", typ = "Raid", code = "C8PAAAAAAAAAAAAAAAAAAAAAAMgxMGWIbwMM0glZMzMmZWGAAAAAAmxMmZZbGjZMDeATzAAAAMAYGLLzMzixMjxMDgZ2AmFjhxmBA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/survival-hunter/talents", stand = "Patch 12.1.5" } },
    { id = "255-pack-leader-mehrere-ziele", held = "Pack Leader", fokus = "Mehrere Ziele", typ = "Mythisch+", code = "C8PAAAAAAAAAAAAAAAAAAAAAAMgxMGWILwMM0gFzMzMzMWGAAAAAAmxMzMLbzYMjZwYaGAAAgBAPwYZZm5BWYmZwYMgZ2AYGjZmNDA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/survival-hunter/talents", stand = "Patch 12.1.5" } },
}
S[62] = { klasse = "MAGE", name = "Arkan", en = "Arcane" }
G[62] = {
    { id = "62-spellslinger-einzelziel", held = "Spellslinger", fokus = "Einzelziel", typ = "Raid", code = "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMDamxAAAwAAgAmZmZZZmJWAAYDzMzM2sMzMzyMGjZmBLMzMzMDAwAAAMzsAAmBADzMD", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/arcane-mage/talents", stand = "Patch 12.1.5" } },
    { id = "62-spellslinger-mythisch", held = "Spellslinger", fokus = "Mythisch+", typ = "Mythisch+", code = "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMDamxAAAwAAgAmZmZZZmJWAAYbwMzwmlZMjZMmZmZGWYmZmZGAgBAAYmZDAMDAGmZG", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/arcane-mage/talents", stand = "Patch 12.1.5" } },
}
S[63] = { klasse = "MAGE", name = "Feuer", en = "Fire" }
G[63] = {
    { id = "63-sunfury-raid-season-1", held = "Sunfury", fokus = "Raid", zusatz = "Season 1", typ = "Raid", code = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMzIzMGAAAGAwMz0sstMDAwmZmx2YmZGLAAAAAYxMzMDAAMmxMmZmZmFAMzQGjxgZYMA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/fire-mage/talents", stand = "Patch 12.1.5" } },
    { id = "63-sunfury-raid-season-2", held = "Sunfury", fokus = "Raid", zusatz = "Season 2", typ = "Raid", code = "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMzIzMGAAAGAwMz0sstMDAwmZmx2MzMzYBAAAAALmZmZAAgZMmZmZMzsMAMzQGjBMDjB", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/fire-mage/talents", stand = "Patch 12.1.5" } },
}
S[64] = { klasse = "MAGE", name = "Frost", en = "Frost" }
G[64] = {
    { id = "64-spellslinger-raid", held = "Spellslinger", fokus = "Raid", typ = "Raid", code = "CAEAAAAAAAAAAAAAAAAAAAAAAMzwYZm5BmFMzEzMGzMzMziZmZMjZAAAgZmZWWmZaDAA2AAAALAstMmZmZY2GGzwCAAAzsBMTGDYGMMA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/frost-mage/talents", stand = "Patch 12.1.5" } },
    { id = "64-spellslinger-mythisch", held = "Spellslinger", fokus = "Mythisch+", typ = "Mythisch+", code = "CAEAAAAAAAAAAAAAAAAAAAAAAMzwYZm5BmFMzEzMGzMzMziZmZMjZgAAAzMzssMz0GAAsBAAAWAYbZMzMzwsNMmhFAAAmZDYGGDYGMMA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/frost-mage/talents", stand = "Patch 12.1.5" } },
}
S[268] = { klasse = "MONK", name = "Braumeister", en = "Brewmaster" }
G[268] = {
    { id = "268-shado-pan-raid", held = "Shado-Pan", fokus = "Raid", typ = "Raid", code = "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGzwYWmxGzMjBAAAAAAYZBzEzMwMMzGDmZmZY2GmxMLPALbPwy2sNmBAAshAAAMbzSzMzsxwGAzMMNGAAwA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/brewmaster-monk/talents", stand = "Patch 12.1.5" } },
    { id = "268-shado-pan-mythisch", held = "Shado-Pan", fokus = "Mythisch+", typ = "Mythisch+", code = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEzMwMM2MMmZmZY2YmxYZYZ7BW2mNMLAAwGCAAwsNLNzMzGDbAMzw0YAAAD", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/brewmaster-monk/talents", stand = "Patch 12.1.5" } },
}
S[269] = { klasse = "MONK", name = "Windläufer", en = "Windwalker" }
G[269] = {
    { id = "269-shado-pan-einzelziel", held = "Shado-Pan", fokus = "Einzelziel", typ = "Raid", code = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AgZZWamZmFAMwMDAjlBiB8B", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/windwalker-monk/talents", stand = "Patch 12.1.5" } },
    { id = "269-shado-pan-mythisch", held = "Shado-Pan", fokus = "Mythisch+", typ = "Mythisch+", code = "C0QAAAAAAAAAAAAAAAAAAAAAAMzYAMGbzMz2MAAAAAAAAAAAALDz0MmhhBMMMzMzwsNMDzyDMBAsYmtZmxMzMDAgNAYWmlmZmZBADMzAwYZgYAD", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/windwalker-monk/talents", stand = "Patch 12.1.5" } },
}
S[270] = { klasse = "MONK", name = "Nebelwirker", en = "Mistweaver" }
G[270] = {
    { id = "270-conduit-of-the-celestials-raid", held = "Conduit of the Celestials", fokus = "Raid", typ = "Raid", code = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmZbGbYmZYmlttZGLMjmxMgBDGWmZmZYWGMYxEAAAAABYxyMLz2MDAAMgBYGwYYsMZMDA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/mistweaver-monk/talents", stand = "Patch 12.1.5" } },
    { id = "270-conduit-of-the-celestials-mythisch", held = "Conduit of the Celestials", fokus = "Mythisch+", typ = "Mythisch+", code = "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMWmZZYxixMzsZsssND2Mz22yMjFmRzYGwgBjZZmZmhZbYGmlZCAAAAgAsYbmlZbmBAAAGgZADwiMmBA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/mistweaver-monk/talents", stand = "Patch 12.1.5" } },
}
S[65] = { klasse = "PALADIN", name = "Heilig", en = "Holy" }
G[65] = {
    { id = "65-herald-of-the-sun-raid-beacon-of-virtue", held = "Herald of the Sun", fokus = "Raid", zusatz = "Beacon of Virtue", typ = "Raid", code = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADAbgNWmxMLz2Mzs1AAAAsAGYzwYGDmBAwMDzYMaA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/holy-paladin/talents", stand = "Patch 12.1.5" } },
    { id = "65-herald-of-the-sun-raid-beacon-of-faith", held = "Herald of the Sun", fokus = "Raid", zusatz = "Beacon of Faith", typ = "Raid", code = "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAwyMzMjZ2mZmNYMsM2mZWMTTMMmZGGzWGAGA2AbsMjZWmtZmZrBAAAYBMwmhxMGYAAMzwMGjGA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/holy-paladin/talents", stand = "Patch 12.1.5" } },
}
S[66] = { klasse = "PALADIN", name = "Schutz", en = "Protection" }
G[66] = {
    { id = "66-lightsmith-raid", held = "Lightsmith", fokus = "Raid", typ = "Raid", code = "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyMzYmZmx2yYMLzithBAYAAAAAAQamZZmxMzYMbtBgBMwMYDAAgAMzsst0yMjFbbYAwYGGAwMDAmZQGL", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/protection-paladin/talents", stand = "Patch 12.1.5" } },
    { id = "66-lightsmith-mythisch", held = "Lightsmith", fokus = "Mythisch+", typ = "Mythisch+", code = "CIEAAAAAAAAAAAAAAAAAAAAAAsZsNLjZMzMzMLLjxYWmlZMAADAAAAAAaamZZmxMDzMbtBgBGwAbAAAEgZmltlWmZsYbBDAYGGDAmZAwMDyYB", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/protection-paladin/talents", stand = "Patch 12.1.5" } },
}
S[70] = { klasse = "PALADIN", name = "Vergeltung", en = "Retribution" }
G[70] = {
    { id = "70-templar-einzelziel", held = "Templar", fokus = "Einzelziel", typ = "Raid", code = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzywMDAAAAAAzUmtZYmx2Y2GmZbGjxMDzYhtBAAkZm2mZ2mBAsBYAwYGGYGjZDbzghxMGMA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/retribution-paladin/talents", stand = "Patch 12.1.5" } },
    { id = "70-templar-mythisch", held = "Templar", fokus = "Mythisch+", typ = "Mythisch+", code = "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxGbAAAZmptZmtZAAbAGAMmhBmxMzGWmBDjZMYA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/retribution-paladin/talents", stand = "Patch 12.1.5" } },
}
S[256] = { klasse = "PRIEST", name = "Disziplin", en = "Discipline" }
G[256] = {
    { id = "256-oracle-raid", held = "Oracle", fokus = "Raid", typ = "Raid", code = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMGWmZmBDmZbmtZmZmxMDAAAAAAAAAgZYZGMzMDzwMgpZamBYmFMEGzyAMGsAAAjxMjBzAMzMTwA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/discipline-priest/talents", stand = "Patch 12.1.5" } },
    { id = "256-oracle-mythisch", held = "Oracle", fokus = "Mythisch+", typ = "Mythisch+", code = "CAQAAAAAAAAAAAAAAAAAAAAAAADsMDWmZMPwMwMbzYmZmZMzAAAAAAAAAAYGWmBzMzgxMD2MNTMAzsghwYWGgxgFAAYMzMjBzAMzMTwM", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/discipline-priest/talents", stand = "Patch 12.1.5" } },
}
S[257] = { klasse = "PRIEST", name = "Heilig", en = "Holy" }
G[257] = {
    { id = "257-oracle-raid", held = "Oracle", fokus = "Raid", typ = "Raid", code = "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMDgZqBwMLYIMmlBYMwiZmZBQzYMGDzMAzMzAD", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/holy-priest/talents", stand = "Patch 12.1.5" } },
    { id = "257-oracle-mythisch", held = "Oracle", fokus = "Mythisch+", typ = "Mythisch+", code = "CEQAAAAAAAAAAAAAAAAAAAAAAwYAAAAAAAMzMmlxMjZGDzALzMzMAAAAGzsMzYmZmhhZGAzUAMzCGCjZbAGDsYMzCgmxMjxgZAmZmBGA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/holy-priest/talents", stand = "Patch 12.1.5" } },
}
S[258] = { klasse = "PRIEST", name = "Schatten", en = "Shadow" }
G[258] = {
    { id = "258-archon-raid", held = "Archon", fokus = "Raid", typ = "Raid", code = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/shadow-priest/talents", stand = "Patch 12.1.5" } },
    { id = "258-archon-mythisch", held = "Archon", fokus = "Mythisch+", typ = "Mythisch+", code = "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbjxMzyMGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/shadow-priest/talents", stand = "Patch 12.1.5" } },
}
S[259] = { klasse = "ROGUE", name = "Meucheln", en = "Assassination" }
G[259] = {
    { id = "259-fatebound-raid", held = "Fatebound", fokus = "Raid", typ = "Raid", code = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsZwAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AjxMjxYmZmxAYgFYGjGzGIbDYzAgZmBD", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/assassination-rogue/talents", stand = "Patch 12.1.5" } },
    { id = "259-fatebound-mythisch", held = "Fatebound", fokus = "Mythisch+", typ = "Mythisch+", code = "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AmxMjxMmZMGADsAzY0YWAZbAbGAMzMDfA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/assassination-rogue/talents", stand = "Patch 12.1.5" } },
}
S[260] = { klasse = "ROGUE", name = "Gesetzlosigkeit", en = "Outlaw" }
G[260] = {
    { id = "260-trickster-einzelziel", held = "Trickster", fokus = "Einzelziel", typ = "Raid", code = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwQGYWYhWYjBYmBDMA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/outlaw-rogue/talents", stand = "Patch 12.1.5" } },
    { id = "260-trickster-mehrere-ziele", held = "Trickster", fokus = "Mehrere Ziele", typ = "Mythisch+", code = "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwQGYWYhWYjBYmBDMA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/outlaw-rogue/talents", stand = "Patch 12.1.5" } },
}
S[261] = { klasse = "ROGUE", name = "Täuschung", en = "Subtlety" }
G[261] = {
    { id = "261-trickster-einzelziel", held = "Trickster", fokus = "Einzelziel", typ = "Raid", code = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMjZwMzMzYMbDzYbbmZmZmZMYMz2AAAAwgxAGzmhBGYW0CtYDzAmZwMGA", quelle = { name = "Icy Veins", url = "https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents", stand = "Patch 12.0.5 / 12.1.5" } },
    { id = "261-trickster-mehrere-ziele", held = "Trickster", fokus = "Mehrere Ziele", typ = "Mythisch+", code = "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMjZMegZmZGjZbYGbbzMzMzMjBjZWGAAAAGMGwY2MMwAziWoFbYGwMDmxA", quelle = { name = "Icy Veins", url = "https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents", stand = "Patch 12.0.5 / 12.1.5" } },
}
S[262] = { klasse = "SHAMAN", name = "Elementar", en = "Elemental" }
G[262] = {
    { id = "262-farseer-raid", held = "Farseer", fokus = "Raid", typ = "Raid", code = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMbzMzYstMTbMzglZmZGzglZmlhxMzCAwwAYmxwwA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/elemental-shaman/talents", stand = "Patch 12.1.5" } },
    { id = "262-farseer-mythisch", held = "Farseer", fokus = "Mythisch+", typ = "Mythisch+", code = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMLzMzYstYajZmtxyMzMjhFLzMLDjZmFAgBAmZMMMA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/elemental-shaman/talents", stand = "Patch 12.1.5" } },
}
S[263] = { klasse = "SHAMAN", name = "Verstärkung", en = "Enhancement" }
G[263] = {
    { id = "263-stormbringer-einzelziel", held = "Stormbringer", fokus = "Einzelziel", typ = "Raid", code = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLkFYGGawCAz2MmxYZZGbMzsNWmZmZYsMGAAzwYmhZCMzgBjB", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/enhancement-shaman/talents", stand = "Patch 12.1.5" } },
    { id = "263-stormbringer-mythisch", held = "Stormbringer", fokus = "Mythisch+", typ = "Mythisch+", code = "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZZGbMzYsMzMzMGLjBAwMMmZYEYmBDGDA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/enhancement-shaman/talents", stand = "Patch 12.1.5" } },
}
S[264] = { klasse = "SHAMAN", name = "Wiederherstellung", en = "Restoration" }
G[264] = {
    { id = "264-totemic-raid", held = "Totemic", fokus = "Raid", typ = "Raid", code = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzYMzYmBjFYDmxmGbDgZgNzgBLjZmpZbZmZxMmF2m5BmZMYWGAAAYmZwMDAMYG", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/restoration-shaman/talents", stand = "Patch 12.1.5" } },
    { id = "264-totemic-mythisch", held = "Totemic", fokus = "Mythisch+", typ = "Mythisch+", code = "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsstMzMzMjZGjZgFYDmxiGbDIzAbMzMY2mZMa2WmZ2MjZhFjZGDLzyAAAAzMDmZAgBzA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/restoration-shaman/talents", stand = "Patch 12.1.5" } },
}
S[265] = { klasse = "WARLOCK", name = "Gebrechen", en = "Affliction" }
G[265] = {
    { id = "265-soul-harvester-einzelziel", held = "Soul Harvester", fokus = "Einzelziel", typ = "Raid", code = "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlBAAYmZxyMzsMzAAjllBGwEMDbBG2GAAAmBAAwMDzMjBGmZmZGzgZmZGAwMwA", quelle = { name = "Icy Veins", url = "https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents", stand = "Patch 12.0.5 / 12.1.5" } },
    { id = "265-hellcaller-mehrere-ziele", held = "Hellcaller", fokus = "Mehrere Ziele", typ = "Mythisch+", code = "CkQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxiZGzyAAAmZmlZzMzyYAALwAziRjZAZ2ALDAAAzAAAzMYMzMmtxYGmZmZYYmZmBAMDMA", quelle = { name = "Icy Veins", url = "https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents", stand = "Patch 12.0.5 / 12.1.5" } },
}
S[266] = { klasse = "WARLOCK", name = "Dämonologie", en = "Demonology" }
G[266] = {
    { id = "266-diabolist-einzelziel", held = "Diabolist", fokus = "Einzelziel", typ = "Raid", code = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjxmZGzyAAAAAAAAGzYYBGYb0GNsYwMLzyMzMmBAmhZmZmZAGzYMbAAgZmZmZGzwyMGwA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/demonology-warlock/talents", stand = "Patch 12.1.5" } },
    { id = "266-diabolist-mythisch", held = "Diabolist", fokus = "Mythisch+", typ = "Mythisch+", code = "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjxmZGzyAAAAAAAAGzYYBGYb0GNsYYmZZ2mZmxMAwMMmZmZAGzYMbAAgZmZmZGzwyMGwA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/demonology-warlock/talents", stand = "Patch 12.1.5" } },
}
S[267] = { klasse = "WARLOCK", name = "Zerstörung", en = "Destruction" }
G[267] = {
    { id = "267-diabolist-einzelziel", held = "Diabolist", fokus = "Einzelziel", typ = "Raid", code = "CsQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmZmlZzMzMLGjFzAAgZmxMzsAGzYYBGYbYjGLMAAwYgxGAmZAMzYMAAAMzMzAAYMM", quelle = { name = "Icy Veins", url = "https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents", stand = "Patch 12.0.5 / 12.1.5" } },
    { id = "267-hellcaller-mehrere-ziele", held = "Hellcaller", fokus = "Mehrere Ziele", typ = "Mythisch+", code = "CsQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmx2MzYWmtZGzsYGLLjBAAzYMzMLWgBmFjGzAY2wGDAAMmhBAAzMYMzwsBAAYmZmBAgZYA", quelle = { name = "Icy Veins", url = "https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents", stand = "Patch 12.0.5 / 12.1.5" } },
}
S[71] = { klasse = "WARRIOR", name = "Waffen", en = "Arms" }
G[71] = {
    { id = "71-slayer-einzelziel", held = "Slayer", fokus = "Einzelziel", typ = "Raid", code = "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzMmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDIMWWGYBMgZYCZGsBmZYsNwyMLDwMDAmhBA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/arms-warrior/talents", stand = "Patch 12.1.5" } },
    { id = "71-colossus-mythisch", held = "Colossus", fokus = "Mythisch+", typ = "Mythisch+", code = "CcEAAAAAAAAAAAAAAAAAAAAAAgZmxsMzMzYGAAAghphxYmxyMzMzwMmZAAAAAM2MDMZDYzMGWgBmRb0YwCYmhx2MMbmtBzMAAzwA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/arms-warrior/talents", stand = "Patch 12.1.5" } },
}
S[72] = { klasse = "WARRIOR", name = "Furor", en = "Fury" }
G[72] = {
    { id = "72-slayer-einzelziel", held = "Slayer", fokus = "Einzelziel", typ = "Raid", code = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDDmx2yMzMzMmxMzMjZmZWmZGjZmthZGAAIGLLDsAmgZYCMDbAzMbMGAAMzYYMzMMYA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/fury-warrior/talents", stand = "Patch 12.1.5" } },
    { id = "72-mountain-thane-mythisch", held = "Mountain Thane", fokus = "Mythisch+", typ = "Mythisch+", code = "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDDzMz2yMmZmxMmZMjZMzyMzYMzsMmZGAAIMwGssZ0YGQmFMjFAzgxAgZGADzMzMMYA", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/fury-warrior/talents", stand = "Patch 12.1.5" } },
}
S[73] = { klasse = "WARRIOR", name = "Schutz", en = "Protection" }
G[73] = {
    { id = "73-mountain-thane-raid", held = "Mountain Thane", fokus = "Raid", typ = "Raid", code = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAzMzwMzYGzmxsMjxY0wMDLzMzMDGzMAAAAYZMAzYAGYDWWMaMDgZLmZDzMmZwsBAzMAAMDMG", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/protection-warrior/talents", stand = "Patch 12.1.5" } },
    { id = "73-mountain-thane-mythisch", held = "Mountain Thane", fokus = "Mythisch+", typ = "Mythisch+", code = "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAjZMmZmZGzmZmlZMGjGzYGLzMzMDDzMAAAAYZmBwYAGYDWWMaMDgZLmZDGzMDjNAYmBAADMG", quelle = { name = "Method.gg", url = "https://www.method.gg/guides/protection-warrior/talents", stand = "Patch 12.1.5" } },
}
