-- siikk-Talentplaner · Erinnerung bei freien Talentpunkten + Hervorhebung im Talentfenster
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local Y, G, R, GR = NS.Y, NS.G, NS.R, NS.GR
local GOLD = NS.GOLD
local ORANGE = "|cffff9933"

local f = CreateFrame("Frame", "siikkTalentErinnerung", UIParent, "BackdropTemplate")
f:SetSize(310, 134); f:SetFrameStrata("MEDIUM"); f:SetClampedToScreen(true); f:Hide()
f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
f:SetBackdropColor(.03, .02, .05, .96); f:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
NS.ErinnerungFenster = f

local kopf = f:CreateTexture(nil, "BORDER"); kopf:SetPoint("TOPLEFT", 4, -4); kopf:SetPoint("TOPRIGHT", -4, -4); kopf:SetHeight(22); kopf:SetColorTexture(.315, .19, .45, .8)
local linie = f:CreateTexture(nil, "ARTWORK"); linie:SetPoint("TOPLEFT", kopf, "BOTTOMLEFT"); linie:SetPoint("TOPRIGHT", kopf, "BOTTOMRIGHT"); linie:SetHeight(1); linie:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], 1)
local kic = f:CreateTexture(nil, "OVERLAY"); kic:SetSize(16, 16); kic:SetPoint("LEFT", kopf, "LEFT", 5, 0); kic:SetTexture(NS.ICON)
local titel = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); titel:SetPoint("LEFT", kic, "RIGHT", 5, 0)
local zu = CreateFrame("Button", nil, f, "UIPanelCloseButton"); zu:SetSize(24, 24); zu:SetPoint("TOPRIGHT", 0, 0)

local ic = f:CreateTexture(nil, "ARTWORK"); ic:SetSize(40, 40); ic:SetPoint("TOPLEFT", 14, -36)
local icRand = f:CreateTexture(nil, "OVERLAY"); icRand:SetPoint("TOPLEFT", ic, -2, 2); icRand:SetPoint("BOTTOMRIGHT", ic, 2, -2)
icRand:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], .55); icRand:SetDrawLayer("BORDER")
local name = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); name:SetPoint("TOPLEFT", ic, "TOPRIGHT", 10, 0); name:SetWidth(234); name:SetJustifyH("LEFT")
local zeile2 = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); zeile2:SetPoint("TOPLEFT", name, "BOTTOMLEFT", 0, -3); zeile2:SetWidth(234); zeile2:SetJustifyH("LEFT")
local zeile3 = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); zeile3:SetPoint("TOPLEFT", zeile2, "BOTTOMLEFT", 0, -3); zeile3:SetWidth(234); zeile3:SetJustifyH("LEFT")
local hinweis = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); hinweis:SetPoint("BOTTOMLEFT", 14, 38); hinweis:SetWidth(282); hinweis:SetJustifyH("LEFT")

local k1 = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); k1:SetSize(138, 22); k1:SetPoint("BOTTOMLEFT", 12, 11)
local k2 = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); k2:SetSize(138, 22); k2:SetPoint("BOTTOMRIGHT", -12, 11)
NS.ErinnerungKnoepfe = { k1, k2 }

-- Position --------------------------------------------------------------------
local function position()
    local p = NS.DB().pos
    f:ClearAllPoints()
    if type(p) == "table" and p[1] then f:SetPoint(p[1], UIParent, p[1], p[2] or 0, p[3] or 0)
    else f:SetPoint("CENTER", UIParent, "CENTER", 0, 190) end
end
NS.ErinnerungPosition = position
f:SetScript("OnDragStart", function(s) if not NS.DB().gesperrt then s:StartMoving() end end)
f:SetScript("OnDragStop", function(s)
    s:StopMovingOrSizing()
    local p, _, _, x, y = s:GetPoint()
    NS.DB().pos = { p or "CENTER", x or 0, y or 0 }
end)
zu:SetScript("OnClick", function() NS.Weggeklickt(); f:Hide() end)

-- Inhalt ------------------------------------------------------------------------
local aktuell = nil
local function knopf(k, text, fn)
    if not text then k:Hide() return end
    k:SetText(text); k:SetScript("OnClick", fn); k:Show(); k:Enable()
end

local function planerMitAktivem()
    local p = NS.AktiverPlan()
    if NS.Planer then NS.Planer(p) end
end

function NS.ErinnerungZeigen(erg)
    aktuell = erg
    position()
    local frei = NS.frei or NS.FreiePunkte()
    titel:SetText(L"Talentpunkt frei!" .. (frei > 1 and (GR .. "  (" .. (L"%d frei"):format(frei) .. ")|r") or ""))
    hinweis:SetText("")
    local plan = erg.plan
    if erg.art == "ok" and erg.t then
        local t = erg.t
        if ic.SetTexCoord then ic:SetTexCoord(0, 1, 0, 1) end
        ic:SetTexture(t.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
        if t.atlas and ic.SetAtlas then pcall(ic.SetAtlas, ic, t.atlas) end
        name:SetText(t.name)
        local baumName = erg.baumName
        if not baumName then local baum = NS.Karte().baum[erg.b]; baumName = baum and baum.name end
        zeile2:SetText((baumName or (L"Baum %d"):format(erg.b)) .. "  ·  " .. (L"Rang %d/%d"):format(erg.rang, t.max))
        zeile3:SetText(erg.zeile3 or (L"Plan: %s · Punkt %d (Stufe %d)"):format(plan.name, erg.schritt, erg.stufe))
        if erg.abweichung then hinweis:SetText(ORANGE .. L"Deine Skillung weicht vom Plan ab – das ist der nächste lernbare Schritt." .. "|r") end
        knopf(k1, L"Talentfenster öffnen", function() NS.TalentfensterOeffnen(erg.b) end)
        knopf(k2, L"Jetzt lernen", function() NS.Lernen(aktuell) end)
        if InCombatLockdown and InCombatLockdown() then k2:Disable() end
    elseif erg.art == "keinplan" then
        ic:SetTexture(NS.ICON)
        name:SetText(L"Kein Plan gewählt")
        zeile2:SetText(L"Wähle einen Plan – dann zeige ich dir bei jedem Punkt das passende Talent.")
        zeile3:SetText("")
        knopf(k1, L"Plan wählen", function() if NS.Auswahl then NS.Auswahl() end end)
        knopf(k2, L"Talentfenster öffnen", function() NS.TalentfensterOeffnen() end)
    elseif erg.art == "fertig" then
        ic:SetTexture(NS.ICON)
        name:SetText(L"Plan komplett umgesetzt")
        zeile2:SetText(L"Dein Plan hat keine weiteren Punkte – verteile den Rest nach Wunsch.")
        zeile3:SetText(plan and (L"Plan: %s"):format(plan.name) or "")
        knopf(k1, L"Talentfenster öffnen", function() NS.TalentfensterOeffnen() end)
        knopf(k2, L"Plan wählen", function() if NS.Auswahl then NS.Auswahl() end end)
    else
        ic:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
        name:SetText(R .. L"Plan passt nicht mehr zu deiner Skillung" .. "|r")
        zeile2:SetText(erg.grund or L"Gerade ist kein Schritt aus dem Plan lernbar.")
        zeile3:SetText(plan and (L"Plan: %s"):format(plan.name) or "")
        if NS.RETAIL then knopf(k1, L"Talentfenster öffnen", function() NS.TalentfensterOeffnen() end)
        else knopf(k1, L"Planer öffnen", planerMitAktivem) end
        knopf(k2, L"Plan wählen", function() if NS.Auswahl then NS.Auswahl() end end)
    end
    f:Show()
end

function NS.ErinnerungVerbergen() aktuell = nil; f:Hide() end
function NS.ErinnerungAktuell() return f:IsShown() and aktuell or nil end

-- Hervorhebung im Blizzard-Talentfenster ------------------------------------------------
-- Classic: TalentFrame / TalentFrameTalent1..n · TBC und neuer: PlayerTalentFrame / PlayerTalentFrameTalent1..n
local glanz = CreateFrame("Frame", nil, UIParent); glanz:Hide()
local gt = glanz:CreateTexture(nil, "OVERLAY"); gt:SetAllPoints(); gt:SetTexture("Interface\\Buttons\\UI-ActionButton-Border"); gt:SetBlendMode("ADD")
local gt2 = glanz:CreateTexture(nil, "OVERLAY"); gt2:SetAllPoints(); gt2:SetTexture("Interface\\Buttons\\UI-ActionButton-Border"); gt2:SetBlendMode("ADD")
NS.Glanz = glanz

local function selectedTab(fr)
    local tab
    if PanelTemplates_GetSelectedTab then
        local ok, x = pcall(PanelTemplates_GetSelectedTab, fr)
        if ok then tab = x end
    end
    return tab or fr.selectedTab or fr.currentSelectedTab
end

local function knopfSuchen(name, index)
    local btn = rawget(_G, name .. "Talent" .. index)
    local function passt(b)
        if type(b) ~= "table" or not b.GetID then return false end
        local ok, id = pcall(b.GetID, b)
        return (not ok) or id == index or id == 0 or id == nil
    end
    if passt(btn) then return btn end
    for i = 1, 40 do                                    -- falls die Knöpfe anders nummeriert sind
        local b = rawget(_G, name .. "Talent" .. i)
        if type(b) == "table" and b.GetID then
            local ok, id = pcall(b.GetID, b)
            if ok and id == index then return b end
        end
    end
    return nil
end

function NS.TalentKnopf(erg)
    if not (erg and erg.art == "ok" and erg.t) then return nil end
    for _, name in ipairs({ "PlayerTalentFrame", "TalentFrame" }) do
        local fr = rawget(_G, name)
        if type(fr) == "table" and fr.IsShown and fr:IsShown() then
            if selectedTab(fr) == erg.b then
                local btn = knopfSuchen(name, erg.t.index)
                if btn and btn.IsVisible and btn:IsVisible() then return btn end
            end
            return nil
        end
    end
    return nil
end

local ziel, takt, zeit = nil, 0, 0
local function glanzSetzen(btn)
    if btn == ziel then return end
    ziel = btn
    if not btn then glanz:Hide() return end
    local ok = pcall(function()
        local w = btn:GetWidth() or 37
        if type(w) ~= "number" or w <= 0 then w = 37 end
        glanz:ClearAllPoints(); glanz:SetPoint("CENTER", btn, "CENTER", 0, 0); glanz:SetSize(w * 1.85, w * 1.85)
        glanz:SetFrameStrata(btn:GetFrameStrata() or "HIGH"); glanz:SetFrameLevel((btn:GetFrameLevel() or 1) + 5)
    end)
    if ok then glanz:Show() else glanz:Hide(); ziel = nil end
end

local ticker = CreateFrame("Frame")
ticker:SetScript("OnUpdate", function(_, el)
    takt = takt + el; zeit = zeit + el
    if takt >= 0.25 then
        takt = 0
        local btn = nil
        local db = NS.DB()
        if db.hervorheben and (NS.frei or 0) > 0 then
            local ok, b = pcall(NS.TalentKnopf, NS.empfehlung)
            if ok then btn = b end
        end
        glanzSetzen(btn)
    end
    if ziel then
        local a = 0.55 + 0.45 * math.sin(zeit * 4)      -- pulsieren: golden ↔ grün
        gt:SetVertexColor(1, .82, .1, 0.35 + a * 0.65)
        gt2:SetVertexColor(.2, 1, .3, (1 - a) * 0.8)
    end
end)

-- Blizzard-Talentfenster geladen: beim Öffnen sofort neu prüfen
function NS.TalentUIGeladen()
    for _, name in ipairs({ "PlayerTalentFrame", "TalentFrame" }) do
        local fr = rawget(_G, name)
        if type(fr) == "table" and fr.HookScript then
            pcall(fr.HookScript, fr, "OnShow", function() takt = 1; if NS.NeuBerechnen then NS.NeuBerechnen() end end)
        end
    end
end
if IsAddOnLoaded or (C_AddOns and C_AddOns.IsAddOnLoaded) then
    local ist = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
    local ok, geladen = pcall(ist, "Blizzard_TalentUI")
    if ok and geladen then NS.TalentUIGeladen() end
end
