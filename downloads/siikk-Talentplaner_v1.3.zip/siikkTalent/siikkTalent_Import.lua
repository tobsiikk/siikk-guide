-- siikk-Talentplaner · Import-Code von siikk-guide.de einfügen / Plan als Code exportieren
-- Code:  siikk1:KLASSE:BRSBRS…   (pro Punkt Baum 1-3, Reihe 1-9, Spalte 1-4)
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local Y, G, R, GR = NS.Y, NS.G, NS.R, NS.GR

-- prüft einen Code für den eigenen Charakter; liefert true, seq, Info  oder  false, Fehlertext
function NS.ImportPruefen(text)
    local klasse, seq = NS.CodeLesen(text)
    if not klasse then return false, seq end
    local meine = NS.Klasse()
    if meine and klasse ~= meine then
        return false, (L"Dieser Code ist für %s – du spielst %s."):format(NS.KlassenName(klasse), NS.KlassenName(meine))
    end
    local ok, i, grund = NS.FolgePruefen(seq)
    if not ok then return false, (L"Punkt %d (Stufe %d): %s"):format(i, NS.StufeFuer(i), grund or "?") end
    return true, seq, (L"Gültig: %d Punkte · Verteilung %s · bis Stufe %d"):format(#seq, NS.PunkteJeBaum(seq), NS.StufeFuer(#seq))
end

local f, modus, exportCode = nil, "import", ""

local function pruefen()
    if modus ~= "import" then return end
    local text = f.code:GetText() or ""
    if text:gsub("%s+", "") == "" then f.status:SetText(GR .. L"Code einfügen (Strg+V)." .. "|r"); f.ok1:Disable(); f.ok2:Disable() return end
    local ok, a, info = NS.ImportPruefen(text)
    if ok then f.status:SetText(G .. info .. "|r"); f.ok1:Enable(); f.ok2:Enable(); f.seq = a
    else f.status:SetText(R .. a .. "|r"); f.ok1:Disable(); f.ok2:Disable(); f.seq = nil end
end

function NS.ImportSpeichern(aktivieren)
    if not (f and f.seq) then return nil end
    local name = f.name:GetText() or ""
    if name:gsub("%s+", "") == "" then name = L"Importierter Plan" end
    local key = NS.PlanSpeichern(name, f.seq, nil)
    if not key then return nil end
    NS.msg((L"Plan importiert: %s"):format(Y .. name .. "|r"))
    if aktivieren then NS.PlanAktivieren(key) end
    if NS.AuswahlNeu then NS.AuswahlNeu() end
    f:Hide()
    return key
end

local function bauen()
    f = NS.FensterBasis("siikkTalentImport", 540, 210, NS.TITEL)
    f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); f.text:SetPoint("TOPLEFT", 18, -44); f.text:SetWidth(504); f.text:SetJustifyH("LEFT")
    local eb = CreateFrame("EditBox", "siikkTalentImportCode", f, "InputBoxTemplate")
    eb:SetSize(496, 24); eb:SetPoint("TOPLEFT", 24, -68); eb:SetAutoFocus(false); eb:SetMaxLetters(600)
    eb:SetScript("OnEscapePressed", function() f:Hide() end)
    eb:SetScript("OnTextChanged", function(s, user)
        if modus == "export" then if user then s:SetText(exportCode); s:HighlightText() end return end
        pruefen()
    end)
    eb:SetScript("OnEditFocusGained", function(s) if modus == "export" then s:HighlightText() end end)
    f.code = eb
    f.nl = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); f.nl:SetPoint("TOPLEFT", 18, -104); f.nl:SetText(L"Name:")
    local nb = CreateFrame("EditBox", "siikkTalentImportName", f, "InputBoxTemplate")
    nb:SetSize(260, 22); nb:SetPoint("LEFT", f.nl, "RIGHT", 12, 0); nb:SetAutoFocus(false); nb:SetMaxLetters(40)
    nb:SetScript("OnEscapePressed", function(s) s:ClearFocus() end); nb:SetScript("OnEnterPressed", function(s) s:ClearFocus() end)
    f.name = nb
    f.status = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.status:SetPoint("TOPLEFT", 18, -132); f.status:SetWidth(504); f.status:SetJustifyH("LEFT")
    f.ok1 = NS.Knopf(f, L"Speichern", 150, function() NS.ImportSpeichern(false) end); f.ok1:SetPoint("BOTTOMLEFT", 14, 12)
    f.ok2 = NS.Knopf(f, L"Speichern + aktivieren", 170, function() NS.ImportSpeichern(true) end); f.ok2:SetPoint("LEFT", f.ok1, "RIGHT", 6, 0)
    f.zu2 = NS.Knopf(f, L"Schließen", 120, function() f:Hide() end); f.zu2:SetPoint("BOTTOMRIGHT", -14, 12)
end

-- Texte/Code für Import und Export – Retail ersetzt NS.ImportText, NS.ExportCode und NS.ExportInfo
function NS.ImportText()
    return L"Füge den Code von siikk-guide.de ein (Strg+V). Er beginnt mit " .. Y .. "siikk1:" .. (NS.Klasse() or "") .. ":|r"
end
function NS.ExportCode(plan) return NS.CodeErzeugen(NS.Klasse() or "?", plan.seq) end
function NS.ExportInfo(plan)
    return (L"%d Punkte · Verteilung %s · mit „Import“ wieder einlesbar"):format(#plan.seq, NS.PunkteJeBaum(plan.seq))
end

-- code/name: optional vorbelegen (Retail: „Aktuelle Skillung speichern“)
function NS.Import(code, name)
    if not f then bauen() end
    modus = "import"; f.seq = nil
    f.titel:SetText(NS.TITEL .. "  " .. GR .. L"· Import" .. "|r")
    f.text:SetText(NS.ImportText())
    f.code:SetText(code or ""); f.name:SetText(name or ""); f.nl:Show(); f.name:Show(); f.ok1:Show(); f.ok2:Show()
    pruefen()
    f:Show()
    if code then f.name:SetFocus(); f.name:HighlightText() else f.code:SetFocus() end
end

function NS.Export(plan)
    if not (plan and ((plan.seq and #plan.seq > 0) or (NS.RETAIL and plan.code))) then NS.msg(L"Der Plan ist noch leer.") return end
    if not f then bauen() end
    modus = "export"
    exportCode = NS.ExportCode(plan)
    f.titel:SetText(NS.TITEL .. "  " .. GR .. L"· Export" .. "|r")
    f.text:SetText((L"Code für „%s“ – ist markiert, mit Strg+C kopieren:"):format(plan.name ~= "" and plan.name or L"Mein Plan"))
    f.nl:Hide(); f.name:Hide(); f.ok1:Hide(); f.ok2:Hide()
    f.status:SetText(GR .. NS.ExportInfo(plan) .. "|r")
    f.code:SetText(exportCode)
    f:Show(); f.code:SetFocus(); f.code:HighlightText()
    return exportCode
end
