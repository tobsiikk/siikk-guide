-- siikk-Talentplaner · Kern: Daten, Pläne, Regeln, Ereignisse, Befehle
-- Pläne werden über (Baum, Reihe, Spalte) mit dem Spiel verbunden – das ist in jeder Sprache gleich.
-- Ein Plan ist eine Folge von Punkten; Punkt i wird auf Stufe 9 + i verteilt (Stufe 10 = 1. Punkt).
local ADDON, NS = ...
local L = siikkL or function(s) return s end
NS.VERSION = "1.3"
NS.MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\Media\\"
NS.ICON = NS.MEDIA .. "siikk_talent_icon"
NS.TITEL = "|cffe03030siikk|r-|cffffd100Talentplaner|r"
NS.GOLD = { .85, .65, .15 }
local Y, G, R, GR = "|cffffd100", "|cff33ff33", "|cffff6060", "|cff999999"
NS.Y, NS.G, NS.R, NS.GR = Y, G, R, GR
function NS.msg(t) print(NS.TITEL .. ": " .. tostring(t)) end

-- Client erkennen -----------------------------------------------------------
local function tocNummer()
    if not GetBuildInfo then return 0 end
    local ok, _, _, _, toc = pcall(GetBuildInfo)
    return ok and tonumber(toc) or 0
end
NS.TOC = tocNummer()
-- Retail (aktuelles WoW, Midnight 12.x): völlig anderes Talentsystem (C_ClassTalents/C_Traits) → eigenes Modul siikkTalent_Retail.lua
-- Nach der Spielversion unterscheiden: WoW Forever (1.60 = 16xxx) läuft auf dem neuen Client und meldet sich
-- ebenfalls als „Mainline“ – hat aber das klassische Talentsystem mit 51 Punkten.
NS.RETAIL = NS.TOC >= 100000 and rawget(_G, "C_ClassTalents") ~= nil and rawget(_G, "C_Traits") ~= nil
NS.FOREVER = NS.TOC >= 16000 and NS.TOC < 20000
NS.TBC = (not NS.RETAIL) and ((WOW_PROJECT_ID ~= nil and WOW_PROJECT_BURNING_CRUSADE_CLASSIC ~= nil and WOW_PROJECT_ID == WOW_PROJECT_BURNING_CRUSADE_CLASSIC)
    or (NS.TOC >= 20000 and NS.TOC < 30000))
NS.MAX_PUNKTE = NS.TBC and 61 or 51            -- Forever/Classic: 51 bei Stufe 60 · TBC: 61 bei Stufe 70
-- Guide-Pläne: Forever → NS.GUIDE (siikk-guide.de) · TBC → NS.GUIDE_TBC (Icy Veins/Wowhead), falls vorhanden · Retail → eigenes Modul
NS.GUIDE_DATEN = (not NS.RETAIL) and ((NS.TBC and NS.GUIDE_TBC) or (not NS.TBC and NS.GUIDE)) or nil
NS.GUIDE_AKTIV = type(NS.GUIDE_DATEN) == "table" and next(NS.GUIDE_DATEN) ~= nil
function NS.StufeFuer(i) return 9 + i end

-- Gespeicherte Daten ----------------------------------------------------------
-- siikkTalent_DB (Konto): Einstellungen + eigene Pläne je Klasse · siikkTalent_Char (Charakter): aktiver Plan
local STANDARD = { erinnerung = true, ton = true, chat = true, hervorheben = true, gesperrt = false }
function NS.DB()
    local db = rawget(_G, "siikkTalent_DB")
    if type(db) ~= "table" then db = {}; siikkTalent_DB = db end
    for k, v in pairs(STANDARD) do if db[k] == nil then db[k] = v end end
    if type(db.eigene) ~= "table" then db.eigene = {} end
    if type(db.naechsteId) ~= "number" then db.naechsteId = 1 end
    return db
end
function NS.CharDB()
    local c = rawget(_G, "siikkTalent_Char")
    if type(c) ~= "table" then c = {}; siikkTalent_Char = c end
    return c
end

function NS.Klasse()
    if not UnitClass then return nil end
    local _, k = UnitClass("player")
    return k
end
function NS.KlassenName(k)
    k = k or NS.Klasse()
    local lok = rawget(_G, "LOCALIZED_CLASS_NAMES_MALE")
    if type(lok) == "table" and lok[k] then return lok[k] end
    local g = (NS.GUIDE_DATEN and NS.GUIDE_DATEN[k]) or (NS.GUIDE and NS.GUIDE[k])
    return g and g.name or tostring(k)
end

-- Codes ----------------------------------------------------------------------
-- Import-Code:  siikk1:KLASSE:BRSBRS…   (pro Punkt Baum 1-3, Reihe 1-9, Spalte 1-4)
local function schluessel(b, r, s) return b * 100 + r * 10 + s end
NS.Schluessel = schluessel

function NS.Dekodieren(ziffern)
    if type(ziffern) ~= "string" then return nil, L"Kein Code." end
    if ziffern:find("[^%d]") then return nil, L"Der Code darf nach der Klasse nur Ziffern enthalten." end
    if #ziffern % 3 ~= 0 then return nil, L"Die Ziffernzahl muss durch 3 teilbar sein (Baum, Reihe, Spalte je Punkt)." end
    local seq = {}
    for i = 1, #ziffern, 3 do
        local b, r, s = tonumber(ziffern:sub(i, i)), tonumber(ziffern:sub(i + 1, i + 1)), tonumber(ziffern:sub(i + 2, i + 2))
        local n = (i + 2) / 3
        if b < 1 or b > 3 then return nil, (L"Punkt %d: Baum muss 1-3 sein."):format(n) end
        if r < 1 or r > 9 then return nil, (L"Punkt %d: Reihe muss 1-9 sein."):format(n) end
        if s < 1 or s > 4 then return nil, (L"Punkt %d: Spalte muss 1-4 sein."):format(n) end
        seq[#seq + 1] = { b, r, s }
    end
    return seq
end

function NS.Kodieren(seq)
    local t = {}
    for i, p in ipairs(seq or {}) do t[i] = p[1] .. p[2] .. p[3] end
    return table.concat(t)
end

function NS.CodeErzeugen(klasse, seq) return "siikk1:" .. tostring(klasse) .. ":" .. NS.Kodieren(seq) end

-- liest einen Import-Code; liefert klasse, seq  oder  nil, Fehlertext
function NS.CodeLesen(text)
    if type(text) ~= "string" then return nil, L"Kein Code." end
    text = text:gsub("%s+", "")
    if text == "" then return nil, L"Kein Code." end
    local ver, klasse, ziffern = text:match("^([%a%d]+):(%a+):(%d*)$")
    if not ver then return nil, L"Das ist kein siikk-Code (Form: siikk1:KLASSE:113113...)." end
    if ver:lower() ~= "siikk1" then return nil, L"Unbekannte Code-Version – bitte das Addon aktualisieren." end
    klasse = klasse:upper()
    if ziffern == "" then return nil, L"Der Code enthält keine Punkte." end
    local seq, fehler = NS.Dekodieren(ziffern)
    if not seq then return nil, fehler end
    if #seq > NS.MAX_PUNKTE then return nil, (L"Zu viele Punkte: %d (höchstens %d)."):format(#seq, NS.MAX_PUNKTE) end
    return klasse, seq
end

-- Talente des Spiels lesen ---------------------------------------------------
-- karte[b][r][s] = { index, name, icon, max, vor = { {r, s}, … } }  ·  karte.baum[b] = { name, icon, bild }
local karte, karteKlasse = nil, nil
local function karteBauen()
    local k = { baum = {}, maxReihe = 0, anzahl = 0 }
    local tabs = 0
    if GetNumTalentTabs then local ok, n = pcall(GetNumTalentTabs); tabs = ok and tonumber(n) or 0 end
    if tabs > 3 then tabs = 3 end
    for b = 1, tabs do
        k[b] = {}
        local tb = { name = "?", punkte = 0 }
        if GetTalentTabInfo then
            local ok, a1, a2, a3, a4, a5, a6, a7, a8 = pcall(GetTalentTabInfo, b)
            if ok then
                -- Classic: name, icon, punkte, hintergrund · neuere Clients: id, name, beschreibung, icon, punkte, hintergrund
                if type(a1) == "number" and type(a2) == "string" then tb.name, tb.icon, tb.bild = a2, a4, a6
                else tb.name, tb.icon, tb.bild = a1, a2, a4 end
            end
        end
        k.baum[b] = tb
        local n = 0
        if GetNumTalents then local ok, x = pcall(GetNumTalents, b); n = ok and tonumber(x) or 0 end
        for i = 1, n do
            local ok, name, icon, reihe, spalte, _, maxRang = pcall(GetTalentInfo, b, i)
            if ok and name and reihe and spalte then
                local t = { index = i, name = name, icon = icon, max = tonumber(maxRang) or 1, r = reihe, s = spalte, b = b, vor = {} }
                if GetTalentPrereqs then
                    local pr = { pcall(GetTalentPrereqs, b, i) }
                    if pr[1] then
                        for j = 2, #pr, 3 do
                            if type(pr[j]) == "number" and type(pr[j + 1]) == "number" then t.vor[#t.vor + 1] = { pr[j], pr[j + 1] } end
                        end
                    end
                end
                k[b][reihe] = k[b][reihe] or {}
                k[b][reihe][spalte] = t
                if reihe > k.maxReihe then k.maxReihe = reihe end
                k.anzahl = k.anzahl + 1
            end
        end
    end
    k.tabs = tabs
    return k
end

function NS.Karte(neu)
    local kl = NS.Klasse()
    if neu or not karte or karteKlasse ~= kl or karte.anzahl == 0 then
        karte = karteBauen(); karteKlasse = kl
        NS.pruefCache = {}
    end
    return karte
end
function NS.KarteVeraltet() karte = nil end

function NS.Talent(b, r, s)
    local k = NS.Karte()
    return k[b] and k[b][r] and k[b][r][s] or nil
end

-- aktueller Stand im Spiel: rang[schluessel], baum[1..3], gesamt
function NS.IstStand()
    local k = NS.Karte()
    local z = { rang = {}, baum = { 0, 0, 0 }, gesamt = 0 }
    for b = 1, k.tabs or 0 do
        for r, reihe in pairs(k[b]) do
            for s, t in pairs(reihe) do
                local ok, _, _, _, _, rang = pcall(GetTalentInfo, b, t.index)
                rang = ok and tonumber(rang) or 0
                if rang > 0 then
                    z.rang[schluessel(b, r, s)] = rang
                    z.baum[b] = z.baum[b] + rang
                    z.gesamt = z.gesamt + rang
                end
            end
        end
    end
    return z
end

-- Freie Punkte: erst Blizzards Abfrage, sonst selbst ausrechnen (1 Punkt je Stufe ab 10, minus vergebene Punkte).
-- In Forever lieferte die Abfrage nichts Brauchbares – dann blieb der Planer still.
function NS.FreiePunkte()
    local api
    if UnitCharacterPoints then
        local ok, n = pcall(UnitCharacterPoints, "player")
        if ok and tonumber(n) then api = tonumber(n) end
    end
    if api == nil and GetUnspentTalentPoints then local ok, n = pcall(GetUnspentTalentPoints); if ok and tonumber(n) then api = tonumber(n) end end
    local stufe = tonumber(UnitLevel and UnitLevel("player")) or 0
    local verfuegbar = math.max(0, math.min(stufe, NS.TBC and 70 or 60) - 9)
    local gerechnet = math.max(0, verfuegbar - (NS.IstStand().gesamt or 0))
    NS.punkteApi, NS.punkteGerechnet = api, gerechnet
    if api and api > 0 then return api end
    -- Abfrage fehlt oder meldet 0, obwohl laut Stufe Punkte frei sind → ausgerechnete Zahl nehmen
    return gerechnet
end

-- Regeln ---------------------------------------------------------------------
-- prüft, ob der nächste Punkt auf (b, r, s) im Zustand z erlaubt ist; liefert true oder false, Grund
function NS.PunktErlaubt(z, b, r, s, maxPunkte)
    local t = NS.Talent(b, r, s)
    if not t then return false, (L"Dieses Talent gibt es im Spiel nicht (Baum %d, Reihe %d, Spalte %d)."):format(b, r, s), "fehlt" end
    maxPunkte = maxPunkte or NS.MAX_PUNKTE
    if z.gesamt >= maxPunkte then return false, (L"Alle %d Punkte sind verteilt."):format(maxPunkte), "voll" end
    local hat = z.rang[schluessel(b, r, s)] or 0
    if hat >= t.max then return false, (L"%s ist schon voll ausgebaut."):format(t.name), "max" end
    local braucht = (r - 1) * 5
    if (z.baum[b] or 0) < braucht then
        return false, (L"Reihe %d braucht %d Punkte in diesem Baum (bisher %d)."):format(r, braucht, z.baum[b] or 0), "reihe"
    end
    for _, v in ipairs(t.vor) do
        local vt = NS.Talent(b, v[1], v[2])
        local vr = z.rang[schluessel(b, v[1], v[2])] or 0
        if not vt or vr < vt.max then
            return false, (L"Zuerst %s voll ausbauen."):format(vt and vt.name or "?"), "vor"
        end
    end
    return true
end

local function punktSetzen(z, b, r, s)
    local key = schluessel(b, r, s)
    z.rang[key] = (z.rang[key] or 0) + 1
    z.baum[b] = (z.baum[b] or 0) + 1
    z.gesamt = z.gesamt + 1
end
NS.PunktSetzen = punktSetzen
function NS.LeererStand() return { rang = {}, baum = { 0, 0, 0 }, gesamt = 0 } end

-- ganze Folge prüfen; liefert true  oder  false, Punktnummer, Grund, Art
function NS.FolgePruefen(seq, maxPunkte)
    local z = NS.LeererStand()
    if #seq > (maxPunkte or NS.MAX_PUNKTE) then
        return false, (maxPunkte or NS.MAX_PUNKTE) + 1, (L"Zu viele Punkte: %d (höchstens %d)."):format(#seq, maxPunkte or NS.MAX_PUNKTE), "voll"
    end
    for i, p in ipairs(seq) do
        local ok, grund, art = NS.PunktErlaubt(z, p[1], p[2], p[3], maxPunkte)
        if not ok then return false, i, grund, art end
        punktSetzen(z, p[1], p[2], p[3])
    end
    return true
end

function NS.PunkteJeBaum(seq)
    local n = { 0, 0, 0 }
    for _, p in ipairs(seq or {}) do n[p[1]] = (n[p[1]] or 0) + 1 end
    return n[1] .. "/" .. n[2] .. "/" .. n[3]
end

-- Pläne ------------------------------------------------------------------------
-- Planobjekt: { key, name, typ, punkte, seq, eigen, id }
local function guidePlaene(kl)
    local g = NS.GUIDE_DATEN and NS.GUIDE_DATEN[kl]
    local liste = {}
    if not (g and NS.GUIDE_AKTIV) then return liste end
    for _, p in ipairs(g.plaene or {}) do
        local seq = NS.Dekodieren(p.code)
        if seq and #seq <= NS.MAX_PUNKTE then
            liste[#liste + 1] = { key = "g:" .. p.id, name = p.name, typ = p.typ, punkte = p.punkte, seq = seq, eigen = false, quelle = p.quelle }
        end
    end
    return liste
end

function NS.EigeneListe(kl)
    local db = NS.DB()
    kl = kl or NS.Klasse() or "?"
    if type(db.eigene[kl]) ~= "table" then db.eigene[kl] = {} end
    return db.eigene[kl]
end

function NS.Plaene()
    local kl = NS.Klasse()
    local liste = guidePlaene(kl)
    for _, e in ipairs(NS.EigeneListe(kl)) do
        local seq = NS.Dekodieren(e.code or "") or {}
        liste[#liste + 1] = { key = "e:" .. e.id, id = e.id, name = e.name or "?", typ = L"Eigener Plan", punkte = NS.PunkteJeBaum(seq), seq = seq, eigen = true }
    end
    return liste
end

function NS.PlanHolen(key)
    if not key then return nil end
    for _, p in ipairs(NS.Plaene()) do if p.key == key then return p end end
    return nil
end

-- passt der Plan zum Spiel? (Ergebnis wird gemerkt, bis sich die Talentdaten ändern)
NS.pruefCache = {}
function NS.PlanStatus(plan)
    if not plan then return false end
    local k = NS.Karte()
    if (k.anzahl or 0) == 0 then return true end    -- Talentdaten noch nicht da: nichts behaupten
    local code = NS.Kodieren(plan.seq)
    local c = NS.pruefCache[code]
    if c then return c.ok, c.i, c.grund end
    local ok, i, grund = NS.FolgePruefen(plan.seq)
    NS.pruefCache[code] = { ok = ok, i = i, grund = grund }
    return ok, i, grund
end

-- aktiver Plan je Charakter (Retail überschreibt diese drei: dort je Spezialisierung)
function NS.AktivKey() return NS.CharDB().aktiv end
function NS.AktivSetzen(key, nurVorschlag)
    local c = NS.CharDB()
    c.aktiv = key
    if not nurVorschlag then c.gewaehlt = true end
end
function NS.Gewaehlt() return NS.CharDB().gewaehlt end

function NS.AktiverPlan()
    return NS.PlanHolen(NS.AktivKey())
end

function NS.PlanAktivieren(key)
    local p = NS.PlanHolen(key)
    if not p then return end
    NS.AktivSetzen(key)
    NS.msg((L"Aktiver Plan: %s"):format(Y .. p.name .. "|r"))
    NS.weg = nil
    NS.Aktualisieren(true)
    if NS.AuswahlNeu then NS.AuswahlNeu() end
end

function NS.PlanSpeichern(name, seq, id)
    local liste = NS.EigeneListe()
    name = (name or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if name == "" then name = L"Mein Plan" end
    local code = NS.Kodieren(seq)
    if id then
        for _, e in ipairs(liste) do
            if e.id == id then e.name = name; e.code = code; NS.Aktualisieren(true); return "e:" .. id end
        end
    end
    local db = NS.DB()
    local neu = { id = db.naechsteId, name = name, code = code, datum = date and date("%d.%m.%Y") or "" }
    db.naechsteId = db.naechsteId + 1
    liste[#liste + 1] = neu
    NS.Aktualisieren(true)
    return "e:" .. neu.id
end

function NS.PlanLoeschen(key)
    local id = tonumber((key or ""):match("^e:(%d+)$"))
    if not id then return false end
    local liste = NS.EigeneListe()
    for i, e in ipairs(liste) do
        if e.id == id then
            table.remove(liste, i)
            local c = NS.CharDB()
            if c.aktiv == key then c.aktiv = nil end
            NS.Aktualisieren(true)
            return true
        end
    end
    return false
end

-- Nächster Schritt -------------------------------------------------------------
-- Ergebnis: { art = "ok" | "fertig" | "passtnicht" | "keinplan", schritt, b, r, s, t (Talent), rang (neu), stufe, abweichung }
function NS.NaechsterSchritt(plan)
    plan = plan or NS.AktiverPlan()
    if not plan then return { art = "keinplan" } end
    local ist = NS.IstStand()
    local geplant, erster = {}, nil
    -- folgt der Spieler dem Plan genau? (die ersten <gesamt> Planpunkte = tatsächliche Ränge)
    local abweichung = false
    do
        local soll = {}
        for i = 1, math.min(ist.gesamt, #plan.seq) do
            local p = plan.seq[i]; local key = schluessel(p[1], p[2], p[3]); soll[key] = (soll[key] or 0) + 1
        end
        if ist.gesamt > #plan.seq then abweichung = true end
        for key, n in pairs(ist.rang) do if soll[key] ~= n then abweichung = true end end
        for key, n in pairs(soll) do if ist.rang[key] ~= n then abweichung = true end end
    end
    for i, p in ipairs(plan.seq) do
        local b, r, s = p[1], p[2], p[3]
        local key = schluessel(b, r, s)
        geplant[key] = (geplant[key] or 0) + 1
        if (ist.rang[key] or 0) < geplant[key] then          -- dieser Planschritt ist noch nicht erreicht
            erster = erster or i
            local ok = NS.PunktErlaubt(ist, b, r, s, NS.MAX_PUNKTE + 99)
            if ok then
                local t = NS.Talent(b, r, s)
                return { art = "ok", schritt = i, b = b, r = r, s = s, t = t, rang = (ist.rang[key] or 0) + 1,
                    stufe = NS.StufeFuer(i), abweichung = abweichung or i ~= erster, plan = plan, ist = ist }
            end
        end
    end
    if not erster then return { art = "fertig", plan = plan, ist = ist } end
    return { art = "passtnicht", schritt = erster, plan = plan, ist = ist }
end

-- Erinnerung steuern -------------------------------------------------------------
NS.weg = nil          -- Anzahl freier Punkte, bei der die Erinnerung weggeklickt wurde
NS.vorgemerkt = false -- im Kampf aufgelaufen, nach dem Kampf zeigen
local gezeigt = false

NS.bereit = false     -- erst nach dem Login-Start (Plan-Vorschlag) aktiv
function NS.Aktualisieren(still)
    if not NS.bereit then return end
    local db = NS.DB()
    local frei = NS.FreiePunkte()
    NS.frei = frei
    if frei <= 0 then
        NS.weg = nil; NS.empfehlung = nil; NS.vorgemerkt = false
        if NS.ErinnerungVerbergen then NS.ErinnerungVerbergen() end
        gezeigt = false
        if NS.AuswahlNeu then NS.AuswahlNeu() end
        return
    end
    local erg = NS.NaechsterSchritt()
    NS.empfehlung = erg
    if NS.AuswahlNeu then NS.AuswahlNeu() end
    if not db.erinnerung then if NS.ErinnerungVerbergen then NS.ErinnerungVerbergen() end gezeigt = false return end
    if NS.weg and frei <= NS.weg then return end          -- weggeklickt: erst bei neuen Punkten wieder
    NS.weg = nil
    if InCombatLockdown and InCombatLockdown() then NS.vorgemerkt = true return end
    NS.vorgemerkt = false
    if NS.ErinnerungZeigen then NS.ErinnerungZeigen(erg) end
    if not gezeigt then
        gezeigt = true
        if not still then NS.Ankuendigen(erg) end
    end
end

function NS.Ankuendigen(erg)
    local db = NS.DB()
    if db.ton and PlaySound then pcall(PlaySound, (SOUNDKIT and SOUNDKIT.TELL_MESSAGE) or 3081) end
    if not db.chat then return end
    if erg.art == "ok" and erg.t then
        NS.msg((L"Talentpunkt frei! Laut Plan jetzt: %s (Rang %d/%d)"):format(Y .. erg.t.name .. "|r", erg.rang, erg.t.max))
    elseif erg.art == "keinplan" then
        NS.msg(L"Talentpunkt frei! Du hast noch keinen Plan gewählt – " .. Y .. "/tp|r")
    elseif erg.art == "fertig" then
        NS.msg(L"Talentpunkt frei! Dein Plan ist schon komplett umgesetzt.")
    else
        NS.msg(L"Talentpunkt frei! Der Plan passt nicht mehr zu deiner Skillung – " .. Y .. "/tp|r")
    end
end

function NS.Weggeklickt() NS.weg = NS.frei or NS.FreiePunkte(); gezeigt = false end

-- Talent lernen / Talentfenster -------------------------------------------------
function NS.TalentfensterOeffnen(baum)
    if InCombatLockdown and InCombatLockdown() then NS.msg(L"Im Kampf nicht möglich.") return end
    local function fenster() return rawget(_G, "PlayerTalentFrame") or rawget(_G, "TalentFrame") end
    local f = fenster()
    if not (f and f:IsShown()) then
        if ToggleTalentFrame then pcall(ToggleTalentFrame)
        else
            local laden = (C_AddOns and C_AddOns.LoadAddOn) or LoadAddOn
            if laden then pcall(laden, "Blizzard_TalentUI") end
            f = fenster(); if f and ShowUIPanel then pcall(ShowUIPanel, f) end
        end
    end
    f = fenster()
    if baum and f and f:IsShown() and f.GetName then
        local reiter = rawget(_G, (f:GetName() or "") .. "Tab" .. baum)
        local aktiv = PanelTemplates_GetSelectedTab and select(2, pcall(PanelTemplates_GetSelectedTab, f))
        if reiter and reiter.Click and aktiv ~= baum then pcall(reiter.Click, reiter) end
    end
end

function NS.Lernen(erg)
    if not (erg and erg.art == "ok" and erg.t) then return end
    if InCombatLockdown and InCombatLockdown() then NS.msg(L"Im Kampf nicht möglich.") return end
    if NS.FreiePunkte() <= 0 then return end
    local vorher = (NS.IstStand().rang[schluessel(erg.b, erg.r, erg.s)] or 0)
    local ok = LearnTalent and pcall(LearnTalent, erg.b, erg.t.index)
    local function pruefen()
        local nachher = NS.IstStand().rang[schluessel(erg.b, erg.r, erg.s)] or 0
        if nachher <= vorher then
            NS.msg(L"Das Spiel hat das Lernen nicht erlaubt – bitte im Talentfenster auf das leuchtende Talent klicken.")
            NS.TalentfensterOeffnen(erg.b)
        end
        NS.Aktualisieren()
    end
    if not ok then NS.msg(L"Lernen per Addon ist hier nicht möglich – bitte im Talentfenster klicken."); NS.TalentfensterOeffnen(erg.b) return end
    if C_Timer then C_Timer.After(0.6, pruefen) else pruefen() end
end

-- Ereignisse ---------------------------------------------------------------------
local ev = CreateFrame("Frame")
local wartet = false
local function spaeter(sek, fn) if C_Timer then C_Timer.After(sek, fn) else fn() end end
local function neuBerechnen()
    if wartet then return end
    wartet = true
    spaeter(0.3, function() wartet = false; NS.Aktualisieren() end)
end
NS.NeuBerechnen = neuBerechnen

local function vorschlag()
    local key = NS.AktivKey()
    if key and NS.PlanHolen(key) then return false end
    -- Standard-Vorschlag: erster passende Guide-Plan der Klasse (Leveln) bzw. in Retail der Spezialisierung
    if not NS.Gewaehlt() then
        for _, p in ipairs(NS.Plaene()) do
            if not p.eigen and NS.PlanStatus(p) then
                NS.AktivSetzen(p.key, true)
                NS.msg((L"Vorschlag aktiv: %s – ändern mit %s"):format(Y .. p.name .. "|r", Y .. "/tp|r"))
                break
            end
        end
    end
    return true
end
NS.Vorschlag = vorschlag

local function ersterStart()
    local c = NS.CharDB()
    if not vorschlag() then return end
    -- nach der Einführung einmalig die Plan-Auswahl öffnen
    if c.auswahlGezeigt then return end
    c.auswahlGezeigt = true
    local function auf() if NS.Auswahl then NS.Auswahl(true) end end
    if SiikkIntroWarte then SiikkIntroWarte(auf) else spaeter(6, auf) end
end

ev:SetScript("OnEvent", function(_, e, a1)
    if e == "ADDON_LOADED" then
        if a1 == ADDON then NS.DB(); NS.CharDB() end
        if (a1 == "Blizzard_TalentUI" or a1 == "Blizzard_PlayerSpells" or a1 == "Blizzard_ClassTalentUI") and NS.TalentUIGeladen then NS.TalentUIGeladen(a1) end
    elseif e == "PLAYER_LOGIN" then
        NS.DB(); NS.Karte(true)
        spaeter(6, function()
            NS.Karte(true); NS.bereit = true; ersterStart(); NS.Aktualisieren()
            -- Diagnose automatisch in die Speicherdatei (für die Fehlersuche, kostet nichts)
            pcall(NS.Befehl, "diagstill")
            -- passt der aktive Plan noch zu den Talentbäumen im Spiel?
            local p = NS.AktiverPlan()
            if p then
                local ok, i, grund = NS.PlanStatus(p)
                if not ok then
                    if NS.PlanWarnung then NS.PlanWarnung(p, grund)
                    else NS.msg(R .. (L"Dein Plan „%s“ passt nicht zum Spiel – Punkt %d: %s"):format(p.name, i or 0, grund or "?") .. "|r") end
                end
            end
        end)
    elseif e == "PLAYER_LEVEL_UP" then
        NS.weg = nil
        spaeter(1, function() NS.Karte(true); NS.Aktualisieren() end)
    elseif e == "CHARACTER_POINTS_CHANGED" or e == "PLAYER_TALENT_UPDATE" or e == "SPELLS_CHANGED" then
        neuBerechnen()
    elseif e == "PLAYER_REGEN_ENABLED" then
        if NS.vorgemerkt then spaeter(0.5, function() NS.Aktualisieren() end) end
    end
end)
for _, e in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "PLAYER_LEVEL_UP", "CHARACTER_POINTS_CHANGED", "PLAYER_TALENT_UPDATE",
    "PLAYER_REGEN_ENABLED", "SPELLS_CHANGED" }) do
    pcall(ev.RegisterEvent, ev, e)
end

-- Befehle -------------------------------------------------------------------------
local function hilfe()
    NS.msg(L"Befehle:")
    print(Y .. "/tp|r " .. L"– Plan wählen" .. " · " .. Y .. "/tp planer|r " .. L"– neuen Plan erstellen")
    print(Y .. "/tp import|r · " .. Y .. "/tp export|r · " .. Y .. "/tp optionen|r" .. (NS.RETAIL and (" · " .. Y .. "/tp speichern|r " .. L"– aktuelle Skillung als Plan") or ""))
    print(Y .. "/tp an|r / " .. Y .. "/tp aus|r " .. L"– Erinnerung ein/aus" .. " · " .. Y .. "/tp jetzt|r " .. L"– nächstes Talent anzeigen")
    print(Y .. "/tp intro|r · " .. Y .. "/tp neu|r " .. L"– was ist neu" .. " · " .. Y .. "/tp reset|r " .. L"– Fenster zurücksetzen")
end

function NS.Befehl(m)
    m = (m or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    local db = NS.DB()
    if m == "" or m == "plan" or m == "plaene" or m == "pläne" then if NS.Auswahl then NS.Auswahl() end
    elseif m == "optionen" or m == "options" or m == "einstellungen" then if NS.Optionen then NS.Optionen() end
    elseif m == "import" then if NS.Import then NS.Import() end
    elseif m == "export" then
        local p = NS.AktiverPlan()
        if p and NS.Export then NS.Export(p) else NS.msg(L"Kein aktiver Plan.") end
    elseif m == "planer" or m == "erstellen" or m == "new" then if NS.Planer then NS.Planer(nil) end
    elseif (m == "speichern" or m == "save") and NS.AktuelleSpeichern then NS.AktuelleSpeichern()
    elseif m == "aus" or m == "off" then db.erinnerung = false; NS.Aktualisieren(true); NS.msg(L"Erinnerung ausgeschaltet.")
    elseif m == "an" or m == "on" then db.erinnerung = true; NS.weg = nil; NS.msg(L"Erinnerung eingeschaltet."); NS.Aktualisieren()
    elseif m == "jetzt" or m == "now" then
        NS.weg = nil
        local erg = NS.NaechsterSchritt()
        if erg.art == "ok" and not erg.stufe then NS.msg((L"Nächstes Talent laut Plan: %s (Rang %d/%d, %s)"):format(Y .. erg.t.name .. "|r", erg.rang, erg.t.max, erg.baumName or "?"))
        elseif erg.art == "ok" then NS.msg((L"Nächstes Talent laut Plan: %s (Rang %d/%d, Stufe %d)"):format(Y .. erg.t.name .. "|r", erg.rang, erg.t.max, erg.stufe))
        elseif erg.art == "keinplan" then NS.msg(L"Kein aktiver Plan.")
        elseif erg.art == "fertig" then NS.msg(L"Dein Plan ist komplett umgesetzt.")
        else NS.msg(L"Plan passt nicht mehr zu deiner Skillung.") end
        NS.Aktualisieren(true)
    elseif m == "check" or m == "diag" or m == "diagstill" then
        local still = (m == "diagstill")
        -- Fehlersuche: echte Talentbäume des Spiels in die Speicherdatei schreiben und Kurzbericht im Chat
        local k = NS.Karte(true)
        local zeilen = {}
        for bb = 1, k.tabs or 0 do
            for r, reihe in pairs(k[bb]) do
                for sp, t in pairs(reihe) do zeilen[#zeilen + 1] = ("%d%d%d %s (max %d, Index %d)"):format(bb, r, sp, tostring(t.name), t.max or 0, t.index or 0) end
            end
        end
        table.sort(zeilen)
        db.diagBaum = { klasse = NS.Klasse(), toc = NS.TOC, tabs = k.tabs, anzahl = k.anzahl, frei = NS.FreiePunkte(), zeilen = zeilen,
            baeume = { k.baum[1] and k.baum[1].name, k.baum[2] and k.baum[2].name, k.baum[3] and k.baum[3].name } }
        local erg = NS.NaechsterSchritt()
        local p = NS.AktiverPlan()
        db.diagBaum.punkteApi = NS.punkteApi; db.diagBaum.punkteGerechnet = NS.punkteGerechnet
        db.diagBaum.apis = "UnitCharacterPoints=" .. type(UnitCharacterPoints) .. " GetUnspentTalentPoints=" .. type(GetUnspentTalentPoints)
            .. " GetNumTalentTabs=" .. type(GetNumTalentTabs) .. " GetTalentInfo=" .. type(GetTalentInfo) .. " LearnTalent=" .. type(LearnTalent)
        db.diagBaum.stufe = UnitLevel and UnitLevel("player"); db.diagBaum.plan = p and p.name; db.diagBaum.ergebnis = erg.art .. (erg.t and (" " .. tostring(erg.t.name)) or "")
        if p and p.seq then
            local z = {}
            for i = 1, math.min(#p.seq, 51) do local q = p.seq[i]; local t = NS.Talent(q[1], q[2], q[3]); z[i] = ("%d: %d%d%d → %s"):format(i, q[1], q[2], q[3], t and t.name or "LEER") end
            db.diagBaum.planPunkte = z
        end
        if still then return end
        NS.msg(("Spiel %d · Klasse %s · Bäume %d · Talente %d · freie Punkte %d · Plan: %s"):format(NS.TOC, tostring(NS.Klasse()), k.tabs or 0, k.anzahl or 0, NS.FreiePunkte(), p and p.name or "keiner"))
        if p and p.seq and p.seq[1] then
            local q = p.seq[1]; local t = NS.Talent(q[1], q[2], q[3])
            NS.msg(("1. Planpunkt: Baum %d, Reihe %d, Spalte %d → im Spiel: %s"):format(q[1], q[2], q[3], t and t.name or "|cffff4040leeres Feld|r"))
        end
        NS.msg("Ergebnis: " .. tostring(erg.art) .. (erg.t and (" → " .. tostring(erg.t.name)) or "") .. " · Bitte jetzt /reload, dann kann Claude die Bäume lesen.")
    elseif m == "reset" then if NS.FensterZuruecksetzen then NS.FensterZuruecksetzen() end
    elseif m == "intro" then local api = rawget(_G, "SiikkIntroAPI"); if api and api["siikk-Talentplaner"] then api["siikk-Talentplaner"]() end
    elseif m == "neu" or m == "news" then local api = rawget(_G, "SiikkNeuAPI"); if api and api["siikk-Talentplaner"] then api["siikk-Talentplaner"]() end
    else hilfe() end
end
SLASH_SIIKKTALENT1 = "/tp"; SLASH_SIIKKTALENT2 = "/talent"; SLASH_SIIKKTALENT3 = "/siikktalent"
SlashCmdList.SIIKKTALENT = function(m) NS.Befehl(m) end

SiikkTalentAPI = {
    Naechster = function() return NS.NaechsterSchritt() end,
    Aktiv = function() local p = NS.AktiverPlan(); return p and p.name end,
}
