-- siikk-Talentplaner · Retail-Modul (aktuelles WoW, Midnight 12.x)
-- Klassenbaum + Spezialisierungsbaum + Heldentalente über C_ClassTalents / C_Traits.
-- Ein Plan = Name + Blizzard-Talent-Code (Loadout-String). Daraus wird die Lernreihenfolge abgeleitet:
-- Klassen- und Spezbaum abwechselnd (wie das Spiel Punkte vergibt), im Baum von oben nach unten (posY, dann posX),
-- Tore (Punkte im Baum) und Kanten (Voraussetzungen) beachtet, danach die Heldentalente.
-- Nur im Retail-Client aktiv – im Classic-/Forever-/TBC-Client kehrt die Datei sofort zurück.
local ADDON, NS = ...
if not NS.RETAIL then return end
local L = siikkL or function(s) return s end
local Y, G, R, GR = NS.Y, NS.G, NS.R, NS.GR
local ORANGE = "|cffff9933"
local _ = { L"Einzelziel", L"Mehrere Ziele", L"Raid", L"Mythisch+" }   -- Schwerpunkte der Guide-Builds (für die Übersetzung)

local RT = {}            -- interne Funktionen (für Tests über NS.RT erreichbar)
NS.RT = RT

-- kleine Helfer -------------------------------------------------------------------
local function rufe(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, a, b, c, d = pcall(fn, ...)
    if ok then return a, b, c, d end
    return nil
end
local function api(ns, name) local t = rawget(_G, ns); return type(t) == "table" and t[name] or nil end

local TYP_AUSWAHL, TYP_HELDENWAHL, TYP_STUFEN = 2, 3, 1      -- Enum.TraitNodeType: Selection, SubTreeSelection, Tiered
local KANTE_GENUEGT, KANTE_NOETIG = 2, 3                       -- Enum.TraitEdgeType: SufficientForAvailability, RequiredForAvailability
local function istWahl(typ) return typ == TYP_AUSWAHL or typ == TYP_HELDENWAHL end

-- Spezialisierung -------------------------------------------------------------------
function NS.SpecID()
    local idx = rufe(api("C_SpecializationInfo", "GetSpecialization")) or rufe(rawget(_G, "GetSpecialization"))
    if not idx or idx == 0 then return nil end
    local id = rufe(api("C_SpecializationInfo", "GetSpecializationInfo"), idx) or rufe(rawget(_G, "GetSpecializationInfo"), idx)
    return tonumber(id)
end

function NS.SpecName(id)
    id = id or NS.SpecID()
    if not id then return "?" end
    local _, name = rufe(rawget(_G, "GetSpecializationInfoByID"), id)
    if type(name) == "string" and name ~= "" then return name end
    local s = NS.RETAIL_SPECS and NS.RETAIL_SPECS[id]
    return s and s.name or tostring(id)
end

local function specKlasse(id)
    local s = NS.RETAIL_SPECS and NS.RETAIL_SPECS[id]
    if s then return s.klasse end
    local r = { rufe(rawget(_G, "GetSpecializationInfoByID"), id) }
    return r[6]
end

-- Talent-Code (Blizzard-Loadout-String) lesen und schreiben ---------------------------------------
-- Format laut Blizzard_ClassTalentImportExport.lua: Base64, Bits je Zeichen von unten nach oben;
-- Kopf: Version 8 Bit, SpecID 16 Bit, Baum-Hash 128 Bit; dann je Knoten (Reihenfolge von C_Traits.GetTreeNodes):
-- gewählt 1 · gekauft 1 · teilweise 1 (+ Ränge 6) · Wahlknoten 1 (+ Index 2)
local B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local B64W = {}
for i = 1, 64 do B64W[B64:sub(i, i)] = i - 1 end

local function leser(text)
    local w = {}
    for i = 1, #text do
        local v = B64W[text:sub(i, i)]
        if v == nil then return nil end
        w[i] = v
    end
    local pos = 0
    local r = { bits = 6 * #w }
    function r.lies(n)
        local v, faktor = 0, 1
        for _ = 1, n do
            local ci = math.floor(pos / 6) + 1
            if ci > #w then return nil end
            local bit = math.floor(w[ci] / 2 ^ (pos % 6)) % 2
            v = v + bit * faktor; faktor = faktor * 2; pos = pos + 1
        end
        return v
    end
    function r.rest() return r.bits - pos end
    return r
end
RT.leser = leser

local function schreiber()
    local bits = {}
    local s = {}
    function s.add(n, v)
        v = math.floor(tonumber(v) or 0)
        for _ = 1, n do bits[#bits + 1] = v % 2; v = math.floor(v / 2) end
    end
    function s.text()
        local t = {}
        for i = 1, #bits, 6 do
            local v, f = 0, 1
            for j = 0, 5 do v = v + (bits[i + j] or 0) * f; f = f * 2 end
            t[#t + 1] = B64:sub(v + 1, v + 1)
        end
        return table.concat(t)
    end
    return s
end
RT.schreiber = schreiber

local function bereinigen(text)
    if type(text) ~= "string" then return "" end
    return (text:gsub("%s+", ""))
end

-- liest den Kopf; liefert kopf, leser  oder  nil
function NS.LoadoutKopf(text)
    text = bereinigen(text)
    if #text < 26 then return nil end
    local r = leser(text)
    if not r then return nil end
    local k = { version = r.lies(8), spec = r.lies(16), hash = {}, hashLeer = true }
    for i = 1, 16 do
        local v = r.lies(8)
        if v == nil then return nil end
        k.hash[i] = v
        if v ~= 0 then k.hashLeer = false end
    end
    if not (k.version and k.spec) then return nil end
    return k, r
end

-- Talentbaum des Spiels lesen ------------------------------------------------------------
-- karte.knoten[nodeID] = { id, index, x, y, typ, max, entries, sichtbar, baum = "klasse"|"spez"|"held", heldWahl, subTree, ein = {Kanten}, tor = {waehrung, menge} }
local karte, karteToken = nil, 0
local eintragCache = {}

local function waehrungVon(k, kn)
    if kn.baum == "klasse" then return k.waehrung.klasse end
    if kn.baum == "spez" then return k.waehrung.spez end
    if kn.subTree then return k.heldWaehrung[kn.subTree] end
    return nil
end
RT.waehrungVon = waehrungVon

local function karteBauen()
    karteToken = karteToken + 1
    eintragCache = {}
    local k = { knoten = {}, liste = {}, ok = false, token = karteToken, waehrung = {}, heldWaehrung = {}, heldName = {}, anzahl = 0 }
    local CT, TR = rawget(_G, "C_ClassTalents"), rawget(_G, "C_Traits")
    if not (CT and TR) then return k end
    local configID = rufe(CT.GetActiveConfigID)
    local spec = NS.SpecID()
    if not (configID and spec) then return k end
    local treeID = rufe(CT.GetTraitTreeForSpec, spec)
    if not treeID then
        local ci = rufe(TR.GetConfigInfo, configID)
        treeID = ci and ci.treeIDs and ci.treeIDs[1]
    end
    if not treeID then return k end
    k.configID, k.treeID, k.spec = configID, treeID, spec
    -- Währungen: [1] Klasse, [2] Spezialisierung (so liest es auch Blizzards ClassTalentsFrame)
    local wi = rufe(TR.GetTreeCurrencyInfo, configID, treeID, false) or {}
    k.waehrung.klasse = wi[1] and wi[1].traitCurrencyID
    k.waehrung.spez = wi[2] and wi[2].traitCurrencyID
    local nodes = rufe(TR.GetTreeNodes, treeID) or {}
    local bed = {}
    local function bedingung(id)
        if bed[id] == nil then bed[id] = rufe(TR.GetConditionInfo, configID, id) or false end
        return bed[id] or nil
    end
    local ohneBaum = {}
    for i, nodeID in ipairs(nodes) do
        local n = rufe(TR.GetNodeInfo, configID, nodeID)
        local kn = { id = nodeID, index = i, ein = {} }
        if type(n) == "table" and n.ID and n.ID ~= 0 then
            kn.x, kn.y = n.posX or 0, n.posY or 0
            kn.typ = n.type or 0
            kn.max = n.maxRanks or 1
            kn.entries = n.entryIDs or {}
            kn.sichtbar = n.isVisible
            kn.kanten = n.visibleEdges or {}
            kn.subTree = n.subTreeID
            if kn.typ == TYP_HELDENWAHL then kn.baum = "held"; kn.heldWahl = true
            elseif kn.subTree then kn.baum = "held"
            else
                local kosten = rufe(TR.GetNodeCost, configID, nodeID)
                local cid = type(kosten) == "table" and kosten[1] and kosten[1].ID
                if cid and cid == k.waehrung.spez then kn.baum = "spez"
                elseif cid and cid == k.waehrung.klasse then kn.baum = "klasse"
                else ohneBaum[#ohneBaum + 1] = kn end
            end
            -- Tor: Bedingung „x Punkte in diesem Baum ausgegeben“
            for _, cid in ipairs(n.conditionIDs or {}) do
                local c = bedingung(cid)
                if c and c.traitCurrencyID and (c.spentAmountRequired or 0) > 0 and (c.isGate or c.isGate == nil) then
                    if not kn.tor or c.spentAmountRequired > kn.tor.menge then kn.tor = { waehrung = c.traitCurrencyID, menge = c.spentAmountRequired } end
                end
            end
            k.anzahl = k.anzahl + 1
        else
            kn.fehlt = true
        end
        k.knoten[nodeID] = kn
        k.liste[i] = kn
    end
    -- Kanten umdrehen: wer schaltet wen frei?
    for _, kn in ipairs(k.liste) do
        for _, e in ipairs(kn.kanten or {}) do
            local ziel = k.knoten[e.targetNode]
            if ziel then ziel.ein[#ziel.ein + 1] = { von = kn.id, typ = e.type } end
        end
    end
    -- Knoten ohne Kosten (z. B. geschenkte) über ihre Kanten einem Baum zuordnen
    for _ = 1, 4 do
        for _, kn in ipairs(ohneBaum) do
            if not kn.baum then
                for _, e in ipairs(kn.ein) do local v = k.knoten[e.von]; if v and v.baum and v.baum ~= "held" then kn.baum = v.baum end end
                for _, e in ipairs(kn.kanten or {}) do local v = k.knoten[e.targetNode]; if v and v.baum and v.baum ~= "held" then kn.baum = v.baum end end
            end
        end
    end
    for _, kn in ipairs(ohneBaum) do kn.baum = kn.baum or "klasse" end
    -- Heldentalente: Währung und Name je Unterbaum
    for _, kn in ipairs(k.liste) do
        if kn.subTree and not k.heldName[kn.subTree] then
            local st = rufe(TR.GetSubTreeInfo, configID, kn.subTree)
            k.heldName[kn.subTree] = st and st.name or "?"
            k.heldWaehrung[kn.subTree] = st and st.traitCurrencyID
        end
    end
    -- ohne Punkte-Währungen (direkt nach dem Login) lieber später neu lesen
    k.ok = k.anzahl > 0 and k.waehrung.klasse ~= nil and k.waehrung.spez ~= nil
    return k
end

function NS.Karte(neu)
    local spec = NS.SpecID()
    if neu or not karte or karte.spec ~= spec or not karte.ok then
        karte = karteBauen()
        NS.pruefCache = {}
    end
    return karte
end
function NS.KarteVeraltet() karte = nil end

-- Name/Symbol eines Eintrags (Talent oder Heldentalent-Baum)
function RT.Eintrag(entryID)
    if not entryID then return { name = "?", max = 1 } end
    local k = NS.Karte()
    if eintragCache[entryID] then return eintragCache[entryID] end
    local TR = rawget(_G, "C_Traits")
    local e = TR and rufe(TR.GetEntryInfo, k.configID, entryID)
    local res = { id = entryID, max = e and e.maxRanks or 1 }
    if e and e.subTreeID then
        local st = rufe(TR.GetSubTreeInfo, k.configID, e.subTreeID)
        res.subTree = e.subTreeID
        res.name = st and st.name
        res.atlas = st and st.iconElementID
    elseif e and e.definitionID then
        local d = rufe(TR.GetDefinitionInfo, e.definitionID)
        local spell = d and (d.spellID or d.overriddenSpellID)
        res.spellID = spell
        res.name = d and d.overrideName
        if (not res.name or res.name == "") and spell then
            res.name = rufe(api("C_Spell", "GetSpellName"), spell)
            if not res.name then res.name = rufe(rawget(_G, "GetSpellInfo"), spell) end
        end
        res.icon = d and d.overrideIcon
        if not res.icon and spell then
            res.icon = rufe(api("C_Spell", "GetSpellTexture"), spell)
            if not res.icon then res.icon = rufe(rawget(_G, "GetSpellTexture"), spell) end
        end
    end
    if not res.name or res.name == "" then res.name = "?" end
    eintragCache[entryID] = res
    return res
end

function RT.BaumName(baum, subTree)
    if baum == "klasse" then return L"Klassenbaum" .. " (" .. NS.KlassenName() .. ")" end
    if baum == "spez" then return L"Spezialisierung" .. " (" .. NS.SpecName() .. ")" end
    local k = NS.Karte()
    local h = subTree and k.heldName[subTree]
    return L"Heldentalente" .. (h and h ~= "?" and (" (" .. h .. ")") or "")
end

-- Plan auswerten: Code dekodieren + Lernreihenfolge ableiten ------------------------------
-- liefert { status = "ok"|"veraltet"|"anderespec"|"kaputt"|"unbekannt", grund, ziel = {nodeID → {rang, entry}}, schritte = {…}, summe = {klasse, spez, held}, hashAnders }
local auswertCache = {}

local function zielLesen(text, k, kopf, r, pruefeSichtbar)
    local ziel, geschenkt = {}, {}
    for _, kn in ipairs(k.liste) do
        local gewaehlt = r.lies(1)
        if gewaehlt == nil then return nil, L"Der Code ist kürzer als der Talentbaum – vermutlich aus einer älteren Spielversion." end
        if gewaehlt == 1 then
            local gekauft = r.lies(1)
            if gekauft == nil then return nil, L"Der Code ist beschädigt." end
            if gekauft == 0 then
                geschenkt[kn.id] = true
            else
                local teil, rang, wahl, idx = r.lies(1), nil, nil, 0
                if teil == 1 then rang = r.lies(6) end
                wahl = r.lies(1)
                if wahl == 1 then idx = r.lies(2) end
                if teil == nil or wahl == nil or idx == nil or (teil == 1 and rang == nil) then return nil, L"Der Code ist beschädigt." end
                if kn.fehlt then return nil, L"Der Code enthält ein Talent, das es im Spiel nicht mehr gibt." end
                if pruefeSichtbar and kn.baum ~= "held" and kn.sichtbar == false then
                    return nil, L"Der Code enthält Talente, die es für diese Spezialisierung nicht (mehr) gibt."
                end
                rang = rang or kn.max
                if rang < 1 or rang > (kn.max or 1) then return nil, L"Der Code passt nicht zum aktuellen Talentbaum (Ränge)." end
                local entry
                if wahl == 1 then
                    if not istWahl(kn.typ) then return nil, L"Der Code passt nicht zum aktuellen Talentbaum (Wahlknoten)." end
                    entry = kn.entries[idx + 1]
                    if not entry then return nil, L"Der Code passt nicht zum aktuellen Talentbaum (Wahlknoten)." end
                else
                    entry = kn.entries[1]          -- wie Blizzards Import: ohne Wahl-Index der erste Eintrag
                end
                ziel[kn.id] = { rang = rang, entry = entry }
            end
        end
    end
    -- übrige Bits müssen leer sein (sonst hatte der Baum beim Export mehr Knoten)
    while r.rest() > 0 do
        local b = r.lies(1)
        if b == 1 then return nil, L"Der Code ist länger als der Talentbaum – vermutlich aus einer anderen Spielversion." end
        if b == nil then break end
    end
    return ziel, nil, geschenkt
end

-- Lernreihenfolge ableiten: je Baum von oben nach unten unter Beachtung von Toren und Kanten
local function reihenfolge(ziel, geschenkt, k)
    local stand, ausgegeben = {}, {}
    local unsicher = false
    local function voll(id)
        if geschenkt[id] then return true end
        local kn = k.knoten[id]
        if not kn then return false end
        local z = ziel[id]
        return (stand[id] or 0) >= ((z and istWahl(kn.typ)) and 1 or (kn.max or 1))
    end
    local function frei(kn)
        if kn.tor and (ausgegeben[kn.tor.waehrung] or 0) < kn.tor.menge then return false end
        local genuegt, genuegtOk = false, false
        for _, e in ipairs(kn.ein) do
            if e.typ == KANTE_NOETIG then
                if not voll(e.von) then return false end
            elseif e.typ == KANTE_GENUEGT then
                genuegt = true
                if voll(e.von) then genuegtOk = true end
            end
        end
        return (not genuegt) or genuegtOk
    end
    local listen = { klasse = {}, spez = {}, held = {} }
    local heldTree
    for id, z in pairs(ziel) do
        local kn = k.knoten[id]
        if kn and kn.heldWahl then
            local e = RT.EintragRoh(z.entry)
            heldTree = e and e.subTreeID
        end
    end
    for _, baum in ipairs({ "klasse", "spez", "held" }) do
        local offen = {}
        for id, z in pairs(ziel) do
            local kn = k.knoten[id]
            if kn and kn.baum == baum then offen[#offen + 1] = kn end
        end
        local function vor(a, b)
            if a.heldWahl ~= b.heldWahl then return a.heldWahl and true or false end
            if a.y ~= b.y then return a.y < b.y end
            if a.x ~= b.x then return a.x < b.x end
            return a.id < b.id
        end
        table.sort(offen, vor)
        while true do
            local best
            for _, kn in ipairs(offen) do
                local soll = istWahl(kn.typ) and 1 or ziel[kn.id].rang
                if (stand[kn.id] or 0) < soll and frei(kn) then best = kn break end
            end
            if not best then
                for _, kn in ipairs(offen) do
                    local soll = istWahl(kn.typ) and 1 or ziel[kn.id].rang
                    if (stand[kn.id] or 0) < soll then best = kn; unsicher = unsicher or kn.id break end
                end
            end
            if not best then break end
            stand[best.id] = (stand[best.id] or 0) + 1
            local w = waehrungVon(k, best) or ("baum:" .. baum)
            ausgegeben[w] = (ausgegeben[w] or 0) + 1
            local z = ziel[best.id]
            listen[baum][#listen[baum] + 1] = { id = best.id, rang = stand[best.id], max = istWahl(best.typ) and 1 or (best.max or 1),
                entry = z.entry, baum = baum, wahl = istWahl(best.typ), subTree = best.subTree or (best.heldWahl and heldTree) or nil }
        end
    end
    -- Klasse und Spezialisierung abwechselnd (das Spiel vergibt die Punkte abwechselnd), danach Heldentalente
    local schritte = {}
    local a, b = listen.klasse, listen.spez
    for i = 1, math.max(#a, #b) do
        if a[i] then schritte[#schritte + 1] = a[i] end
        if b[i] then schritte[#schritte + 1] = b[i] end
    end
    for _, s in ipairs(listen.held) do schritte[#schritte + 1] = s end
    for i, s in ipairs(schritte) do s.nr = i end
    return schritte, unsicher, { klasse = #a, spez = #b, held = #listen.held }, heldTree
end

-- Eintrag ohne Cache-Namen (für die Reihenfolge reicht die subTreeID)
function RT.EintragRoh(entryID)
    local k = NS.Karte()
    local TR = rawget(_G, "C_Traits")
    return entryID and TR and rufe(TR.GetEntryInfo, k.configID, entryID) or nil
end

function RT.Auswerten(code, specErwartet)
    local k = NS.Karte()
    if not k.ok then return { status = "unbekannt", grund = L"Die Talentdaten sind noch nicht geladen – bitte gleich noch einmal versuchen." } end
    code = bereinigen(code)
    local cacheKey = code .. "#" .. k.token
    if auswertCache[cacheKey] then return auswertCache[cacheKey] end
    local erg = { status = "ok" }
    local kopf, r = NS.LoadoutKopf(code)
    if not kopf then
        erg.status, erg.grund = "kaputt", L"Das ist kein gültiger Talent-Code."
    elseif kopf.spec ~= k.spec then
        erg.status, erg.grund, erg.spec = "anderespec", (L"Der Code ist für %s – aktiv ist %s."):format(NS.SpecName(kopf.spec), NS.SpecName(k.spec)), kopf.spec
    else
        local ver = rufe(api("C_Traits", "GetLoadoutSerializationVersion"))
        if ver and kopf.version ~= ver then
            erg.status, erg.grund = "veraltet", L"Der Code stammt aus einer anderen Spielversion (Code-Format)."
        else
            local ziel, fehler, geschenkt = zielLesen(code, k, kopf, r, true)
            if not ziel then
                erg.status, erg.grund = "veraltet", fehler
            else
                erg.ziel, erg.geschenkt = ziel, geschenkt
                erg.schritte, erg.unsicher, erg.summe, erg.heldTree = reihenfolge(ziel, geschenkt, k)
                if #erg.schritte == 0 then erg.status, erg.grund = "kaputt", L"Der Code enthält keine Talentpunkte." end
                if not kopf.hashLeer then
                    local h = rufe(api("C_Traits", "GetTreeHash"), k.treeID)
                    if type(h) == "table" then
                        for i = 1, 16 do if (h[i] or 0) ~= kopf.hash[i] then erg.hashAnders = true end end
                    end
                end
            end
        end
    end
    auswertCache[cacheKey] = erg
    return erg
end

-- Pläne ----------------------------------------------------------------------------------------
-- Guide-Pläne: NS.GUIDE_RETAIL[specID] (siikkTalent_DatenRetail.lua) · eigene: siikkTalent_DB.eigeneRetail[specID]
local function buildName(b)
    local n = (b.held and b.held ~= "") and (b.held .. " – ") or ""
    n = n .. L(b.fokus or b.typ or "")
    if b.zusatz and b.zusatz ~= "" then n = n .. " (" .. b.zusatz .. ")" end
    return n
end
RT.buildName = buildName

function NS.EigeneListe(spec)
    local db = NS.DB()
    spec = spec or NS.SpecID() or 0
    if type(db.eigeneRetail) ~= "table" then db.eigeneRetail = {} end
    local key = tostring(spec)
    if type(db.eigeneRetail[key]) ~= "table" then db.eigeneRetail[key] = {} end
    return db.eigeneRetail[key]
end

function NS.Plaene(spec)
    spec = spec or NS.SpecID()
    local liste = {}
    if not spec then return liste end
    for i, b in ipairs((NS.GUIDE_RETAIL and NS.GUIDE_RETAIL[spec]) or {}) do
        liste[#liste + 1] = { key = "rg:" .. (b.id or (spec .. "-" .. i)), name = buildName(b), typ = b.typ, code = b.code, quelle = b.quelle,
            held = b.held, eigen = false, spec = spec, retail = true }
    end
    for _, e in ipairs(NS.EigeneListe(spec)) do
        liste[#liste + 1] = { key = "re:" .. e.id, id = e.id, name = e.name or "?", typ = L"Eigener Plan", code = e.code or "",
            eigen = true, spec = spec, retail = true, datum = e.datum }
    end
    return liste
end

function NS.PlanSpeichern(name, code, id, spec)
    code = bereinigen(code)
    if code == "" then return nil end
    local kopf = NS.LoadoutKopf(code)
    spec = spec or (kopf and kopf.spec) or NS.SpecID()
    local liste = NS.EigeneListe(spec)
    name = (name or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if name == "" then name = L"Mein Plan" end
    if id then
        for _, e in ipairs(liste) do
            if e.id == id then e.name = name; e.code = code; NS.Aktualisieren(true); return "re:" .. id end
        end
    end
    local db = NS.DB()
    local neu = { id = db.naechsteId, name = name, code = code, datum = date and date("%d.%m.%Y") or "" }
    db.naechsteId = db.naechsteId + 1
    liste[#liste + 1] = neu
    NS.Aktualisieren(true)
    return "re:" .. neu.id
end

function NS.PlanLoeschen(key)
    local id = tonumber((key or ""):match("^re:(%d+)$"))
    if not id then return false end
    local liste = NS.EigeneListe()
    for i, e in ipairs(liste) do
        if e.id == id then
            table.remove(liste, i)
            if NS.AktivKey() == key then NS.CharDB().retail[tostring(NS.SpecID() or 0)] = nil end
            NS.Aktualisieren(true)
            return true
        end
    end
    return false
end

-- aktiver Plan je Spezialisierung
local function charRetail()
    local c = NS.CharDB()
    if type(c.retail) ~= "table" then c.retail = {} end
    if type(c.retailGewaehlt) ~= "table" then c.retailGewaehlt = {} end
    return c
end
function NS.AktivKey() local c = charRetail(); return c.retail[tostring(NS.SpecID() or 0)] end
function NS.AktivSetzen(key, nurVorschlag)
    local c = charRetail(); local s = tostring(NS.SpecID() or 0)
    c.retail[s] = key
    if not nurVorschlag then c.retailGewaehlt[s] = true end
end
function NS.Gewaehlt() local c = charRetail(); return c.retailGewaehlt[tostring(NS.SpecID() or 0)] end

-- Status für Auswahl/Tooltip: true  oder  false, nil, Grund
NS.pruefCache = {}
function NS.PlanStatus(plan)
    if not plan then return false end
    local a = RT.Auswerten(plan.code)
    if a.status == "ok" or a.status == "unbekannt" then return true, nil, nil, a end
    return false, nil, a.grund, a
end

function NS.PlanWarnung(p, grund)
    NS.msg(R .. (L"Dein Plan „%s“ ist veraltet oder passt nicht: %s – bitte neu importieren." ):format(p.name, grund or "?") .. "|r")
end

-- Spielstand ------------------------------------------------------------------------------------
-- freie Punkte je Baum (klasse, spez, held) über die Talentpunkt-Währungen
function RT.FreiJeBaum()
    local k = NS.Karte()
    local frei = { klasse = 0, spez = 0, held = 0 }
    if not k.ok then return frei end
    local wi = rufe(api("C_Traits", "GetTreeCurrencyInfo"), k.configID, k.treeID, false) or {}
    local menge = {}
    for _, w in ipairs(wi) do if w.traitCurrencyID then menge[w.traitCurrencyID] = w.quantity or 0 end end
    frei.klasse = (k.waehrung.klasse and menge[k.waehrung.klasse]) or 0
    frei.spez = (k.waehrung.spez and menge[k.waehrung.spez]) or 0
    for _, cid in pairs(k.heldWaehrung) do
        if cid and (menge[cid] or 0) > frei.held then frei.held = menge[cid] end
    end
    if frei.held == 0 then
        local hat, n = rufe(api("C_ClassTalents", "HasUnspentHeroTalentPoints"))
        if hat then frei.held = tonumber(n) or 1 end
    end
    return frei
end

function NS.FreiePunkte()
    local f = RT.FreiJeBaum()
    return (f.klasse or 0) + (f.spez or 0) + (f.held or 0)
end

local function istKnoten(k, id)
    local n = rufe(api("C_Traits", "GetNodeInfo"), k.configID, id)
    if type(n) ~= "table" then return { rang = 0 } end
    local entry = n.activeEntry and n.activeEntry.entryID
    return { rang = n.ranksPurchased or 0, aktivRang = n.activeRank or 0, entry = entry, info = n,
        geschenkt = ((n.activeRank or 0) - (n.ranksPurchased or 0)) > 0 }
end
RT.istKnoten = istKnoten

local function lernbar(k, s, ist)
    local TR = rawget(_G, "C_Traits")
    if s.wahl then
        local ok = rufe(TR and TR.CanPurchaseRank, k.configID, s.id, s.entry)
        if ok ~= nil then return ok and true or false end
        local n = ist.info or {}
        return (n.isAvailable and n.meetsEdgeRequirements) and true or false
    end
    local n = ist.info or {}
    if n.canPurchaseRank ~= nil then return n.canPurchaseRank and true or false end
    return (n.isAvailable and n.meetsEdgeRequirements) and true or false
end

-- Nächster Schritt -------------------------------------------------------------------------------
-- Ergebnis wie im Classic-Modul: { art = "ok"|"fertig"|"passtnicht"|"keinplan", schritt, t, rang, b, baumName, nodeID, entryID, wahl, … }
local BAUM_NR = { klasse = 1, spez = 2, held = 3 }
function NS.NaechsterSchritt(plan)
    plan = plan or NS.AktiverPlan()
    if not plan then return { art = "keinplan" } end
    local a = RT.Auswerten(plan.code)
    if a.status ~= "ok" then return { art = "passtnicht", plan = plan, grund = a.grund } end
    local k = NS.Karte()
    local frei = RT.FreiJeBaum()
    local cache = {}
    local function ist(id) if not cache[id] then cache[id] = istKnoten(k, id) end return cache[id] end
    local abweichung, offen = false, {}
    local kandidat = {}
    for i, s in ipairs(a.schritte) do
        local x = ist(s.id)
        local erreicht
        if s.wahl then
            erreicht = (x.rang > 0) or (x.entry ~= nil and x.aktivRang > 0)
            if erreicht and x.entry and s.entry and x.entry ~= s.entry then abweichung = true end
        else
            erreicht = x.rang >= s.rang
        end
        if not erreicht then
            offen[s.baum] = true
            if not kandidat[s.baum] and (frei[s.baum] or 0) > 0 and lernbar(k, s, x) then kandidat[s.baum] = i end
        end
    end
    -- Ränge in Knoten, die der Plan nicht (so hoch) vorsieht → Abweichung
    for _, kn in ipairs(k.liste) do
        if kn.baum ~= "held" and kn.sichtbar ~= false and not kn.fehlt then
            local z = a.ziel[kn.id]
            local x = ist(kn.id)
            if x.rang > 0 and (not z or (not istWahl(kn.typ) and x.rang > z.rang)) then abweichung = true break end
        end
    end
    local best
    for _, baum in ipairs({ "klasse", "spez", "held" }) do
        local i = kandidat[baum]
        if i and (not best or i < best) then best = i end
    end
    if best then
        local s = a.schritte[best]
        local e = RT.Eintrag(s.entry)
        local t = { name = e.name, icon = e.icon, atlas = e.atlas, max = s.max }
        if s.wahl and k.knoten[s.id] and k.knoten[s.id].heldWahl then t.name = L"Heldentalente wählen: " .. e.name end
        -- frühere, noch offene Schritte im selben Baum, die gerade nicht gehen → Abweichung anzeigen
        local frueher = false
        for j = 1, best - 1 do
            local s2 = a.schritte[j]
            if s2.baum == s.baum then
                local x2 = ist(s2.id)
                if (s2.wahl and x2.rang == 0 and not (x2.entry and x2.aktivRang > 0)) or (not s2.wahl and x2.rang < s2.rang) then frueher = true break end
            end
        end
        return { art = "ok", schritt = best, gesamt = #a.schritte, b = BAUM_NR[s.baum], baumName = RT.BaumName(s.baum, s.subTree),
            t = t, rang = s.wahl and 1 or s.rang, nodeID = s.id, entryID = s.entry, wahl = s.wahl, plan = plan,
            abweichung = abweichung or frueher,
            zeile3 = (L"Plan: %s · Schritt %d von %d"):format(plan.name, best, #a.schritte) }
    end
    local passt = false
    for baum, n in pairs(frei) do if n > 0 and offen[baum] then passt = true end end
    if not passt then return { art = "fertig", plan = plan } end
    return { art = "passtnicht", plan = plan }
end

-- Lernen / Talentfenster ------------------------------------------------------------------------
function NS.TalentfensterOeffnen()
    if InCombatLockdown and InCombatLockdown() then NS.msg(L"Im Kampf nicht möglich.") return end
    local psf = rawget(_G, "PlayerSpellsFrame")
    local util = rawget(_G, "PlayerSpellsUtil")
    if psf and psf.IsShown and psf:IsShown() and psf.TalentsFrame and psf.TalentsFrame.IsShown and psf.TalentsFrame:IsShown() then return end
    if util and util.OpenToClassTalentsTab then
        if pcall(util.OpenToClassTalentsTab) then return end
    end
    local tog = rawget(_G, "TogglePlayerSpellsFrame")
    if tog and pcall(tog, 2) then return end
    local laden = (C_AddOns and C_AddOns.LoadAddOn) or rawget(_G, "LoadAddOn")
    if laden then pcall(laden, "Blizzard_PlayerSpells") end
    psf = rawget(_G, "PlayerSpellsFrame")
    if psf and ShowUIPanel then pcall(ShowUIPanel, psf) return end
    if ToggleTalentFrame then pcall(ToggleTalentFrame) end
end

local function rangJetzt(k, erg)
    local x = istKnoten(k, erg.nodeID)
    if erg.wahl then return (x.entry == erg.entryID and x.aktivRang > 0) and 1 or 0 end
    return x.rang
end

function NS.Lernen(erg)
    if not (erg and erg.art == "ok" and erg.nodeID) then return end
    if InCombatLockdown and InCombatLockdown() then NS.msg(L"Im Kampf nicht möglich.") return end
    if NS.FreiePunkte() <= 0 then return end
    local k = NS.Karte()
    local CT, TR = rawget(_G, "C_ClassTalents"), rawget(_G, "C_Traits")
    if rufe(CT and CT.GetStarterBuildActive) then
        NS.msg(L"Der Starter-Build des Spiels ist aktiv – dann verteilt das Spiel die Punkte selbst. Zum eigenen Plan im Talentfenster den Starter-Build abwählen.")
        NS.TalentfensterOeffnen()
        return
    end
    local vorher = rangJetzt(k, erg)
    local ok
    if erg.wahl then ok = rufe(TR and TR.SetSelection, k.configID, erg.nodeID, erg.entryID)
    else ok = rufe(TR and TR.PurchaseRank, k.configID, erg.nodeID) end
    if ok then ok = rufe(TR and TR.CommitConfig, k.configID) end
    if not ok then
        rufe(TR and TR.RollbackConfig, k.configID)
        NS.msg(L"Lernen per Addon ist hier nicht möglich – bitte im Talentfenster klicken.")
        NS.TalentfensterOeffnen()
        return
    end
    local function pruefen()
        if rangJetzt(NS.Karte(), erg) <= vorher then
            NS.msg(L"Das Spiel hat das Lernen nicht erlaubt – bitte im Talentfenster auf das leuchtende Talent klicken.")
            NS.TalentfensterOeffnen()
        end
        NS.Aktualisieren()
    end
    if C_Timer then C_Timer.After(1.5, pruefen) else pruefen() end
end

-- Hervorhebung im Blizzard-Talentfenster: Knopf über die nodeID suchen
function NS.TalentKnopf(erg)
    if not (erg and erg.art == "ok" and erg.nodeID) then return nil end
    local tf
    local psf = rawget(_G, "PlayerSpellsFrame")
    if type(psf) == "table" then tf = psf.TalentsFrame end
    if not tf then local ctf = rawget(_G, "ClassTalentFrame"); tf = type(ctf) == "table" and ctf.TalentsTab or nil end
    if not (type(tf) == "table" and tf.IsVisible and tf:IsVisible() and tf.GetTalentButtonByNodeID) then return nil end
    local ok, btn = pcall(tf.GetTalentButtonByNodeID, tf, erg.nodeID)
    if ok and type(btn) == "table" and btn.IsVisible and btn:IsVisible() then return btn end
    return nil
end

function NS.TalentUIGeladen()
    for _, name in ipairs({ "PlayerSpellsFrame", "ClassTalentFrame" }) do
        local fr = rawget(_G, name)
        if type(fr) == "table" and fr.HookScript and not fr.siikkHook then
            fr.siikkHook = true
            pcall(fr.HookScript, fr, "OnShow", function() if NS.NeuBerechnen then NS.NeuBerechnen() end end)
        end
    end
end

-- Aktuelle Skillung als Code ------------------------------------------------------------------
-- eigener Export (wie ClassTalentImportExportMixin:WriteLoadoutContent), falls C_Traits.GenerateImportString fehlt
function RT.CodeAusSpiel()
    local k = NS.Karte()
    if not k.ok then return nil end
    local TR = rawget(_G, "C_Traits")
    local code = rufe(TR and TR.GenerateImportString, k.configID)
    if type(code) == "string" and #code > 30 then return code end
    local w = schreiber()
    w.add(8, rufe(TR and TR.GetLoadoutSerializationVersion) or 2)
    w.add(16, k.spec)
    local h = rufe(TR and TR.GetTreeHash, k.treeID)
    for i = 1, 16 do w.add(8, type(h) == "table" and h[i] or 0) end
    for _, kn in ipairs(k.liste) do
        local n = rufe(TR.GetNodeInfo, k.configID, kn.id)
        if type(n) ~= "table" or kn.fehlt then w.add(1, 0)
        else
            local gekauft = (n.ranksPurchased or 0) > 0
            local geschenkt = ((n.activeRank or 0) - (n.ranksPurchased or 0)) > 0
            if not (gekauft or geschenkt) then w.add(1, 0)
            else
                w.add(1, 1)
                w.add(1, gekauft and 1 or 0)
                if gekauft then
                    local teil = n.ranksPurchased ~= n.maxRanks
                    w.add(1, teil and 1 or 0)
                    if teil then w.add(6, n.ranksPurchased) end
                    local wahl = istWahl(n.type)
                    w.add(1, wahl and 1 or 0)
                    if wahl then
                        local idx = 0
                        for i, e in ipairs(n.entryIDs or {}) do if n.activeEntry and e == n.activeEntry.entryID then idx = i - 1 end end
                        w.add(2, idx)
                    end
                end
            end
        end
    end
    return w.text()
end

function NS.AktuelleSpeichern()
    local code = RT.CodeAusSpiel()
    if not code then NS.msg(L"Die Talentdaten sind noch nicht geladen – bitte gleich noch einmal versuchen.") return nil end
    local name = (L"Meine Skillung %s"):format(date and date("%d.%m.") or "")
    if NS.Import then NS.Import(code, name) end
    return code
end

-- Import / Export (Texte und Prüfung für Retail-Codes) -----------------------------------------------
function NS.ImportText()
    return L"Füge einen Talent-Code ein (Strg+V) – aus dem Blizzard-Talentfenster („Exportieren“), von Wowhead, Icy Veins, Method oder Raidbots."
end
function NS.ExportCode(plan) return plan.code end
function NS.ExportInfo(plan)
    return L"Blizzard-Talent-Code – im Talentfenster unter „Importieren“ oder hier mit „Import“ einlesbar."
end

function NS.ImportPruefen(text)
    text = bereinigen(text)
    if text == "" then return false, L"Kein Code." end
    if text:lower():find("^siikk1:") then
        return false, L"Das ist ein siikk-Code für WoW Forever/Classic – hier brauchst du einen Talent-Code aus dem aktuellen WoW."
    end
    local kopf = NS.LoadoutKopf(text)
    if not kopf then return false, L"Das ist kein gültiger Talent-Code." end
    local spec = NS.SpecID()
    if kopf.spec ~= spec then
        local kl1, kl2 = specKlasse(kopf.spec), NS.Klasse()
        if not kl1 or kl1 ~= kl2 then
            return false, (L"Dieser Code ist für %s – du spielst %s."):format(NS.SpecName(kopf.spec), NS.KlassenName())
        end
        -- andere Spezialisierung derselben Klasse: speichern erlaubt, geprüft wird beim Wechsel
        return true, text, ORANGE .. (L"Code für %s – wird dort als eigener Plan gespeichert und beim Wechsel geprüft."):format(NS.SpecName(kopf.spec)) .. "|r"
    end
    local a = RT.Auswerten(text)
    if a.status ~= "ok" then return false, a.grund or "?" end
    local info = (L"Gültig: %d Punkte Klasse · %d Spezialisierung · %d Helden"):format(a.summe.klasse, a.summe.spez, a.summe.held)
    if a.hashAnders then info = info .. ORANGE .. "  " .. L"(aus einer anderen Spielversion – bitte prüfen)" .. "|r" end
    return true, text, info
end

-- Darstellung in der Plan-Auswahl --------------------------------------------------------------------
function NS.AuswahlTitel() return (L"Pläne für %s"):format(NS.SpecName() .. " " .. NS.KlassenName()) end

function NS.AuswahlHinweis(liste)
    return GR .. L"Vorgeschlagene Builds (Quelle im Tooltip) und deine eigenen. Eigene Pläne: im Blizzard-Talentfenster skillen, Code exportieren und hier importieren." .. "|r"
end

function NS.PlanUnterzeile(p)
    local a = RT.Auswerten(p.code)
    local t = (L(p.typ or "") ~= "" and (L(p.typ) .. " · ") or "")
    if a.status == "ok" then return t .. (L"%d/%d/%d Punkte (Klasse/Spez./Helden)"):format(a.summe.klasse, a.summe.spez, a.summe.held) end
    return t .. GR .. "–" .. "|r"
end

function NS.PlanStatusKurz(p)
    local a = RT.Auswerten(p.code)
    if a.status == "anderespec" then return L"andere Spezialisierung" end
    if a.status == "kaputt" then return L"Code ungültig" end
    return L"veraltet"
end

function NS.PlanTooltip(p)
    local a = RT.Auswerten(p.code)
    if p.typ then GameTooltip:AddLine(L(p.typ) .. (p.held and (" · " .. p.held) or ""), .85, .85, .85) end
    local q, url = NS.QuelleText(p.quelle)
    if q then GameTooltip:AddLine(L"Quelle: " .. q, .6, .8, 1, true) end
    if url then GameTooltip:AddLine(url, .5, .5, .5, true) end
    if a.status == "ok" then
        GameTooltip:AddLine((L"%d Punkte Klasse · %d Spezialisierung · %d Helden"):format(a.summe.klasse, a.summe.spez, a.summe.held), .85, .85, .85)
        if a.heldTree then
            local k = NS.Karte()
            local h = k.heldName[a.heldTree]
            if h and h ~= "?" then GameTooltip:AddLine(L"Heldentalente: " .. h, .85, .85, .85) end
        end
        if a.hashAnders then GameTooltip:AddLine(L"Der Code stammt aus einer anderen Spielversion – bitte im Talentfenster prüfen.", 1, .6, .2, true) end
        local namen, gesehen = {}, {}
        for _, s in ipairs(a.schritte) do
            if not gesehen[s.id] then
                gesehen[s.id] = true
                namen[#namen + 1] = RT.Eintrag(s.entry).name
                if #namen >= 6 then break end
            end
        end
        if #namen > 0 then GameTooltip:AddLine(L"Beginnt mit: " .. table.concat(namen, ", ") .. " ...", .7, .7, .7, true) end
    else
        GameTooltip:AddLine(a.grund or "?", 1, .4, .4, true)
    end
end

function NS.PlanDetail(p)
    local a = RT.Auswerten(p.code)
    if a.status == "ok" then
        return GR .. (L"Ausgewählt: %s · %d Schritte (Klasse und Spezialisierung abwechselnd, dann Helden)"):format(p.name, #a.schritte) .. "|r"
    end
    return R .. (a.grund or "?") .. "|r"
end

-- Plan-Auswahl: Knöpfe für Retail umbauen („Neu“ → aktuelle Skillung, „Bearbeiten“ → Talentfenster)
function NS.AuswahlKnoepfe(f)
    f.neu:SetText(L"Aktuelle Skillung")
    f.neu:SetScript("OnClick", function() NS.AktuelleSpeichern() end)
    f.bearbeiten:SetText(L"Talentfenster")
    f.bearbeiten:SetScript("OnClick", function() NS.TalentfensterOeffnen() end)
end

-- Einen eigenen grafischen Planer gibt es in Retail nicht – Blizzard hat einen.
function NS.Planer()
    NS.msg(L"Im aktuellen WoW planst du im Blizzard-Talentfenster: Skillung zusammenstellen, Code exportieren und hier mit /tp import einfügen.")
end

-- Ereignisse ------------------------------------------------------------------------------------------
local ev = CreateFrame("Frame")
local function specWechsel()
    NS.KarteVeraltet(); auswertCache = {}
    NS.weg = nil
    if NS.bereit then
        if NS.Vorschlag then NS.Vorschlag() end
        NS.Aktualisieren()
    end
end
ev:SetScript("OnEvent", function(_, e)
    if e == "ACTIVE_PLAYER_SPECIALIZATION_CHANGED" or e == "PLAYER_SPECIALIZATION_CHANGED" or e == "TRAIT_TREE_CHANGED" then
        if C_Timer then C_Timer.After(0.5, specWechsel) else specWechsel() end
    elseif e == "CONFIG_COMMIT_FAILED" then
        NS.msg(L"Das Spiel hat die Talentänderung abgelehnt – bitte im Talentfenster lernen.")
        if NS.NeuBerechnen then NS.NeuBerechnen() end
    else
        if NS.NeuBerechnen then NS.NeuBerechnen() end
    end
end)
for _, e in ipairs({ "TRAIT_CONFIG_UPDATED", "TRAIT_TREE_CURRENCY_INFO_UPDATED", "TRAIT_NODE_CHANGED", "ACTIVE_PLAYER_SPECIALIZATION_CHANGED",
    "PLAYER_SPECIALIZATION_CHANGED", "TRAIT_TREE_CHANGED", "TRAIT_CONFIG_LIST_UPDATED", "CONFIG_COMMIT_FAILED" }) do
    pcall(ev.RegisterEvent, ev, e)
end
local ist = (C_AddOns and C_AddOns.IsAddOnLoaded) or rawget(_G, "IsAddOnLoaded")
if ist and rufe(ist, "Blizzard_PlayerSpells") then NS.TalentUIGeladen() end
