-- siikk-Infoleiste · „Was ist neu?“ – erzeugt aus tools/changelog.py (nicht von Hand ändern)
siikkNeu("siikk-Infoleiste", "|cffe03030siikk|r-|cffffd100Infoleiste|r", "Interface\\AddOns\\siikkInfo\\Media\\siikk_info_icon", "1.0",
{
    { version = "1.0", datum = "31.10.2026", punkte = { "Neues Addon: Infoleiste oben am Bildschirm im siikk-Design.", "Ort mit Koordinaten, Gold (mit Sitzungsgewinn und allen Charakteren), Haltbarkeit mit Reparaturkosten, freie Taschenplätze, Ehre, FPS & Latenz, Uhr.", "Erfahrung mit großem Infofenster: Spielzeit, EP, Erholt, Kills und Quests bis zur Stufe, EP pro Stunde und Zeit bis zur Stufe.", "Einstellungen mit /il – oben oder unten, jeder Eintrag einzeln an/aus, Deckkraft." } }
}, function() return rawget(_G, "siikkInfo_DB") end, "/il neu")
