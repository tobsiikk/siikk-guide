-- siikk-Schadenszahlen · „Was ist neu?“ – erzeugt aus tools/changelog.py (nicht von Hand ändern)
siikkNeu("siikk-Schadenszahlen", "|cffe03030siikk|r-|cffffd100Schadenszahlen|r", "Interface\\AddOns\\siikkSZ\\Media\\siikk_sz_icon", "1.0",
{
    { version = "1.0", datum = "31.10.2026", punkte = { "Neues Addon: schönere Schadenszahlen über dem Gegner im siikk-Stil – fette, kursive Schrift mit dunkler Kontur.", "Farben je Magieschule (Schatten lila, Feuer orange …), Krits in Gold mit „!“, Leuchten und Funken.", "Begleiter-Schaden und DoT-Ticks kleiner, Verfehlt/Widerstanden in Grau, auf Wunsch deine Heilung in Grün.", "Einstellungen mit /sz, Vorschau mit /sz test. In Midnight wird nur die Schrift der Blizzard-Zahlen ersetzt." } }
}, function() return rawget(_G, "siikkSZ_DB") end, "/sz neu")
