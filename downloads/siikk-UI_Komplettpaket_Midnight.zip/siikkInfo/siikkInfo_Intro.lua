-- siikk-Infoleiste · Einführung beim ersten Start (/il intro)
local ADDON, NS = ...
local Y = "|cffffd100"
siikkIntro("siikk-Infoleiste", "|cffe03030siikk|r-|cffffd100Infoleiste|r", NS.MEDIA .. "siikk_info_icon", {
    { "Willkommen bei der siikk-Infoleiste",
      "Oben links siehst du jetzt eine kleine Leiste im siikk-Design mit allem Wichtigen auf einen Blick – nur so breit wie nötig.\n\n" ..
      "• " .. Y .. "Maus darüber|r: jeder Eintrag zeigt ein Infofenster mit Details.\n\n" ..
      "• " .. Y .. "Klicken|r: Ort öffnet die Weltkarte, Gold und Taschen öffnen die Taschen, die Uhr den Kalender.\n\n" ..
      "• " .. Y .. "Ziehen|r: die Leiste mit der Maus an jeden Platz schieben (gesperrt: Shift + Ziehen)." },
    { "Was die Leiste zeigt",
      "• " .. Y .. "Ort|r mit Koordinaten – farbig: grün freundlich, rot feindlich, orange umkämpft, blau Zufluchtsort\n" ..
      "• " .. Y .. "Gold|r – im Infofenster Gewinn dieser Sitzung und das Gold aller deiner Charaktere auf dem Realm\n" ..
      "• " .. Y .. "Haltbarkeit|r – schlechtestes Teil in %, jedes Teil einzeln und die Reparaturkosten\n" ..
      "• " .. Y .. "Taschen|r – freie Plätze\n" ..
      "• " .. Y .. "Ehre|r – Ehren- und Arenapunkte, Siege heute und gesamt\n" ..
      "• Auf Wunsch zusätzlich " .. Y .. "FPS & Latenz|r und " .. Y .. "Uhr|r (in den Einstellungen anhaken – die siikk-Oberfläche zeigt beides schon)" },
    { "Erfahrung",
      "Der Eintrag " .. Y .. "Stufe|r zeigt deinen Fortschritt in % und den Erholungsbonus (lila).\n\n" ..
      "Im Infofenster:\n" ..
      "• Spielzeit gesamt, auf dieser Stufe und in dieser Sitzung\n" ..
      "• EP dieser Stufe, Erholt, EP bis zur nächsten Stufe, EP dieser Sitzung\n" ..
      "• " .. Y .. "Kills bis zur Stufe|r (nach deinem letzten Kill) und " .. Y .. "Quests bis zur Stufe|r (nach deiner letzten Quest)\n" ..
      "• " .. Y .. "EP pro Stunde|r und " .. Y .. "Zeit bis zur Stufe|r – einmal im Tempo der ganzen Stufe, einmal im Tempo dieser Sitzung" },
    { "Einstellungen & Befehle",
      "Mit " .. Y .. "/il|r oder Linksklick auf den Minimap-Knopf: jeden Eintrag einzeln an/aus, Leiste sperren, Position zurücksetzen, Deckkraft.\n\n" ..
      Y .. "/il|r – Einstellungen\n" .. Y .. "/il an|r / " .. Y .. "/il aus|r – Leiste an oder aus\n" .. Y .. "/il sperren|r – Leiste festmachen · " .. Y .. "/il reset|r – zurück nach oben links\n" ..
      Y .. "/il intro|r – diese Einführung · " .. Y .. "/il neu|r – was ist neu\n\n" ..
      "Minimap-Knopf: " .. Y .. "Linksklick|r Einstellungen · " .. Y .. "Rechtsklick|r Leiste ein/aus · " .. Y .. "Ziehen|r verschiebt den Knopf." },
}, function() return rawget(_G, "siikkInfo_DB") end, "/il intro")
