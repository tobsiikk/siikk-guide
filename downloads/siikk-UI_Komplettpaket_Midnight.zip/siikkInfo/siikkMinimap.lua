-- siikk · gemeinsamer Minimap-Knopf (in jedem siikk-Addon enthalten, damit jedes auch einzeln läuft)
-- siikkMinimapKnopf(id, titel, icon, sv, linksKlick, rechtsKlick, zeilen)
--   sv: gespeicherte Tabelle des Addons ({ winkel = Zahl, aus = true/false })
-- Jeder Knopf meldet sich in SiikkMinimapAPI an, damit siikk-Oberfläche ihn zentral ein-/ausblenden kann.
SiikkMinimapAPI = rawget(_G, "SiikkMinimapAPI") or {}
if not rawget(_G, "siikkMinimapKnopf") then
    function siikkMinimapKnopf(id, titel, icon, svFn, links, rechts, zeilen, startWinkel)
        local b = CreateFrame("Button", "siikkMM_" .. id:gsub("[^%w]", ""), Minimap)
        b:SetSize(31, 31); b:SetFrameStrata("MEDIUM"); b:SetFrameLevel(8)
        b:RegisterForClicks("LeftButtonUp", "RightButtonUp"); b:RegisterForDrag("LeftButton")
        b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
        local bg = b:CreateTexture(nil, "BACKGROUND"); bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background"); bg:SetSize(20, 20); bg:SetPoint("TOPLEFT", 7, -5)
        b.icon = b:CreateTexture(nil, "ARTWORK"); b.icon:SetSize(20, 20); b.icon:SetPoint("TOPLEFT", 6, -5); b.icon:SetTexture(icon)
        local rand = b:CreateTexture(nil, "OVERLAY"); rand:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder"); rand:SetSize(53, 53); rand:SetPoint("TOPLEFT")
        local function sv() local t = svFn(); return type(t) == "table" and t or {} end
        local function platz()
            local a = math.rad(sv().winkel or startWinkel or 200)
            local r = ((Minimap:GetWidth() or 140) / 2) + 5
            b:ClearAllPoints(); b:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
        end
        b:SetScript("OnDragStart", function(s)
            s:SetScript("OnUpdate", function()
                local mx, my = Minimap:GetCenter(); local px, py = GetCursorPosition(); local sc = Minimap:GetEffectiveScale()
                sv().winkel = math.deg(math.atan2(py / sc - my, px / sc - mx)); platz()
            end)
        end)
        b:SetScript("OnDragStop", function(s) s:SetScript("OnUpdate", nil) end)
        b:SetScript("OnClick", function(_, btn) if btn == "RightButton" then if rechts then rechts() end elseif links then links() end end)
        b:SetScript("OnEnter", function(s)
            GameTooltip:SetOwner(s, "ANCHOR_LEFT"); GameTooltip:AddLine(titel)
            for _, z in ipairs(zeilen or {}) do GameTooltip:AddLine(z, 0.85, 0.85, 0.85, true) end
            GameTooltip:AddLine("Ziehen: Knopf verschieben", 0.6, 0.6, 0.6); GameTooltip:Show()
        end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        local function anwenden() platz(); b:SetShown(not sv().aus) end
        b.Anwenden = anwenden
        SiikkMinimapAPI[id] = { titel = titel, get = function() return not sv().aus end, set = function(an) sv().aus = not an; anwenden() end }
        local ev = CreateFrame("Frame"); ev:RegisterEvent("PLAYER_LOGIN")
        ev:SetScript("OnEvent", function() anwenden() end)
        if IsLoggedIn and IsLoggedIn() then anwenden() end
        return b
    end
end
