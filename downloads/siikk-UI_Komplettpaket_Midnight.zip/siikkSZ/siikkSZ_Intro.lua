-- siikk-Schadenszahlen · Einführung beim ersten Start (/sz intro)
local ADDON, NS = ...
local Y = "|cffffd100"
local seiten
if NS.MIDNIGHT then
    seiten = {
        { "Willkommen bei siikk-Schadenszahlen",
          "Die Schadenszahlen über deinen Gegnern bekommen die " .. Y .. "siikk-Schrift|r (fett und kursiv, gut lesbar).\n\n" ..
          "• In " .. Y .. "Midnight|r lässt Blizzard Addons nicht mehr an den Kampflog. Eigene Zahlen mit Farben je Magieschule und goldenen Krits gibt es deshalb nur in " .. Y .. "Anniversary, Classic und Forever|r.\n\n" ..
          "• Hier kannst du die Schrift an/aus schalten und die Größe der Blizzard-Zahlen ändern.\n\n" ..
          "• Die Schrift gilt ab dem nächsten Einloggen." },
        { "Befehle",
          Y .. "/sz|r – Einstellungen\n" .. Y .. "/sz intro|r – diese Einführung · " .. Y .. "/sz neu|r – was ist neu\n\n" ..
          "Minimap-Knopf: " .. Y .. "Linksklick|r Einstellungen · " .. Y .. "Ziehen|r verschiebt den Knopf." },
    }
else
    seiten = {
        { "Willkommen bei siikk-Schadenszahlen",
          "Deine Schadenszahlen über dem Gegner im " .. Y .. "siikk-Stil|r:\n\n" ..
          "• Eigene Schrift, fett und kursiv mit dunkler Kontur.\n\n" ..
          "• " .. Y .. "Farben je Magieschule|r: Schatten lila, Feuer orange, Frost hellblau, Natur grün, Arkan rosa, körperlich weiß.\n\n" ..
          "• " .. Y .. "Krits in Gold|r mit „!“, springen groß ins Bild, leuchten kurz auf und sprühen Funken.\n\n" ..
          "• Die Blizzard-Zahlen über dem Gegner werden dafür ausgeblendet – schaltest du siikk aus, sind sie wieder da." },
        { "Wo die Zahlen erscheinen",
          "• Direkt über der " .. Y .. "Namensplakette|r des Gegners, den du triffst. Mit " .. Y .. "V|r schaltest du die Namensplaketten der Gegner ein.\n\n" ..
          "• Ohne Namensplakette erscheinen die Zahlen über der " .. Y .. "Bildschirmmitte|r (abschaltbar).\n\n" ..
          "• Schaden deines " .. Y .. "Begleiters|r (Wichtel, Leerwandler, Wildtier) etwas kleiner, " .. Y .. "DoT-Ticks|r wie Verderbnis ebenfalls kleiner.\n\n" ..
          "• Verfehlt, Widerstanden und Immun stehen klein in Grau." },
        { "Einstellungen",
          "Mit " .. Y .. "/sz|r oder Linksklick auf den Minimap-Knopf:\n\n" ..
          "• " .. Y .. "Größe|r und " .. Y .. "Krit-Größe|r per Regler\n" ..
          "• Leuchten und „!“ bei Krits, Farben je Schule\n" ..
          "• Kurze Zahlen (12,5k), Begleiter, DoT-Ticks, Verfehlt, deine Heilung (grün)\n" ..
          "• siikk-Schrift auch für die übrigen Blizzard-Zahlen\n\n" ..
          "Der Knopf " .. Y .. "Vorschau|r (oder Rechtsklick auf den Minimap-Knopf) zeigt ein paar Beispielzahlen über deinem Ziel." },
        { "Befehle",
          Y .. "/sz|r – Einstellungen\n" .. Y .. "/sz an|r / " .. Y .. "/sz aus|r – eigene Zahlen an oder aus\n" .. Y .. "/sz test|r – Vorschau\n" ..
          Y .. "/sz intro|r – diese Einführung · " .. Y .. "/sz neu|r – was ist neu\n\n" ..
          "Minimap-Knopf: " .. Y .. "Linksklick|r Einstellungen · " .. Y .. "Rechtsklick|r Vorschau · " .. Y .. "Ziehen|r verschiebt den Knopf." },
    }
end
siikkIntro("siikk-Schadenszahlen", "|cffe03030siikk|r-|cffffd100Schadenszahlen|r", NS.MEDIA .. "siikk_sz_icon", seiten, function() return rawget(_G, "siikkSZ_DB") end, "/sz intro")
