-- siikk-Schadenszahlen · Einführung beim ersten Start (/sz intro)
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local Y = "|cffffd100"
local seiten
if NS.MIDNIGHT then
    seiten = {
        { L"Willkommen bei siikk-Schadenszahlen",
          L"Die Schadenszahlen über deinen Gegnern bekommen die " .. Y .. L"siikk-Schrift|r (fett und kursiv, gut lesbar).\n\n" ..
          "• In " .. Y .. L"Midnight|r lässt Blizzard Addons nicht mehr an den Kampflog. Eigene Zahlen mit Farben je Magieschule und goldenen Krits gibt es deshalb nur in " .. Y .. L"Anniversary, Classic und Forever|r.\n\n" ..
          L"• Hier kannst du die Schrift an/aus schalten und die Größe der Blizzard-Zahlen ändern.\n\n" ..
          L"• Die Schrift gilt ab dem nächsten Einloggen." },
        { L"Befehle",
          Y .. L"/sz|r – Einstellungen\n" .. Y .. L"/sz intro|r – diese Einführung · " .. Y .. L"/sz neu|r – was ist neu\n\n" ..
          L"Minimap-Knopf: " .. Y .. L"Linksklick|r Einstellungen · " .. Y .. L"Ziehen|r verschiebt den Knopf." },
    }
else
    seiten = {
        { L"Willkommen bei siikk-Schadenszahlen",
          L"Deine Schadenszahlen über dem Gegner im " .. Y .. L"siikk-Stil|r:\n\n" ..
          L"• Eigene Schrift, fett und kursiv mit dunkler Kontur.\n\n" ..
          "• " .. Y .. L"Farben je Magieschule|r: Schatten lila, Feuer orange, Frost hellblau, Natur grün, Arkan rosa, körperlich weiß.\n\n" ..
          "• " .. Y .. L"Krits in Gold|r mit „!“, springen groß ins Bild, leuchten kurz auf und sprühen Funken.\n\n" ..
          L"• Die Blizzard-Zahlen über dem Gegner werden dafür ausgeblendet – schaltest du siikk aus, sind sie wieder da." },
        { L"Wo die Zahlen erscheinen",
          L"• Direkt über der " .. Y .. L"Namensplakette|r des Gegners, den du triffst. Mit " .. Y .. L"V|r schaltest du die Namensplaketten der Gegner ein.\n\n" ..
          L"• Ohne Namensplakette erscheinen die Zahlen über der " .. Y .. L"Bildschirmmitte|r (abschaltbar).\n\n" ..
          L"• Schaden deines " .. Y .. L"Begleiters|r (Wichtel, Leerwandler, Wildtier) etwas kleiner, " .. Y .. L"DoT-Ticks|r wie Verderbnis ebenfalls kleiner.\n\n" ..
          L"• Verfehlt, Widerstanden und Immun stehen klein in Grau." },
        { L"Einstellungen",
          L"Mit " .. Y .. L"/sz|r oder Linksklick auf den Minimap-Knopf:\n\n" ..
          "• " .. Y .. L"Stil-Vorlagen|r mit einem Klick: siikk, Klassisch, Minimal, Episch, Comic, Retro, Elegant, Explosiv\n" ..
          "• " .. Y .. L"Schriftart|r, Größe, Krit-Größe, Kontur und Schatten\n" ..
          "• " .. Y .. L"Muster|r: Aufsteigen, Bogen, Fächer, Stapel, Seitlich, Explosion, Herabfallen – dazu die Krit-Animation\n" ..
          L"• Farben je Schule, eigene Farbe, Klassenfarbe oder Regenbogen\n" ..
          L"• Zahlenformat, Zauber-Symbol, Treffer zusammenfassen, Begleiter, DoT-Ticks, Verfehlt, Heilung\n\n" ..
          L"Der Knopf " .. Y .. L"Vorschau|r (oder Rechtsklick auf den Minimap-Knopf) zeigt ein paar Beispielzahlen über deinem Ziel." },
        { L"Befehle",
          Y .. L"/sz|r – Einstellungen\n" .. Y .. "/sz an|r / " .. Y .. L"/sz aus|r – eigene Zahlen an oder aus\n" .. Y .. L"/sz test|r – Vorschau\n" ..
          Y .. L"/sz intro|r – diese Einführung · " .. Y .. L"/sz neu|r – was ist neu\n\n" ..
          L"Minimap-Knopf: " .. Y .. L"Linksklick|r Einstellungen · " .. Y .. L"Rechtsklick|r Vorschau · " .. Y .. L"Ziehen|r verschiebt den Knopf." },
    }
end
siikkIntro("siikk-Schadenszahlen", "|cffe03030siikk|r-|cffffd100Schadenszahlen|r", NS.MEDIA .. "siikk_sz_icon", seiten, function() return rawget(_G, "siikkSZ_DB") end, "/sz intro")
