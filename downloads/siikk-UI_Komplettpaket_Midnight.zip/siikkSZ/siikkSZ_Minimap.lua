-- siikk-Schadenszahlen · eigener Minimap-Knopf
local ADDON, NS = ...
siikkMinimapKnopf("siikk-Schadenszahlen", "|cffe03030siikk|r-|cffffd100Schadenszahlen|r", NS.MEDIA .. "siikk_sz_icon",
    function() local db = NS.DB(); db.mm = db.mm or {}; return db.mm end,
    function() NS.Optionen() end,
    function() NS.Vorschau() end,
    NS.MIDNIGHT and { "Linksklick: Einstellungen (Schrift und Größe der Blizzard-Zahlen)" }
        or { "Linksklick: Einstellungen", "Rechtsklick: Vorschau (über deinem Ziel)" }, 290)
