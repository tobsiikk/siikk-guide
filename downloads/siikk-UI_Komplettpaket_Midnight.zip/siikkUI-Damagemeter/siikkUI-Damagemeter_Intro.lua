-- siikk-Damagemeter · Einführung beim ersten Start (/meter intro)
local ADDON = ...
local Y = "|cffffd100"
siikkIntro("siikk-Damagemeter", "|cffe03030siikk|r-|cffffd100Damagemeter|r", "Interface\\AddOns\\" .. ADDON .. "\\Media\\siikk_dm_icon", {
    { "Willkommen beim siikk-Damagemeter",
      "Der Damagemeter zeigt dir nach jedem Kampf, wer wie viel " .. Y .. "Schaden|r gemacht, " .. Y .. "geheilt|r oder " .. Y .. "Aggro|r gezogen hat – für dich, deine Gruppe und deinen Schlachtzug. Begleiter (z. B. dein Wichtel) zählen zu ihrem Besitzer.\n\n" ..
      "• Jeder Balken in Klassenfarbe mit Klassensymbol.\n\n" ..
      "• Läuft mit jeder Oberfläche – mit der siikk-Oberfläche zusammen übernimmt er, der eingebaute Messer startet dann nicht.\n\n" ..
      "• An der Minimap hat er seinen eigenen Knopf (gekreuzte Schwerter)." },
    { "Das Fenster",
      "• " .. Y .. "Reiter oben|r: Schaden · Heilung · Aggro.\n\n" ..
      "• " .. Y .. "Kampf / Gesamt|r: nur der letzte Kampf oder alles seit dem Zurücksetzen.\n\n" ..
      "• " .. Y .. "Maus über einen Spieler|r: Aufschlüsselung nach Fähigkeiten, die stärkste oben.\n\n" ..
      "• " .. Y .. "Verschieben|r: an der Kopfzeile ziehen. " .. Y .. "Größe|r: am Griff unten rechts.\n\n" ..
      "• " .. Y .. "+|r öffnet bis zu 3 weitere Fenster – z. B. Schaden und Heilung nebeneinander. " .. Y .. "Reset|r setzt alle Werte zurück." },
    { "Aggro",
      "• Im Reiter " .. Y .. "Aggro|r siehst du, wie nah jeder an der Bedrohung des Tanks ist.\n\n" ..
      "• Ab 80 % blinkt dein Balken rot – Zeit, kurz langsamer zu machen.\n\n" ..
      "• " .. Y .. "Klick auf einen Namen|r visiert diesen Spieler an – auch im Kampf." },
    { "Minimap-Knopf & Befehle",
      "Minimap-Knopf: " .. Y .. "Linksklick|r Fenster an/aus · " .. Y .. "Rechtsklick|r Schaden → Heilung → Aggro · " .. Y .. "Shift+Linksklick|r zurücksetzen · " .. Y .. "Ziehen|r verschiebt den Knopf.\n\n" ..
      Y .. "/meter|r – an/aus\n" .. Y .. "/meter schaden|r · " .. Y .. "heilung|r · " .. Y .. "aggro|r – Reiter wechseln\n" ..
      Y .. "/meter kampf|r · " .. Y .. "gesamt|r – Zeitraum\n" .. Y .. "/meter 2|r · " .. Y .. "3|r · " .. Y .. "4|r – weitere Fenster\n" ..
      Y .. "/meter reset|r – zurücksetzen\n" .. Y .. "/meter intro|r – diese Einführung · " .. Y .. "/meter neu|r – was ist neu\n\n" ..
      "Mit der siikk-Oberfläche: " .. Y .. "/th addons|r schaltet den Damagemeter und seinen Minimap-Knopf an oder aus." },
}, function() return DamagemeterTobsiikkDB end, "/meter intro")

do -- /meter intro
    local alt = SlashCmdList.SIIKKUIDM
    SlashCmdList.SIIKKUIDM = function(input)
        local a = (input or ""):lower():match("^%s*(.-)%s*$")
        if a == "intro" or a == "info" or a == "einführung" then SiikkIntroAPI["siikk-Damagemeter"]() return end
        if a == "neu" or a == "neuigkeiten" then if SiikkNeuAPI and SiikkNeuAPI["siikk-Damagemeter"] then SiikkNeuAPI["siikk-Damagemeter"]() end return end
        if alt then alt(input) end
    end
end
