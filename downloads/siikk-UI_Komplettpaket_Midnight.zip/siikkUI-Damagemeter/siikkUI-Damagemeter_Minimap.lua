-- siikk-Damagemeter · eigener Minimap-Knopf
local ADDON = ...
local function sv()
    DamagemeterTobsiikkDB = DamagemeterTobsiikkDB or {}
    DamagemeterTobsiikkDB.mm = DamagemeterTobsiikkDB.mm or {}
    return DamagemeterTobsiikkDB.mm
end
siikkMinimapKnopf("siikk-Damagemeter", "|cffe03030siikk|r-|cffffd100Damagemeter|r", "Interface\\AddOns\\" .. ADDON .. "\\Media\\siikk_dm_icon", sv,
    function() if IsShiftKeyDown() then SlashCmdList.SIIKKUIDM("reset") else SlashCmdList.SIIKKUIDM("") end end,
    function()
        local reihe = { schaden = "heilung", heilung = "aggro", aggro = "schaden" }
        local db = DamagemeterTobsiikkDB and DamagemeterTobsiikkDB.meter
        local jetzt = (type(db) == "table" and db.art) or "schaden"
        SlashCmdList.SIIKKUIDM(reihe[jetzt] or "schaden")
    end,
    { "Linksklick: Fenster an/aus", "Rechtsklick: Schaden → Heilung → Aggro", "Shift+Linksklick: Werte zurücksetzen" }, 235)
