-- siikk-Damagemeter · „Was ist neu?“ – erzeugt aus tools/changelog.py (nicht von Hand ändern)
siikkNeu("siikk-Damagemeter", "|cffe03030siikk|r-|cffffd100Damagemeter|r", "Interface\\AddOns\\siikkUI-Damagemeter\\Media\\siikk_dm_icon", "2.5",
{
    { version = "2.5", datum = "31.10.2026", punkte = { "Neu: Fenster „Was ist neu?“ nach jedem Update (wieder öffnen: /meter neu)." } },
    { version = "2.4", datum = "31.10.2026", punkte = { "Neu: Einführung beim ersten Start (/meter intro)." } },
    { version = "2.3", datum = "31.10.2026", punkte = { "Neuer Name: siikk-Damagemeter.", "Eigener Minimap-Knopf (gekreuzte Schwerter): Linksklick an/aus, Rechtsklick Schaden → Heilung → Aggro, Shift+Linksklick zurücksetzen." } },
    { version = "2.2", datum = "31.10.2026", punkte = { "siikkUI-Schild oben auf dem Messer, neue Standard-Position." } }
}, function() return DamagemeterTobsiikkDB end, "/meter neu")
