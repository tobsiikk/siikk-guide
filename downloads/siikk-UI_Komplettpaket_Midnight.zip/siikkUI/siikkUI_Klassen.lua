-- siikkUI · Klassen
-- Damit das Addon auf jedem Charakter passt: erkennt die Klasse und zeigt automatisch
--  1) eine Cooldown-Leiste mit den wichtigen Abklingzeiten der Klasse (Bilder kommen aus dem Spiel),
--  2) eine Leiste mit DEINEN Schwächungen (DoTs/Debuffs) am Ziel – für alle Klassen außer dem Hexer (der hat seine DoT-Symbole),
--  3) Erinnerungen an fehlende Klassen-Buffs (z. B. Magier: Rüstung + Arkane Intelligenz).
-- Hexer-Teile (Seelensplitter, Seelenstein, Gesundheitsstein, Einbruch der Nacht …) bleiben nur beim Hexer an.
local ADDON, NS = ...
NS = NS or {}
local DB
local function msg(t) if NS.msg then NS.msg(t) else DEFAULT_CHAT_FRAME:AddMessage("|cffe03030siikk|r|cffffd100UI|r: " .. t) end end
local function pass(ok, ...) if ok then return ... end end
local function safe(fn, ...) if not fn then return nil end return pass(pcall(fn, ...)) end
local function secret(v) return issecretvalue and issecretvalue(v) end
local function num(v) return type(v) == "number" and not secret(v) end
local GOLD = NS.GOLD or { .85, .65, .15 }
local FONT = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"

---------------------------------------------------------------------------
-- Zauber pro Klasse (Burning Crusade / Classic; Rang-1-IDs – Namen und Bilder holt das Spiel selbst, auch auf Deutsch)
---------------------------------------------------------------------------
local CD = {
  WARRIOR = { 12292, 1719, 871, 12975, 2565, 6552, 72, 18499, 1161, 355, 20252, 100 },
  PALADIN = { 642, 498, 1022, 633, 853, 31884, 20271, 26573, 20216, 1044, 20925, 31935 },
  HUNTER  = { 3045, 19574, 34477, 5384, 781, 1499, 19263, 3044, 2643, 19503, 1543, 19434 },
  ROGUE   = { 13750, 13877, 14177, 2983, 5277, 1856, 2094, 1766, 31224, 14185, 1776, 408 },
  PRIEST  = { 10060, 33206, 586, 8122, 32379, 34433, 14751, 6346, 15487, 17, 724, 32546 },
  SHAMAN  = { 2825, 32182, 16166, 16188, 30823, 8042, 2894, 2062, 17364, 8177, 20608, 421 },
  MAGE    = { 12472, 12042, 12043, 11129, 45438, 1953, 2139, 12051, 122, 120, 31687, 11958 },
  WARLOCK = { 6789, 5484, 17877, 18708, 1122, 30283, 17962, 30108, 6229, 29858, 18288, 1714 },
  DRUID   = { 29166, 22812, 17116, 740, 20484, 5229, 22842, 5209, 16979, 33831, 18562, 33878 },
}
-- Buffs, an die erinnert wird (einer aus der Liste reicht). waffe = Waffen-Verzauberung (Gift, Schamanen-Waffe)
local BUFF = {
  MAGE    = { { "Rüstung", { 30482, 6117, 168, 7302 } }, { "Arkane Intelligenz", { 1459, 23028 } } },
  PRIEST  = { { "Seelenstärke", { 1243, 21562 } }, { "Inneres Feuer", { 588 } } },
  DRUID   = { { "Mal der Wildnis", { 1126, 21849 } }, { "Dornen", { 467 } } },
  PALADIN = { { "Aura", { 465, 7294, 19746, 19876, 19888, 19891, 32223 } }, { "Segen", { 19740, 19742, 20217, 1038, 20911, 19977, 25782, 25894, 25898 } } },
  HUNTER  = { { "Aspekt", { 13165, 5118, 13163, 34074, 20043, 13159 } } },
  WARRIOR = { { "Schlachtruf", { 6673, 469 } } },
  SHAMAN  = { { "Schild", { 324, 24398 } }, { "Waffe verzaubert", nil, "waffe", { 8017, 8024, 8033, 8232, 8024 } } },
  ROGUE   = { { "Gift auf der Waffe", nil, "waffe", { 8679, 2823, 3408, 5761, 13219 } } },
}

-- Kleine Helfer, die in Classic, TBC, Forever und Midnight funktionieren
local function sInfo(id)
  if C_Spell and C_Spell.GetSpellInfo then
    local t = safe(C_Spell.GetSpellInfo, id)
    if type(t) == "table" then return t.name, t.iconID end
  end
  if GetSpellInfo then local n, _, ic = safe(GetSpellInfo, id); return n, ic end
end
local function known(id)
  if IsPlayerSpell and safe(IsPlayerSpell, id) then return true end
  if IsSpellKnown and safe(IsSpellKnown, id) then return true end
  if C_SpellBook and C_SpellBook.IsSpellKnown and safe(C_SpellBook.IsSpellKnown, id) then return true end
  return false
end
local function cdOf(id)
  if C_Spell and C_Spell.GetSpellCooldown then
    local t = safe(C_Spell.GetSpellCooldown, id)
    if type(t) == "table" then return t.startTime, t.duration end
  end
  if GetSpellCooldown then local s, d = safe(GetSpellCooldown, id); return s, d end
end
local function fmtT(left)
  if left >= 3600 then return math.floor(left / 3600 + .5) .. "h" end
  if left >= 60 then return math.floor(left / 60 + .5) .. "m" end
  if left >= 10 then return tostring(math.floor(left)) end
  return string.format("%.1f", left)
end
local function cdClear(cd) if cd.Clear then pcall(cd.Clear, cd) else pcall(cd.SetCooldown, cd, 0, 0) end end
local function blink(fs, left)
  if NS.blinkTimer then NS.blinkTimer(fs, left) return end
  if left < 3 then fs:SetTextColor(1, .15, .15); fs:SetAlpha((math.floor(GetTime() * 4) % 2 == 0) and 1 or .25) else fs:SetTextColor(1, 1, 1); fs:SetAlpha(1) end
end

---------------------------------------------------------------------------
-- Gemeinsamer Baustein: verschiebbare Symbol-Leiste
---------------------------------------------------------------------------
local function mkBar(name, key, x, y)
  local f = CreateFrame("Frame", name, UIParent)
  f:SetSize(40, 40); f:SetMovable(true); f:SetClampedToScreen(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", function(s) if DB and not DB.gesperrt then s:StartMoving() end end)
  f:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); if NS.savePos then NS.savePos(s, key) end end)
  if NS.makeScalable then NS.makeScalable(f, key) end
  if NS.extraFrames then table.insert(NS.extraFrames, { frame = f, key = key, point = "CENTER", x = x, y = y }) end
  f.icons = {}
  f:Hide()
  return f
end
local function mkIcon(parent, size)
  local b = CreateFrame("Frame", nil, parent, "BackdropTemplate"); b:SetSize(size, size)
  if b.SetBackdrop then b:SetBackdrop({ edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 }); b:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .9) end
  b.tex = b:CreateTexture(nil, "ARTWORK"); b.tex:SetPoint("TOPLEFT", 1, -1); b.tex:SetPoint("BOTTOMRIGHT", -1, 1); b.tex:SetTexCoord(.08, .92, .08, .92)
  b.cd = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate"); b.cd:SetAllPoints(b.tex)
  if b.cd.SetHideCountdownNumbers then b.cd:SetHideCountdownNumbers(true) end
  if b.cd.SetDrawEdge then b.cd:SetDrawEdge(false) end
  local lay = CreateFrame("Frame", nil, b); lay:SetAllPoints(); lay:SetFrameLevel(b.cd:GetFrameLevel() + 2)
  b.time = lay:CreateFontString(nil, "OVERLAY"); b.time:SetPoint("CENTER"); pcall(b.time.SetFont, b.time, FONT, size >= 30 and 14 or 11, "OUTLINE")
  b.count = lay:CreateFontString(nil, "OVERLAY"); b.count:SetPoint("BOTTOMRIGHT", -1, 1); pcall(b.count.SetFont, b.count, FONT, 10, "OUTLINE")
  b:EnableMouse(true)
  b:SetScript("OnEnter", function(s) if s.spell then GameTooltip:SetOwner(s, "ANCHOR_TOP"); pcall(GameTooltip.SetSpellByID, GameTooltip, s.spell); GameTooltip:Show() elseif s.tip then GameTooltip:SetOwner(s, "ANCHOR_TOP"); GameTooltip:AddLine(s.tip); GameTooltip:Show() end end)
  b:SetScript("OnLeave", function() GameTooltip:Hide() end)
  -- Ziehen an einem Symbol verschiebt die ganze Leiste
  b:RegisterForDrag("LeftButton")
  b:SetScript("OnDragStart", function() local p = parent; if DB and not DB.gesperrt then p:StartMoving() end end)
  b:SetScript("OnDragStop", function() local p = parent; p:StopMovingOrSizing(); local s = p:GetScript("OnDragStop"); if s then s(p) end end)
  b:Hide()
  return b
end
local function layoutRow(f, list, size, cols)
  cols = cols or 99
  for i, b in ipairs(f.icons) do
    if i <= #list then b:ClearAllPoints(); b:SetPoint("TOPLEFT", f, "TOPLEFT", ((i - 1) % cols) * (size + 4), -math.floor((i - 1) / cols) * (size + 4)); b:Show() else b:Hide() end
  end
  local c, r = math.min(#list, cols), math.max(1, math.ceil(#list / cols))
  f:SetSize(math.max(size, c * (size + 4) - 4), r * (size + 4) - 4)
end

local cls -- Klassen-Kürzel, z. B. "MAGE"
local WARLOCK_ONLY_KEYS = { "splitter", "seelenstein", "dots", "gesundheitsstein", "nacht", "seelendieb", "erinnerung", "beschwoeren", "cc" }

---------------------------------------------------------------------------
-- 1) Cooldown-Leiste
---------------------------------------------------------------------------
local cdBar = mkBar("TobsiikkHelferCooldowns", "klassen_cooldowns", 0, -230)
local cdList = {}
-- Alle Fähigkeiten mit Abklingzeit aus dem Zauberbuch (dazu die bewährte Klassenliste als Standard-Auswahl)
local function baseCD(id)
  local ms = safe(rawget(_G, "GetSpellBaseCooldown"), id)
  if not num(ms) and type(C_Spell) == "table" then ms = safe(C_Spell.GetSpellBaseCooldown, id) end
  return num(ms) and ms / 1000 or 0
end
local function bookSpells()
  local out = {}
  local GSBI = rawget(_G, "GetSpellBookItemInfo")
  if type(GSBI) == "function" and type(rawget(_G, "GetNumSpellTabs")) == "function" then
    for t = 1, (safe(GetNumSpellTabs) or 0) do
      local _, _, off, n = safe(GetSpellTabInfo, t)
      if num(off) and num(n) then
        for i = off + 1, off + n do
          local typ, id = safe(GSBI, i, rawget(_G, "BOOKTYPE_SPELL") or "spell")
          if typ == "SPELL" and num(id) and not safe(rawget(_G, "IsPassiveSpell"), id) then out[#out + 1] = id end
        end
      end
    end
  elseif type(C_SpellBook) == "table" and C_SpellBook.GetNumSpellBookSkillLines and C_SpellBook.GetSpellBookItemInfo then
    local E = rawget(_G, "Enum"); local bank = type(E) == "table" and type(E.SpellBookSpellBank) == "table" and E.SpellBookSpellBank.Player or 0
    for t = 1, (safe(C_SpellBook.GetNumSpellBookSkillLines) or 0) do
      local li = safe(C_SpellBook.GetSpellBookSkillLineInfo, t)
      if type(li) == "table" and num(li.itemIndexOffset) and num(li.numSpellBookItems) and not li.shouldHide then
        for i = li.itemIndexOffset + 1, li.itemIndexOffset + li.numSpellBookItems do
          local it = safe(C_SpellBook.GetSpellBookItemInfo, i, bank)
          if type(it) == "table" and num(it.spellID) and not it.isPassive and not it.isOffSpec then out[#out + 1] = it.spellID end
        end
      end
    end
  end
  return out
end
local function cdCandidates()
  local list, seen = {}, {}
  local function add(id, def)
    local n, ic = sInfo(id)
    if type(n) ~= "string" or secret(n) then return end
    local e = seen[n]
    if e then e.id = id; if ic then e.icon = ic end return end -- höherer Rang ersetzt den niedrigeren
    e = { id = id, name = n, icon = ic, def = def }; seen[n] = e; list[#list + 1] = e
  end
  for _, id in ipairs(CD[cls] or {}) do if known(id) then add(id, true) end end
  for _, id in ipairs(bookSpells()) do if seen[(sInfo(id))] or baseCD(id) > 1.5 then add(id, false) end end
  for _, e in ipairs(list) do e.cd = baseCD(e.id) end
  return list
end
local function gewaehlt(e)
  local w
  if DB and type(DB.cdWahl) == "table" then w = DB.cdWahl[e.name] end
  if w == nil then return e.def end
  return w
end
local function buildCD()
  cdList = {}
  if not (DB and DB.cdLeiste ~= false) then cdBar:Hide() return end
  for _, e in ipairs(cdCandidates()) do if gewaehlt(e) then cdList[#cdList + 1] = e end end
  for i, e in ipairs(cdList) do
    local b = cdBar.icons[i] or mkIcon(cdBar, 36); cdBar.icons[i] = b
    b.tex:SetTexture(e.icon); b.spell = e.id; b.cdEnd = nil
  end
  layoutRow(cdBar, cdList, 36, DB.cdSpalten or 12)
  if #cdList > 0 then cdBar:Show() else cdBar:Hide() end
end
local cdAcc = 0
cdBar:SetScript("OnUpdate", function(_, el)
  cdAcc = cdAcc + (el or 0); if cdAcc < .1 then return end; cdAcc = 0
  local now = GetTime()
  for i, e in ipairs(cdList) do
    local b = cdBar.icons[i]
    local s, d = cdOf(e.id)
    if num(s) and num(d) and d > 1.6 and s > 0 then
      local left = s + d - now
      if b.cdEnd ~= s + d then b.cd:SetCooldown(s, d); b.cdEnd = s + d end
      b.tex:SetDesaturated(true); b:SetAlpha(1)
      if left > 0 then b.time:SetText(fmtT(left)); blink(b.time, left) else b.time:SetText("") end
    else
      if b.cdEnd then cdClear(b.cd); b.cdEnd = nil end
      b.tex:SetDesaturated(false); b.time:SetText("")
    end
  end
end)

---------------------------------------------------------------------------
-- Einstellungen: Reiter „Cooldowns“ – jede Klasse wählt selbst, welche Abklingzeiten angezeigt werden
---------------------------------------------------------------------------
local cm = CreateFrame("Frame", "TobsiikkHelferCooldownMenue", UIParent, "BasicFrameTemplateWithInset")
cm:SetSize(560, 620); cm:SetPoint("CENTER", 0, 20); cm:SetFrameStrata("DIALOG"); cm:Hide()
cm:SetMovable(true); cm:EnableMouse(true); cm:RegisterForDrag("LeftButton"); cm:SetClampedToScreen(true)
cm:SetScript("OnDragStart", cm.StartMoving); cm:SetScript("OnDragStop", cm.StopMovingOrSizing)
if tinsert and UISpecialFrames then tinsert(UISpecialFrames, "TobsiikkHelferCooldownMenue") end
cm.title = cm:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); cm.title:SetPoint("TOP", 0, -5); cm.title:SetText("siikkUI · Klasse & Cooldowns")
cm.head = cm:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); cm.head:SetPoint("TOPLEFT", 18, -34)
cm.info = cm:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); cm.info:SetPoint("TOPLEFT", 18, -56); cm.info:SetWidth(524); cm.info:SetJustifyH("LEFT")
cm.info:SetText("Häkchen = wird in der Cooldown-Leiste angezeigt. Die Liste zeigt alle Fähigkeiten mit Abklingzeit aus deinem Zauberbuch. Neue Zauber erscheinen hier automatisch, sobald du sie lernst.")
cm.an = CreateFrame("CheckButton", nil, cm, "UICheckButtonTemplate"); cm.an:SetSize(26, 26); cm.an:SetPoint("TOPLEFT", 14, -84)
for _, k in ipairs({ "text", "Text" }) do local t = rawget(cm.an, k); if type(t) == "table" and t.SetText then t:SetText("") end end
cm.anT = cm:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); cm.anT:SetPoint("LEFT", cm.an, "RIGHT", 2, 1); cm.anT:SetText("Cooldown-Leiste anzeigen")
cm.spT = cm:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); cm.spT:SetPoint("TOPLEFT", 300, -90)
local function cmCheck(x, y, text, get, set)
  local c = CreateFrame("CheckButton", nil, cm, "UICheckButtonTemplate"); c:SetSize(26, 26); c:SetPoint("TOPLEFT", x, y)
  for _, k in ipairs({ "text", "Text" }) do local t = rawget(c, k); if type(t) == "table" and t.SetText then t:SetText("") end end
  local fs = c:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); fs:SetPoint("LEFT", c, "RIGHT", 2, 1); fs:SetText(text)
  c.get = get; c:SetScript("OnClick", function(s) set(s:GetChecked() and true or false) end)
  return c
end
cm.deb = cmCheck(14, -110, "Meine Schwächungen am Ziel", function() return DB.debuffLeiste ~= false end, function(v) DB.debuffLeiste = v; updateDebuffs() end)
cm.erin = cmCheck(300, -110, "Buff-Erinnerungen der Klasse", function() return DB.klassenErinnerung ~= false end, function(v) DB.klassenErinnerung = v; updateReminder() end)
local scroll = CreateFrame("ScrollFrame", "TobsiikkHelferCooldownScroll", cm, "UIPanelScrollFrameTemplate")
scroll:SetPoint("TOPLEFT", 14, -142); scroll:SetPoint("BOTTOMRIGHT", -34, 50)
local content = CreateFrame("Frame", nil, scroll); content:SetSize(500, 10); scroll:SetScrollChild(content)
local cmRows = {}
local function cmButton(x, w, text, fn)
  local b = CreateFrame("Button", nil, cm, "UIPanelButtonTemplate"); b:SetSize(w, 24); b:SetPoint("BOTTOMLEFT", x, 16); b:SetText(text); b:SetScript("OnClick", fn); return b
end
local function cdText(sec)
  if not sec or sec <= 0 then return "" end
  if sec >= 60 then local m = sec / 60; return (m == math.floor(m) and string.format("%d", m) or string.format("%.1f", m)) .. " Min." end
  return math.floor(sec + .5) .. " Sek."
end
local cmFill
local function setWahl(e, on)
  DB.cdWahl = type(DB.cdWahl) == "table" and DB.cdWahl or {}
  if on == e.def then DB.cdWahl[e.name] = nil else DB.cdWahl[e.name] = on end
end
cmFill = function()
  if not DB then return end
  local list = cdCandidates()
  cm.head:SetText((NS.klassenName and NS.klassenName() or tostring(cls)) .. ": " .. #list .. " Fähigkeiten mit Abklingzeit")
  cm.an:SetChecked(DB.cdLeiste ~= false)
  cm.deb:SetChecked(cm.deb.get() and true or false); cm.erin:SetChecked(cm.erin.get() and true or false)
  cm.deb:SetShown(cls ~= "WARLOCK") -- der Hexer hat dafür seine DoT-Symbole (Reiter „Hexer“)
  cm.erin:SetShown(BUFF[cls] ~= nil)
  cm.spT:SetText("Symbole pro Reihe: |cffffd100" .. (DB.cdSpalten or 12) .. "|r")
  local half = math.ceil(#list / 2)
  for i, e in ipairs(list) do
    local r = cmRows[i]
    if not r then
      r = CreateFrame("CheckButton", nil, content, "UICheckButtonTemplate"); r:SetSize(24, 24)
      for _, k in ipairs({ "text", "Text" }) do local t = rawget(r, k); if type(t) == "table" and t.SetText then t:SetText("") end end
      r.icon = r:CreateTexture(nil, "ARTWORK"); r.icon:SetSize(22, 22); r.icon:SetPoint("LEFT", r, "RIGHT", 2, 0); r.icon:SetTexCoord(.08, .92, .08, .92)
      r.t = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); r.t:SetPoint("LEFT", r.icon, "RIGHT", 5, 0); r.t:SetWidth(170); r.t:SetJustifyH("LEFT")
      if r.t.SetWordWrap then r.t:SetWordWrap(false) end
      r.cdt = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); r.cdt:SetPoint("LEFT", r.t, "RIGHT", 2, 0)
      r:SetScript("OnClick", function(s) setWahl(s.e, s:GetChecked() and true or false); if not InCombatLockdown() then buildCD() end end)
      r:SetScript("OnEnter", function(s) GameTooltip:SetOwner(s, "ANCHOR_RIGHT"); pcall(GameTooltip.SetSpellByID, GameTooltip, s.e.id); GameTooltip:Show() end)
      r:SetScript("OnLeave", function() GameTooltip:Hide() end)
      cmRows[i] = r
    end
    r.e = e
    local col, row = (i > half) and 1 or 0, (i > half) and (i - half - 1) or (i - 1)
    r:ClearAllPoints(); r:SetPoint("TOPLEFT", content, "TOPLEFT", 4 + col * 250, -row * 28)
    r.icon:SetTexture(e.icon); r.t:SetText(e.name); r.cdt:SetText(cdText(e.cd))
    r:SetChecked(gewaehlt(e) and true or false); r:Show()
  end
  for i = #list + 1, #cmRows do cmRows[i]:Hide() end
  content:SetHeight(math.max(10, half * 28))
end
cm.an:SetScript("OnClick", function(s) DB.cdLeiste = s:GetChecked() and true or false; buildCD() end)
local sp1 = CreateFrame("Button", nil, cm, "UIPanelButtonTemplate"); sp1:SetSize(24, 22); sp1:SetPoint("LEFT", cm.spT, "RIGHT", 8, 0); sp1:SetText("-")
local sp2 = CreateFrame("Button", nil, cm, "UIPanelButtonTemplate"); sp2:SetSize(24, 22); sp2:SetPoint("LEFT", sp1, "RIGHT", 2, 0); sp2:SetText("+")
sp1:SetScript("OnClick", function() DB.cdSpalten = math.max(1, (DB.cdSpalten or 12) - 1); buildCD(); cmFill() end)
sp2:SetScript("OnClick", function() DB.cdSpalten = math.min(24, (DB.cdSpalten or 12) + 1); buildCD(); cmFill() end)
cmButton(16, 120, "Alle an", function() for _, e in ipairs(cdCandidates()) do setWahl(e, true) end; buildCD(); cmFill() end)
cmButton(140, 120, "Alle aus", function() for _, e in ipairs(cdCandidates()) do setWahl(e, false) end; buildCD(); cmFill() end)
cmButton(264, 130, "Standard", function() DB.cdWahl = {}; buildCD(); cmFill() end)
do
  local ib = CreateFrame("Button", nil, cm, "UIPanelButtonTemplate"); ib:SetSize(170, 22); ib:SetPoint("TOPRIGHT", -14, -30); ib:SetText("Einführung & Klasse")
  ib:SetScript("OnClick", function() cm:Hide(); NS.showIntro() end)
end
cmButton(400, 140, "Leiste platzieren", function() if SlashCmdList.TOBSIIKKHELFER then SlashCmdList.TOBSIIKKHELFER("verschieben") end end)
cm:SetScript("OnShow", function() cmFill() end)
if NS.attachTabs then NS.attachTabs(cm, function() return (cls and cls ~= "WARLOCK") and 1 or 6 end) end
NS.tab1Win = function() if cls and cls ~= "WARLOCK" then return cm end end
NS.cooldownMenu = cmFill

---------------------------------------------------------------------------
-- 2) Deine Schwächungen am Ziel (alle Klassen außer Hexer)
---------------------------------------------------------------------------
local dbBar = mkBar("TobsiikkHelferMeineDebuffs", "klassen_debuffs", 0, -190)
local function myDebuffs()
  local out = {}
  for i = 1, 40 do
    local name, icon, count, dur, exp, src, sid
    if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
      local d = safe(C_UnitAuras.GetAuraDataByIndex, "target", i, "HARMFUL|PLAYER")
      if type(d) ~= "table" then break end
      name, icon, count, dur, exp, src, sid = d.name, d.icon, d.applications, d.duration, d.expirationTime, d.sourceUnit, d.spellId
    elseif UnitAura then
      local n, ic, c, _, du, ex, so, _, _, si = safe(UnitAura, "target", i, "HARMFUL|PLAYER")
      if not n then break end
      name, icon, count, dur, exp, src, sid = n, ic, c, du, ex, so, si
    else break end
    if name then out[#out + 1] = { icon = icon, count = count, dur = dur, exp = exp, spell = sid } end
  end
  return out
end
local dbList = {}
local function updateDebuffs()
  if not (DB and DB.debuffLeiste ~= false) or cls == "WARLOCK" or not safe(UnitExists, "target") then
    dbList = {}; for _, b in ipairs(dbBar.icons) do b:Hide() end
    if not (NS.isPlacing and NS.isPlacing()) then dbBar:Hide() end
    return
  end
  dbList = myDebuffs()
  for i, e in ipairs(dbList) do
    if i > 10 then break end
    local b = dbBar.icons[i] or mkIcon(dbBar, 32); dbBar.icons[i] = b
    b.tex:SetTexture(e.icon); b.spell = e.spell
    b.count:SetText((num(e.count) and e.count > 1) and tostring(e.count) or "")
    if num(e.dur) and num(e.exp) and e.dur > 0 then b.cd:SetCooldown(e.exp - e.dur, e.dur); b.exp = e.exp else cdClear(b.cd); b.exp = nil; b.time:SetText("") end
  end
  local shown = {}; for i = 1, math.min(10, #dbList) do shown[i] = dbList[i] end
  layoutRow(dbBar, shown, 32)
  if #dbList > 0 then dbBar:Show() elseif not (NS.isPlacing and NS.isPlacing()) then dbBar:Hide() end
end
local dbAcc = 0
dbBar:SetScript("OnUpdate", function(_, el)
  dbAcc = dbAcc + (el or 0); if dbAcc < .1 then return end; dbAcc = 0
  local now = GetTime()
  for _, b in ipairs(dbBar.icons) do
    if b:IsShown() and b.exp then local left = b.exp - now; if left > 0 then b.time:SetText(fmtT(left)); blink(b.time, left) else b.time:SetText("") end end
  end
end)

---------------------------------------------------------------------------
-- 3) Buff-Erinnerungen der Klasse
---------------------------------------------------------------------------
local erBar = mkBar("TobsiikkHelferKlassenErinnerung", "klassen_erinnerung", 0, 150)
local function hasBuffNamed(names)
  for i = 1, 40 do
    local n
    if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
      local d = safe(C_UnitAuras.GetAuraDataByIndex, "player", i, "HELPFUL"); if type(d) ~= "table" then break end; n = d.name
    elseif UnitBuff then n = safe(UnitBuff, "player", i); if not n then break end
    else break end
    if n and not secret(n) and names[n] then return true end
  end
  return false
end
local function weaponOk()
  if not GetWeaponEnchantInfo then return true end
  local mh = safe(GetWeaponEnchantInfo)
  return mh == true
end
local function updateReminder()
  local list = {}
  if DB and DB.klassenErinnerung ~= false and not safe(UnitIsDeadOrGhost, "player") then
    for _, r in ipairs(BUFF[cls] or {}) do
      local label, ids, kind, need = r[1], r[2], r[3], r[4]
      if kind == "waffe" then
        local any; for _, id in ipairs(need or {}) do if known(id) then any = id break end end
        if any and not weaponOk() then local _, ic = sInfo(any); list[#list + 1] = { icon = ic, tip = label .. " fehlt!" } end
      else
        local names, first = {}, nil
        for _, id in ipairs(ids) do
          local n, ic = sInfo(id)
          if n then names[n] = true; if known(id) and not first then first = { icon = ic, id = id } end end
        end
        if first and not hasBuffNamed(names) then list[#list + 1] = { icon = first.icon, tip = label .. " fehlt!", spell = first.id } end
      end
    end
  end
  for i, e in ipairs(list) do
    local b = erBar.icons[i] or mkIcon(erBar, 40); erBar.icons[i] = b
    b.tex:SetTexture(e.icon); b.spell = e.spell; b.tip = e.tip
    if b.SetBackdropBorderColor then b:SetBackdropBorderColor(1, .3, .3, 1) end
  end
  layoutRow(erBar, list, 40)
  erBar.n = #list
  if #list > 0 then erBar:Show() elseif not (NS.isPlacing and NS.isPlacing()) then erBar:Hide() end
end
local erAcc = 0
erBar:SetScript("OnUpdate", function(s, el)
  erAcc = erAcc + (el or 0)
  if erAcc > 2 then erAcc = 0; updateReminder() end
  -- fehlende Buffs pulsieren sanft
  if (s.n or 0) > 0 then s:SetAlpha(.55 + .45 * math.abs(math.sin(GetTime() * 3))) else s:SetAlpha(1) end
end)

---------------------------------------------------------------------------
-- Einrichtung beim ersten Start: Klasse wählen + kurze Einführung in alle Funktionen (/th intro zeigt sie erneut)
---------------------------------------------------------------------------
local CLASSES = { "WARRIOR", "PALADIN", "HUNTER", "ROGUE", "PRIEST", "SHAMAN", "MAGE", "WARLOCK", "DRUID" }
local CLASS_DE = { WARRIOR = "Krieger", PALADIN = "Paladin", HUNTER = "Jäger", ROGUE = "Schurke", PRIEST = "Priester", SHAMAN = "Schamane", MAGE = "Magier", WARLOCK = "Hexenmeister", DRUID = "Druide" }
local Y = "|cffffd100"
local PAGES = {
  { "Einstellungen öffnen",
    "• " .. Y .. "/th|r öffnet die Einstellungen – oder Klick auf den runden Knopf am Rand der Minimap.\n\n" ..
    "• Die " .. Y .. "Reiter|r im Fenster: Klasse · Hinweise · Allgemein · Rahmen & Chat · Leisten · Cooldowns · Positionen. Ganz oben rechts: der lila Knopf „Platzieren starten“.\n\n" ..
    "• " .. Y .. "/th hilfe|r zeigt alle Befehle im Chat.\n\n" ..
    "• Diese Einführung kannst du jederzeit mit " .. Y .. "/th intro|r wieder öffnen." },
  { "Fenster verschieben, einrasten, Größe ändern",
    "• " .. Y .. "/th verschieben|r (oder der lila Knopf) startet den Platzier-Modus: ein Raster erscheint, alle Leisten und Symbole werden sichtbar.\n\n" ..
    "• " .. Y .. "Ziehen|r verschiebt, " .. Y .. "Shift beim Loslassen|r rastet ein, " .. Y .. "Mausrad|r ändert die Größe (in %). Bei Leisten voller Knöpfe ziehst du am goldenen Griff.\n\n" ..
    "• Reiter " .. Y .. "Positionen|r: jedes Element einzeln aufleuchten lassen – praktisch, wenn zwei übereinanderliegen.\n\n" ..
    "• " .. Y .. "/th reset|r bzw. „Plätze zurücksetzen“ stellt die Standard-Anordnung wieder her. Fertig? " .. Y .. "/th sperren|r." },
  { "Aktionsleisten, Taschen & Tasten",
    "• Größe der Leisten (z. B. 3 × 8 oder 2 × 5): Reiter " .. Y .. "Leisten|r, gleich oben die Regler Spalten und Felder.\n\n" ..
    "• " .. Y .. "/kb|r = Tastenbelegung: Maus über ein Feld halten und Taste drücken. Rechtsklick löscht, Esc beendet.\n\n" ..
    "• Taschen: alle in einem Fenster, mit Suchfeld oben rechts; Müll grau mit Münze, Quest-Gegenstände gelb.\n\n" ..
    "• Beim Lehrer und in Berufen leuchtet die angeklickte Zeile gelb; Liste und Erklärung stehen in eigenen Kästen.\n\n" ..
    "• Beim Händler: Knopf " .. Y .. "Schnellverkaufen|r unten rechts (oder " .. Y .. "/th verkaufen|r) verkauft alles mit Münzsymbol – der Erlös steht darüber.\n\n" ..
    "• Auktionshaus: Addon " .. Y .. "siikk-Auktionshaus|r (" .. Y .. "/ah|r) – Preise scannen, schnell verkaufen und kaufen, Gewinn-Übersicht.\n\n" ..
    "• Schadenszahlen: Addon " .. Y .. "siikk-Schadenszahlen|r (" .. Y .. "/sz|r) – eigene Schrift, Farben je Magieschule, goldene Krits.\n\n" ..
    "• Infoleiste: Addon " .. Y .. "siikk-Infoleiste|r (" .. Y .. "/il|r) – Ort, Gold aller Charaktere, Haltbarkeit, Erfahrung mit Zeit bis zur Stufe." },
  { "Quests, Questpfeil & Leveln",
    "• " .. Y .. "Questanzeige|r (/th quests): an der Kopfzeile ziehen, Griff unten rechts = Größe, Strg+Mausrad = Schrift. Gelbes ! = angenommen, grüner Haken = fertig.\n\n" ..
    "• " .. Y .. "Questpfeil|r (/th pfeil): führt dich zum Questziel und zur Abgabe. " .. Y .. "Shift+Klick|r auf eine Quest = Pfeil folgt ihr. An/aus per Häkchen „Pfeil“ in der Questanzeige.\n\n" ..
    "• Mit dem Addon " .. Y .. "siikk-Questhilfe|r: wählen, welche Anzeige läuft (Reiter Allgemein oder " .. Y .. "/th quests hilfe|standard|r).\n\n" ..
    "• " .. Y .. "Zeit bis Level|r (/th level an|aus|reset) und " .. Y .. "FPS & Latenz|r (/th fps)." },
  { "Hilfen im Kampf",
    "• " .. Y .. "Zauberleiste|r: Farbe und Zeichen (Horde/Allianz) im Reiter Allgemein.\n\n" ..
    "• " .. Y .. "Cooldown-Leiste|r: Reiter Cooldowns – such dir aus deinem Zauberbuch aus, was angezeigt wird. Die letzten 3 Sek. blinken rot.\n\n" ..
    "• " .. Y .. "Deine Schwächungen am Ziel|r und " .. Y .. "Buff-Erinnerungen|r (fehlender Buff pulsiert rot).\n\n" ..
    "• Buffs/Debuffs über deinem Rahmen und dem Zielrahmen, Zauberleiste des Gegners, eigene Namensplaketten (/th plaketten)." },
  { "Schadensmesser",
    "• " .. Y .. "/meter|r blendet ihn ein/aus. Reiter " .. Y .. "Schaden · Heilung · Aggro|r.\n\n" ..
    "• Maus über einen Spieler = Aufschlüsselung je Fähigkeit (stärkste oben).\n\n" ..
    "• Im Aggro-Reiter: ab 80 % blinkt es rot; " .. Y .. "Klick auf einen Namen|r visiert den Spieler an (auch im Kampf).\n\n" ..
    "• " .. Y .. "+|r öffnet bis zu 3 weitere Fenster, " .. Y .. "Kampf/Gesamt|r schaltet um, " .. Y .. "Reset|r setzt alles zurück." },
  { "Aussehen",
    "• " .. Y .. "Fraktions-Logo|r (Horde/Allianz): ein Schalter für alle Stellen – Fenster, Chat, Zauberleiste, Lebensbalken.\n\n" ..
    "• " .. Y .. "Rahmenfarbe|r: Reiter Rahmen & Chat – gilt für alle Rahmen, auch in den Fenstern. Bei Schwarz werden die Fenster-Rahmen leicht gelblich.\n\n" ..
    "• Uhr mit Datum und Wochentag an der Minimap, Chat-Design mit Logo (/th chat)." },
  { "Profile – und los geht's!",
    "• Reiter " .. Y .. "Allgemein|r → Profile: Einstellungen (auf Wunsch mit Tasten) unter einem Namen speichern und auf Twinks laden.\n\n" ..
    "• Heißt ein Profil wie eine Klasse (z. B. „Magier“), bekommt jeder neue Charakter dieser Klasse es automatisch.\n\n" ..
    "• " .. Y .. "Alle siikk-Addons|r (Oberfläche, Damagemeter, Questhilfe, Auktionshaus, Schadenszahlen, Infoleiste): " .. Y .. "/th addons|r oder Shift+Klick auf den Minimap-Knopf – an/aus, Minimap-Knöpfe und „Info“ (Einführung jedes Addons: " .. Y .. "/meter intro|r, " .. Y .. "/qh intro|r, " .. Y .. "/ah intro|r, " .. Y .. "/sz intro|r, " .. Y .. "/il intro|r).\n\n" ..
    "• Viel Spaß! " .. Y .. "/th intro|r zeigt diese Einführung erneut." },
}
local intro = CreateFrame("Frame", "TobsiikkHelferIntro", UIParent, "BasicFrameTemplateWithInset")
intro:SetSize(540, 440); intro:SetPoint("CENTER", 0, 40); intro:SetFrameStrata("DIALOG"); intro:Hide()
intro:SetMovable(true); intro:EnableMouse(true); intro:RegisterForDrag("LeftButton"); intro:SetClampedToScreen(true)
intro:SetScript("OnDragStart", intro.StartMoving); intro:SetScript("OnDragStop", intro.StopMovingOrSizing)
intro.title = intro:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); intro.title:SetPoint("TOP", 0, -5); intro.title:SetText("siikk-UI · Einrichtung")
-- Hintergrund: siikkUI-Logo, abgedunkelt, damit die Schrift gut lesbar bleibt
intro.bgLogo = intro:CreateTexture(nil, "ARTWORK", nil, -8); intro.bgLogo:SetPoint("TOPLEFT", 4, -24); intro.bgLogo:SetPoint("BOTTOMRIGHT", -4, 4)
intro.bgLogo:SetTexture("Interface\\AddOns\\siikkUI\\Media\\siikkui_logo", nil, nil, "TRILINEAR")
do local a = (532 / 412) / 2; intro.bgLogo:SetTexCoord(.5 - a / 2, .5 + a / 2, 0, 1) end
intro.bgDark = intro:CreateTexture(nil, "ARTWORK", nil, -7); intro.bgDark:SetAllPoints(intro.bgLogo); intro.bgDark:SetColorTexture(0, 0, 0, .55)
intro.head = intro:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); intro.head:SetPoint("TOPLEFT", 24, -38); intro.head:SetWidth(440); intro.head:SetJustifyH("LEFT")
intro.body = intro:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); intro.body:SetPoint("TOPLEFT", intro.head, "BOTTOMLEFT", 0, -12); intro.body:SetWidth(492); intro.body:SetJustifyH("LEFT"); intro.body:SetJustifyV("TOP")
intro.pageTxt = intro:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); intro.pageTxt:SetPoint("TOPRIGHT", -16, -40)
intro.nie = CreateFrame("Button", nil, intro, "UIPanelButtonTemplate"); intro.nie:SetSize(190, 24); intro.nie:SetPoint("BOTTOM", 0, 10); intro.nie:SetText("Nicht wieder anzeigen")
NS.introKonto = function() local r = rawget(_G, "HexenmeisterProfile"); if type(r) ~= "table" then r = {}; HexenmeisterProfile = r end; return r end
intro.back = CreateFrame("Button", nil, intro, "UIPanelButtonTemplate"); intro.back:SetSize(110, 24); intro.back:SetPoint("BOTTOMLEFT", 16, 10); intro.back:SetText("Zurück")
intro.next = CreateFrame("Button", nil, intro, "UIPanelButtonTemplate"); intro.next:SetSize(110, 24); intro.next:SetPoint("BOTTOMRIGHT", -16, 10); intro.next:SetText("Weiter")
intro.classBtns = {}
for i, c in ipairs(CLASSES) do
  local b = CreateFrame("Button", nil, intro, "BackdropTemplate"); b:SetSize(158, 44)
  b:SetPoint("TOPLEFT", 24 + ((i - 1) % 3) * 166, -212 - math.floor((i - 1) / 3) * 52)
  if b.SetBackdrop then b:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 }) end
  b.icon = b:CreateTexture(nil, "ARTWORK"); b.icon:SetSize(34, 34); b.icon:SetPoint("LEFT", 5, 0)
  b.icon:SetTexture("Interface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes")
  local tc = CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[c]; if tc then b.icon:SetTexCoord(tc[1], tc[2], tc[3], tc[4]) end
  b.t = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); b.t:SetPoint("LEFT", b.icon, "RIGHT", 8, 0)
  local col = RAID_CLASS_COLORS and RAID_CLASS_COLORS[c]
  b.t:SetText(CLASS_DE[c]); if col then b.t:SetTextColor(col.r, col.g, col.b) end
  b.cls = c
  intro.classBtns[i] = b
end
local function applyClass(c)
  cls = c; DB.klasse = c
  for _, k in ipairs(WARLOCK_ONLY_KEYS) do DB[k] = (c == "WARLOCK") end
  if not InCombatLockdown() then buildCD() end
  updateDebuffs(); updateReminder()
  if NS.applyLayout then NS.applyLayout() end
  if NS.updateKlassenReiter then NS.updateKlassenReiter() end
end
local function showPage(n)
  intro.page = n
  local isClass = n == 0
  for _, b in ipairs(intro.classBtns) do
    if isClass then
      b:Show()
      local on = b.cls == (DB.klasse or cls)
      if b.SetBackdropColor then b:SetBackdropColor(on and .32 or .05, on and .12 or .04, on and .45 or .07, .95); b:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], on and 1 or .4) end
    else b:Hide() end
  end
  if isClass then
    intro.head:SetText("Herzlich Willkommen und vielen Dank, dass du dich für das Addon von siikkUI entschieden hast!")
    intro.body:SetText("Klicke auf „Weiter“, um alle Einstellungen und Funktionen kennenzulernen.\n\n" .. Y .. "Wähle deine Klasse:|r\n|cffbbbbbb(erkannt: " .. (CLASS_DE[cls] or "?") .. " – das Addon passt Cooldowns und Buff-Erinnerungen daran an)|r")
    intro.back:Hide()
  else
    local p = PAGES[n]
    intro.head:SetText(p[1]); intro.body:SetText(p[2]); intro.back:Show()
  end
  intro.next:SetText(n == #PAGES and "Fertig" or "Weiter")
  intro.pageTxt:SetText((n + 1) .. " / " .. (#PAGES + 1))
end
for _, b in ipairs(intro.classBtns) do
  b:SetScript("OnClick", function(x) applyClass(x.cls); showPage(0); msg("Klasse eingestellt: |cffffd100" .. CLASS_DE[x.cls] .. "|r") end)
end
intro.back:SetScript("OnClick", function() showPage(math.max(0, (intro.page or 0) - 1)) end)
intro.next:SetScript("OnClick", function()
  local n = (intro.page or 0)
  if n == 0 and not DB.klasse then applyClass(cls) end
  if n >= #PAGES then DB.introFertig = true; intro:Hide(); msg("Einrichtung fertig – Einstellungen jederzeit mit |cffffd100/th|r.") return end
  showPage(n + 1)
end)
intro:SetScript("OnHide", function() if DB then DB.introFertig = true end end)
intro.nie:SetScript("OnClick", function()
  NS.introKonto().introNie = true; if DB then DB.introFertig = true end; intro:Hide()
  msg("Die Einführung erscheint nicht mehr von selbst. Öffnen kannst du sie jederzeit in den Einstellungen (Knopf „Einführung & Klasse“ in den Reitern „Rahmen & Chat“ und Klasse/„Cooldowns“) oder mit |cffffd100/th intro|r.")
end)
NS.showIntro = function() showPage(0); intro:Show() end
NS.klassenName = function() return CLASS_DE[cls] or tostring(cls) end
-- Reiter an die gewählte Klasse anpassen: Reiter 1 heißt wie die Klasse; Hexer-Extras nur beim Hexenmeister
NS.updateKlassenReiter = function()
  local hexer = cls == "WARLOCK"
  local tb = NS.tabBtns
  if type(tb) == "table" and tb[1] then
    tb[1].t:SetText(hexer and "Hexer" or (CLASS_DE[cls] or "Klasse"))
    if tb[6] then tb[6]:SetShown(hexer) end
    if tb[7] and tb[5] then tb[7]:ClearAllPoints(); tb[7]:SetPoint("LEFT", (hexer and tb[6]) or tb[5], "RIGHT", 3, 0) end
  end
  for _, o in ipairs(NS.hexerOnly or {}) do if o and o.SetShown then o:SetShown(hexer) end end
  -- „Hinweise“: ohne die Hexer-Zeilen rutscht alles darunter nach oben (keine Lücke)
  for _, o in ipairs(NS.helferMove or {}) do
    if o and o.GetPoint then
      if not o.siikkPos then local p, rel, rp, x, y = o:GetPoint(1); o.siikkPos = { p, rel, rp, x, y } end
      local q = o.siikkPos
      if type(q[5]) == "number" then o:ClearAllPoints(); o:SetPoint(q[1], q[2], q[3], q[4], q[5] + (hexer and 0 or 120)) end
    end
  end
  if cm:IsShown() then cmFill() end
end
---------------------------------------------------------------------------
-- Start, Ereignisse, Befehle
---------------------------------------------------------------------------
local WARLOCK_ONLY = WARLOCK_ONLY_KEYS
local ev = CreateFrame("Frame")
for _, e in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "PLAYER_ENTERING_WORLD", "SPELLS_CHANGED", "LEARNED_SPELL_IN_TAB", "PLAYER_TARGET_CHANGED", "UNIT_AURA", "PLAYER_REGEN_ENABLED", "UNIT_INVENTORY_CHANGED" }) do pcall(ev.RegisterEvent, ev, e) end
ev:SetScript("OnEvent", function(_, e, a1)
  if e == "ADDON_LOADED" then
    if a1 ~= ADDON then return end
    TobsiikkHelferDB = TobsiikkHelferDB or {}; DB = TobsiikkHelferDB
    local _, c = UnitClass("player"); cls = DB.klasse or c
    if cls and cls ~= "WARLOCK" then
      -- Hexer-Teile auf anderen Klassen aus (sie hätten dort nichts anzuzeigen)
      for _, k in ipairs(WARLOCK_ONLY) do DB[k] = false end
    end
    return
  end
  if not DB then return end
  if e == "PLAYER_LOGIN" or e == "PLAYER_ENTERING_WORLD" or e == "SPELLS_CHANGED" or e == "LEARNED_SPELL_IN_TAB" then
    if not InCombatLockdown() then buildCD() end
    updateDebuffs(); updateReminder()
    if e == "PLAYER_LOGIN" and NS.applyLayout then NS.applyLayout() end
    if e == "PLAYER_LOGIN" and NS.updateKlassenReiter then NS.updateKlassenReiter() end
    if e == "PLAYER_LOGIN" and not DB.introFertig and not NS.introKonto().introNie then
      if C_Timer and C_Timer.After then C_Timer.After(2, function() if not InCombatLockdown() then NS.showIntro() end end) else NS.showIntro() end
    end
  elseif e == "PLAYER_TARGET_CHANGED" then updateDebuffs()
  elseif e == "UNIT_AURA" then
    if a1 == "target" then updateDebuffs() elseif a1 == "player" then updateReminder() end
  elseif e == "UNIT_INVENTORY_CHANGED" then updateReminder()
  elseif e == "PLAYER_REGEN_ENABLED" then buildCD(); updateReminder() end
end)

-- im Platzier-Modus alle drei Leisten zeigen (damit man sie hinschieben kann)
local prevLayout = NS.onLayout
NS.onLayout = function(placing)
  if prevLayout then pcall(prevLayout, placing) end
  if placing then
    for _, f in ipairs({ cdBar, dbBar, erBar }) do
      if #f.icons == 0 then local b = mkIcon(f, 36); f.icons[1] = b; b.tex:SetTexture(134400) end
      if not f:IsShown() then f.icons[1]:Show(); f:SetSize(36, 36); f:Show() end
    end
  else
    buildCD(); updateDebuffs(); updateReminder()
  end
end

local baseSlash = SlashCmdList.TOBSIIKKHELFER
if baseSlash then
  SlashCmdList.TOBSIIKKHELFER = function(input)
    local c, arg = (input or ""):lower():match("^(%S*)%s*(.-)$")
    if (c == "cooldowns" or c == "cd") and (arg == "an" or arg == "aus") then DB.cdLeiste = (arg ~= "aus"); buildCD(); msg("Cooldown-Leiste " .. (DB.cdLeiste and "an." or "aus."))
    elseif c == "cooldowns" or c == "cd" or c == "klasse" and arg == "menü" then if NS.showTab then NS.showTab(cls ~= "WARLOCK" and 1 or 6) else cm:Show() end
    elseif c == "debuffs" then DB.debuffLeiste = (arg ~= "aus"); updateDebuffs(); msg("Leiste mit deinen Schwächungen am Ziel " .. (DB.debuffLeiste and "an." or "aus."))
    elseif c == "klassenbuffs" or c == "erinnerungen" then DB.klassenErinnerung = (arg ~= "aus"); updateReminder(); msg("Klassen-Erinnerungen " .. (DB.klassenErinnerung and "an." or "aus."))
    elseif c == "intro" or c == "einrichtung" then NS.showIntro()
    elseif (c == "logo" or c == "zeichen") and NS.applyZeichen then
      if arg == "horde" or arg == "allianz" then DB.zeichen = arg else DB.zeichen = (NS.zeichenArt() == "allianz") and "horde" or "allianz" end
      NS.applyZeichen(); msg("Logo überall: |cffffd100" .. (DB.zeichen == "allianz" and "Allianz" or "Horde") .. "|r")
    elseif c == "klasse" then
      local n = 0; for _ in ipairs(cdList) do n = n + 1 end
      msg("Klasse: " .. tostring(cls) .. " · Cooldowns erkannt: " .. n .. " · eigene Schwächungen am Ziel: " .. #dbList)
    else
      baseSlash(input)
      if c == "hilfe" or c == "help" or c == "?" then msg("/th cd an|aus · /th debuffs an|aus · /th klassenbuffs an|aus · /th klasse – Klassen-Leisten") end
    end
  end
end
NS.klassenDebug = { cdBar = cdBar, dbBar = dbBar, erBar = erBar, cdList = function() return cdList end, build = buildCD, rem = updateReminder, deb = updateDebuffs }
