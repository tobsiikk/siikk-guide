-- siikk-Oberfläche · „Was ist neu?“ – erzeugt aus tools/changelog.py (nicht von Hand ändern)
siikkNeu("siikk-Oberfläche", "|cffe03030siikk|r-|cffffd100Oberfläche|r", "Interface\\AddOns\\siikkUI\\Media\\" .. ((UnitFactionGroup("player") == "Alliance") and "allianz_hd" or "horde_rot_hd"), "14.1",
{
    { version = "14.1", datum = "31.10.2026", punkte = { "Taschenfenster zeigt den Auktionspreis vom siikk-Auktionshaus auf jedem Gegenstand (wenn das Auktionshaus-Addon aktiv ist)." } },
    { version = "14.0", datum = "31.10.2026", punkte = { "Auktionshaus im siikk-Design: die Blizzard-Steinbilder sind weg, Kategorien, Spaltenköpfe und Reiter sind flach mit Goldrand.", "Kategorien, Ergebnisliste und die untere Leiste (Gebot, Sofortkauf) stehen jeweils in einem eigenen Kasten – auch in den Reitern Gebote und Auktionen." } },
    { version = "13.9", datum = "31.10.2026", punkte = { "Neu: Nach jedem Update zeigt jedes siikk-Addon einmal ein Fenster „Was ist neu?“ mit Datum, Version und allen Änderungen.", "Jederzeit wieder: /th neu (Oberfläche) – in der Zentrale /th addons gibt es dafür den Knopf „Neu“." } },
    { version = "13.8", datum = "31.10.2026", punkte = { "Zentrale (/th addons): neuer Knopf „Info“ öffnet die Einführung jedes Addons.", "Die Einführung nennt jetzt auch die Einführungen der anderen Addons (/meter intro, /qh intro, /ah intro)." } },
    { version = "13.7", datum = "31.10.2026", punkte = { "Neuer Name: siikk-Oberfläche – Teil des Komplettpakets siikk-UI.", "Eigener Minimap-Knopf mit deinem Horde- oder Allianz-Wappen.", "Neu: Zentrale für alle siikk-Addons (/th addons oder Shift+Klick auf den Minimap-Knopf): jedes Addon an/aus, Minimap-Knöpfe ein/aus." } },
    { version = "13.6", datum = "31.10.2026", punkte = { "Hinweis auf das neue siikk-Auktionshaus in Einführung und /th-Hilfe." } },
    { version = "13.5", datum = "31.10.2026", punkte = { "Händler: Knopf „Schnellverkaufen“ jetzt unten rechts, der Erlös steht direkt darüber.", "Händler: unterer Bereich (Reparatur, Rückkauf, Geld) als sauberer Kasten, leere Plätze ohne Rahmen." } },
    { version = "13.4", datum = "31.10.2026", punkte = { "Händler: jedes Angebot in einem eigenen Kasten.", "Neu: Schnellverkauf – verkauft alles mit Münzsymbol auf einen Klick (/th verkaufen)." } }
}, function() return rawget(_G, "HexenmeisterProfile") end, "/th neu")
