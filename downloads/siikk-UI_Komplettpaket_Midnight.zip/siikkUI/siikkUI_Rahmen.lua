-- siikkUI · Rahmen & Chat
-- Eigenes Spieler-, Begleiter-, Ziel-, Gruppen- und Raidfenster sowie ein Chat-Design mit Horde-Emblem.
-- Der Chat selbst bleibt der originale WoW-Chat (alle Kanäle, Farben, Hochscrollen bleiben erhalten).

local ADDON, NS = ...
local L = siikkL or function(s) return s end
NS = NS or {}
local DB
local function msg(t) if NS.msg then NS.msg(t) else print(t) end end
local function pass(ok, ...) if ok then return ... end end
local function safe(fn, ...) if not fn then return nil end return pass(pcall(fn, ...)) end
local function isSecret(v) return issecretvalue and issecretvalue(v) or false end
local function num(v) if v == nil or isSecret(v) or type(v) ~= "number" then return nil end return v end

local RDEF = { rahmen = true, rahmenBlizzAus = true, gruppe = true, raid = true, chatSkin = true, chatLogo = .35, chatDunkel = .6 }
local LOGO = "Interface\\AddOns\\siikkUI\\Media\\horde3d_hd"
local HORDE = "Interface\\AddOns\\siikkUI\\Media\\horde_rot_hd"
-- Zeichen in den Lebensleisten umschalten (Einstellung: Reiter „Bedienung“)
NS.applyLebenZeichen = function()
  local aus = (TobsiikkHelferDB and TobsiikkHelferDB.lebenZeichen) == "aus"
  for _, lg in ipairs(NS.lebenLogos or {}) do
    if aus then lg:Hide()
    else
      lg:SetVertexColor(1, 1, 1)
      if NS.paintLogo then NS.paintLogo({ tex = lg, horde = HORDE }) else lg:SetTexture(HORDE) end
      lg:SetAlpha(NS.zeichenArt and NS.zeichenArt() == "allianz" and .55 or .7)
      lg:Show()
    end
  end
end
local BAR = "Interface\\TargetingFrame\\UI-StatusBar"
local HP_GRUEN, HP_ROT, HP_TOT = { .15, 1, .3 }, { 1, .1, .1 }, { .4, .4, .4 }
local MANA_BLAU = { .1, .55, 1 }
local LILA = "|cffb266ff"

local frames = {}          -- alle eigenen Einheitenrahmen
local pending = false      -- Änderung wartet auf das Kampfende
local hidden = CreateFrame("Frame"); hidden:Hide()

---------------------------------------------------------------------------
-- Hilfen
---------------------------------------------------------------------------
local function classColor(unit)
  if not UnitIsPlayer or not safe(UnitIsPlayer, unit) then return nil end
  local _, cls = safe(UnitClass, unit)
  if not cls or isSecret(cls) then return nil end
  local c = (CUSTOM_CLASS_COLORS and CUSTOM_CLASS_COLORS[cls]) or (RAID_CLASS_COLORS and RAID_CLASS_COLORS[cls])
  return c
end
local function short(v)
  v = num(v); if not v then return "" end
  if v >= 1e6 then return (string.format("%.1fM", v / 1e6):gsub("%.", ",")) end
  if v >= 1e4 then return (string.format("%.1fk", v / 1e3):gsub("%.", ",")) end
  return tostring(math.floor(v))
end
local function reactionName(unit)
  local c = classColor(unit)
  if c then return c.r, c.g, c.b end
  local r = num(safe(UnitReaction, unit, "player"))
  if r then
    if r <= 3 then return 1, .25, .25 elseif r == 4 then return 1, .85, .2 else return .3, 1, .35 end
  end
  return 1, 1, 1
end
local function setBarValue(bar, v, m)
  -- Funktioniert auch, wenn das Spiel geheime Werte liefert (die Leiste darf sie anzeigen)
  pcall(bar.SetMinMaxValues, bar, 0, m or 1)
  pcall(bar.SetValue, bar, v or 0)
end
local function glow(bar)
  local g = bar:CreateTexture(nil, "OVERLAY")
  g:SetColorTexture(1, 1, 1, .22); g:SetBlendMode("ADD")
  g:SetPoint("TOPLEFT", bar:GetStatusBarTexture(), "TOPLEFT"); g:SetPoint("TOPRIGHT", bar:GetStatusBarTexture(), "TOPRIGHT")
  g:SetHeight(math.max(2, (bar:GetHeight() or 10) * .45))
  bar.glow = g
end
local function setFont(fs, size, flags)
  if not fs or not fs.SetFont then return end
  local path = fs.GetFont and fs:GetFont()
  if type(path) ~= "string" then path = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF" end
  pcall(fs.SetFont, fs, path, size, flags)
end
local function backdrop(fr, r, g, b, a)
  if not fr.SetBackdrop then return end
  fr:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = false, edgeSize = 10, insets = { left = 2, right = 2, top = 2, bottom = 2 } })
  fr:SetBackdropColor(r or 0, g or 0, b or 0, a or .9)
  fr:SetBackdropBorderColor(.25, .25, .25, 1)
end

---------------------------------------------------------------------------
-- Einheitenrahmen
---------------------------------------------------------------------------
-- style: "gross" (Spieler/Ziel mit Porträt), "klein" (Begleiter/Ziel des Ziels), "gruppe", "raid"
local function mkUnit(unit, gname, style, w, h, parent)
  local b = CreateFrame("Button", gname, parent or UIParent, "SecureUnitButtonTemplate,BackdropTemplate")
  b:SetSize(w, h)
  b:SetAttribute("unit", unit)
  b:SetAttribute("type1", "target")
  b:SetAttribute("type2", "togglemenu")
  b:RegisterForClicks("AnyUp")
  b.style, b.baseUnit = style, unit
  backdrop(b, 0, 0, 0, .9)

  local x0 = 4
  if style == "gross" then
    b.portrait = b:CreateTexture(nil, "ARTWORK")
    b.portrait:SetSize(h - 8, h - 8); b.portrait:SetPoint("LEFT", 4, 0)
    x0 = h
  end
  local hpH = (style == "gross") and math.floor((h - 8) * .62) or (style == "klein" and math.floor((h - 8) * .62)) or math.floor((h - 8) * .5)
  if style == "gruppe" or style == "raid" then
    -- Klassenfarbe als Hintergrund, darunter die Lebensleiste
    b.cls = b:CreateTexture(nil, "BACKGROUND", nil, 1); b.cls:SetPoint("TOPLEFT", 2, -2); b.cls:SetPoint("BOTTOMRIGHT", -2, 2)
    b.cls:SetColorTexture(.3, .3, .3, .6)
    hpH = math.floor((h - 8) * (style == "raid" and .38 or .32))
  end
  b.hp = CreateFrame("StatusBar", nil, b)
  b.hp:SetStatusBarTexture(BAR); b.hp:SetStatusBarColor(HP_GRUEN[1], HP_GRUEN[2], HP_GRUEN[3])
  if style == "gruppe" or style == "raid" then
    b.hp:SetPoint("BOTTOMLEFT", 4, 4); b.hp:SetPoint("BOTTOMRIGHT", -4, 4); b.hp:SetHeight(hpH)
  else
    b.hp:SetPoint("TOPLEFT", x0, -4); b.hp:SetPoint("TOPRIGHT", -4, -4); b.hp:SetHeight(hpH)
  end
  b.hp.bg = b.hp:CreateTexture(nil, "BACKGROUND"); b.hp.bg:SetAllPoints(); b.hp.bg:SetColorTexture(0, .12, 0, .8)
  glow(b.hp)

  if style == "gross" or style == "klein" then
    b.pw = CreateFrame("StatusBar", nil, b)
    b.pw:SetStatusBarTexture(BAR); b.pw:SetStatusBarColor(MANA_BLAU[1], MANA_BLAU[2], MANA_BLAU[3])
    b.pw:SetPoint("TOPLEFT", b.hp, "BOTTOMLEFT", 0, -2); b.pw:SetPoint("BOTTOMRIGHT", -4, 4)
    b.pw.bg = b.pw:CreateTexture(nil, "BACKGROUND"); b.pw.bg:SetAllPoints(); b.pw.bg:SetColorTexture(0, 0, .15, .8)
    glow(b.pw)
    b.pwText = b.pw:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); b.pwText:SetPoint("CENTER")
  end

  local nameFont = (style == "raid") and "GameFontHighlightSmall" or "GameFontNormal"
  b.name = (b.hp):CreateFontString(nil, "OVERLAY", nameFont)
  b.hpText = b.hp:CreateFontString(nil, "OVERLAY", (style == "gross") and "GameFontHighlight" or "GameFontHighlightSmall")
  if style == "gruppe" or style == "raid" then
    b.name:SetParent(b); b.name:ClearAllPoints(); b.name:SetPoint("TOPLEFT", 6, -5); b.name:SetPoint("RIGHT", b, "RIGHT", style == "raid" and -4 or -46, 0)
    b.name:SetJustifyH("LEFT")
    b.hpText:SetParent(b); b.hpText:ClearAllPoints()
    if style == "raid" then b.hpText:SetPoint("CENTER", b.hp, "CENTER", 0, 0)
    else b.hpText:SetFontObject("GameFontNormalLarge"); b.hpText:SetPoint("TOPRIGHT", -6, -4) end
  else
    -- Name über dem Fenster, damit er sich nicht mit den Zahlen überschneidet
    b.name:SetParent(b); b.name:ClearAllPoints()
    b.name:SetPoint("BOTTOMLEFT", b, "TOPLEFT", 4, 1); b.name:SetPoint("BOTTOMRIGHT", b, "TOPRIGHT", -4, 1)
    b.name:SetJustifyH("LEFT")
    b.name:SetShadowOffset(1, -1); b.name:SetShadowColor(0, 0, 0, 1)
    b.hpText:SetPoint("CENTER", b.hp, "CENTER", 0, 0)
    b.hpText:SetShadowOffset(1, -1); b.hpText:SetShadowColor(0, 0, 0, 1)
  end
  if (unit == "player" or unit == "target") and style == "gross" then
    -- Fraktions-Zeichen hinter der Lebensanzeige (Spieler und Ziel) – Horde (dunkelrot) / Allianz / aus
    local lg = b.hp:CreateTexture(nil, "OVERLAY", nil, -2)
    lg:SetSize(hpH * 1.15, hpH * 1.15); lg:SetPoint("CENTER", b.hp, "CENTER", 0, 0)
    b.hp.logo = lg
    NS.lebenLogos = NS.lebenLogos or {}; table.insert(NS.lebenLogos, lg)
    if NS.applyLebenZeichen then NS.applyLebenZeichen() end
  end
  if b.name.SetWordWrap then b.name:SetWordWrap(false) end
  if style == "gross" then
    b.lvl = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    b.lvl:SetPoint("BOTTOMLEFT", b.portrait, "BOTTOMLEFT", 1, 1)
  end
  b.dead = b:CreateFontString(nil, "OVERLAY", "GameFontNormal"); b.dead:SetPoint("CENTER", b.hp, "CENTER"); b.dead:Hide()
  -- Schrift: Name über dem Fenster größer und dicker, Zahlen mit kräftigem Rand (etwa doppelt so dick)
  local sizes = { gross = { 15, 14, 12 }, klein = { 13, 12, 11 }, gruppe = { 12, 16 }, raid = { 10, 11 } }
  local z = sizes[style]
  setFont(b.name, z[1], (style == "gross" or style == "klein") and "OUTLINE" or nil)
  setFont(b.hpText, z[2], "OUTLINE")
  if b.pwText then setFont(b.pwText, z[3], "OUTLINE") end
  setFont(b.dead, z[2], "OUTLINE")

  b:SetScript("OnEnter", function(s)
    local u = s:GetAttribute("unit")
    if u and UnitExists(u) then
      if GameTooltip_SetDefaultAnchor then GameTooltip_SetDefaultAnchor(GameTooltip, s) else GameTooltip:SetOwner(s, "ANCHOR_RIGHT") end
      GameTooltip:SetUnit(u); GameTooltip:Show()
    end
  end)
  b:SetScript("OnLeave", function() GameTooltip:Hide() end)
  table.insert(frames, b)
  return b
end

local function powerColor(unit)
  local pt, tok = safe(UnitPowerType, unit)
  if isSecret(pt) then pt = 0 end
  if (pt or 0) == 0 then return MANA_BLAU, true end
  local c = PowerBarColor and (PowerBarColor[tok] or PowerBarColor[pt])
  if c then return { c.r, c.g, c.b }, false end
  return MANA_BLAU, false
end

local function updatePortrait(b, u)
  if b.portrait and SetPortraitTexture then pcall(SetPortraitTexture, b.portrait, u) end
end

local function updateUnit(b, el)
  local u = b:GetAttribute("unit") or b.baseUnit
  local preview = b.preview
  if not preview and not UnitExists(u) then return end
  if preview and not UnitExists(u) then
    -- Beispielanzeige im Platzier-Modus
    b.name:SetText((b.style == "raid" or b.style == "gruppe") and (b.sample or L"Mitspieler") or (b.sample or u))
    b.name:SetTextColor(1, 1, 1)
    setBarValue(b.hp, 62, 100); b.hpText:SetText((b.style == "gross") and "6200 / 10000  62 %" or "62 %")
    b.hp:SetStatusBarColor(HP_GRUEN[1], HP_GRUEN[2], HP_GRUEN[3]); b.hp:SetAlpha(1)
    if b.pw then setBarValue(b.pw, 80, 100); b.pwText:SetText("80 %") end
    if b.cls then local c = RAID_CLASS_COLORS and RAID_CLASS_COLORS.WARLOCK; if c then b.cls:SetColorTexture(c.r, c.g, c.b, .6) end end
    if b.portrait then b.portrait:SetTexture(136218) end
    b.dead:Hide()
    return
  end

  -- Name und Farbe
  local nm = safe(UnitName, u)
  b.name:SetText(nm or "")
  local r, g, bl = reactionName(u)
  if b.style == "gruppe" or b.style == "raid" then b.name:SetTextColor(1, 1, 1) else b.name:SetTextColor(r, g, bl) end
  if b.cls then
    local c = classColor(u)
    if c then b.cls:SetColorTexture(c.r, c.g, c.b, .6) else b.cls:SetColorTexture(.3, .3, .3, .6) end
  end
  if b.lvl then
    local lv = safe(UnitLevel, u)
    local cl = safe(UnitClassification, u)
    local t = (num(lv) and (lv > 0 and tostring(lv) or "??")) or ""
    if cl == "elite" or cl == "worldboss" or cl == "rareelite" then t = t .. "+" end
    b.lvl:SetText(t)
  end

  -- Porträt nur bei Wechsel der Einheit neu zeichnen
  local guid = safe(UnitGUID, u)
  if b.portrait then
    if isSecret(guid) then
      b.pt = (b.pt or 0) + (el or 0); if b.pt > 2 then b.pt = 0; updatePortrait(b, u) end
    elseif guid ~= b.guid then updatePortrait(b, u) end
  end
  if not isSecret(guid) then b.guid = guid end

  -- Leben
  local h, m = safe(UnitHealth, u), safe(UnitHealthMax, u)
  setBarValue(b.hp, h, m)
  local hn, mn = num(h), num(m)
  local p = (hn and mn and mn > 0) and (hn / mn) or nil
  local dead = safe(UnitIsDeadOrGhost, u) and not isSecret(safe(UnitIsDeadOrGhost, u))
  local off = UnitIsConnected and (safe(UnitIsConnected, u) == false)
  if dead or off then
    b.dead:SetText(off and L"Offline" or L"Tot"); b.dead:Show(); b.hpText:SetText("")
  else
    b.dead:Hide()
    if p then
      local pc = math.floor(p * 100 + .5)
      if b.style == "gross" then b.hpText:SetText(short(hn) .. " / " .. short(mn) .. "  " .. pc .. " %")
      else b.hpText:SetText(pc .. " %") end
    elseif UnitHealthPercent then
      local ok = pcall(function()
        local v = UnitHealthPercent(u, true, CurveConstants and CurveConstants.ScaleTo100)
        b.hpText:SetFormattedText("%.0f %%", v)
      end)
      if not ok then b.hpText:SetText("") end
    else b.hpText:SetText("") end
  end

  -- Kraft (Mana bleibt blau)
  local mp
  if b.pw then
    local col, isMana = powerColor(u)
    local pv, pm = safe(UnitPower, u), safe(UnitPowerMax, u)
    setBarValue(b.pw, pv, pm)
    b.pw:SetStatusBarColor(col[1], col[2], col[3])
    local pvn, pmn = num(pv), num(pm)
    if pvn and pmn and pmn > 0 then
      b.pwText:SetText(short(pvn) .. " / " .. short(pmn))
      if isMana then mp = pvn / pmn end
    else b.pwText:SetText("") end
  end

  -- Unter 20 % Leben oder Mana: Lebensleiste blinkt rot (nicht beim eigenen Spielerrahmen – auf Wunsch aus)
  local low = b.baseUnit ~= "player" and not dead and not off and ((p and p < .2) or (mp and mp < .2))
  if dead or off then
    b.hp:SetStatusBarColor(HP_TOT[1], HP_TOT[2], HP_TOT[3]); b.hp:SetAlpha(1)
  elseif low then
    b.blink = (b.blink or 0) + (el or 0)
    b.hp:SetStatusBarColor(HP_ROT[1], HP_ROT[2], HP_ROT[3])
    b.hp:SetAlpha(.35 + .65 * math.abs(math.sin(b.blink * 6)))
  else
    b.hp:SetStatusBarColor(HP_GRUEN[1], HP_GRUEN[2], HP_GRUEN[3]); b.hp:SetAlpha(1)
  end
end

local function attachUpdate(b)
  b.acc = 0
  b:HookScript("OnUpdate", function(s, el)
    s.acc = s.acc + el
    if s.acc >= .08 then local e = s.acc; s.acc = 0; updateUnit(s, e) end
  end)
  b:HookScript("OnShow", function(s) s.guid = nil; updateUnit(s, 0) end)
end

---------------------------------------------------------------------------
-- Rahmen anlegen
---------------------------------------------------------------------------
local function makeMovable(fr, key, dx, dy, dragTarget)
  local mover = dragTarget or fr
  mover:SetMovable(true); mover:SetClampedToScreen(true)
  fr:RegisterForDrag("LeftButton")
  fr:SetScript("OnDragStart", function() if DB and not DB.gesperrt and not InCombatLockdown() then mover:StartMoving() end end)
  fr:SetScript("OnDragStop", function() mover:StopMovingOrSizing(); if NS.savePos then NS.savePos(mover, key) end end)
  if not dragTarget then
    if NS.makeScalable then NS.makeScalable(fr, key) end
    if NS.extraFrames then table.insert(NS.extraFrames, { frame = fr, key = key, x = dx, y = dy }) end
  end
end

local player = mkUnit("player", "TobsiikkHelferSpieler", "gross", 240, 64)
makeMovable(player, "rahmen_spieler", -300, -140); attachUpdate(player)
local pet = mkUnit("pet", "TobsiikkHelferBegleiter", "klein", 150, 30)
makeMovable(pet, "rahmen_begleiter", -345, -215); attachUpdate(pet)
local target = mkUnit("target", "TobsiikkHelferZiel", "gross", 240, 64)
makeMovable(target, "rahmen_ziel", 300, -140); attachUpdate(target)
local tot = mkUnit("targettarget", "TobsiikkHelferZielDesZiels", "klein", 150, 30)
makeMovable(tot, "rahmen_zielziel", 345, -215); attachUpdate(tot)
player.sample, pet.sample, target.sample, tot.sample = (UnitName and UnitName("player")) or "Du", L"Begleiter", L"Ziel (Beispiel)", L"Ziel des Ziels"

-- Gruppe: du selbst + 4 Mitspieler, untereinander
local partyBox = CreateFrame("Frame", "TobsiikkHelferGruppe", UIParent, "SecureHandlerStateTemplate,BackdropTemplate")
partyBox:SetSize(164, 5 * 44 + 8)
local partyBtns = {}
for i = 0, 4 do
  local u = (i == 0) and "player" or ("party" .. i)
  local b = mkUnit(u, "TobsiikkHelferGruppe" .. i, "gruppe", 156, 42, partyBox)
  b:SetPoint("TOPLEFT", 4, -4 - i * 44)
  b.sample = (i == 0) and ((UnitName and UnitName("player")) or "Du") or (L"Mitspieler " .. i)
  makeMovable(b, "gruppe", 0, 0, partyBox); attachUpdate(b)
  partyBtns[#partyBtns + 1] = b
end
if NS.makeScalable then NS.makeScalable(partyBox, "gruppe") end
if NS.extraFrames then table.insert(NS.extraFrames, { frame = partyBox, key = "gruppe", x = -520, y = 120 }) end

-- Raid: 8 Gruppen nebeneinander, je 5 Spieler untereinander
local RAID_W, RAID_H = 78, 34
local raidBox = CreateFrame("Frame", "TobsiikkHelferRaid", UIParent, "SecureHandlerStateTemplate,BackdropTemplate")
raidBox:SetSize(8 * (RAID_W + 2) + 6, 5 * (RAID_H + 2) + 6)
local raidBtns = {}
for gidx = 1, 8 do
  for pidx = 1, 5 do
    local i = (gidx - 1) * 5 + pidx
    local b = mkUnit("raid" .. i, "TobsiikkHelferRaid" .. i, "raid", RAID_W, RAID_H, raidBox)
    b:SetPoint("TOPLEFT", 3 + (gidx - 1) * (RAID_W + 2), -3 - (pidx - 1) * (RAID_H + 2))
    b.sample = L"Gruppe " .. gidx
    makeMovable(b, "raid", 0, 0, raidBox); attachUpdate(b)
    raidBtns[i] = b
  end
end
if NS.makeScalable then NS.makeScalable(raidBox, "raid") end
if NS.extraFrames then table.insert(NS.extraFrames, { frame = raidBox, key = "raid", x = -380, y = 260 }) end

-- Raid nach Gruppen sortieren (nur außerhalb des Kampfes erlaubt)
local function sortRaid()
  if InCombatLockdown() then pending = true return end
  local slots = {}
  for gidx = 1, 8 do slots[gidx] = 0 end
  local used = {}
  local n = num(safe(GetNumGroupMembers)) or 0
  if safe(IsInRaid) then
    for r = 1, 40 do
      local name, _, sub = safe(GetRaidRosterInfo, r)
      sub = num(sub)
      if name and sub and sub >= 1 and sub <= 8 and slots[sub] < 5 then
        slots[sub] = slots[sub] + 1
        local i = (sub - 1) * 5 + slots[sub]
        raidBtns[i]:SetAttribute("unit", "raid" .. r); used[i] = true
      end
    end
  end
  -- leere Plätze zeigen eine Einheit, die es nicht gibt – RegisterUnitWatch blendet sie aus
  local inRaid = safe(IsInRaid) and n > 0
  for i = 1, 40 do if not used[i] then raidBtns[i]:SetAttribute("unit", inRaid and "raid99" or ("raid" .. i)) end end
end

---------------------------------------------------------------------------
-- Sichtbarkeit (sicher, funktioniert auch im Kampf)
---------------------------------------------------------------------------
local watched = { target, tot, pet }
for i = 2, 5 do watched[#watched + 1] = partyBtns[i] end
for i = 1, 40 do watched[#watched + 1] = raidBtns[i] end

local previewOn = false
local function applyVisibility()
  if InCombatLockdown() then pending = true return end
  if not DB then return end
  local on, grp, rd = DB.rahmen, DB.gruppe, DB.raid
  -- Platzier-Modus: alles zeigen
  if previewOn then
    for _, b in ipairs(watched) do if UnregisterUnitWatch then UnregisterUnitWatch(b) end; b.preview = true; b:Show() end
    player.preview = true
    if UnregisterStateDriver then UnregisterStateDriver(partyBox, "visibility"); UnregisterStateDriver(raidBox, "visibility") end
    if on then player:Show(); pet:Show(); target:Show(); tot:Show() else player:Hide(); pet:Hide(); target:Hide(); tot:Hide() end
    if grp then partyBox:Show() else partyBox:Hide() end
    if rd then raidBox:Show() else raidBox:Hide() end
    return
  end
  for _, b in ipairs(frames) do b.preview = nil end
  if on then
    player:Show()
    for _, b in ipairs({ pet, target, tot }) do if RegisterUnitWatch then RegisterUnitWatch(b) end end
  else
    player:Hide()
    for _, b in ipairs({ pet, target, tot }) do if UnregisterUnitWatch then UnregisterUnitWatch(b) end; b:Hide() end
  end
  for i = 2, 5 do local b = partyBtns[i]; if RegisterUnitWatch then RegisterUnitWatch(b) end end
  for i = 1, 40 do if RegisterUnitWatch then RegisterUnitWatch(raidBtns[i]) end end
  if RegisterStateDriver then
    if grp then RegisterStateDriver(partyBox, "visibility", L"[group:raid] hide; [group:party] show; hide") else UnregisterStateDriver(partyBox, "visibility"); partyBox:Hide() end
    if rd then RegisterStateDriver(raidBox, "visibility", L"[group:raid] show; hide") else UnregisterStateDriver(raidBox, "visibility"); raidBox:Hide() end
  end
  sortRaid()
end

---------------------------------------------------------------------------
-- Blizzard-Rahmen ausblenden (wieder einblenden: Haken weg + /reload)
---------------------------------------------------------------------------
local blizzDone = false
local function hideBlizz()
  if blizzDone or not DB or not DB.rahmenBlizzAus or InCombatLockdown() then return end
  blizzDone = true
  local function kill(fr)
    if not fr then return end
    pcall(fr.UnregisterAllEvents, fr); pcall(fr.Hide, fr); pcall(fr.SetParent, fr, hidden)
  end
  if DB.rahmen then kill(PlayerFrame); kill(TargetFrame); kill(PetFrame); kill(TargetFrameToT); kill(ComboFrame) end
  if DB.gruppe then
    kill(PartyFrame); kill(CompactPartyFrame)
    for i = 1, 4 do kill(_G["PartyMemberFrame" .. i]) end
  end
  if DB.raid then kill(CompactRaidFrameManager); kill(CompactRaidFrameContainer) end
end

---------------------------------------------------------------------------
-- Chat-Design mit Logo (originaler Chat bleibt voll nutzbar)
---------------------------------------------------------------------------
local skinned = {}
local function fitLogo(cf)
  local s = skinned[cf]; if not s then return end
  local w, h = cf:GetWidth() or 300, cf:GetHeight() or 150
  local size = math.min(w, h) * 1.05
  s.logo:SetSize(size, size)
end
local function skinOne(cf)
  if not cf or skinned[cf] then return skinned[cf] end
  local s = {}
  s.dark = cf:CreateTexture(nil, "BACKGROUND", nil, -7)
  s.dark:SetPoint("TOPLEFT", -6, 6); s.dark:SetPoint("BOTTOMRIGHT", 6, -8)
  s.logo = cf:CreateTexture(nil, "BACKGROUND", nil, -6)
  s.logo:SetTexture(LOGO); s.logo:SetPoint("CENTER", 0, 0)
  if NS.addLogo then NS.addLogo(s.logo, LOGO) end
  s.edge = CreateFrame("Frame", nil, cf, "BackdropTemplate")
  s.edge:SetPoint("TOPLEFT", -8, 8); s.edge:SetPoint("BOTTOMRIGHT", 8, -10)
  s.edge:SetFrameLevel(math.max(0, cf:GetFrameLevel() - 1))
  if s.edge.SetBackdrop then
    s.edge:SetBackdrop({ edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12 })
    s.edge:SetBackdropBorderColor(NS.GOLD[1], NS.GOLD[2], NS.GOLD[3], .9) -- Rahmenfarbe (Standard: Gold wie im Logo)
  end
  skinned[cf] = s
  if cf.HookScript then cf:HookScript("OnSizeChanged", fitLogo) end
  -- Ziehgriff zum Vergrößern/Verkleinern
  if cf == ChatFrame1 then
    pcall(cf.SetResizable, cf, true)
    if cf.SetResizeBounds then pcall(cf.SetResizeBounds, cf, 220, 100, 1400, 900)
    elseif cf.SetMinResize then pcall(cf.SetMinResize, cf, 220, 100); pcall(cf.SetMaxResize, cf, 1400, 900) end
    local g = CreateFrame("Button", "TobsiikkHelferChatGriff", cf)
    g:SetSize(16, 16); g:SetPoint("BOTTOMRIGHT", 6, -8); g:SetFrameLevel(cf:GetFrameLevel() + 20)
    g:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    g:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    g:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    g:SetScript("OnMouseDown", function() if not InCombatLockdown() then pcall(cf.StartSizing, cf, "BOTTOMRIGHT") end end)
    g:SetScript("OnMouseUp", function()
      pcall(cf.StopMovingOrSizing, cf)
      if FCF_SavePositionAndDimensions then pcall(FCF_SavePositionAndDimensions, cf) end
    end)
    g:SetScript("OnEnter", function(x) GameTooltip:SetOwner(x, "ANCHOR_RIGHT"); GameTooltip:AddLine(L"Ziehen: Chat größer/kleiner"); GameTooltip:Show() end)
    g:SetScript("OnLeave", function() GameTooltip:Hide() end)
    s.grip = g
  end
  return s
end
local function applyChat()
  if not DB then return end
  for i = 1, (NUM_CHAT_WINDOWS or 10) do
    local cf = _G["ChatFrame" .. i]
    if cf then
      local s = skinned[cf]
      if DB.chatSkin then
        s = skinOne(cf)
        s.dark:SetColorTexture(0, 0, 0, (DB.chatDunkel or .6) * (NS.calmFactor or 1))
        s.logo:SetAlpha((DB.chatLogo or .35) * (NS.calmFactor or 1))
        s.dark:Show(); s.logo:Show(); s.edge:Show(); if s.grip then s.grip:Show() end
        fitLogo(cf)
      elseif s then
        s.dark:Hide(); s.logo:Hide(); s.edge:Hide(); if s.grip then s.grip:Hide() end
      end
    end
  end
end

NS.applyChat = applyChat
---------------------------------------------------------------------------
-- Einstellungsfenster „Rahmen & Chat“
---------------------------------------------------------------------------
local win = CreateFrame("Frame", "TobsiikkHelferRahmenMenue", UIParent, "BasicFrameTemplateWithInset")
win:SetSize(560, 620); win:SetPoint("CENTER", 60, 0); win:SetFrameStrata("DIALOG"); win:Hide()
win:SetMovable(true); win:EnableMouse(true); win:RegisterForDrag("LeftButton"); win:SetClampedToScreen(true)
win:SetScript("OnDragStart", win.StartMoving); win:SetScript("OnDragStop", win.StopMovingOrSizing)
if tinsert and UISpecialFrames then tinsert(UISpecialFrames, "TobsiikkHelferRahmenMenue") end
win.title = win:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); win.title:SetPoint("TOP", 0, -5)
win.title:SetText(L"siikkUI · Rahmen & Chat")
if NS.addScaleGrip then NS.addScaleGrip(win, "rahmen", 560) end

local wChecks, wSliders = {}, {}
local function wRefresh()
  if not DB then return end
  for _, c in ipairs(wChecks) do c:SetChecked(c.get() and true or false) end
  for _, s in ipairs(wSliders) do s.quiet = true; s:SetValue(s.get()); s.quiet = false end
end
local function wHead(t, y) local h = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); h:SetPoint("TOPLEFT", 18, y); h:SetText(t) end
local function wCheck(y, text, get, set)
  local c = CreateFrame("CheckButton", nil, win, "UICheckButtonTemplate")
  c:SetSize(26, 26); c:SetPoint("TOPLEFT", 16, y)
  for _, k in ipairs({ "text", "Text" }) do local t = rawget(c, k); if type(t) == "table" and t.SetText then t:SetText("") end end
  local fs = c:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); fs:SetPoint("LEFT", c, "RIGHT", 2, 1); fs:SetText(text)
  c:SetScript("OnClick", function(s) set(s:GetChecked() and true or false); wRefresh() end)
  c.get = get; table.insert(wChecks, c); return c
end
local function wSlider(y, label, minv, maxv, step, get, set)
  local t = win:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); t:SetPoint("TOPLEFT", 22, y)
  local s = CreateFrame("Slider", nil, win)
  s:SetOrientation("HORIZONTAL"); s:SetSize(360, 18); s:SetPoint("TOPLEFT", 22, y - 18)
  local bg = s:CreateTexture(nil, "BACKGROUND"); bg:SetColorTexture(0, 0, 0, .7); bg:SetPoint("LEFT"); bg:SetPoint("RIGHT"); bg:SetHeight(6)
  s:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
  s:SetMinMaxValues(minv, maxv); s:SetValueStep(step); if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
  s:EnableMouse(true)
  s:SetScript("OnValueChanged", function(self, v)
    v = math.floor(v / step + .5) * step
    t:SetText(label .. ": |cffffd100" .. math.floor(v * 100 + .5) .. " %|r")
    if not self.quiet then set(v) end
  end)
  s.get = get; table.insert(wSliders, s); return s
end
local function wButton(x, y, w, text, fn)
  local b = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
  b:SetSize(w, 24); b:SetPoint("TOPLEFT", x, y); b:SetText(text)
  b:SetScript("OnClick", function() fn(); wRefresh() end)
  return b
end
local function needReload() msg(L"Damit die Blizzard-Rahmen wieder erscheinen: |cffffd100/reload|r eingeben.") end
local function later() if InCombatLockdown() then msg(L"Wird nach dem Kampf übernommen.") end end

wHead(L"Fenster", -34)
wCheck(-56, L"Spieler-, Begleiter- und Zielfenster", function() return DB.rahmen end, function(v) DB.rahmen = v; later(); applyVisibility(); if v then hideBlizz() else needReload() end end)
wCheck(-80, L"Gruppenanzeige (Klassenfarben, Leben in %)", function() return DB.gruppe end, function(v) DB.gruppe = v; later(); applyVisibility(); if v then hideBlizz() else needReload() end end)
wCheck(-104, L"Raidanzeige (8 Gruppen)", function() return DB.raid end, function(v) DB.raid = v; later(); applyVisibility(); if v then hideBlizz() else needReload() end end)
wCheck(-128, L"Normale Blizzard-Fenster ausblenden", function() return DB.rahmenBlizzAus end, function(v) DB.rahmenBlizzAus = v; if v then blizzDone = false; hideBlizz() else needReload() end end)
wHead(L"Chat", -170)
wCheck(-192, L"Chat-Design mit Fraktions-Logo", function() return DB.chatSkin end, function(v) DB.chatSkin = v; applyChat() end)
wSlider(-226, L"Logo-Sichtbarkeit", 0, 1, .05, function() return DB.chatLogo or .35 end, function(v) DB.chatLogo = v; applyChat() end)
wSlider(-280, L"Hintergrund-Dunkelheit", 0, 1, .05, function() return DB.chatDunkel or .6 end, function(v) DB.chatDunkel = v; applyChat() end)
wHead(L"Rahmenfarbe", -334)
do -- Farbe aller (bisher goldenen) Rahmen – eigener Block wegen Luas Variablen-Grenze
  local FARBEN = { { L"Gold", .85, .65, .15 }, { L"Silber", .72, .74, .8 }, { L"Rot", .85, .1, .1 }, { L"Blutrot", .5, .03, .04 }, { L"Blau", .15, .45, .95 },
    { L"Türkis", .1, .8, .8 }, { L"Grün", .2, .8, .25 }, { L"Lila", .62, .22, .95 }, { L"Orange", 1, .5, .05 }, { L"Weiß", .94, .94, .94 }, { L"Schwarz", .06, .06, .06 } }
  local function near(a, b) return type(a) == "number" and math.abs(a - b) < .015 end
  local function recolor(r, g, b)
    local G = NS.GOLD; local o1, o2, o3 = G[1], G[2], G[3]
    if near(r, o1) and near(g, o2) and near(b, o3) then return end
    G[1], G[2], G[3] = r, g, b
    local EF = rawget(_G, "EnumerateFrames")
    local f = type(EF) == "function" and EF() or nil
    while f do
      local okF, forb = pcall(function() return f.IsForbidden and f:IsForbidden() end)
      if okF and not forb and type(f.GetBackdropBorderColor) == "function" then
        local ok, cr, cg, cb, ca = pcall(f.GetBackdropBorderColor, f)
        if ok and near(cr, o1) and near(cg, o2) and near(cb, o3) then pcall(f.SetBackdropBorderColor, f, r, g, b, ca) end
      end
      f = EF(f)
    end
    if NS.onRahmenFarbe then pcall(NS.onRahmenFarbe) end
  end
  local sw = {}
  local function paint()
    local G = NS.GOLD
    for _, b in ipairs(sw) do
      local on = near(b.c[2], G[1]) and near(b.c[3], G[2]) and near(b.c[4], G[3])
      if b.SetBackdropBorderColor then b:SetBackdropBorderColor(on and 1 or .3, on and 1 or .3, on and 1 or .3, 1) end
    end
  end
  -- Farbwechsel sammeln und höchstens alle 0,15 s anwenden (der Farbkreis feuert sehr oft)
  local want, acc = nil, 0
  local tick = CreateFrame("Frame"); tick:Hide()
  tick:SetScript("OnUpdate", function(s, el) acc = acc + el; if acc < .15 then return end; acc = 0; s:Hide(); if want then recolor(want[1], want[2], want[3]); paint() end end)
  local function setFarbe(r, g, b, now)
    if not DB then return end
    DB.rahmenFarbe = { r, g, b }; want = { r, g, b }
    if now then recolor(r, g, b); paint() else tick:Show() end
  end
  for i, c in ipairs(FARBEN) do
    local b = CreateFrame("Button", nil, win, "BackdropTemplate"); b:SetSize(28, 22); b:SetPoint("TOPLEFT", 18 + (i - 1) * 32, -358)
    if b.SetBackdrop then b:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 2 }); b:SetBackdropColor(c[2], c[3], c[4], 1) end
    b.c = c
    b:SetScript("OnClick", function(s) setFarbe(s.c[2], s.c[3], s.c[4], true) end)
    b:SetScript("OnEnter", function(s) GameTooltip:SetOwner(s, "ANCHOR_TOP"); GameTooltip:AddLine(s.c[1]); GameTooltip:Show() end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    sw[i] = b
  end
  local function pickCustom()
    local CP = rawget(_G, "ColorPickerFrame"); if type(CP) ~= "table" then return end
    local G = NS.GOLD; local r0, g0, b0 = G[1], G[2], G[3]
    local function apply() local r, g, b = CP:GetColorRGB(); setFarbe(r, g, b) end
    local function cancel() setFarbe(r0, g0, b0, true) end
    if CP.SetupColorPickerAndShow then
      pcall(CP.SetupColorPickerAndShow, CP, { r = r0, g = g0, b = b0, hasOpacity = false, swatchFunc = apply, cancelFunc = cancel })
    else
      CP.func, CP.cancelFunc, CP.opacityFunc, CP.hasOpacity, CP.previousValues = apply, cancel, nil, false, { r0, g0, b0 }
      pcall(CP.SetColorRGB, CP, r0, g0, b0); CP:Hide(); CP:Show()
    end
  end
  wButton(18, -386, 185, L"Eigene Farbe wählen …", pickCustom)
  wButton(212, -386, 185, L"Zurück auf Gold", function() setFarbe(.85, .65, .15, true) end)
  NS.applyRahmenFarbe = function()
    local c = DB and DB.rahmenFarbe
    if type(c) == "table" and type(c[1]) == "number" then recolor(c[1], c[2], c[3]) end
    paint()
  end
  NS.setRahmenFarbe = setFarbe
end
wHead(L"Sonstiges", -424)
wButton(18, -448, 185, L"Platzier-Modus an/aus", function() SlashCmdList.TOBSIIKKHELFER("verschieben") end)
wButton(212, -448, 185, L"Einführung & Klasse", function() win:Hide(); if NS.showIntro then NS.showIntro() end end)
local wTip = win:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
wTip:SetPoint("TOPLEFT", 20, -482); wTip:SetWidth(380); wTip:SetJustifyH("LEFT")
wTip:SetText(L"Im Platzier-Modus siehst du alle Fenster mit Beispielwerten: ziehen = verschieben, Mausrad = Größe (in %). " ..
  L"Linksklick auf ein Fenster wählt die Person als Ziel, Rechtsklick öffnet das Menü. Den Chat verschiebst du wie gewohnt über seinen Reiter (Rechtsklick > Fenster entsperren), " ..
  L"die Größe mit dem Ziehgriff unten rechts am Chat.")
win:SetScript("OnShow", function() if win.applySavedScale then win.applySavedScale() end; wRefresh() end)
NS.openFrames = function() if NS.showTab then NS.showTab(4) else if NS.mainPanel then NS.mainPanel:Hide() end; win:Show() end end
if NS.attachTabs then NS.attachTabs(win, 4) end

---------------------------------------------------------------------------
-- Ereignisse, Befehle, Platzier-Modus
---------------------------------------------------------------------------
NS.onLayout = function(placing)
  local want = placing and true or false
  if want ~= previewOn then previewOn = want; applyVisibility() end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("PLAYER_ENTERING_WORLD")
ev:RegisterEvent("PLAYER_REGEN_ENABLED")
ev:RegisterEvent("GROUP_ROSTER_UPDATE")
ev:RegisterEvent("PLAYER_TARGET_CHANGED")
pcall(ev.RegisterEvent, ev, "UNIT_PORTRAIT_UPDATE")
pcall(ev.RegisterEvent, ev, "UNIT_MODEL_CHANGED")
pcall(ev.RegisterEvent, ev, "UPDATE_CHAT_WINDOWS")
ev:SetScript("OnEvent", function(_, e, a1)
  if e == "ADDON_LOADED" then
    if a1 ~= ADDON then return end
    TobsiikkHelferDB = TobsiikkHelferDB or {}
    for k, v in pairs(RDEF) do if TobsiikkHelferDB[k] == nil then TobsiikkHelferDB[k] = v end end
    DB = TobsiikkHelferDB
    pcall(NS.applyLebenZeichen)
    return
  end
  if not DB then return end
  if e == "PLAYER_LOGIN" or e == "PLAYER_ENTERING_WORLD" then
    applyVisibility(); hideBlizz(); applyChat()
    if NS.applyRahmenFarbe then pcall(NS.applyRahmenFarbe) end
    if NS.applyZeichen then pcall(NS.applyZeichen) end
  elseif e == "PLAYER_REGEN_ENABLED" then
    if pending then pending = false; applyVisibility(); hideBlizz() end
  elseif e == "GROUP_ROSTER_UPDATE" then
    sortRaid()
  elseif e == "PLAYER_TARGET_CHANGED" then
    target.guid = nil; tot.guid = nil
  elseif e == "UNIT_PORTRAIT_UPDATE" or e == "UNIT_MODEL_CHANGED" then
    for _, b in ipairs({ player, target }) do
      local u = b:GetAttribute("unit")
      if a1 == u or (a1 and UnitIsUnit and safe(UnitIsUnit, a1, u)) then updatePortrait(b, u) end
    end
  elseif e == "UPDATE_CHAT_WINDOWS" then
    applyChat()
  end
end)

-- /th rahmen, /th chat
local baseSlash = SlashCmdList.TOBSIIKKHELFER
SlashCmdList.TOBSIIKKHELFER = function(input)
  local c = (input or ""):lower():match("^(%S*)")
  if c == "rahmen" or c == "frames" then NS.openFrames()
  elseif c == "chat" then DB.chatSkin = not DB.chatSkin; applyChat(); msg(L"Chat-Design " .. (DB.chatSkin and "an" or "aus") .. ".")
  else
    baseSlash(input)
    if c == "hilfe" or c == "help" or c == "?" then
      msg(L"/th rahmen – Einstellungen für Spieler-, Ziel-, Gruppen-, Raidfenster und Chat")
      msg(L"/th chat – Chat-Design mit Logo an/aus")
    end
  end
end
NS.frameDebug = { player = player, target = target, pet = pet, tot = tot, party = partyBtns, raid = raidBtns, partyBox = partyBox, raidBox = raidBox,
  update = updateUnit, applyVisibility = applyVisibility, sortRaid = sortRaid, applyChat = applyChat, skinned = skinned, win = win }
