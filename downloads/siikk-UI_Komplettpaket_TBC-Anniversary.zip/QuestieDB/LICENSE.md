# Licensing

## Note to contributors

If you are considering contributing to QuestieDB please be aware that submitting pull requests after 21.10.2026 will be counted as consent for licensing your contribution under the GPLv3 license.

If you are a former contributor please consider adding your name to the GPLv3 list below, or giving us consent to do so for you through a GitHub issue or a Discord message.

If you are a former contributor and feel any of the things discussed here are infringing on your copyrights please contact us through the aforementioned means.

## Other licensing

The priority of licensing information is as follows:

1. License information inside an individual file
2. LICENSE (or similarly named) files inside a subdirectory
3. This LICENSE.md file in the root directory

## Content imported from Questie

QuestieDB's initial data, schema and corrections were imported from [Questie](https://github.com/Questie/Questie) (see `PROVENANCE.md`). That content and its later modifications are subject to [Questie's licensing](https://github.com/Questie/Questie/blob/master/LICENSE.md), which includes the contributions of over 100 historic Questie contributors.

## QuestieDB's licensing

### All rights reserved disclaimer

Because QuestieDB and the Questie content it was built from historically never had a proper license the situation is complicated and it is unlikely we will be able to gather consent from all the historic contributors for a specific license, so when in doubt consider QuestieDB content not covered above as "all rights reserved".

That being said, the Questie team considers historic contributions made in the spirit of open source development, although of course we cannot make that statement on behalf of all individual former contributors.

Hence the Questie team is alright with others forking the repository or copying code from it under the GPLv3 terms, but we can not promise all contributors are.

This does NOT extend to the Questie name and logo! Please change them when you maintain a fork.

### GPLv3

In an effort to clear the licensing situation up we will try to gain enough consent for GPLv3 license coverage so that we can consider the remaining unlicensed contributions as being public domain and/or fair use. For a copy of the GPLv3 license see `gpl-3.0.md`.

This does NOT extend to the Questie name and logo! Please change them when you maintain a fork.

The following contributors have agreed to put their individual contributions under this license:

* Muehe
* Logon
* TheCrux/BreakBB
* Drejjmit
* Cheeq
* TechoHunter
* Yttrium
