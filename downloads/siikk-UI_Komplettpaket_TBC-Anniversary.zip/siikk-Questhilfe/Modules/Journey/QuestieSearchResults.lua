---@type QuestieCompat
local QuestieCompat = QuestieLoader:ImportModule("QuestieCompat")

---@class QuestieSearchResults
local QuestieSearchResults = QuestieLoader:CreateModule("QuestieSearchResults")
-------------------------
--Import modules.
-------------------------
---@type QuestDetailsFrame
local QuestDetailsFrame = QuestieLoader:ImportModule("QuestDetailsFrame")
---@type QuestieJourneyUtils
local QuestieJourneyUtils = QuestieLoader:ImportModule("QuestieJourneyUtils")
---@type QuestieSearch
local QuestieSearch = QuestieLoader:ImportModule("QuestieSearch")
---@type QuestieMap
local QuestieMap = QuestieLoader:ImportModule("QuestieMap")
---@type QuestieDB
local QuestieDB = QuestieLoader:ImportModule("QuestieDB")
---@type QuestieCorrections
local QuestieCorrections = QuestieLoader:ImportModule("QuestieCorrections")
---@type QuestieLib
local QuestieLib = QuestieLoader:ImportModule("QuestieLib")
---@type QuestieLink
local QuestieLink = QuestieLoader:ImportModule("QuestieLink")
---@type TrackerUtils
local TrackerUtils = QuestieLoader:ImportModule("TrackerUtils")
---@type l10n
local l10n = QuestieLoader:ImportModule("l10n")
---@type ThreadLib
local ThreadLib = QuestieLoader:ImportModule("ThreadLib")

-- this variable defines how many operations to run (batched at a time) before yielding for a frame.
-- 1 would mean yielding every operation (so lower = slower but less lag)
-- this variable is not a hard limit when invoked, but rather a guideline;
-- each code block may put a modifier on it, for instance 10x  if the loop is lightweight
local TICKS_PER_YIELD = 30

if Questie.IsHardcore then
    -- The addon timing restrictions from the Blizzard watchdog are much higher for HC servers.
    -- Therefore we need a quite low tick rate to make sure we don't get bitten on less performant machines.
    TICKS_PER_YIELD = 15
end

local GetItemInfo = QuestieCompat.GetItemInfo
local stringrep = string.rep
local stringsub = string.sub

local AceGUI = LibStub("AceGUI-3.0");

local _HandleTreeItemSelected, _FindFirstSpawn
local lastOpenSearch = "quest"
local _selected = 0

local BY_NAME = 1
local BY_ID = 2


---Takes a frame and adds a paragraph with a header text and a list of links to other search results
---@param frame AceGUIWidget The frame to work on
---@param linkType string The type of result to link to (npc|object|quest|item)
---@param lookup table Table of IDs (npc|object|quest|item)
---@param header string The text header to show above the links
---@param query function The function used to get link name from
---@param boolean addTomTomButton Whether to add a button for setting a TomTom target for the first spawn of each linked result, if available
local function AddLinkedParagraph(frame, linkType, lookup, header, query, addTomTomButton)
    if lookup and #lookup > 0 then
        local group = AceGUI:Create("InlineGroup");
        group:SetFullWidth(true);
        group:SetLayout("flow");
        group:SetTitle(header);
        frame:AddChild(group);

        for _,id in pairs(lookup) do
            id = abs(id)
            local link = AceGUI:Create("InteractiveLabel")
            local name = query(id, "name")
            local text
            if linkType == 'quest' then
                text = QuestieLib:GetColoredQuestName(id,  true, true)
            elseif linkType == 'npc' then
                local lvl = query(id, 'maxLevel')
                text = '['..lvl..'] '..name..' ('..id..')'
            else
                text = name.." ("..id..")"
            end
            link:SetText(text);
            link:SetUserData("id", id)
            link:SetUserData("type", linkType)
            link:SetUserData("name", name)
            link:SetCallback("OnClick", function() QuestieSearchResults:SetSearch(linkType, id) end)
            link:SetCallback("OnEnter", QuestieJourneyUtils.ShowJourneyTooltip)
            link:SetCallback("OnLeave", QuestieJourneyUtils.HideJourneyTooltip)
            group:AddChild(link);
        end

        if addTomTomButton and TomTom and TomTom.AddWaypoint then
            for _, id in pairs(lookup) do
                id = abs(id)
                local spawns = query(id, "spawns")
                if spawns then
                    local zone, x, y = _FindFirstSpawn(spawns)
                    if zone then
                        local name = query(id, "name")
                        QuestieJourneyUtils:Spacer(group)
                        local button = AceGUI:Create("Button")
                        button:SetText(l10n("Set |cFF54e33bTomTom|r Target"))
                        button:SetCallback("OnClick", function()
                            TrackerUtils:SetTomTomTarget(name, zone, x, y)
                        end)
                        group:AddChild(button)
                        break
                    end
                end
            end
        end
    end
end

-- Track which items the user explicitly chose to show on the map
---@type table<string, true>
local _shownItemIds = {}

function QuestieSearchResults.ClearShownItemIds()
    _shownItemIds = {}
end

-- Check whether the relevant manual frames are already shown on the map
---@param id NpcId|ObjectId|ItemId @NPC (>0) or object (<0) id, or item id when idsToShow is provided
---@param idsToShow NpcId[]|ObjectId[]? @NPC/object ids shown together (e.g. all mobs dropping an item)
---@param groupName string? @Source group name for items (e.g. "NPC", "Object", "Vendor")
local function _HasShownFrames(id, idsToShow, groupName)
    if idsToShow and groupName then
        return _shownItemIds[id .. ":" .. groupName] ~= nil
    end
    if (not QuestieMap.manualFrames["any"]) then
        return false
    end
    return QuestieMap.manualFrames["any"][id] ~= nil
end

-- Create a button for showing/hiding manual notes of NPCs/objects
---@param id NpcId|ObjectId|ItemId @NPC (>0) or object (<0) id, or item id when idsToShow is provided
---@param idsToShow NpcId[]|ObjectId[]? @NPC/object ids shown together (e.g. all mobs dropping an item)
---@param groupName string? @Source group name for items (e.g. "NPC", "Object", "Vendor")
local function CreateShowHideButton(id, idsToShow, groupName)
    -- Initialise button
    local button = AceGUI:Create("Button")
    button.id = id
    button.idsToShow = idsToShow
    button.groupName = groupName
    if (not _HasShownFrames(id, idsToShow, groupName)) then
        button:SetText(l10n("Show on Map"))
        button:SetCallback("OnClick", function(self) self:ShowOnMap(self) end)
    else
        button:SetText(l10n("Remove from Map"))
        button:SetCallback("OnClick", function(self) self:RemoveFromMap(self) end)
    end
    -- Functions for showing/hiding and switching behaviour afterwards
    button.RemoveFromMap = function(self)
        self:SetText(l10n("Show on Map"))
        self:SetCallback("OnClick", function() self:ShowOnMap(self) end)

        if self.idsToShow and self.groupName then
            _shownItemIds[self.id .. ":" .. self.groupName] = nil
            local ids = {}
            for _, spawnId in pairs(self.idsToShow) do
                ids[#ids + 1] = spawnId
            end

            ThreadLib.ThreadInstant(function()
                local yieldCount = 0
                for i = 1, #ids do
                    QuestieMap:UnloadManualFrames(ids[i])
                    yieldCount = yieldCount + 1
                    if yieldCount >= TICKS_PER_YIELD then
                        yieldCount = 0
                        coroutine.yield()
                    end
                end
            end)
        else
            QuestieMap:UnloadManualFrames(self.id)
        end
    end
    button.ShowOnMap = function(self)
        self:SetText(l10n("Remove from Map"))
        self:SetCallback("OnClick", function() self:RemoveFromMap(self) end)

        if self.idsToShow and self.groupName then
            _shownItemIds[self.id .. ":" .. self.groupName] = true
            local ids = {}
            for _, spawnId in pairs(self.idsToShow) do
                ids[#ids + 1] = spawnId
            end

            ThreadLib.ThreadInstant(function()
                local yieldCount = 0
                for i = 1, #ids do
                    if ids[i] > 0 then
                        QuestieMap:ShowNPC(ids[i])
                    else
                        QuestieMap:ShowObject(-ids[i])
                    end
                    yieldCount = yieldCount + 1
                    if yieldCount >= TICKS_PER_YIELD then
                        yieldCount = 0
                        coroutine.yield()
                    end
                end
            end)
        else
            if self.id > 0 then
                QuestieMap:ShowNPC(self.id)
            elseif self.id < 0 then
                QuestieMap:ShowObject(-self.id)
            end
        end
    end
    return button
end

--- Finds the first valid spawn location from a spawns table
---@param spawns table<AreaId, CoordPair[]>
---@return AreaId|nil zone
---@return number|nil x
---@return number|nil y
_FindFirstSpawn = function(spawns)
    for zoneId, coords in pairs(spawns) do
        if coords and coords[1] then
            local x = coords[1][1]
            local y = coords[1][2]
            if x and y and (x ~= -1 or y ~= -1) then
                return zoneId, x, y
            end
        end
    end
    return nil, nil, nil
end

local function rec(theTable, ret, indent)
    ret = ret..stringrep('    ', indent)..'{\n'
    indent = indent + 1
    for k, v in pairs(theTable) do
        local t = type(v)
        if t == 'nil' then
            ret = ret..stringrep('    ', indent)..'['..k..']=nil'
        elseif t == 'table' then
            ret = rec(v, ret..stringrep('    ', indent)..'['..k..']=\n', indent)
        else
            ret = ret..stringrep('    ', indent)..'['..k..']='..v
        end
        ret = ret..'\n'
    end
    return ret..stringrep('    ', indent-1)..'},'
end

local function recurseTable(theTable, theKeys)
    local ret = Questie:Colorize('Raw data (shown because debug is enabled):\n\n', 'red')
    for key, _ in pairs(theKeys) do
        ret = ret..Questie:Colorize(key, 'yellow')..': '
        local t = type(theTable[key])
        if t == 'nil' then
            ret = ret..'nil'
        elseif t == 'table' then
            ret = rec(theTable[key], ret, 0)
        else
            ret = ret..theTable[key]
        end
        ret = ret..'\n'
    end
    return ret
end

function QuestieSearchResults:SpawnDetailsFrame(f, spawn, spawnType)
    local header = AceGUI:Create("Heading");
    header:SetFullWidth(true);

    local id = 0
    local typeLabel = ""
    local query
    local spawnObject
    if spawnType == "npc" then
        typeLabel = l10n("NPC ID")
        spawnObject = QuestieDB:GetNPC(spawn)
    elseif spawnType == "object" then
        typeLabel = l10n("Object ID")
        spawnObject = QuestieDB:GetObject(spawn)
    end

    header:SetText(spawnObject.name);
    f:AddChild(header);

    QuestieJourneyUtils:Spacer(f);

    QuestieJourneyUtils:AddLine(f, Questie:Colorize(l10n(typeLabel))..l10n(": ")..spawn)
    if spawnType == "npc" then
        if spawnObject.subName then
            QuestieJourneyUtils:AddLine(f, Questie:Colorize(l10n("Title"))..l10n(": ")..spawnObject.subName)
        end
        local minLevel = spawnObject.minLevel
        local maxLevel = spawnObject.maxLevel
        local level
        if minLevel == maxLevel then level = minLevel else level = minLevel.." - "..maxLevel end
        QuestieJourneyUtils:AddLine(f, Questie:Colorize(l10n("Level"))..l10n(": ")..level)
        local minLevelHealth = spawnObject.minLevelHealth
        local maxLevelHealth = spawnObject.maxLevelHealth
        local health
        if minLevelHealth == maxLevelHealth then health = minLevelHealth else health = minLevelHealth.." - "..maxLevelHealth end
        QuestieJourneyUtils:AddLine(f, Questie:Colorize(l10n("Health"))..l10n(": ")..health)
        local friendlyTo = l10n("no faction")
        if spawnObject.friendlyToFaction == "AH" then
            friendlyTo = l10n("both factions")
        elseif spawnObject.friendlyToFaction == "A" then
            friendlyTo = l10n("Alliance")
        elseif spawnObject.friendlyToFaction == "H" then
            friendlyTo = l10n("Horde")
        end
        QuestieJourneyUtils:AddLine(f, Questie:Colorize(l10n("Friendly to"))..l10n(": ")..friendlyTo)
    end

    QuestieJourneyUtils:Spacer(f);

    -- Also Starts
    if spawnObject.questStarts then
        AddLinkedParagraph(f, "quest", spawnObject.questStarts, l10n("Starts the following quests"), QuestieDB.QueryQuestSingle, false)
    end

    -- Also ends
    if spawnObject.questEnds then
        AddLinkedParagraph(f, "quest", spawnObject.questEnds, l10n("Ends the following quests"), QuestieDB.QueryQuestSingle, false)
    end

    local spawnZone = AceGUI:Create("Label")
    spawnZone:SetFontObject(GameFontNormal)
    spawnZone:SetFullWidth(true)
    local spawns = spawnObject.spawns

    if spawns then
        f:AddChild(CreateShowHideButton(spawnType == "npc" and spawn or -spawn))
        local startindex = 0;
        for i in pairs(spawns) do
            if spawns[i][1] then
                startindex = i;
                break;
            end
        end

        if TomTom and TomTom.AddWaypoint and spawns[startindex] and spawns[startindex][1] then
            local tx = spawns[startindex][1][1]
            local ty = spawns[startindex][1][2]
            if tx ~= -1 or ty ~= -1 then
                local tomTomButton = AceGUI:Create("Button")
                tomTomButton:SetText(l10n("Set |cFF54e33bTomTom|r Target"))
                tomTomButton:SetCallback("OnClick", function()
                    TrackerUtils:SetTomTomTarget(spawnObject.name, startindex, tx, ty)
                end)
                f:AddChild(tomTomButton)
            end
        end

        local zoneName = QuestieJourneyUtils:GetZoneName(startindex)

        spawnZone:SetText(l10n(zoneName));
        f:AddChild(spawnZone);

        if spawns[startindex] and spawns[startindex][1] then
            local startx = spawns[startindex][1][1];
            local starty = spawns[startindex][1][2];

            if (startx ~= -1 or starty ~= -1) then
                local spawnLoc = AceGUI:Create("Label");
                spawnLoc:SetText("X" .. l10n(": ") .. string.format("%.2f",startx) .." || Y" .. l10n(": ") .. string.format("%.2f",starty));
                spawnLoc:SetFontObject(GameFontNormal)
                spawnLoc:SetFullWidth(true);
                f:AddChild(spawnLoc);
            end
        end
    else
        spawnZone:SetText(l10n("No spawn data available."))
        f:AddChild(spawnZone);
    end

    QuestieJourneyUtils:Spacer(f);

    if Questie.db.profile.debugEnabled then
        if spawnType == "npc" then
            QuestieJourneyUtils:AddLine(f, recurseTable(spawnObject, QuestieDB.npcKeys))
        elseif spawnType == "object" then
            QuestieJourneyUtils:AddLine(f, recurseTable(spawnObject, QuestieDB.objectKeys))
        end
    end

    -- Fix for sometimes the scroll content will max out and not show everything until window is resized
    f.content:SetHeight(10000);
end

--- Used for pre-caching item data, see the function below
---@type GameTooltip
local QuestieScanningTooltip = CreateFrame("GameTooltip", "QuestieScanningTooltip", nil, "GameTooltipTemplate")
QuestieScanningTooltip:SetOwner(WorldFrame, "ANCHOR_NONE")

--- This function queries an item tooltip from the server, waits for the result, then calls the following function to draw an item info frame to a given parent frame.
---@param f Frame The frame to attach the created item details frame to
---@param itemId ItemId The ID for the item to show details about
---@return nil
function QuestieSearchResults:ItemDetailsFrame(f, itemId)
    -- Caching an item creates visible lag of 2 or 3 seconds at times (e.g. 13490, 13492 on Era)
    -- So we need to make sure the item data is *sufficiently* cached before we draw the frame
    -- We can't use the following because it creates a delay in the tooltip being drawn:
    -- C_Item.RequestLoadItemDataByID(itemId)

    -- Instead we use this:
    QuestieScanningTooltip:SetItemByID(itemId)

    -- Then we wait for client to say it cached the item
    local ticker
    ticker = C_Timer.NewTicker(0.05, function()
        -- When it does...
        if C_Item.IsItemDataCachedByID(itemId) then
            ticker:Cancel()
            -- We still need another tiny delay because the following content might still clip the last few lines otherwise
            C_Timer.After(0.05, function() QuestieSearchResults:ItemsFrameAfterTicker(f, itemId) end)
        end
    end)
end

--- This function draws an item info frame to a given parent frame after the previous function made sure its data is cached.
---@param f Frame The frame to attach the created item details frame to
---@param itemId ItemId The ID for the item to show details about
function QuestieSearchResults:ItemsFrameAfterTicker(f, itemId)
    local header = AceGUI:Create("Heading")
    header:SetFullWidth(true)

    local query = QuestieDB.QueryItemSingle

    header:SetText(query(itemId, "name"))
    f:AddChild(header)

    local grp = AceGUI:Create("SimpleGroup")
    grp:SetFullWidth(true)
    grp:SetLayout("Flow")

    local itemIcon = QuestieJourneyUtils.GetItemIcon(itemId)
    grp:AddChild(itemIcon)

    local spawnIdLabel = AceGUI:Create("Label")
    spawnIdLabel:SetText(l10n("Item ID")..l10n(": ") .. itemId)
    grp:AddChild(spawnIdLabel)

    f:AddChild(grp)

    local tooltip = AceGUI:Create("GameTooltipWidget", itemId)
    tooltip:SetOwner(itemIcon.frame, "ANCHOR_BOTTOMRIGHT")
    tooltip:SetItemByID(itemId)
    tooltip:ShowTooltip()

    f:AddChild(tooltip)

    if QuestieCorrections.questItemBlacklist[itemId] then
        QuestieJourneyUtils:Spacer(f)
        local itemBlacklistedLabel = AceGUI:Create("Label")
        itemBlacklistedLabel:SetText(l10n("This item is blacklisted because it has too many sources"))
        itemBlacklistedLabel:SetFullWidth(true)
        f:AddChild(itemBlacklistedLabel)
        return
    end

    local sources = QuestieDB.QueryItem(itemId, {"npcDrops", "objectDrops", "vendors"})
    local npcDrops = sources[1]
    local objectDrops = sources[2]
    local vendors = sources[3]

    local npcSpawnsHeading = AceGUI:Create("Heading")
    npcSpawnsHeading:SetText(l10n("NPCs"))
    npcSpawnsHeading:SetFullWidth(true)
    f:AddChild(npcSpawnsHeading)

    if (not npcDrops or not next(npcDrops)) then
        local noNPCSourcesLabel = AceGUI:Create("Label")
        noNPCSourcesLabel:SetText(l10n("No NPC drops this item"))
        noNPCSourcesLabel:SetFullWidth(true)
        f:AddChild(noNPCSourcesLabel)
    else
        local npcLabel = AceGUI:Create("Label")

        local npcIdsWithSpawns = {}
        for _, npcId in pairs(npcDrops) do
            local spawns = QuestieDB.QueryNPCSingle(npcId, "spawns")
            if spawns then
                npcIdsWithSpawns[#npcIdsWithSpawns + 1] = npcId
            end
        end

        npcLabel:SetText(l10n("%d NPCs drop this item", #npcIdsWithSpawns))
        f:AddChild(npcLabel)
        if (#npcIdsWithSpawns > 0) then
            local showHideButton = CreateShowHideButton(itemId, npcIdsWithSpawns, "NPC")
            f:AddChild(showHideButton)
        end
        AddLinkedParagraph(f, "npc", npcIdsWithSpawns, "", QuestieDB.QueryNPCSingle, false)
    end

    local objectSpawnsHeading = AceGUI:Create("Heading")
    objectSpawnsHeading:SetText(l10n("Objects"))
    objectSpawnsHeading:SetFullWidth(true)
    f:AddChild(objectSpawnsHeading)

    if (not objectDrops or not next(objectDrops)) then
        local noObjectSourcesLabel = AceGUI:Create("Label")
        noObjectSourcesLabel:SetText(l10n("No Object drops this item"))
        noObjectSourcesLabel:SetFullWidth(true)
        f:AddChild(noObjectSourcesLabel)
    else
        local objectLabel = AceGUI:Create("Label")

        local objectIdsWithSpawns = {}
        for _, objectId in pairs(objectDrops) do
            local spawns = QuestieDB.QueryObjectSingle(objectId, "spawns")
            if spawns then
                objectIdsWithSpawns[#objectIdsWithSpawns + 1] = -objectId
            end
        end

        objectLabel:SetText(l10n("%d Objects drop this item", #objectIdsWithSpawns))
        f:AddChild(objectLabel)
        if (#objectIdsWithSpawns > 0) then
            local showHideButton = CreateShowHideButton(itemId, objectIdsWithSpawns, "Object")
            f:AddChild(showHideButton)
        end
        AddLinkedParagraph(f, "object", objectIdsWithSpawns, "", QuestieDB.QueryObjectSingle, false)
    end

    local vendorSpawnsHeading = AceGUI:Create("Heading")
    vendorSpawnsHeading:SetText(l10n("Vendors"))
    vendorSpawnsHeading:SetFullWidth(true)
    f:AddChild(vendorSpawnsHeading)

    if (not vendors or not next(vendors)) then
        local noVendorSourcesLabel = AceGUI:Create("Label")
        noVendorSourcesLabel:SetText(l10n("No Vendor sells this item"))
        noVendorSourcesLabel:SetFullWidth(true)
        f:AddChild(noVendorSourcesLabel)
    else
        local vendorLabel = AceGUI:Create("Label")

        local vendorIdsWithSpawns = {}
        for _, npcId in pairs(vendors) do
            local spawns = QuestieDB.QueryNPCSingle(npcId, "spawns")
            local friendlyToFaction = QuestieDB.QueryNPCSingle(npcId, "friendlyToFaction")

            if spawns and QuestieDB.IsFriendlyToPlayer(friendlyToFaction) then
                vendorIdsWithSpawns[#vendorIdsWithSpawns + 1] = npcId
            end
        end

        vendorLabel:SetText(l10n("%d Vendors sell this item", #vendorIdsWithSpawns))
        f:AddChild(vendorLabel)
        if (#vendorIdsWithSpawns > 0) then
            local showHideButton = CreateShowHideButton(itemId, vendorIdsWithSpawns, "Vendor")
            f:AddChild(showHideButton)
        end
        AddLinkedParagraph(f, "npc", vendorIdsWithSpawns, "", QuestieDB.QueryNPCSingle)
    end

    if Questie.db.profile.debugEnabled then
        QuestieJourneyUtils:AddLine(f, recurseTable(QuestieDB:GetItem(itemId), QuestieDB.itemKeys))
    end
    -- Fix for sometimes the scroll content will max out and not show everything until window is resized
    f.content:SetHeight(10000);
end

-- draws a list of results of a certain type, e.g. "quest"
function QuestieSearchResults:DrawResultTab(container, resultType)
    -- probably already done by `JourneySelectTabGroup`, doesn't hurt to be safe though
    container:ReleaseChildren();

    local results = {}
    local database
    if resultType == "quest" then
        database = QuestieDB.QueryQuestSingle
    elseif resultType == "npc" then
        database = QuestieDB.QueryNPCSingle
    elseif resultType == "object" then
        database = QuestieDB.QueryObjectSingle
    elseif resultType == "item" then
        database = QuestieDB.QueryItemSingle
    else
        return
    end
    local max=0
    for k,_ in pairs(QuestieSearch.LastResult[resultType]) do
        if k > max then max = k end
    end
    for k=1, max do
        if QuestieSearch.LastResult[resultType][k] then
            local name = database(k, "name")
            if name then
                local complete = ''
                if Questie.db.char.complete[k] and resultType == "quest" then
                    complete = Questie:Colorize("(" .. l10n("Complete") .. ")" , "green")
                end
                -- TODO rename option to "enabledIDs" or create separate ones for npcs/objects/items
                local id = ''
                if Questie.db.profile.enableTooltipsQuestID then
                    id = ' (' .. k .. ')'
                end
                table.insert(results, {
                    ["text"] = name .. id .. " " .. complete,
                    ["value"] = tonumber(k)
                })
            end
        end
    end
    local resultFrame = AceGUI:Create("SimpleGroup");
    resultFrame:SetLayout("Fill");
    resultFrame:SetFullWidth(true);
    resultFrame:SetFullHeight(true);

    local resultTree = AceGUI:Create("TreeGroup");
    resultTree:SetFullWidth(true);
    resultTree:SetFullHeight(true);
    resultTree.treeframe:SetWidth(415);
    resultTree:SetTree(results);
    -- Programmatic selection fires OnGroupSelected, not OnClick.
    resultTree:SetCallback("OnGroupSelected", _HandleTreeItemSelected)
    resultTree:SetCallback("OnClick", function(_, _, selectedId)
        if IsShiftKeyDown() and lastOpenSearch == "quest" then
            ChatEdit_InsertLink(QuestieLink.GetQuestLinkStringById(tonumber(selectedId)))
        end
    end)

    resultFrame:AddChild(resultTree)
    container:AddChild(resultFrame);
    if _selected ~= 0 then
        resultTree:SelectByValue(_selected)
        _selected = 0
    end
end

_HandleTreeItemSelected = function(group, _, value)
    -- This is either the questId, npcId, objectId or itemId
    local selectedId = tonumber(value)

    -- get master frame and create scroll frame inside
    local master = group.frame.obj;
    master:ReleaseChildren();
    master:SetLayout("Fill");
    master:SetFullWidth(true);
    master:SetFullHeight(true);

    local details = AceGUI:Create("ScrollFrame");
    details:SetLayout("Flow");
    master:AddChild(details);

    if lastOpenSearch == "quest" then
        QuestDetailsFrame:Draw(details, QuestieDB.GetQuest(selectedId))
    elseif lastOpenSearch == "npc" then
        QuestieSearchResults:SpawnDetailsFrame(details, selectedId, 'npc');
    elseif lastOpenSearch == "object" then
        QuestieSearchResults:SpawnDetailsFrame(details, selectedId, 'object')
    elseif lastOpenSearch == "item" then
        QuestieSearchResults:ItemDetailsFrame(details, selectedId)
    end
end

local function SelectTabGroup(container, _, resultType)
    lastOpenSearch = resultType
    QuestieSearchResults:DrawResultTab(container, resultType);
end

local function _GetSearchFunction(searchBox, searchGroup)
    return function()
        if searchBox:GetText() ~= "" then
            local searchText = searchBox:GetText()

            local itemName = GetItemInfo(searchText)
            if stringsub(searchText, 1, 4) == "|cff" and itemName then
                -- An itemLink was added to the searchBox
                searchBox:SetText(itemName)
                QuestieSearchResults:DrawSearchResultTab(searchGroup, BY_NAME, itemName, false)
            elseif stringsub(searchText, 1, 4) == "|cff" then
                -- This should be impossible to reach, since when you see an item link in the game the item should
                -- be cached already which would be caught by the condition above
                Questie.Debug(Questie.DEBUG_DEVELOP, "Search with link of an uncached item")
            else
                -- Normal search
                local text = string.trim(searchText, " \n\r\t[]");
                QuestieSearchResults:DrawSearchResultTab(searchGroup, tonumber(text) and BY_ID or BY_NAME, text, false)
            end
            searchBox:ClearFocus()
        end
    end
end

-- Draw search results from advanced search tab
local searchResultTabs
function QuestieSearchResults:DrawSearchResultTab(searchGroup, searchType, query, useLast)
    if not searchResultTabs then
        searchGroup:ReleaseChildren();
        if searchType == BY_NAME and (not useLast) then
            QuestieSearch:ByName(query)
        elseif searchType == BY_ID and (not useLast) then
            QuestieSearch:ByID(query)
        end
        local results = QuestieSearch.LastResult;
        local resultTypes = {
            ["quest"] = "Quests",
            ["npc"] = "Mobs",
            ["object"] = "Objects",
            ["item"] = "Items",
        }
        local resultCountTotal = 0
        local resultCounts = {
            total = 0,
            quest = 0,
            npc = 0,
            object = 0,
            item = 0
        }
        for type,_ in pairs(resultTypes) do
            for _,_ in pairs(results[type]) do
                resultCountTotal = resultCountTotal + 1
                resultCounts[type] = resultCounts[type] + 1
            end
        end
        if (resultCountTotal == 0) then
            local noresults = AceGUI:Create("Label");
            noresults:SetText(Questie:Colorize(l10n('No Match for Search Results: %s', query), 'yellow'));
            noresults:SetFullWidth(true);
            searchGroup:AddChild(noresults);
            return;
        end
        searchResultTabs = AceGUI:Create("TabGroup");
        searchResultTabs:SetFullWidth(true);
        searchResultTabs:SetFullHeight(true);
        searchResultTabs:SetLayout("Flow");
        searchResultTabs:SetTabs({
            {
                text = l10n('Quests') .. " ("..resultCounts.quest..")",
                value = "quest",
                disabled = resultCounts.quest == 0,
            },
            {
                text = l10n('NPCs') .. " ("..resultCounts.npc..")",
                value = "npc",
                disabled = resultCounts.npc == 0,
            },
            {
                text = l10n('Objects') .. " ("..resultCounts.object..")",
                value = "object",
                disabled = resultCounts.object == 0,
            },
            {
                text = l10n('Items') .. " ("..resultCounts.item..")",
                value = "item",
                disabled = resultCounts.item == 0,
            },
        })
        searchResultTabs:SetCallback("OnGroupSelected", SelectTabGroup)
        if _selected == 0 then searchResultTabs:SelectTab("quest"); end
        searchGroup:AddChild(searchResultTabs);
    else
        searchGroup:ReleaseChildren();
        searchResultTabs = nil;
        self:DrawSearchResultTab(searchGroup, searchType, query, useLast);
    end
end

-- The "Advanced Search" tab
local typeDropdown
local searchBox
local searchGroup
local searchButton
function QuestieSearchResults:DrawSearchTab(container)
    -- Header
    local header = AceGUI:Create("Heading");
    header:SetText(l10n("Enter in your Search"));
    header:SetFullWidth(true);
    container:AddChild(header);
    QuestieJourneyUtils:Spacer(container);

    searchBox = AceGUI:Create("EditBox");
    searchGroup = AceGUI:Create("SimpleGroup");
    searchButton = AceGUI:Create("Button");

    searchButton:SetText(l10n("Search"));
    searchButton:SetDisabled(true);
    searchButton:SetCallback("OnClick", _GetSearchFunction(searchBox, searchGroup));
    container:AddChild(searchButton);

    searchBox:SetFocus();
    searchBox:SetRelativeWidth(0.6);
    searchBox:SetLabel(l10n("Advanced Search") .. " (".. l10n("Quests") .. ", ".. l10n("NPCs") .. ", ".. l10n("Objects") .. ", ".. l10n("Items") .. ")");
    searchBox:DisableButton(true);
    searchBox:SetCallback("OnTextChanged", function()
        if searchBox:GetText() ~= "" then
            searchButton:SetDisabled(false);
        else
            searchButton:SetDisabled(true);
        end
    end);
    searchBox:SetCallback("OnEnterPressed", _GetSearchFunction(searchBox, searchGroup));
    -- Check for existence of previous search, if present use its text
    if QuestieSearch.LastResult.query ~= "" then
        searchBox:SetText(QuestieSearch.LastResult.query)
    end
    container:AddChild(searchBox);

    searchGroup:SetFullHeight(true);
    searchGroup:SetFullWidth(true);
    searchGroup:SetLayout("fill");
    container:AddChild(searchGroup);
    -- Check for existence of previous search, if present use its result
    if QuestieSearch.LastResult.query ~= "" then
        searchButton:SetDisabled(false)
        local text = string.trim(searchBox:GetText(), " \n\r\t[]")
        QuestieSearchResults:DrawSearchResultTab(searchGroup, tonumber(text) and BY_ID or BY_NAME, text, true)
    end
end

function QuestieSearchResults:GetDetailFrame(detailType, id)
    local frame = AceGUI:Create("Frame")
    frame:SetHeight(500)
    frame:SetWidth(300)
    frame:SetLayout("Fill");
    local details = AceGUI:Create("ScrollFrame")
    details:SetFullWidth(true);
    details:SetFullHeight(true);
    details:SetLayout("Flow")
    frame:AddChild(details)
    if detailType == "quest" then
        QuestDetailsFrame:Draw(details, QuestieDB.GetQuest(id))
        frame:SetTitle(l10n("Quest Details"))
    elseif detailType == "npc" then
        QuestieSearchResults:SpawnDetailsFrame(details, id, detailType)
        frame:SetTitle(l10n("NPC Details"))
    elseif detailType == "object" then
        QuestieSearchResults:SpawnDetailsFrame(details, id, detailType)
        frame:SetTitle(l10n("Object Details"))
    elseif detailType == "item" then
        QuestieSearchResults:ItemDetailsFrame(details, id)
        frame:SetTitle(l10n("Item Details"))
    else
        frame:ReleaseChildren()
        return
    end
    frame:Show()
end

function QuestieSearchResults:SetSearch(detailType, id)
    _selected = id
    searchBox:SetText(tostring(id))
    QuestieSearchResults:DrawSearchResultTab(searchGroup, BY_ID, id, false)
    searchResultTabs:SelectTab(detailType)
end
