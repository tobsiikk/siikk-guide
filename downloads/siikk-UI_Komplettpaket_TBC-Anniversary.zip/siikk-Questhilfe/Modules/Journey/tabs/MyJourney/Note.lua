---@type QuestiePopup
local Popup = QuestieLoader:ImportModule("QuestiePopup")

---@type QuestieJourney
local QuestieJourney = QuestieLoader:ImportModule("QuestieJourney")
local _QuestieJourney = QuestieJourney.private
_QuestieJourney.notePopup = nil
-------------------------
--Import modules
-------------------------
---@type QuestieJourneyUtils
local QuestieJourneyUtils = QuestieLoader:ImportModule("QuestieJourneyUtils")
---@type l10n
local l10n = QuestieLoader:ImportModule("l10n")

local AceGUI = LibStub("AceGUI-3.0")
local titleBox, messageBox

local _CreateNoteWindow, _CreateContainer, _CreateDescription, _CreateTitleBox, _CreateMessageBox
local _CreateNoteAddButton, _HandleNoteEntry, _DeleteNote


function _QuestieJourney:ShowNotePopup()
    if (not _QuestieJourney.notePopup) then
        _QuestieJourney.notePopup = _CreateNoteWindow()
    elseif (not _QuestieJourney.notePopup:IsShown()) then
        _QuestieJourney.notePopup:Show()
    else
        _QuestieJourney.notePopup:Hide()
    end
end

_CreateNoteWindow = function ()
    local notePopup = AceGUI:Create("Window")
    notePopup:Show()
    notePopup:SetTitle(l10n('Add New Adventure Note'))
    notePopup:SetWidth(400)
    notePopup:SetHeight(400)
    notePopup:EnableResize(false)
    notePopup.frame:SetFrameStrata(_QuestieJourney.containerCache.frame:GetFrameStrata())
    notePopup.frame:SetFrameLevel(_QuestieJourney.containerCache.frame:GetFrameLevel())
    notePopup.frame:Raise()
    notePopup:SetCallback("OnClose", function()
        notePopup:Hide()
    end)

    local container = _CreateContainer()
    notePopup:AddChild(container)

    local desc = _CreateDescription()
    container:AddChild(desc)

    QuestieJourneyUtils:Spacer(container)

    titleBox = _CreateTitleBox()
    container:AddChild(titleBox)

    messageBox = _CreateMessageBox()
    container:AddChild(messageBox)

    local addEntryBtn = _CreateNoteAddButton()
    container:AddChild(addEntryBtn)

    return notePopup
end

_CreateContainer = function ()
    local container = AceGUI:Create("InlineGroup")
    container:SetFullHeight(true)
    container:SetFullWidth(true)
    container:SetLayout('flow')
    container:SetTitle(l10n('New Note'))
    return container
end

_CreateDescription  =function ()
    local desc = AceGUI:Create("Label")
    desc:SetText(Questie:Colorize(l10n('Create an entry in your journal to remember a specific moment. Simply supply a title and description and Questie will remember it for you!'), 'yellow'))
    desc:SetFullWidth(true)
    return desc
end

_CreateTitleBox = function ()
    local box = AceGUI:Create("EditBox")
    box:SetFullWidth(true)
    box:SetLabel(l10n('Entry Title'))
    box:DisableButton(true)
    box:SetFocus()
    return box
end

_CreateMessageBox = function ()
    local box = AceGUI:Create("MultiLineEditBox")
    box:SetFullWidth(true)
    box:SetNumLines(12)
    box:SetLabel(l10n('Journal Entry'))
    box:DisableButton(true)
    return box
end

_CreateNoteAddButton = function ()
    local addEntryBtn = AceGUI:Create("Button")
    addEntryBtn:SetText(l10n('Add Entry'))
    addEntryBtn:SetCallback("OnClick", _HandleNoteEntry)
    return addEntryBtn
end

_HandleNoteEntry = function ()
    local error = Questie:Colorize('[Questie] ', 'lightBlue')
    if titleBox:GetText() == '' then
        print (error .. l10n('No Title was entered. You must enter a title before submitting your note.'))
        return
    elseif messageBox:GetText() == '' then
        print (error .. l10n('No Note was entered. You must enter a note before submitting.'))
        return
    end
    local data = {}
    data.Event = "Note"
    data.Note = messageBox:GetText()
    data.Title = titleBox:GetText()
    data.Timestamp = time()

    tinsert(Questie.db.char.journey, data)

    _QuestieJourney.myJourney:ManageTree(_QuestieJourney.treeCache)
    _QuestieJourney.notePopup:Hide()
end

_DeleteNote = function(noteIndex)
    local success = false
    if noteIndex and noteIndex > 0 and noteIndex <= #Questie.db.char.journey then
        local entry = Questie.db.char.journey[noteIndex]
        if entry and entry.Event == "Note" then
            table.remove(Questie.db.char.journey, noteIndex)
            success = true
            Questie:Print(l10n('Note deleted successfully'))
            if _QuestieJourney.myJourney and _QuestieJourney.treeCache then
                _QuestieJourney.myJourney:ManageTree(_QuestieJourney.treeCache)
            end
        end
    end

    return success
end


Popup.Dialogs["QUESTIE_DELETE_NOTE_CONFIRM"] = {
    text = "",
    button1 = YES,
    button2 = NO,
    OnAccept = function(self)
        local noteIndex = self.data
        _DeleteNote(noteIndex)
    end,
    OnShow = function(self)
        local noteIndex = self.data
        local confirmText = l10n("Are you sure you want to delete this note?")
        if noteIndex then
            local entry = Questie.db.char.journey[noteIndex]
            if entry and entry.Event == "Note" then
                confirmText = confirmText .. "\n\n" .. Questie:Colorize(entry.Title, 'yellow')
            end
        end
        self.Text:SetText(confirmText)
        self:SetFrameStrata("FULLSCREEN_DIALOG")
        self:Raise()
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
}
