---@class QuestiePlayer
---@field numberOfGroupMembers number @The number of players currently in the group
---@field faction number @"Horde" or "Alliance"
local QuestiePlayer = QuestieLoader:CreateModule("QuestiePlayer");
local _QuestiePlayer = QuestiePlayer.private
-------------------------
--Import modules.
-------------------------
---@type ZoneDB
local ZoneDB = QuestieLoader:ImportModule("ZoneDB")
---@type l10n
local l10n = QuestieLoader:ImportModule("l10n")

---@type table<QuestId, Quest>
QuestiePlayer.currentQuestlog = {} --Gets populated by QuestieQuest:GetAllQuestIds(), this is either an object to the quest in question, or the ID if the object doesn't exist.
_QuestiePlayer.playerLevel = -1
local playerRaceFlag = 255 -- dummy default value to always return race not matching, corrected in init
local playerRaceFlagX2 = 1 -- dummy default value to always return race not matching, corrected in init
local playerClassName = ""
local playerClassFlag = 255 -- dummy default value to always return class not matching, corrected in init
local playerClassFlagX2 = 1 -- dummy default value to always return class not matching, corrected in init

-- Optimizations
local math_max = math.max;

QuestiePlayer.numberOfGroupMembers = 0

function QuestiePlayer:Initialize()
    _QuestiePlayer.playerLevel = UnitLevel("player")

    -- The provider owns the encoding used by its quest masks. Race IDs are not bit positions.
    local playerRaceId = select(3, UnitRace("player"))
    playerRaceFlag = LibQuestieDB.Enum.raceMaskById[playerRaceId]
    if not playerRaceFlag then
        error("QuestieDB has no race mask for race ID " .. tostring(playerRaceId) .. ". Update QuestieDB and reload.")
    end
    playerRaceFlagX2 = 2 * playerRaceFlag

    playerClassName = select(1, UnitClass("player"))
    local classId = select(3, UnitClass("player"))
    playerClassFlag = 2 ^ (classId - 1)
    playerClassFlagX2 = 2 * playerClassFlag

    QuestiePlayer.faction = UnitFactionGroup("player")
end

--Always compare to the UnitLevel parameter, returning the highest.
---@param level Level
function QuestiePlayer:SetPlayerLevel(level)
    local localLevel = UnitLevel("player");
    _QuestiePlayer.playerLevel = math_max(localLevel, level);
end

-- Gets the highest playerlevel available, most of the time playerLevel should be the most correct one
-- doing UnitLevel for completeness.
---@return Level
function QuestiePlayer.GetPlayerLevel()
    local level = UnitLevel("player");
    return math_max(_QuestiePlayer.playerLevel, level);
end

-- Find out if the player is at max level for the active expansion
---@return boolean isMaxLevel
function QuestiePlayer.IsMaxLevel()
    local level = QuestiePlayer.GetPlayerLevel()
    return (Questie.IsMoP and level == 90) or (Questie.IsCata and level == 85) or (Questie.IsWotlk and level == 80) or (Questie.IsTBC and level == 70) or (Questie.IsClassic and level == 60)
end

---@return string
function QuestiePlayer:GetLocalizedClassName()
    return playerClassName
end

function QuestiePlayer:GetGroupType()
    if(UnitInRaid("player")) then
        return "raid";
    elseif(IsInGroup(LE_PARTY_CATEGORY_INSTANCE)) then
        return "instance";
    elseif(UnitInParty("player")) then
        return "party";
    else
        return nil;
    end
end

---@param requiredRaces number? Race mask; nil and zero are unrestricted.
---@return boolean
function QuestiePlayer.HasRequiredRace(requiredRaces)
    -- Faction-wide masks already include their races in the provider. Do not widen subsets here.
    -- Arithmetic preserves Skyborne bits above the range of 32-bit bitwise operations.
    return (not requiredRaces) or (requiredRaces == 0) or ((requiredRaces % playerRaceFlagX2) >= playerRaceFlag)
end

---@return boolean
function QuestiePlayer.HasRequiredClass(requiredClasses)
    -- test a bit flag: (value % (2*flag) >= flag)
    return (not requiredClasses) or (requiredClasses == 0) or ((requiredClasses % playerClassFlagX2) >= playerClassFlag)
end

---@return AreaId?
function QuestiePlayer:GetCurrentZoneId()
    local uiMapId = C_Map.GetBestMapForUnit("player")
    if uiMapId then
        local mapInfo = C_Map.GetMapInfo(uiMapId)
        if mapInfo and mapInfo.mapType <= Enum.UIMapType.Continent then
            -- Pre-Cata caves and dungeon entrance areas have no map of their own, so the client
            -- reports the continent (or world) map. The zone text still names the real zone, so use that.
            return ZoneDB:GetAreaIdByName(GetRealZoneText()) or ZoneDB:GetAreaIdByUiMapId(uiMapId)
        end
        return ZoneDB:GetAreaIdByUiMapId(uiMapId)
    end

    return ZoneDB.instanceIdToAreaId[select(8, GetInstanceInfo())]
end

---@return number
function QuestiePlayer:GetCurrentContinentId()
    local currentZoneId = QuestiePlayer:GetCurrentZoneId()
    if (not currentZoneId) or currentZoneId == 0 then
        return 1 -- Default to Eastern Kingdom
    end

    local currentContinentId = 1 -- Default to Eastern Kingdom
    for cId, cont in pairs(l10n.zoneLookup) do
        for id, _ in pairs(cont) do
            if id == currentZoneId then
                currentContinentId = cId
            end
        end
    end

    return currentContinentId
end

function QuestiePlayer:GetPartyMemberByName(playerName)
    -- Resolve the name through the unit API instead of string-comparing against names built
    -- from UnitName: comms sender names are normalized full names (e.g. "Bob-OldBlanchy"),
    -- which don't reliably match a manual "name-realm" concatenation for cross-realm members.
    if(UnitInParty(playerName) or UnitInRaid(playerName)) then
        local _, classFilename = UnitClass(playerName);
        if classFilename then
            local rPerc, gPerc, bPerc, argbHex = GetClassColor(classFilename)
            return {
                name = playerName,
                class = classFilename,
                r = rPerc,
                g = gPerc,
                b = bPerc,
                colorHex = argbHex,
            };
        end
    end
    return nil;
end

---@param questId number
---@return boolean
function QuestiePlayer.HasArenaRating(questId)
    local hasArenaRating = false
    if questId == 95158 then
        local rating2v2 = GetPersonalRatedInfo(1)
        -- the rating condition is not known. it could also have to not be 1500
        if rating2v2 > 0 then
            hasArenaRating = true
        end
    end
    if questId == 95251 then
        local rating3v3 = GetPersonalRatedInfo(2)
        -- the rating condition is not known. it could also have to not be 1500
        if rating3v3 > 0 then
            hasArenaRating = true
        end
    end
    if questId == 95252 then
        local rating5v5 = GetPersonalRatedInfo(3)
        -- the rating condition is not known. it could also have to not be 1500
        if rating5v5 > 0 then
            hasArenaRating = true
        end
    end
    return hasArenaRating
end
