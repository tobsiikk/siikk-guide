---@type QuestieCompat
local QuestieCompat = QuestieLoader:ImportModule("QuestieCompat")

---@class QuestieReputation
local QuestieReputation = QuestieLoader:CreateModule("QuestieReputation")
---@type QuestiePlayer
local QuestiePlayer = QuestieLoader:ImportModule("QuestiePlayer")
---@type QuestieQuest
local QuestieQuest = QuestieLoader:ImportModule("QuestieQuest")
---@type QuestieDB
local QuestieDB = QuestieLoader:ImportModule("QuestieDB")
---@type Expansions
local Expansions = QuestieLoader:ImportModule("Expansions")

local playerReputations = {}

local _ReachedNewStanding, _WinterSaberChanged, _GetRewardMultiplier, _GetBuffMultiplier, _GetActiveDiplomatStacks, _FilterShaTarRewards

-- Fast local references
local ExpandFactionHeader, GetNumFactions, GetFactionInfo = QuestieCompat.ExpandFactionHeader, QuestieCompat.GetNumFactions, QuestieCompat.GetFactionInfo
local tinsert, floor = table.insert, math.floor

--- Updates all factions a player already discovered and checks if any of these
--- reached a new reputation level
---@param isInit boolean? @
function QuestieReputation:Update(isInit)
    Questie.Debug(Questie.DEBUG_DEVELOP, "QuestieReputation: Update")
    ExpandFactionHeader(0) -- Expand all header

    local factionChanged = false
    local newFaction = false

    for i=1, GetNumFactions() do
        local name, description, standingId, _, _, barValue, _, _, _, _, _, _, _, factionID, _, _ = GetFactionInfo(i)
        if factionID and description then -- we use description instead of isHeader because some factions are header (e.g. The Tillers)
            local previousValues = playerReputations[factionID]
            if (not previousValues) then
                -- This is a faction the player encountered for the first time
                newFaction = true
            end

            playerReputations[factionID] = {standingId, barValue}

            if (not isInit) and (
                    _ReachedNewStanding(previousValues, standingId)
                    or _WinterSaberChanged(factionID, previousValues, barValue)) then
                Questie.Debug(Questie.DEBUG_DEVELOP, "QuestieReputation: Update - faction \"" .. name .. "\" (" .. factionID .. ") changed")
                factionChanged = true
            end
        end
    end

    -- Handle Scyers/Aldor standing when they are not in reputation tab yet for TBC or later
    if isInit and Expansions.Current >= Expansions.Tbc then
        local _, _, raceId = UnitRace("player")
        local scryers = QuestieDB.factionIDs.THE_SCRYERS
        local aldor = QuestieDB.factionIDs.THE_ALDOR
        if raceId == 10 then -- Blood Elf
            -- Sometimes you can have one faction discovered, but not the other
            -- so we check for these individually
            if not playerReputations[aldor] then
                playerReputations[aldor] = {2, -3500} -- standingID 2, -3500 reputation (Hostile)
                newFaction = true
            end
            if not playerReputations[scryers] then
                playerReputations[scryers] = {5, 3500} -- standingID 5, 3500 reputation (Friendly)
                newFaction = true
            end
        elseif raceId == 11 then -- Draenei
            if not playerReputations[aldor] then
                playerReputations[aldor] = {5, 3500} -- standingID 5, 3500 reputation (Friendly)
                newFaction = true
            end
            if not playerReputations[scryers] then
                playerReputations[scryers] = {2, -3500} -- standingID 2, -3500 reputation (Hostile)
                newFaction = true
            end
        else -- every other race
            if not playerReputations[aldor] then
                playerReputations[aldor] = {4, 0} -- standingID 4, 0 reputation (Neutral)
                newFaction = true
            end
            if not playerReputations[scryers] then
                playerReputations[scryers] = {4, 0} -- standingID 4, 0 reputation (Neutral)
                newFaction = true
            end
        end
    end

    -- Handle hidden faction Nomi for MoP
    if Expansions.Current >= Expansions.MoP then
        local nomiFactionId = QuestieDB.factionIDs.NOMI
        playerReputations[nomiFactionId] = {4, 0} -- Nomi, Neutral 0 rep
        local repInfo = C_GossipInfo.GetFriendshipReputation(nomiFactionId)
        local standingId
        if repInfo and repInfo.standing >= 0 then
            if repInfo.standing < 3000 then
                standingId = 4
            elseif repInfo.standing < 9000 then
                standingId = 5
            elseif repInfo.standing < 21000 then
                standingId = 6
            elseif repInfo.standing < 42000 then
                standingId = 7
            else
                standingId = 8
            end
            playerReputations[nomiFactionId] = {standingId, repInfo.standing}
        end
    end

    if factionChanged or newFaction then
        -- Reset all autoBlacklisted quests, so availability is checked correctly again
        QuestieQuest.ResetAutoblacklistCategory("rep")
    end

    return factionChanged, newFaction
end

QuestieReputation.factionsStartingBelowNeutral = {
    [87] = true, -- Bloodsail Buccaneeers
    [576] = true, -- Timbermaw Hold
    [910] = true, -- Brood of Nozdormu
    [941] = true, -- The Maghar
    [970] = true, -- Sporeggar
    [978] = true, -- Kurenai
    [1015] = true, -- Netherwing
    [1171] = true, -- Therazane
}

---@return boolean
_ReachedNewStanding = function(previousValues, standingId)
    return (not previousValues) -- New faction
        or (previousValues[1] ~= standingId) -- Standing changed
end

---@return boolean
_WinterSaberChanged = function(factionID, previousValues, barValue)
    return factionID == QuestieDB.factionIDs.WINTERSABER_TRAINERS
        and previousValues and ((previousValues[2] < 4500 and barValue >= 4500)
            or (previousValues[2] < 13000 and barValue >= 13000))
end

-- This function is just for debugging purpose
-- There is no need to access the playerReputations table somewhere else
function QuestieReputation:GetPlayerReputations()
    return playerReputations
end

---@param requiredMinRep { [1]: number, [2]: number }? [1] = factionId, [2] = repValue
---@param requiredMaxRep { [1]: number, [2]: number }? [1] = factionId, [2] = repValue
---@return boolean AboveMinRep
---@return boolean HasMinFaction
---@return boolean BelowMaxRep
---@return boolean HasMaxFaction
function QuestieReputation:HasFactionAndReputationLevel(requiredMinRep, requiredMaxRep)
    local aboveMinRep, belowMaxRep, hasMinFaction, hasMaxFaction

    if requiredMinRep then
        local minFactionID = requiredMinRep[1]
        local reqMinValue = requiredMinRep[2]

        if playerReputations[minFactionID] then
            hasMinFaction = true
            aboveMinRep = playerReputations[minFactionID][2] >= reqMinValue
        -- Consider undiscovered factions to be at 0 reputation in this check unless they start below neutral
        elseif not QuestieReputation.factionsStartingBelowNeutral[minFactionID] then
            hasMinFaction = true
            aboveMinRep = 0 >= reqMinValue
        -- Consider undiscovered factions to be at -36000 reputation in this check when they start below neutral
        else
            hasMinFaction = true
            aboveMinRep = -36000 >= reqMinValue
        end
    else
        -- If requiredMinRep is nil, we don't care about the reputation aka it fullfils it
        aboveMinRep = true
        hasMinFaction = true
    end
    if requiredMaxRep then
        local maxFactionID = requiredMaxRep[1]
        local reqMaxValue = requiredMaxRep[2]

        if playerReputations[maxFactionID] then
            hasMaxFaction = true
            belowMaxRep = playerReputations[maxFactionID][2] < reqMaxValue
        -- Consider undiscovered factions to be at 0 reputation in this check unless they start below neutral
        elseif not QuestieReputation.factionsStartingBelowNeutral[maxFactionID] then
            hasMaxFaction = true
            belowMaxRep = 0 < reqMaxValue
        -- Consider undiscovered factions to be at -36000 reputation in this check when they start below neutral
        else
            hasMaxFaction = true
            belowMaxRep = -36000 < reqMaxValue
        end
    else
        -- If requiredMaxRep is nil, we don't care about the reputation aka it fullfils it
        belowMaxRep = true
        hasMaxFaction = true
    end
    return aboveMinRep, hasMinFaction, belowMaxRep, hasMaxFaction
end

--- Checkout https://github.com/Questie/Questie/wiki/Corrections#reputation-levels for more information
---@return boolean HasReputation Is the player within the required reputation ranges specified by the parameters
function QuestieReputation.HasReputation(requiredMinRep, requiredMaxRep)
    local aboveMinRep, hasMinFaction, belowMaxRep, hasMaxFaction = QuestieReputation:HasFactionAndReputationLevel(requiredMinRep, requiredMaxRep)

    return ((aboveMinRep and hasMinFaction) and (belowMaxRep and hasMaxFaction))
end

-- Using https://wago.tools/db2/QuestFactionReward?build=4.4.0.54217
local reputationRewards = {
    [1] = 10,
    [2] = 25,
    [3] = 75,
    [4] = 150,
    [5] = 250,
    [6] = 350,
    [7] = 500,
    [8] = 1000,
    [9] = 5,
    -- Somehow quests also reward different values than the DBC lists :shrug:
    [10] = 1400,
    [11] = 2000,
    [12] = 300,
    [13] = 60,
    [14] = 1500,
    [15] = 400,
    [16] = 275,
    [17] = 1800,
    [18] = 2600,
    [19] = 3000,
    [20] = 3300,
    [21] = 7000,
    [22] = 900,
    [23] = 540,
    [24] = 700,
    [25] = 999,
    [26] = 6000,
    [27] = 20,
    [28] = 50,
    [29] = 2850,
    [30] = 130,
    [31] = 200,
    [32] = 450,
    [33] = 100,
    [34] = 3750,
    [35] = 5000,
    [36] = 750,
    [37] = 1050,
}

---@param questId QuestId
---@return ReputationPair[]
function QuestieReputation.GetReputationReward(questId)
    local reputationReward = QuestieDB.QueryQuestSingle(questId, "reputationReward")

    if (not reputationReward) then
        return {}
    end

    local factionIDs = QuestieDB.factionIDs
    if Expansions.Current >= Expansions.Tbc then
        reputationReward = _FilterShaTarRewards(reputationReward, factionIDs)
    end

    -- Add Aldor/Scryer penalty to quests from the opposite faction
    for _, entry in pairs(reputationReward) do
        local factionId = entry[1]
        local value = entry[2]
        if Expansions.Current > Expansions.Wotlk then
            value = reputationRewards[value]
        end
        if factionId == factionIDs.THE_ALDOR then
            value = 0 - floor(value * 1.1)
            tinsert(reputationReward, {factionIDs.THE_SCRYERS, value})
            break
        elseif factionId == factionIDs.THE_SCRYERS then
            value = 0 - floor(value * 1.1)
            tinsert(reputationReward, {factionIDs.THE_ALDOR, value})
            break
        end
    end

    local rewards = {}
    local reputationMultiplier = _GetRewardMultiplier()

    for _, entry in pairs(reputationReward) do
        local factionId = entry[1]
        local reward = entry[2]

        if Expansions.Current > Expansions.Wotlk then
            -- In the base DBs for Cata and beyond a reputation mapping is used instead of the raw values from the quest.
            -- Also corrections for quests before cataclysm are still applied to cataclysm quests.
            -- Therefore they most likely don't match any entry reputationRewards. We work around with "or entry[2]"
            if entry[2] > 0 then
                reward = reputationRewards[entry[2]] or entry[2]
            elseif entry[2] < 0 then
                local rewardEntry = reputationRewards[-entry[2]]
                reward = rewardEntry and -rewardEntry or entry[2]
            end
        end

        if reward then
            reward = reward * (reward > 0 and reputationMultiplier or 1)
            -- faction bonus commendation check
            if select(15, QuestieCompat.GetFactionInfoByID(factionId)) == true then
                reward = reward * 2
            end

            tinsert(rewards, {factionId, reward})
        end
    end

    return rewards
end

_GetActiveDiplomatStacks = function()
    -- Correct API command to get the player's active progression configuration
    local configID = C_Traits.GetConfigIDBySystemID(45) -- 45 for Legacy Tree
    if not configID then return 0 end

    -- Fetch the specific tree structural data attached to this config
    local configInfo = C_Traits.GetConfigInfo(configID)
    if not configInfo or not configInfo.treeIDs then return 0 end

    for _, treeID in ipairs(configInfo.treeIDs) do
        local nodes = C_Traits.GetTreeNodes(treeID)
        for _, nodeID in ipairs(nodes or {}) do
            local nodeInfo = C_Traits.GetNodeInfo(configID, nodeID)
            
            if nodeInfo and nodeInfo.entryIDs then
                for _, entryID in ipairs(nodeInfo.entryIDs) do
                    local entryInfo = C_Traits.GetEntryInfo(configID, entryID)
                    if entryInfo and entryInfo.definitionID then
                        local defInfo = C_Traits.GetDefinitionInfo(entryInfo.definitionID)
                        -- Match against the target Diplomat spell ID (1225485)
                        if defInfo and defInfo.spellID == 1225485 then 
                            return nodeInfo.currentRank or 0
                        end
                    end
                end
            end
        end
    end
    return 0
end

_GetRewardMultiplier = function()
    local knowsMrPopularityRank1 = QuestieCompat.IsSpellKnown(78634)
    local knowsMrPopularityRank2 = QuestieCompat.IsSpellKnown(78635)
    local buffMultiplier = _GetBuffMultiplier()
    local multiplier = 1 + buffMultiplier

    -- in Forever the Classic human racial is now a legacy talent, available for every race
    if Questie.IsForever then
        local diplomatRanks = _GetActiveDiplomatStacks()
        multiplier = multiplier + diplomatRanks * 0.02 -- 2% bonus reputation for each rank of Diplomat
    else
        local playerIsHuman = QuestiePlayer.HasRequiredRace(QuestieDB.raceKeys.HUMAN)
        if playerIsHuman and not Questie.IsTitanReforged then
            multiplier = multiplier + 0.1 -- 10% bonus reputation from Diplomacy (Human Racial, not present on Titan servers)
        end
    end

    if knowsMrPopularityRank2 then
        multiplier = multiplier + 0.1 -- 10% bonus reputation from Mr. Popularity Rank 2
    elseif knowsMrPopularityRank1 then
        multiplier = multiplier + 0.05 -- 5% bonus reputation from Mr. Popularity Rank 1
    end

    return multiplier
end

---Returns the temporary reputation bonus, omitting aura bonuses during Forever combat.
---This changes only the displayed estimate; racial and other non-aura modifiers still apply.
---@return number
_GetBuffMultiplier = function()
    if Questie.IsForever and (InCombatLockdown() or IsInInstance()) then return 0 end

    local buffMultiplier = 0
    for i = 1, 40 do
        local _, _, _, _, _, _, _, _, _, spellId, _ = QuestieCompat.UnitAura("player", i, "HELPFUL")
        if spellId == nil then
            break
        end

        if spellId == 46668 then
            buffMultiplier = buffMultiplier + 0.1 -- 10% bonus reputation from Darkmoon Faire buff
        elseif spellId == 95987 then
            buffMultiplier = buffMultiplier + 0.1 -- 10% bonus reputation from Unburdened (Hallow's End Alliance)
        elseif spellId == 24705 then
            buffMultiplier = buffMultiplier + 0.1 -- 10% bonus reputation from Grim Visage (Hallow's End Horde)
        elseif spellId == 377749 then
            buffMultiplier = buffMultiplier + (Questie.IsTitanReforged and 1 or 0) -- 100% bonus reputation from Joyous Journeys (Titan server only)
        end
    end

    return buffMultiplier
end

---@param reputationReward ReputationPair[]
---@param factionIDs table
_FilterShaTarRewards = function(reputationReward, factionIDs)
    local playerIsHonoredWithShaTar = QuestieReputation.HasReputation({ factionIDs.THE_SHATAR, 9000 }, nil)
    -- filter out Sha'Tar reputation rewards when quest also rewards Aldor/Scryer reputation and the player is already honored with them Sha'Tar
    if playerIsHonoredWithShaTar then
        local hasAldorOrScryer = false
        for _, entry in pairs(reputationReward) do
            local factionId = entry[1]
            if factionId == factionIDs.THE_ALDOR or factionId == factionIDs.THE_SCRYERS then
                hasAldorOrScryer = true
                break
            end
        end

        if hasAldorOrScryer then
            local filteredReputationReward = {}
            for _, entry in pairs(reputationReward) do
                local factionId = entry[1]
                if factionId ~= factionIDs.THE_SHATAR then
                    tinsert(filteredReputationReward, entry)
                end
            end
            reputationReward = filteredReputationReward
        end
    end

    return reputationReward
end

---@param factionId FactionId
---@return string name @Name of the faction
function QuestieReputation.GetFactionName(factionId)
    local friendReputation = C_GossipInfo.GetFriendshipReputation(factionId)
    if friendReputation and friendReputation.name and friendReputation.name ~= "" then
        return friendReputation.name
    end

    return select(1, QuestieCompat.GetFactionInfoByID(factionId))
end

---@param reputationReward ReputationPair[]
---@return string @Formatted reputation reward string
function QuestieReputation.GetReputationRewardString(reputationReward)
    local rewardTable = {}

    for _, rewardPair in pairs(reputationReward) do
        local factionId = rewardPair[1]
        local rewardValue = rewardPair[2]
        local factionName = QuestieReputation.GetFactionName(factionId)
        if factionName then
            rewardTable[#rewardTable + 1] = (rewardValue > 0 and "+" or "") .. rewardValue .. " " .. factionName
        end
    end

    return table.concat(rewardTable, " / ")
end