-- siikk-Questhilfe · siikk-Design
-- Eigenes Aussehen für den Quest-Tracker:
--  · Fraktions-Logo (Horde/Allianz) als Hintergrund
--  · Rahmen- und Kopfzeilenfarbe frei wählbar (Einstellungen → Reiter „siikk-Design“)
--  · Questpfeil-Feld (verschiebbar): Nummer, Questname, Ziel, Pfeil und Meterzahl; Quests in der Anzeige nummeriert
--  · Tracker dauerhaft verschiebbar und in der Größe änderbar
---@class SiikkDesign
local SiikkDesign = QuestieLoader:CreateModule("SiikkDesign")

---@type TrackerLinePool
local TrackerLinePool = QuestieLoader:ImportModule("TrackerLinePool")
---@type DistanceUtils
local DistanceUtils = QuestieLoader:ImportModule("DistanceUtils")
---@type ZoneDB
local ZoneDB = QuestieLoader:ImportModule("ZoneDB")

local HBD = LibStub("HereBeDragonsQuestie-2.0")
local ICONS = "Interface\\AddOns\\siikk-Questhilfe\\Icons\\"
local GOLD = { r = 0.85, g = 0.65, b = 0.15 }

local function P() return Questie and Questie.db and Questie.db.profile end
SiikkDesign.fehler = {}
local function sc(name, fn, ...)
    local ok, e = pcall(fn, ...)
    if not ok then SiikkDesign.fehler[name] = tostring(e) end
    return ok, e
end
SiikkDesign.sc = sc
local function farbe(key, std)
    local p = P(); local c = p and p[key]
    if type(c) == "table" and type(c.r) == "number" then return c end
    return std
end

---------------------------------------------------------------------------
-- Rahmen, Kopfzeile, Logo
---------------------------------------------------------------------------
local base, logo, painting
local function fraktion()
    local p = P(); local w = p and p.siikkLogoFraktion
    if w == "horde" or w == "allianz" then return w end
    local f = UnitFactionGroup and UnitFactionGroup("player")
    return f == "Alliance" and "allianz" or "horde"
end

function SiikkDesign.Apply()
    base = base or _G["Questie_BaseFrame"]
    if not base then return end
    local p = P() or {}
    -- Logo im Hintergrund
    if not logo then
        -- Ebene BORDER: liegt sicher über dem (auch deckenden) Hintergrund, aber unter den Questzeilen
        logo = base:CreateTexture(nil, "BORDER", nil, -8)
        logo:SetPoint("CENTER", base, "CENTER", 0, 0)
    end
    local w, h = base:GetWidth() or 200, base:GetHeight() or 200
    local s = math.max(40, math.min(w, h) * 0.9)
    logo:SetSize(s, s)
    logo:SetTexture(ICONS .. (fraktion() == "allianz" and "siikk_allianz" or "siikk_horde"))
    logo:SetAlpha(p.siikkLogoAlpha or 0.55)
    logo:SetShown(p.siikkLogo ~= false and (not Questie.db.char or Questie.db.char.isTrackerExpanded ~= false))
    -- Rahmenfarbe neu setzen (Alpha bleibt, wie Questie sie gerade setzt)
    local _, _, _, a = base:GetBackdropBorderColor()
    local c = farbe("siikkBorderColor", GOLD)
    painting = true; base:SetBackdropBorderColor(c.r, c.g, c.b, a or 1); painting = false
    -- Kopfzeile
    local hf = _G["Questie_HeaderFrame"]
    if hf and hf.siikkBg then
        local hc = farbe("siikkHeaderColor", { r = 0.315, g = 0.19, b = 0.45, a = 0.8 })
        hf.siikkBg:SetColorTexture(hc.r, hc.g, hc.b, hc.a or 0.8)
        hf.siikkLine:SetColorTexture(c.r, c.g, c.b, 1)
    end
end

local function hookBase()
    base = _G["Questie_BaseFrame"]
    if not base or base.siikkHooked then return end
    base.siikkHooked = true
    hooksecurefunc(base, "SetBackdropBorderColor", function(self, _, _, _, a)
        if painting then return end
        local c = farbe("siikkBorderColor", GOLD)
        painting = true; self:SetBackdropBorderColor(c.r, c.g, c.b, a or 1); painting = false
    end)
    base:HookScript("OnSizeChanged", function() SiikkDesign.Apply() end)
    SiikkDesign.Apply()
end

---------------------------------------------------------------------------
-- Questpfeil: eigenes, verschiebbares Feld mit Nummer, Questname, Ziel und Meterzahl
---------------------------------------------------------------------------
SiikkDesign.nummern = {}   -- [questId] = Nummer in der Questanzeige
SiikkDesign.quests = {}    -- [questId] = Quest-Objekt (aus der Questanzeige)
SiikkDesign.reihe = {}     -- Nummer -> questId

-- wird von der Questanzeige vor jedem Neuzeichnen aufgerufen
SiikkDesign.meterZeilen = {} -- [Zeile] = Quest
function SiikkDesign.NummernStart()
    SiikkDesign.nummern, SiikkDesign.quests, SiikkDesign.reihe = {}, {}, {}
    for line in pairs(SiikkDesign.meterZeilen) do if line.siikkM then line.siikkM:Hide() end end
    SiikkDesign.meterZeilen = {}
end
function SiikkDesign.Nummer(quest)
    local n = #SiikkDesign.reihe + 1
    SiikkDesign.reihe[n] = quest.Id; SiikkDesign.nummern[quest.Id] = n; SiikkDesign.quests[quest.Id] = quest
    return n
end

local ziele = {} -- [questId] = { wx, wy, inst, name, dist, t }
local function zielVon(quest)
    local z = ziele[quest.Id]
    local now = GetTime()
    if z and now - z.t < 1.5 then return z end
    local ok, spawn, zone, name = pcall(DistanceUtils.GetNearestSpawnForQuest, quest)
    z = { t = now }
    if ok and type(spawn) == "table" and spawn[1] and zone then
        local uiMap = ZoneDB:GetUiMapIdByAreaId(zone)
        if uiMap then
            local wx, wy, inst = HBD:GetWorldCoordinatesFromZone(spawn[1] / 100, spawn[2] / 100, uiMap)
            z.wx, z.wy, z.inst, z.name = wx, wy, inst, name
        end
    end
    ziele[quest.Id] = z
    return z
end

local function meter(yards)
    local m = yards * 0.9144
    if m >= 1000 then return string.format("%.1f km", m / 1000) end
    return math.floor(m + 0.5) .. " m"
end

-- Meterzahl hinter jeder Quest in der Questanzeige (ohne Pfeil)
local function meterText(quest)
    local px, py, pinst = HBD:GetPlayerWorldPosition()
    if not px then return "" end
    local z = zielVon(quest)
    if not z.wx or z.inst ~= pinst then return "" end
    local _, d = HBD:GetWorldVector(pinst, px, py, z.wx, z.wy)
    if not d then return "" end
    if d < 12 then return "|cff33ff33da|r" end
    return meter(d)
end
function SiikkDesign.MeterZeile(line, quest)
    local p = P()
    if p and p.siikkMeterListe == false then if line.siikkM then line.siikkM:Hide() end return end
    if not line.siikkM then
        line.siikkM = line:CreateFontString(nil, "OVERLAY")
        line.siikkM:SetJustifyH("RIGHT"); if line.siikkM.SetWordWrap then line.siikkM:SetWordWrap(false) end
    end
    local font, size, flags = line.label:GetFont()
    line.siikkM:SetFont(font or STANDARD_TEXT_FONT, math.max(8, (size or 12) - 1), flags or "")
    line.siikkM:SetTextColor(0.75, 0.55, 1)
    line.siikkM:SetWidth(52)
    line.siikkM:SetText(meterText(quest))
    line.siikkM:Show()
    SiikkDesign.meterZeilen[line] = quest
    SiikkDesign.MeterPlatz(line)
end
-- Meter immer am rechten Rand des sichtbaren Fensters ausrichten (die Questzeilen liegen in einem
-- Rollbereich, der alles abschneidet, was rechts darüber hinausragt) und den Questnamen davor kürzen
function SiikkDesign.MeterPlatz(line)
    local fs, lab = line.siikkM, line.label
    local b = base or _G["Questie_BaseFrame"]
    if not (fs and lab and b) then return end
    local rechts, links = b:GetRight(), lab:GetLeft()
    if not rechts or not links then return end
    local x = (rechts - 12) - links
    if x < 80 then fs:Hide() return end
    fs:ClearAllPoints(); fs:SetPoint("TOPRIGHT", lab, "TOPLEFT", x, 0)
    local maxW = x - 56
    if (lab:GetWidth() or 0) > maxW then lab:SetWidth(maxW) end
end
local function meterAktualisieren()
    for line, quest in pairs(SiikkDesign.meterZeilen) do
        if line.siikkM and line:IsShown() then line.siikkM:SetText(meterText(quest)); SiikkDesign.MeterPlatz(line) end
    end
end

local pf
local function baueFeld()
    if pf then return pf end
    pf = CreateFrame("Button", "SiikkQuestPfeilFeld", UIParent, BackdropTemplateMixin and "BackdropTemplate")
    pf:SetSize(250, 64); pf:SetFrameStrata("MEDIUM"); pf:SetClampedToScreen(true); pf:SetMovable(true); pf:EnableMouse(true)
    pf:RegisterForDrag("LeftButton"); pf:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    pf:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    pf.nr = pf:CreateFontString(nil, "OVERLAY"); pf.nr:SetFont(STANDARD_TEXT_FONT, 22, "OUTLINE"); pf.nr:SetPoint("LEFT", 10, 0); pf.nr:SetTextColor(0.75, 0.55, 1)
    pf.pfeil = pf:CreateTexture(nil, "ARTWORK"); pf.pfeil:SetSize(40, 40); pf.pfeil:SetPoint("LEFT", 36, 0); pf.pfeil:SetTexture(ICONS .. "siikk_pfeil")
    local function zeile(size, y, r, g, b)
        local fs = pf:CreateFontString(nil, "OVERLAY"); fs:SetFont(STANDARD_TEXT_FONT, size, "OUTLINE"); fs:SetJustifyH("LEFT")
        fs:SetPoint("TOPLEFT", 84, y); fs:SetPoint("RIGHT", pf, "RIGHT", -8, 0); if fs.SetWordWrap then fs:SetWordWrap(false) end
        fs:SetTextColor(r, g, b); return fs
    end
    pf.titel = zeile(12, -8, 1, 0.82, 0.2)
    pf.ziel = zeile(11, -25, 0.9, 0.9, 0.9)
    pf.dist = zeile(13, -42, 0.75, 0.55, 1)
    pf:SetScript("OnDragStart", function(s) s:StartMoving() end)
    pf:SetScript("OnDragStop", function(s)
        s:StopMovingOrSizing()
        local a, _, b, x, y = s:GetPoint(1); Questie.db.char.siikkPfeilPos = { a, b, x, y }
    end)
    pf:SetScript("OnClick", function(_, btn)
        if btn == "RightButton" or IsShiftKeyDown() then SiikkDesign.Folge(nil)
        else -- nächste Quest der Reihe nach
            local n = #SiikkDesign.reihe; if n == 0 then return end
            local cur = SiikkDesign.nummern[Questie.db.char.siikkFolge or -1] or 0
            SiikkDesign.Folge(SiikkDesign.reihe[cur % n + 1])
        end
    end)
    pf:SetScript("OnEnter", function(s)
        GameTooltip:SetOwner(s, "ANCHOR_BOTTOM"); GameTooltip:AddLine("Questpfeil", 1, 0.82, 0)
        GameTooltip:AddLine("Linksklick: nächste Quest · Rechtsklick: automatisch (nächstgelegene) · Ziehen: verschieben", 0.8, 0.8, 0.8, true)
        GameTooltip:AddLine("Mausrad: Größe ändern", 0.8, 0.8, 0.8, true)
        GameTooltip:AddLine("In der Questanzeige: Rechtsklick auf eine Quest → „Diese Quest verfolgen“", 0.75, 0.55, 1, true)
        if s.modus == "klein" and s.titel:GetText() then
            GameTooltip:AddLine(" "); GameTooltip:AddLine(s.titel:GetText(), 1, 0.82, 0.2)
            if s.ziel:GetText() then GameTooltip:AddLine(s.ziel:GetText(), 1, 1, 1) end
            if s.dist:GetText() then GameTooltip:AddLine(s.dist:GetText(), 0.75, 0.55, 1) end
        end
        GameTooltip:Show()
    end)
    pf:SetScript("OnLeave", function() GameTooltip:Hide() end)
    pf:EnableMouseWheel(true)
    pf:SetScript("OnMouseWheel", function(s, d)
        local sc = math.max(0.5, math.min(2.5, (Questie.db.profile.siikkPfeilScale or 1) + d * 0.05))
        Questie.db.profile.siikkPfeilScale = sc; s:SetScale(sc)
        GameTooltip:SetOwner(s, "ANCHOR_BOTTOM"); GameTooltip:AddLine("Größe: " .. math.floor(sc * 100 + 0.5) .. " %", 1, 0.82, 0); GameTooltip:Show()
    end)
    return pf
end

-- Ansicht des Pfeilfelds: "gross" = Nummer, Pfeil, Quest, Ziel und Meter · "klein" = nur Nummer und Pfeil
local function feldModus() local p = P(); return (p and p.siikkPfeilModus == "klein") and "klein" or "gross" end
local function feldLayout()
    if not pf then return end
    local m = feldModus()
    if pf.modus ~= m then
        pf.modus = m
        if m == "klein" then
            -- klein: Nummer oben links, Meterzahl darunter, Pfeil rechts
            pf:SetSize(112, 62); pf.nr:ClearAllPoints(); pf.nr:SetPoint("TOPLEFT", 9, -8)
            pf.pfeil:ClearAllPoints(); pf.pfeil:SetSize(44, 44); pf.pfeil:SetPoint("RIGHT", -9, 0)
            pf.titel:Hide(); pf.ziel:Hide()
            pf.dist:ClearAllPoints(); pf.dist:SetPoint("BOTTOMLEFT", 9, 8); pf.dist:SetWidth(62); pf.dist:Show()
        else
            pf:SetSize(250, 64); pf.nr:ClearAllPoints(); pf.nr:SetPoint("LEFT", 10, 0)
            pf.pfeil:ClearAllPoints(); pf.pfeil:SetSize(40, 40); pf.pfeil:SetPoint("LEFT", 36, 0)
            pf.dist:ClearAllPoints(); pf.dist:SetPoint("TOPLEFT", 84, -42); pf.dist:SetPoint("RIGHT", pf, "RIGHT", -8, 0)
            pf.titel:Show(); pf.ziel:Show(); pf.dist:Show()
        end
    end
    local sc = (P() and P().siikkPfeilScale) or 1
    if math.abs((pf:GetScale() or 1) - sc) > 0.001 then pf:SetScale(sc) end
end
SiikkDesign.FeldLayout = function() if pf then pf.modus = nil; feldLayout() end end

local function platziereFeld()
    local s = Questie.db.char.siikkPfeilPos
    pf:ClearAllPoints()
    if type(s) == "table" and s[1] then pf:SetPoint(s[1], UIParent, s[2] or s[1], s[3] or 0, s[4] or 0)
    else pf:SetPoint("TOP", UIParent, "TOP", 0, -140) end
end

function SiikkDesign.Folge(questId)
    Questie.db.char.siikkFolge = questId
    local n = questId and SiikkDesign.nummern[questId]
    if questId then
        local q = SiikkDesign.quests[questId]
        Questie:Print("Questpfeil folgt: " .. (n and ("|cffb266ff#" .. n .. "|r ") or "") .. (q and q.name or ("Quest " .. questId)))
    else
        Questie:Print("Questpfeil folgt automatisch der nächstgelegenen Quest.")
    end
end

local function zeichneFeld()
    local p = P() or {}
    if p.siikkArrows == false or not p.trackerEnabled then if pf then pf:Hide() end return end
    baueFeld()
    if not pf.platziert then platziereFeld(); pf.platziert = true end
    local c = farbe("siikkBorderColor", GOLD)
    pf:SetBackdropBorderColor(c.r, c.g, c.b, 1)
    local bg = farbe("siikkPfeilBg", { r = 0.08, g = 0.04, b = 0.12 })
    pf:SetBackdropColor(bg.r, bg.g, bg.b, p.siikkPfeilAlpha or 0.35)
    feldLayout()
    pf:Show()

    local px, py, pinst = HBD:GetPlayerWorldPosition()
    local facing = GetPlayerFacing and GetPlayerFacing()
    -- welche Quest?
    local folge = Questie.db.char.siikkFolge
    if folge and not SiikkDesign.quests[folge] then folge = nil end
    local quest, z, dist, angle
    local function messen(q)
        local zz = zielVon(q)
        if zz.wx and px and zz.inst == pinst then
            local a, d = HBD:GetWorldVector(pinst, px, py, zz.wx, zz.wy)
            return zz, d, a
        end
        return zz
    end
    if folge then
        quest = SiikkDesign.quests[folge]; z, dist, angle = messen(quest)
    else
        for _, id in ipairs(SiikkDesign.reihe) do
            local q = SiikkDesign.quests[id]
            local zz, d, a = messen(q)
            if d and (not dist or d < dist) then quest, z, dist, angle = q, zz, d, a end
        end
    end
    if not quest then
        pf.nr:SetText(""); pf.pfeil:Hide(); pf.titel:SetText("Questpfeil")
        pf.ziel:SetText("|cffaaaaaa" .. (#SiikkDesign.reihe == 0 and "Keine Quests in der Questanzeige" or "Kein Ziel in der Nähe") .. "|r"); pf.dist:SetText("")
        return
    end
    pf.nr:SetText("#" .. (SiikkDesign.nummern[quest.Id] or "?"))
    pf.titel:SetText((folge and "" or "|cff999999Auto ·|r ") .. (quest.name or ""))
    local fertig = quest.IsComplete and (quest:IsComplete() == 1)
    pf.ziel:SetText((fertig and "Abgabe: " or "Ziel: ") .. (z and z.name or "?"))
    if not dist or not facing then
        pf.pfeil:Hide(); pf.dist:SetText("|cffaaaaaa" .. ((z and z.wx) and "anderer Kontinent / Dungeon" or "Ort unbekannt") .. "|r"); return
    end
    pf.pfeil:Show()
    if dist < 12 then
        pf.pfeil:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready"); pf.pfeil:SetRotation(0); pf.pfeil:SetVertexColor(1, 1, 1)
        pf.dist:SetText("|cff33ff33Ziel erreicht|r"); return
    end
    local rel = angle - facing
    pf.pfeil:SetTexture(ICONS .. "siikk_pfeil"); pf.pfeil:SetRotation(rel)
    local w = math.abs(((rel + math.pi) % (2 * math.pi)) - math.pi)
    if w < 0.5 then pf.pfeil:SetVertexColor(1, 1, 1) elseif w < 1.8 then pf.pfeil:SetVertexColor(1, 0.75, 0.45) else pf.pfeil:SetVertexColor(1, 0.45, 0.4) end
    pf.dist:SetText(meter(dist))
end

---------------------------------------------------------------------------
-- Start
---------------------------------------------------------------------------
-- Alte Icon-Pfade aus gespeicherten Profilen (Questie-Originale) auf die siikk-Symbole umstellen
local ALT_ICON = { slay = "slay", loot = "loot", event = "event", object = "object", chatbubblegossipicon = "talk", interact = "interact",
    available = "available", available_gray = "available_gray", complete = "complete", incomplete = "incomplete",
    repeatable = "repeatable", repeatable_complete = "repeatable_complete", eventquest = "eventquest",
    eventquest_complete = "eventquest_complete", pvpquest = "pvpquest", pvpquest_complete = "pvpquest_complete",
    hand = "hand", slay_mono = "slay_mono", loot_mono = "loot_mono", object_mono = "object_mono" }
local function iconsUmstellen(p)
    for k, v in pairs(p) do
        if type(k) == "string" and k:find("^ICON_") and type(v) == "string" then
            local name = v:lower():match("icons[\\/]([%w_]+)%.%a+$")
            if name and ALT_ICON[name] and Questie.icons[ALT_ICON[name]] then p[k] = Questie.icons[ALT_ICON[name]] end
        end
    end
end
-- Questhilfe-Fenster sicher anzeigen: Tracker starten, falls er beim Login aus war, und auch ohne Quests sichtbar halten
function SiikkDesign.TrackerSicherstellen()
    local p = P(); if not p or not p.trackerEnabled then return end
    if type(SiikkUIQuestFensterModus) == "function" and SiikkUIQuestFensterModus() == "standard" then return end
    local ok, T = pcall(QuestieLoader.ImportModule, QuestieLoader, "QuestieTracker")
    if not ok or not T then return end
    -- Nur neu zeichnen – NIE ein zweites Mal starten (sonst entstehen doppelte Tracker-Fenster)
    if T.started then pcall(T.Update, T) end
end

function SiikkDesign.Initialize()
    SiikkDesign.gestartet = true
    pcall(function()
        local p0 = P()
        if p0 then
            iconsUmstellen(p0)
            if p0.siikkImmerZeigen == nil then p0.siikkImmerZeigen = true; p0.alwaysShowTracker = true end
        end
    end)
    -- nach jedem Neuzeichnen der Questanzeige Logo und Farben sicherstellen
    pcall(function()
        local T = QuestieLoader:ImportModule("QuestieTracker")
        if T and T.Update and not SiikkDesign.updHook then
            SiikkDesign.updHook = true
            hooksecurefunc(T, "Update", function() if base and base.siikkHooked then pcall(SiikkDesign.Apply) else pcall(hookBase) end end)
        end
    end)
    if C_Timer and C_Timer.After then
        C_Timer.After(3, function() pcall(SiikkDesign.TrackerSicherstellen) end)
        C_Timer.After(10, function() pcall(SiikkDesign.TrackerSicherstellen) end)
    end
    local acc, acc2, acc3 = 0, 0, 0
    local f = CreateFrame("Frame")
    f:SetScript("OnUpdate", function(_, el)
        acc, acc2 = acc + el, acc2 + el
        if acc >= 0.05 then acc = 0; sc("Pfeilfeld", zeichneFeld) end
        acc3 = acc3 + el; if acc3 >= 0.5 then acc3 = 0; sc("Meter", meterAktualisieren) end
        if acc2 >= 1 then acc2 = 0; if not (base and base.siikkHooked) then sc("Rahmen", hookBase) end end
    end)
    f:RegisterEvent("PLAYER_ENTERING_WORLD")
    f:SetScript("OnEvent", function() ziele = {}; pcall(hookBase); pcall(SiikkDesign.Apply) end)
end

---------------------------------------------------------------------------
-- Schnittstelle für siikkUI: welche Questanzeige soll laufen?
---------------------------------------------------------------------------
SiikkQuesthilfe = {
    -- an = true: Questhilfe-Tracker mit Pfeil · an = false: Tracker und Pfeil aus (siikkUI-Standardanzeige übernimmt)
    SetTracker = function(an)
        if not (Questie and Questie.db and Questie.db.profile) then return end
        an = an and true or false
        if (Questie.db.profile.trackerEnabled and true or false) ~= an then
            Questie.db.profile.trackerEnabled = an
            pcall(function() QuestieLoader:ImportModule("QuestieTracker"):Update() end)
        end
        if not an and pf then pf:Hide() end
        if an then pcall(SiikkDesign.TrackerSicherstellen) end
    end,
    IsTracker = function() return Questie and Questie.db and Questie.db.profile.trackerEnabled and true or false end,
}

---------------------------------------------------------------------------
-- Einstellungen: Reiter „siikk-Design“
---------------------------------------------------------------------------
local function farbOpt(order, name, key, std, mitAlpha)
    return {
        type = "color", order = order, name = name, hasAlpha = mitAlpha, width = 1.5,
        get = function() local c = farbe(key, std); return c.r, c.g, c.b, c.a or 1 end,
        set = function(_, r, g, b, a) Questie.db.profile[key] = { r = r, g = g, b = b, a = a }; SiikkDesign.Apply() end,
    }
end
function SiikkDesign.OptionsTab()
    return {
        name = "|cffe03030siikk|r-Design", type = "group", order = 0.5,
        args = {
            fenster = { type = "select", order = 1.5, width = "full", name = "Welche Questanzeige?",
                values = { hilfe = "siikk-Questhilfe – mit Questpfeil und Hilfen", standard = "siikkUI-Standard – ohne Hilfe" },
                hidden = function() return type(SiikkUIQuestFenster) ~= "function" end,
                get = function() return (type(SiikkUIQuestFensterModus) == "function" and SiikkUIQuestFensterModus()) or "hilfe" end,
                set = function(_, v) if type(SiikkUIQuestFenster) == "function" then SiikkUIQuestFenster(v) end end },
            info = { type = "description", order = 1, fontSize = "medium",
                name = "Aussehen des Quest-Trackers im siikk-Stil. Den Tracker verschiebst du jederzeit mit gedrückter linker Maustaste an der Kopfzeile, die Größe änderst du am Griff in der Ecke.\n" },
            rahmen = farbOpt(2, "Rahmenfarbe", "siikkBorderColor", GOLD, false),
            kopf = farbOpt(3, "Farbe der Kopfzeile", "siikkHeaderColor", { r = 0.315, g = 0.19, b = 0.45, a = 0.8 }, true),
            hintergrund = {
                type = "color", order = 4, name = "Hintergrundfarbe", hasAlpha = true, width = 1.5,
                get = function() local c = Questie.db.profile.trackerBackdropColor; return c.r, c.g, c.b, c.a end,
                set = function(_, r, g, b, a)
                    Questie.db.profile.trackerBackdropColor = { r = r, g = g, b = b, a = a }
                    if base and Questie.db.profile.trackerBackdropEnabled then base:SetBackdropColor(r, g, b, a) end
                end,
            },
            hgAlpha = { type = "range", order = 4.5, width = 1.5, name = "Deckkraft des Hintergrunds", min = 0, max = 1, step = 0.05, isPercent = true,
                get = function() local c = Questie.db.profile.trackerBackdropColor; return (c and c.a) or 1 end,
                set = function(_, v)
                    local c = Questie.db.profile.trackerBackdropColor or { r = 0, g = 0, b = 0, a = 1 }
                    Questie.db.profile.trackerBackdropColor = { r = c.r or 0, g = c.g or 0, b = c.b or 0, a = v }
                    Questie.db.profile.trackerBackdropEnabled = true
                    local b = base or _G["Questie_BaseFrame"]
                    if b and b.SetBackdropColor then b:SetBackdropColor(c.r or 0, c.g or 0, c.b or 0, v) end
                end },
            logo = { type = "toggle", order = 5, width = 1.5, name = "Fraktions-Logo als Hintergrund",
                get = function() return Questie.db.profile.siikkLogo ~= false end,
                set = function(_, v) Questie.db.profile.siikkLogo = v; SiikkDesign.Apply() end },
            logoFraktion = { type = "select", order = 6, width = 1.5, name = "Welches Logo",
                values = { auto = "Automatisch (deine Fraktion)", horde = "Horde", allianz = "Allianz" },
                get = function() return Questie.db.profile.siikkLogoFraktion or "auto" end,
                set = function(_, v) Questie.db.profile.siikkLogoFraktion = v; SiikkDesign.Apply() end },
            logoAlpha = { type = "range", order = 7, width = 1.5, name = "Sichtbarkeit des Logos", min = 0.05, max = 1, step = 0.01, isPercent = true,
                get = function() return Questie.db.profile.siikkLogoAlpha or 0.55 end,
                set = function(_, v) Questie.db.profile.siikkLogoAlpha = v; SiikkDesign.Apply() end },
            immer = { type = "toggle", order = 7.5, width = "full", name = "Fenster immer zeigen (auch wenn gerade keine Quest verfolgt wird)",
                get = function() return Questie.db.profile.alwaysShowTracker and true or false end,
                set = function(_, v) Questie.db.profile.alwaysShowTracker = v and true or false; pcall(SiikkDesign.TrackerSicherstellen) end },
            pfeile = { type = "toggle", order = 8, width = "full", name = "Questpfeil-Feld anzeigen (Nummer, Quest, Ziel und Meterzahl – verschiebbar)",
                get = function() return Questie.db.profile.siikkArrows ~= false end,
                set = function(_, v) Questie.db.profile.siikkArrows = v end },
            meterListe = { type = "toggle", order = 7.8, width = "full", name = "Meterzahl hinter jeder Quest in der Questanzeige",
                get = function() return Questie.db.profile.siikkMeterListe ~= false end,
                set = function(_, v) Questie.db.profile.siikkMeterListe = v and true or false; pcall(function() QuestieLoader:ImportModule("QuestieTracker"):Update() end) end },
            pfeilModus = { type = "select", order = 8.1, width = 1.5, name = "Ansicht des Questpfeils",
                values = { gross = "Groß – Nummer, Pfeil, Quest, Ziel und Meter", klein = "Klein – Nummer, Pfeil und Meter" },
                get = function() return Questie.db.profile.siikkPfeilModus or "gross" end,
                set = function(_, v) Questie.db.profile.siikkPfeilModus = v; SiikkDesign.FeldLayout() end },
            pfeilGroesse = { type = "range", order = 8.2, width = 1.5, name = "Größe des Questpfeils (auch Mausrad)", min = 0.5, max = 2.5, step = 0.05, isPercent = true,
                get = function() return Questie.db.profile.siikkPfeilScale or 1 end,
                set = function(_, v) Questie.db.profile.siikkPfeilScale = v; SiikkDesign.FeldLayout() end },
            pfeilAlpha = { type = "range", order = 8.3, width = 1.5, name = "Hintergrund des Questpfeils (Deckkraft)", min = 0, max = 1, step = 0.05, isPercent = true,
                get = function() return Questie.db.profile.siikkPfeilAlpha or 0.35 end,
                set = function(_, v) Questie.db.profile.siikkPfeilAlpha = v end },
            pfeilReset = { type = "execute", order = 8.5, name = "Questpfeil an den Startplatz",
                func = function() Questie.db.char.siikkPfeilPos = nil; Questie.db.profile.siikkPfeilScale = nil; if pf then platziereFeld(); SiikkDesign.FeldLayout() end end },
            reset = { type = "execute", order = 9, name = "Farben zurücksetzen",
                func = function() local p = Questie.db.profile; p.siikkBorderColor, p.siikkHeaderColor = nil, nil; p.trackerBackdropColor = { r = 0.03, g = 0.02, b = 0.05, a = 0.75 }; SiikkDesign.Apply() end },
        },
    }
end

-- Sicherheitsnetz: Logo/Farben auch dann anbringen, wenn der normale Start nicht durchläuft
do
    local w, n, gesamt = CreateFrame("Frame"), 0, 0
    w:RegisterEvent("PLAYER_ENTERING_WORLD")
    w:SetScript("OnEvent", function()
        n, gesamt = 0, 0
        w:SetScript("OnUpdate", function(self, el)
            n, gesamt = n + el, gesamt + el
            if n >= 2 then
                n = 0
                sc("Rahmen", hookBase); sc("Logo", SiikkDesign.Apply)
                if gesamt > 30 then self:SetScript("OnUpdate", nil) end
            end
        end)
    end)
end

-- Prüfbericht: /qhdiag
SLASH_SIIKKQHDIAG1 = "/qhdiag"
SlashCmdList.SIIKKQHDIAG = function()
    local function j(v) return v and "|cff33ff33ja|r" or "|cffff4444nein|r" end
    local function out(t) DEFAULT_CHAT_FRAME:AddMessage("|cffb266ff[QH-Diag]|r " .. t) end
    local p = P() or {}
    local b = _G["Questie_BaseFrame"]
    out("Version " .. tostring(C_AddOns and C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata("siikk-Questhilfe", "Version") or "?") .. " · Start gelaufen: " .. j(SiikkDesign.gestartet))
    out("Tracker-Rahmen: " .. j(b) .. (b and (" · sichtbar " .. j(b:IsShown()) .. " · Ebene " .. tostring(b:GetFrameStrata()) .. "/" .. tostring(b:GetFrameLevel()) .. " · eingehängt " .. j(b.siikkHooked)) or ""))
    if b and b.GetBackdropColor then local r, g, bb, a = b:GetBackdropColor(); out(string.format("Hintergrund: %.2f %.2f %.2f Deckkraft %.2f", r or -1, g or -1, bb or -1, a or -1)) end
    if logo then
        local l, sl = logo:GetDrawLayer()
        out("Logo: da · sichtbar " .. j(logo:IsVisible()) .. " · Alpha " .. string.format("%.2f", logo:GetAlpha() or -1) .. " · Größe " .. math.floor(logo:GetWidth() or 0) .. " · Ebene " .. tostring(l) .. "/" .. tostring(sl) .. " · Bild " .. tostring(logo:GetTexture()))
    else out("Logo: |cffff4444nicht angelegt|r") end
    out("Einstellung Logo an: " .. j(p.siikkLogo ~= false) .. " · Alpha-Einstellung " .. tostring(p.siikkLogoAlpha) .. " · Fraktion " .. tostring(p.siikkLogoFraktion))
    local n, beispiel = 0, nil
    for line, q in pairs(SiikkDesign.meterZeilen or {}) do n = n + 1; if not beispiel then local ok, t = pcall(meterText, q); beispiel = (q.name or "?") .. " -> " .. tostring(ok and t or ("Fehler: " .. tostring(t))) end end
    out("Meter-Zeilen: " .. n .. (beispiel and (" · " .. beispiel) or ""))
    local px, py, pinst = HBD:GetPlayerWorldPosition()
    out("Spielerposition: " .. tostring(px and math.floor(px)) .. ", " .. tostring(py and math.floor(py)) .. " · Welt " .. tostring(pinst))
    local leer = true
    for k, v in pairs(SiikkDesign.fehler) do leer = false; out("|cffff4444Fehler " .. k .. ":|r " .. v) end
    if leer then out("Keine Fehler gemerkt.") end
end

-- Minimap-Knopf zentral schaltbar (siikk-Oberfläche → /th addons)
SiikkMinimapAPI = rawget(_G, "SiikkMinimapAPI") or {}
SiikkMinimapAPI["siikk-Questhilfe"] = {
    get = function() local p = P(); return not (p and p.minimap and p.minimap.hide) end,
    set = function(an)
        local p = P(); if not p then return end
        p.minimap = p.minimap or {}; p.minimap.hide = not an
        local I = LibStub and LibStub("LibDBIcon-1.0", true)
        if I then if an then pcall(I.Show, I, "siikk-Questhilfe") else pcall(I.Hide, I, "siikk-Questhilfe") end end
    end,
}
