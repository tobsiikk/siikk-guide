-- siikk-Questhilfe · Einführung beim ersten Start (/qh intro)
local L = siikkL or function(s) return s end
local Y = "|cffffd100"
siikkIntro("siikk-Questhilfe", "|cffe03030siikk|r-|cffb266ffQuesthilfe|r", "Interface\\AddOns\\siikk-Questhilfe\\Icons\\questie", {
    { L"Willkommen bei der siikk-Questhilfe",
      L"Die Questhilfe zeigt dir alle " .. Y .. L"Questgeber|r, " .. Y .. L"Questziele|r und " .. Y .. L"Abgabe-NPCs|r auf Weltkarte und Minimap – mit eigenen siikk-Symbolen. Die Questdaten bringt das Addon " .. Y .. L"QuestieDB|r mit (muss mit installiert sein).\n\n" ..
      L"• |cffffd100!|r gold = Quest annehmen · |cffffd100?|r gold = Quest abgeben · grau = noch nicht fertig bzw. noch nicht verfügbar.\n" ..
      L"• Blau = wiederholbar · grün = Event · rot = PvP.\n" ..
      L"• Rauten-Symbole = Ziele: Schwerter töten, Edelsteine sammeln, Zahnrad benutzen, Brief reden, Hände anfassen.\n\n" ..
      L"• Der Minimap-Knopf (goldenes !) öffnet die Einstellungen." },
    { L"Das Questfenster",
      L"• Alle angenommenen Quests, " .. Y .. L"nummeriert|r, nach Gebiet sortiert. Hinter jeder Quest steht in Lila, " .. Y .. L"wie viele Meter|r das Ziel entfernt ist (bei fertigen Quests: bis zum Abgabe-NPC).\n\n" ..
      "• " .. Y .. L"Verschieben|r: an der Kopfzeile ziehen. " .. Y .. L"Größe|r: am Griff unten rechts.\n\n" ..
      "• " .. Y .. L"Zahnrad oben rechts|r: Linksklick = Einstellungen, Rechtsklick = Quest-Tagebuch.\n\n" ..
      "• " .. Y .. L"Rechtsklick auf eine Quest|r → „Diese Quest verfolgen“: der Questpfeil führt dann genau zu dieser Quest (im Fenster mit > markiert).\n\n" ..
      L"• Klick auf das Minus vor einer Quest klappt sie zu." },
    { L"Der Questpfeil",
      L"Ein eigenes, frei verschiebbares Feld mit Pfeil und Meterzahl.\n\n" ..
      L"• Ohne Auswahl führt er " .. Y .. L"automatisch|r zur nächstgelegenen Quest (\"Auto\").\n" ..
      "• " .. Y .. L"Linksklick|r: nächste Quest der Reihe nach · " .. Y .. L"Rechtsklick|r: zurück auf automatisch.\n" ..
      "• " .. Y .. L"Mausrad|r über dem Feld: Größe ändern (50–250 %).\n" ..
      L"• Der Pfeil färbt sich: weiß = geradeaus, orange = seitlich, rot = hinter dir. Unter 12 m: grüner Haken.\n\n" ..
      L"• Zwei Ansichten: " .. Y .. L"Groß|r (Nummer, Pfeil, Questname, Ziel, Meter) oder " .. Y .. L"Klein|r (Nummer, Pfeil, Meter)." },
    { L"Einstellungen – Reiter „siikk-Design“",
      "• " .. Y .. L"Welche Questanzeige?|r – Questhilfe mit Pfeil oder die schlichte Anzeige der siikk-Oberfläche (immer nur eine).\n" ..
      "• " .. Y .. L"Rahmenfarbe|r, " .. Y .. L"Farbe der Kopfzeile|r, " .. Y .. L"Hintergrundfarbe|r und " .. Y .. L"Deckkraft des Hintergrunds|r.\n" ..
      "• " .. Y .. L"Fraktions-Logo|r an/aus, Horde oder Allianz, " .. Y .. L"Sichtbarkeit|r des Logos.\n" ..
      "• " .. Y .. L"Fenster immer zeigen|r (auch ohne verfolgte Quest).\n" ..
      "• " .. Y .. L"Meterzahl hinter jeder Quest|r an/aus.\n" ..
      "• " .. Y .. L"Questpfeil|r an/aus, Ansicht Groß/Klein, Größe, Deckkraft des Hintergrunds, an den Startplatz.\n\n" ..
      L"Die übrigen Reiter (Allgemein, Icons, Weltkarte, Tracker, Automatisch …) regeln Symbolgrößen, Kartenanzeige, automatisches Annehmen/Abgeben und mehr." },
    { L"Befehle",
      Y .. L"/qh|r – Einstellungen öffnen\n" .. Y .. L"/qh intro|r – diese Einführung · " .. Y .. L"/qh neu|r – was ist neu\n" .. Y .. L"/qh journey|r – Quest-Tagebuch\n" .. Y .. L"/qhdiag|r – Prüfbericht, falls etwas nicht angezeigt wird\n\n" ..
      L"Mit der siikk-Oberfläche:\n" .. Y .. L"/th quests hilfe|r – Questhilfe-Fenster benutzen · " .. Y .. L"/th quests standard|r – schlichte Anzeige\n" ..
      Y .. L"/th addons|r – Questhilfe und ihren Minimap-Knopf an/aus\n\n" ..
      L"Nach einem Update immer WoW ganz neu starten, nicht nur /reload." },
}, function() return Questie and Questie.db and Questie.db.global end, "/qh intro")
