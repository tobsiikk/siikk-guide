-- siikk-Questhilfe · Einführung beim ersten Start (/qh intro)
local Y = "|cffffd100"
siikkIntro("siikk-Questhilfe", "|cffe03030siikk|r-|cffb266ffQuesthilfe|r", "Interface\\AddOns\\siikk-Questhilfe\\Icons\\questie", {
    { "Willkommen bei der siikk-Questhilfe",
      "Die Questhilfe zeigt dir alle " .. Y .. "Questgeber|r, " .. Y .. "Questziele|r und " .. Y .. "Abgabe-NPCs|r auf Weltkarte und Minimap – mit eigenen siikk-Symbolen. Die Questdaten bringt das Addon " .. Y .. "QuestieDB|r mit (muss mit installiert sein).\n\n" ..
      "• |cffffd100!|r gold = Quest annehmen · |cffffd100?|r gold = Quest abgeben · grau = noch nicht fertig bzw. noch nicht verfügbar.\n" ..
      "• Blau = wiederholbar · grün = Event · rot = PvP.\n" ..
      "• Rauten-Symbole = Ziele: Schwerter töten, Edelsteine sammeln, Zahnrad benutzen, Brief reden, Hände anfassen.\n\n" ..
      "• Der Minimap-Knopf (goldenes !) öffnet die Einstellungen." },
    { "Das Questfenster",
      "• Alle angenommenen Quests, " .. Y .. "nummeriert|r, nach Gebiet sortiert. Hinter jeder Quest steht in Lila, " .. Y .. "wie viele Meter|r das Ziel entfernt ist (bei fertigen Quests: bis zum Abgabe-NPC).\n\n" ..
      "• " .. Y .. "Verschieben|r: an der Kopfzeile ziehen. " .. Y .. "Größe|r: am Griff unten rechts.\n\n" ..
      "• " .. Y .. "Zahnrad oben rechts|r: Linksklick = Einstellungen, Rechtsklick = Quest-Tagebuch.\n\n" ..
      "• " .. Y .. "Rechtsklick auf eine Quest|r → „Diese Quest verfolgen“: der Questpfeil führt dann genau zu dieser Quest (im Fenster mit > markiert).\n\n" ..
      "• Klick auf das Minus vor einer Quest klappt sie zu." },
    { "Der Questpfeil",
      "Ein eigenes, frei verschiebbares Feld mit Pfeil und Meterzahl.\n\n" ..
      "• Ohne Auswahl führt er " .. Y .. "automatisch|r zur nächstgelegenen Quest (\"Auto\").\n" ..
      "• " .. Y .. "Linksklick|r: nächste Quest der Reihe nach · " .. Y .. "Rechtsklick|r: zurück auf automatisch.\n" ..
      "• " .. Y .. "Mausrad|r über dem Feld: Größe ändern (50–250 %).\n" ..
      "• Der Pfeil färbt sich: weiß = geradeaus, orange = seitlich, rot = hinter dir. Unter 12 m: grüner Haken.\n\n" ..
      "• Zwei Ansichten: " .. Y .. "Groß|r (Nummer, Pfeil, Questname, Ziel, Meter) oder " .. Y .. "Klein|r (Nummer, Pfeil, Meter)." },
    { "Einstellungen – Reiter „siikk-Design“",
      "• " .. Y .. "Welche Questanzeige?|r – Questhilfe mit Pfeil oder die schlichte Anzeige der siikk-Oberfläche (immer nur eine).\n" ..
      "• " .. Y .. "Rahmenfarbe|r, " .. Y .. "Farbe der Kopfzeile|r, " .. Y .. "Hintergrundfarbe|r und " .. Y .. "Deckkraft des Hintergrunds|r.\n" ..
      "• " .. Y .. "Fraktions-Logo|r an/aus, Horde oder Allianz, " .. Y .. "Sichtbarkeit|r des Logos.\n" ..
      "• " .. Y .. "Fenster immer zeigen|r (auch ohne verfolgte Quest).\n" ..
      "• " .. Y .. "Meterzahl hinter jeder Quest|r an/aus.\n" ..
      "• " .. Y .. "Questpfeil|r an/aus, Ansicht Groß/Klein, Größe, Deckkraft des Hintergrunds, an den Startplatz.\n\n" ..
      "Die übrigen Reiter (Allgemein, Icons, Weltkarte, Tracker, Automatisch …) regeln Symbolgrößen, Kartenanzeige, automatisches Annehmen/Abgeben und mehr." },
    { "Befehle",
      Y .. "/qh|r – Einstellungen öffnen\n" .. Y .. "/qh intro|r – diese Einführung · " .. Y .. "/qh neu|r – was ist neu\n" .. Y .. "/qh journey|r – Quest-Tagebuch\n" .. Y .. "/qhdiag|r – Prüfbericht, falls etwas nicht angezeigt wird\n\n" ..
      "Mit der siikk-Oberfläche:\n" .. Y .. "/th quests hilfe|r – Questhilfe-Fenster benutzen · " .. Y .. "/th quests standard|r – schlichte Anzeige\n" ..
      Y .. "/th addons|r – Questhilfe und ihren Minimap-Knopf an/aus\n\n" ..
      "Nach einem Update immer WoW ganz neu starten, nicht nur /reload." },
}, function() return Questie and Questie.db and Questie.db.global end, "/qh intro")
