-- siikk-Questhilfe · „Was ist neu?“ – erzeugt aus tools/changelog.py (nicht von Hand ändern)
local L = siikkL or function(s) return s end
siikkNeu("siikk-Questhilfe", "|cffe03030siikk|r-|cffb266ffQuesthilfe|r", "Interface\\AddOns\\siikk-Questhilfe\\Icons\\questie", "3.1",
{
    { version = "3.1", datum = "04.11.2026", punkte = { L"Auf Questie 12.5.1 aktualisiert – mit eigener Ladedatei für WoW Forever (der Spiel-Client erkennt das Addon jetzt sicher).", L"Neue Questdaten für Forever (QuestieDB 1.0.10): viele korrigierte Quests, NPCs und Ruf-Belohnungen.", L"Neues Einstellungsfenster wie bei Blizzard – der Reiter siikk-Design ist ganz vorne mit dabei.", L"Questanzeige: Knöpfe vor dem Questnamen, Hervorhebung beim Drüberfahren; VoiceOver-Knöpfe immer sichtbar." } },
    { version = "3.0", datum = "02.11.2026", punkte = { L"Neu: Sprache wählbar – Deutsch, English, Русский, Français, Español. Mit /sprache für alle siikk-Addons auf einmal umschalten (startet in der Sprache deines WoW).", L"Übersetzt sind die siikk-Teile (Design-Reiter, Pfeil, Meter, Einführung); die Questtexte selbst übersetzt die Questhilfe wie bisher über ihre eigene Spracheinstellung." } },
    { version = "2.9", datum = "31.10.2026", punkte = { L"Neu: Fenster „Was ist neu?“ nach jedem Update (wieder öffnen: /qh neu)." } },
    { version = "2.8", datum = "31.10.2026", punkte = { L"Neu: Einführung beim ersten Start mit allen Symbolen, Fenstern und Einstellungen (/qh intro)." } },
    { version = "2.7", datum = "31.10.2026", punkte = { L"Minimap-Knopf mit dem goldenen „!“, zentral schaltbar über /th addons." } },
    { version = "2.6", datum = "31.10.2026", punkte = { L"Kleines Pfeilfeld zeigt jetzt auch die Meterzahl." } },
    { version = "2.5", datum = "31.10.2026", punkte = { L"Neuer Regler „Deckkraft des Hintergrunds“ im Reiter siikk-Design." } },
    { version = "2.0 – 2.4", datum = "31.10.2026", punkte = { L"Meterzahl hinter jeder Quest im Questfenster.", L"Fraktions-Logo deutlich sichtbarer, Fehler mit doppeltem Fenster behoben.", L"Prüfbericht /qhdiag." } },
    { version = "1.5 – 1.9", datum = "31.10.2026", punkte = { L"Eigene Symbole im siikk-Design auf Karte und Minimap, Name Questie überall entfernt.", L"Zahnrad für die Einstellungen oben rechts.", L"Pfeilfeld: Größe per Mausrad, durchsichtiger Hintergrund, Ansicht Groß/Klein.", L"Fenster immer an, außer man schaltet es ab." } }
}, function() return Questie and Questie.db and Questie.db.global end, "/qh neu")
