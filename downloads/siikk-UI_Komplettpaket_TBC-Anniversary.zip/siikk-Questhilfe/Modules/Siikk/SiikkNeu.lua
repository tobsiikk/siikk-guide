-- siikk-Questhilfe · „Was ist neu?“ – erzeugt aus tools/changelog.py (nicht von Hand ändern)
siikkNeu("siikk-Questhilfe", "|cffe03030siikk|r-|cffb266ffQuesthilfe|r", "Interface\\AddOns\\siikk-Questhilfe\\Icons\\questie", "2.9",
{
    { version = "2.9", datum = "31.10.2026", punkte = { "Neu: Fenster „Was ist neu?“ nach jedem Update (wieder öffnen: /qh neu)." } },
    { version = "2.8", datum = "31.10.2026", punkte = { "Neu: Einführung beim ersten Start mit allen Symbolen, Fenstern und Einstellungen (/qh intro)." } },
    { version = "2.7", datum = "31.10.2026", punkte = { "Minimap-Knopf mit dem goldenen „!“, zentral schaltbar über /th addons." } },
    { version = "2.6", datum = "31.10.2026", punkte = { "Kleines Pfeilfeld zeigt jetzt auch die Meterzahl." } },
    { version = "2.5", datum = "31.10.2026", punkte = { "Neuer Regler „Deckkraft des Hintergrunds“ im Reiter siikk-Design." } },
    { version = "2.0 – 2.4", datum = "31.10.2026", punkte = { "Meterzahl hinter jeder Quest im Questfenster.", "Fraktions-Logo deutlich sichtbarer, Fehler mit doppeltem Fenster behoben.", "Prüfbericht /qhdiag." } },
    { version = "1.5 – 1.9", datum = "31.10.2026", punkte = { "Eigene Symbole im siikk-Design auf Karte und Minimap, Name Questie überall entfernt.", "Zahnrad für die Einstellungen oben rechts.", "Pfeilfeld: Größe per Mausrad, durchsichtiger Hintergrund, Ansicht Groß/Klein.", "Fenster immer an, außer man schaltet es ab." } }
}, function() return Questie and Questie.db and Questie.db.global end, "/qh neu")
