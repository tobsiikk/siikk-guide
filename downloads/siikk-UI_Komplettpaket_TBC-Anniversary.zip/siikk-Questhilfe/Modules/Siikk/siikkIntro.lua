-- siikk · gemeinsames Infofenster für den ersten Start (in jedem siikk-Addon enthalten)
-- siikkIntro(id, titel, icon, seiten, svFn, befehl)   – erscheint einmal beim ersten Start, danach über den Befehl / Info-Knopf
--   seiten: { { "Überschrift", "Text" }, ... }   svFn: liefert die gespeicherte Tabelle des Addons (oder nil, solange sie noch nicht bereit ist)
-- Mehrere Addons zeigen ihre Infofenster nacheinander, nie gleichzeitig. Jedes meldet sich in SiikkIntroAPI an (Info-Knopf in der Zentrale).
local L = siikkL or function(s) return s end
SiikkIntroAPI = rawget(_G, "SiikkIntroAPI") or {}
if not rawget(_G, "siikkIntro") then
    local GOLD = { 0.85, 0.65, 0.15 }
    local warte = {}          -- Reihenfolge der noch zu zeigenden Infofenster
    local offen = nil         -- gerade sichtbares Fenster
    local function blockiert()
        if offen and offen:IsShown() then return true end
        local o = rawget(_G, "TobsiikkHelferIntro"); if o and o:IsShown() then return true end   -- Einführung der siikk-Oberfläche
        local k = rawget(_G, "TobsiikkHelferKlasse"); if k and k:IsShown() then return true end
        return InCombatLockdown and InCombatLockdown()
    end
    function SiikkIntroWarte(fn) warte[#warte + 1] = fn end
    local takt = CreateFrame("Frame"); local t = 0
    takt:SetScript("OnUpdate", function(_, el)
        t = t + el; if t < 1 then return end; t = 0
        if #warte == 0 or blockiert() then return end
        local w = table.remove(warte, 1); w()
    end)

    function siikkIntro(id, titel, icon, seiten, svFn, befehl)
        local f = CreateFrame("Frame", "siikkIntro_" .. id:gsub("[^%w]", ""), UIParent, "BackdropTemplate")
        f:SetSize(540, 400); f:SetPoint("CENTER", 0, 60); f:SetFrameStrata("DIALOG"); f:Hide()
        f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton"); f:SetClampedToScreen(true)
        f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
        f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
        f:SetBackdropColor(0.03, 0.02, 0.05, 0.96); f:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
        local bild = f:CreateTexture(nil, "BORDER", nil, -8); bild:SetSize(230, 230); bild:SetPoint("CENTER", 0, -10); bild:SetTexture(icon); bild:SetAlpha(0.1)
        local kopf = f:CreateTexture(nil, "BORDER"); kopf:SetPoint("TOPLEFT", 4, -4); kopf:SetPoint("TOPRIGHT", -4, -4); kopf:SetHeight(28); kopf:SetColorTexture(0.315, 0.19, 0.45, 0.8)
        local linie = f:CreateTexture(nil, "ARTWORK"); linie:SetPoint("TOPLEFT", kopf, "BOTTOMLEFT"); linie:SetPoint("TOPRIGHT", kopf, "BOTTOMRIGHT"); linie:SetHeight(1); linie:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], 1)
        local ic = f:CreateTexture(nil, "OVERLAY"); ic:SetSize(22, 22); ic:SetPoint("LEFT", kopf, "LEFT", 6, 0); ic:SetTexture(icon)
        local tt = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); tt:SetPoint("LEFT", ic, "RIGHT", 6, 0); tt:SetText(titel .. L"  |cffccccccEinführung|r")
        local zu = CreateFrame("Button", nil, f, "UIPanelCloseButton"); zu:SetPoint("TOPRIGHT", 0, 0)
        local head = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); head:SetPoint("TOPLEFT", 22, -46); head:SetWidth(420); head:SetJustifyH("LEFT")
        local nr = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); nr:SetPoint("TOPRIGHT", -18, -48)
        local body = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); body:SetPoint("TOPLEFT", head, "BOTTOMLEFT", 0, -12); body:SetWidth(496); body:SetJustifyH("LEFT"); body:SetJustifyV("TOP")
        local zur = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); zur:SetSize(110, 24); zur:SetPoint("BOTTOMLEFT", 16, 12); zur:SetText(L"Zurück")
        local vor = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); vor:SetSize(110, 24); vor:SetPoint("BOTTOMRIGHT", -16, 12); vor:SetText(L"Weiter")
        local hint = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); hint:SetPoint("BOTTOM", 0, 18)
        hint:SetText(befehl and (L"Später wieder öffnen: |cffffd100" .. befehl .. "|r") or "")
        local seite = 1
        local function zeichnen()
            local s = seiten[seite]
            head:SetText(s[1]); body:SetText(s[2]); nr:SetText(seite .. " / " .. #seiten)
            zur:SetEnabled(seite > 1); vor:SetText(seite < #seiten and L"Weiter" or L"Fertig")
        end
        local function sv() local x = svFn and svFn(); return type(x) == "table" and x or nil end
        zur:SetScript("OnClick", function() if seite > 1 then seite = seite - 1; zeichnen() end end)
        vor:SetScript("OnClick", function()
            if seite < #seiten then seite = seite + 1; zeichnen()
            else local x = sv(); if x then x.introGesehen = true end; f:Hide() end
        end)
        f:SetScript("OnHide", function() local x = sv(); if x then x.introGesehen = true end; if offen == f then offen = nil end end)
        local function zeigen()
            seite = 1; zeichnen()
            offen = f; f:Show()
        end
        SiikkIntroAPI[id] = zeigen
        -- erster Start: einreihen, sobald die gespeicherten Daten bereit sind
        local ev = CreateFrame("Frame"); ev:RegisterEvent("PLAYER_ENTERING_WORLD")
        ev:SetScript("OnEvent", function(self)
            self:UnregisterAllEvents()
            local versuche = 0
            local function pruefen()
                local x = sv()
                if not x then versuche = versuche + 1; if versuche < 30 and C_Timer then C_Timer.After(2, pruefen) end return end
                if not x.introGesehen then warte[#warte + 1] = zeigen end
            end
            if C_Timer then C_Timer.After(4, pruefen) else pruefen() end
        end)
        return zeigen
    end
end

-- siikk · „Was ist neu?“ nach einem Update
-- siikkNeu(id, titel, icon, version, aenderungen, svFn, befehl)
--   aenderungen: { { version = "2.4", datum = "31.10.2026", punkte = { "…", "…" } }, … }  (neueste zuerst)
-- Erscheint einmal, wenn sich die Version seit dem letzten Start geändert hat (nicht bei der ersten Installation).
SiikkNeuAPI = rawget(_G, "SiikkNeuAPI") or {}
if not rawget(_G, "siikkNeu") then
    function siikkNeu(id, titel, icon, version, aenderungen, svFn, befehl)
        local Y = "|cffffd100"
        local seiten = {}
        for i, a in ipairs(aenderungen) do
            if i > 3 then break end
            local t = {}
            for _, p in ipairs(a.punkte) do t[#t + 1] = "• " .. p end
            seiten[#seiten + 1] = { L"Version " .. a.version .. L"  |cff999999· aktualisiert am " .. a.datum .. "|r", table.concat(t, "\n\n") }
        end
        local sv0 = svFn
        local function sv() local x = sv0 and sv0(); return type(x) == "table" and x or nil end
        -- eigenes Fenster (gleiches Aussehen wie die Einführung), Titel „Was ist neu?“
        local zeigen = siikkIntro(id .. "-neu", titel .. L"  |cff33ff33Was ist neu?|r", icon, seiten, function()
            local x = sv(); if not x then return nil end
            x.neu = x.neu or {}; x.neu.introGesehen = true; return x.neu -- nie über den Einführungs-Weg, nur nach Update
        end, befehl)
        SiikkNeuAPI[id] = zeigen
        -- Einführung-Automatik für dieses Fenster abschalten; wir entscheiden selbst anhand der Version
        local ev = CreateFrame("Frame"); ev:RegisterEvent("PLAYER_ENTERING_WORLD")
        ev:SetScript("OnEvent", function(self)
            self:UnregisterAllEvents()
            local versuche = 0
            local function pruefen()
                local x = sv()
                if not x then versuche = versuche + 1; if versuche < 30 and C_Timer then C_Timer.After(2, pruefen) end return end
                x.neu = x.neu or {}; x.neu.introGesehen = true -- nie automatisch über den Einführungs-Weg
                local alt = x.letzteVersion
                x.letzteVersion = version
                if alt and alt ~= version then SiikkIntroWarte(zeigen) end
            end
            if C_Timer then C_Timer.After(5, pruefen) else pruefen() end
        end)
        return zeigen
    end
end
