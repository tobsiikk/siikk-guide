-- siikk · gemeinsames Sprach-System (in jedem siikk-Addon enthalten, wird nur einmal aktiv)
-- Texte stehen im Code auf Deutsch: L"Text". siikkL schlägt die Übersetzung der gewählten Sprache nach.
-- Sprache: zuerst die des WoW-Clients, umschaltbar für ALLE siikk-Addons auf einmal mit /sprache.
-- Gespeichert in siikkSprache_DB des kleinen Addons „siikkSprache“. Alle siikk-Addons laden es zuerst (OptionalDeps),
-- damit die gewählte Sprache schon feststeht, wenn ihre Texte entstehen. Fehlt es, gilt die Sprache des Clients.
SIIKK_TEXTE = rawget(_G, "SIIKK_TEXTE") or { en = {}, ru = {}, fr = {}, es = {} }
if not rawget(_G, "siikkL") then
    local SPRACHEN = { "de", "en", "ru", "fr", "es" }
    local NAMEN = { de = "Deutsch", en = "English", ru = "Русский", fr = "Français", es = "Español" }
    local CLIENT = { deDE = "de", enUS = "en", enGB = "en", ruRU = "ru", frFR = "fr", esES = "es", esMX = "es" }
    local aktuell

    local function clientSprache() return CLIENT[GetLocale and GetLocale() or ""] or "en" end
    local function bestimmen()
        local sv = rawget(_G, "siikkSprache_DB")
        local w = type(sv) == "table" and sv.lang
        aktuell = (w and NAMEN[w]) and w or clientSprache()
    end
    function siikkSprache() if not aktuell then bestimmen() end return aktuell end
    function siikkSpracheName(c) return NAMEN[c or siikkSprache()] end
    function siikkL(s)
        if type(s) ~= "string" then return s end
        local c = aktuell or siikkSprache()
        if c == "de" then return s end
        local t = SIIKK_TEXTE[c]
        return (t and t[s]) or s
    end

    -- Russisch auf einem westlichen Client: Schriften mit kyrillischen Zeichen verwenden
    local CYR = "Fonts\\FRIZQT___CYR.TTF"
    local function kyrillisch()
        if siikkSprache() ~= "ru" or (GetLocale and GetLocale() == "ruRU") then return end
        for _, n in ipairs({ "GameFontNormal", "GameFontNormalSmall", "GameFontNormalLarge", "GameFontHighlight", "GameFontHighlightSmall",
            "GameFontHighlightLarge", "GameFontDisable", "GameFontDisableSmall", "GameFontRed", "GameFontGreen", "GameTooltipText",
            "GameTooltipTextSmall", "GameTooltipHeaderText", "GameFontWhite", "GameFontNormalHuge", "SystemFont_Shadow_Med1" }) do
            local f = rawget(_G, n)
            if type(f) == "table" and f.GetFont then
                local _, gr, fl = f:GetFont(); if gr then pcall(f.SetFont, f, CYR, gr, fl or "") end
            end
        end
    end
    function siikkSchrift(standard) if siikkSprache() == "ru" and not (GetLocale and GetLocale() == "ruRU") then return CYR end return standard end

    -- gespeicherte Wahl einlesen, sobald „siikkSprache“ geladen ist
    local ev = CreateFrame("Frame"); ev:RegisterEvent("ADDON_LOADED"); ev:RegisterEvent("PLAYER_LOGIN")
    ev:SetScript("OnEvent", function(_, e, name)
        if e == "ADDON_LOADED" and name == "siikkSprache" then bestimmen()
        elseif e == "PLAYER_LOGIN" then kyrillisch() end
    end)

    -- Auswahlfenster (/sprache)
    local fenster
    local function setzen(c)
        siikkSprache_DB = { lang = c }
        bestimmen()
    end
    local function oeffnen()
        if not fenster then
            local G = { .85, .65, .15 }
            local f = CreateFrame("Frame", "siikkSpracheFenster", UIParent, "BackdropTemplate"); fenster = f
            f:SetSize(300, 262); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG"); f:EnableMouse(true); f:SetMovable(true)
            f:RegisterForDrag("LeftButton"); f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
            f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
            f:SetBackdropColor(.03, .02, .05, .96); f:SetBackdropBorderColor(G[1], G[2], G[3], 1)
            tinsert(UISpecialFrames, "siikkSpracheFenster")
            local k = f:CreateTexture(nil, "BORDER"); k:SetPoint("TOPLEFT", 4, -4); k:SetPoint("TOPRIGHT", -4, -4); k:SetHeight(28); k:SetColorTexture(.315, .19, .45, .8)
            local t = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); t:SetPoint("LEFT", k, "LEFT", 10, 0)
            t:SetFont(CYR, 15, ""); t:SetText("|cffe03030siikk|r · Sprache / Language")
            local zu = CreateFrame("Button", nil, f, "UIPanelCloseButton"); zu:SetPoint("TOPRIGHT", 0, 0)
            f.knoepfe = {}
            for i, c in ipairs(SPRACHEN) do
                local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); b:SetSize(240, 28); b:SetPoint("TOP", 0, -40 - (i - 1) * 34)
                local fs = b:GetFontString(); if type(fs) == "table" then fs:SetFont(CYR, 13, "") end
                b:SetText(NAMEN[c]); b.code = c
                b:SetScript("OnClick", function()
                    setzen(c)
                    for _, x in ipairs(f.knoepfe) do x:SetText((x.code == c and "» " or "") .. NAMEN[x.code] .. (x.code == c and " «" or "")) end
                    if StaticPopup_Show then StaticPopup_Show("SIIKK_SPRACHE_NEU") end
                end)
                f.knoepfe[#f.knoepfe + 1] = b
            end
            if StaticPopupDialogs then
                StaticPopupDialogs["SIIKK_SPRACHE_NEU"] = { text = "siikk: Reload UI now to change the language? / Jetzt neu laden?", button1 = "Reload", button2 = "×",
                    OnAccept = function() ReloadUI() end, timeout = 0, whileDead = true, hideOnEscape = true }
            end
        end
        local c = siikkSprache()
        for _, x in ipairs(fenster.knoepfe) do x:SetText((x.code == c and "» " or "") .. NAMEN[x.code] .. (x.code == c and " «" or "")) end
        fenster:Show()
    end
    SiikkSpracheOeffnen = oeffnen
    SLASH_SIIKKSPRACHE1 = "/sprache"; SLASH_SIIKKSPRACHE2 = "/language"; SLASH_SIIKKSPRACHE3 = "/siikklang"
    SlashCmdList.SIIKKSPRACHE = function(m)
        m = (m or ""):lower():gsub("%s+", "")
        if NAMEN[m] then setzen(m); print("|cffe03030siikk|r: " .. NAMEN[m] .. " – /reload"); return end
        oeffnen()
    end
end
