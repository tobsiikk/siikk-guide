-- Use /dump UnitGUID("player") to get the GUID of your character.
-- The first 4 digits represent the server ID, the next 4 digits represent the character ID.

-- This file does not use the module system, so it names its own load-timing interval.
QuestieLoader:StampLoadBoundary()

---@class DeveloperCharacters
Questie.devChars = {
    ["4440"] = {"064FC13C", "064FC234", "064FC0EE"},
    ["4454"] = {"060A0278", "06094BCA", "0609F5FC", "060949E1", "0609AF76", "061564F4"},
    ["5066"] = {"033C8B94"},
    ["5149"] = {"04564413","04987F43"},
    ["6064"] = {"02FA1F22", "03430D5D", "02F7D6DD"},
    ["6409"] = {"04ACFA0C", "030B1A50", "04E0A897", "05400FB9"},
    ["6412"] = {"03134700"},
    ["5813"] = {"0603B3F7", "0604F467", "01302E30", "0285411C", "01D427FD", "0606F7BC"},
    ["5126"] = {"025AD3E3"},
}
