---@type QuestieCompat
local QuestieCompat = QuestieLoader:ImportModule("QuestieCompat")

---@class TrackerHeaderFrame
local TrackerHeaderFrame = QuestieLoader:CreateModule("TrackerHeaderFrame")
-------------------------
--Import QuestieTracker modules.
-------------------------
---@type TrackerBaseFrame
local TrackerBaseFrame = QuestieLoader:ImportModule("TrackerBaseFrame")
---@type TrackerFadeTicker
local TrackerFadeTicker = QuestieLoader:ImportModule("TrackerFadeTicker")
---@type TrackerUtils
local TrackerUtils = QuestieLoader:ImportModule("TrackerUtils")
-------------------------
--Import Questie modules.
-------------------------
---@type QuestieLib
local QuestieLib = QuestieLoader:ImportModule("QuestieLib")
---@type QuestieOptions
local QuestieOptions = QuestieLoader:ImportModule("QuestieOptions")
---@type QuestieJourney
local QuestieJourney = QuestieLoader:ImportModule("QuestieJourney")
---@type QuestLogCache
local QuestLogCache = QuestieLoader:ImportModule("QuestLogCache")
---@type QuestieCombatQueue
local QuestieCombatQueue = QuestieLoader:ImportModule("QuestieCombatQueue")
---@type l10n
local l10n = QuestieLoader:ImportModule("l10n")
---@type QuestieOptionsEngine
local QuestieOptionsEngine = QuestieLoader:ImportModule("QuestieOptionsEngine")

local LSM30 = LibStub("LibSharedMedia-3.0")
local IsAddOnLoaded = QuestieCompat.IsAddOnLoaded

local headerFrame, trackerBaseFrame

function TrackerHeaderFrame.Initialize(baseFrame, OnTrackedQuestClick)
    trackerBaseFrame = baseFrame
    headerFrame = CreateFrame("Button", "Questie_HeaderFrame", trackerBaseFrame)
    -- siikk-Design: lila Kopfbalken mit goldener Linie darunter
    headerFrame.siikkBg = headerFrame:CreateTexture(nil, "BACKGROUND", nil, -1)
    headerFrame.siikkBg:SetPoint("TOP", headerFrame, "TOP", 0, 3); headerFrame.siikkBg:SetPoint("BOTTOM", headerFrame, "BOTTOM", 0, -2)
    headerFrame.siikkBg:SetPoint("LEFT", trackerBaseFrame, "LEFT", 3, 0); headerFrame.siikkBg:SetPoint("RIGHT", trackerBaseFrame, "RIGHT", -3, 0)
    headerFrame.siikkBg:SetColorTexture(0.70 * 0.45, 0.42 * 0.45, 1 * 0.45, 0.8)
    headerFrame.siikkLine = headerFrame:CreateTexture(nil, "BORDER")
    headerFrame.siikkLine:SetPoint("BOTTOMLEFT", headerFrame.siikkBg, "BOTTOMLEFT", 0, 0); headerFrame.siikkLine:SetPoint("BOTTOMRIGHT", headerFrame.siikkBg, "BOTTOMRIGHT", 0, 0)
    headerFrame.siikkLine:SetHeight(1); headerFrame.siikkLine:SetColorTexture(0.85, 0.65, 0.15, 1)

    TrackerHeaderFrame.PositionTrackerHeaderFrame()

    -- Questie Icon Settings
    local questieIcon = CreateFrame("Button", nil, trackerBaseFrame)
    questieIcon:SetPoint("TOPLEFT", headerFrame, "TOPLEFT", 0, 0)
    questieIcon:SetAlpha(1)

    -- Questie Icon Texture Settings
    questieIcon.texture = questieIcon:CreateTexture(nil, "BACKGROUND", nil, 0)
    questieIcon.texture:SetTexture("Interface\\AddOns\\siikk-Questhilfe\\Icons\\siikk_einstellungen")
    questieIcon.texture:SetPoint("CENTER", 0, 0)

    questieIcon:EnableMouse(true)
    questieIcon:RegisterForDrag("LeftButton")
    questieIcon:RegisterForClicks("LeftButtonUp", "RightButtonUp")

    questieIcon:SetScript("OnClick", function(_, button)
        if button == "LeftButton" then
            if QuestieJourney:IsShown() then
                QuestieJourney:ToggleJourneyWindow()
            end
            QuestieOptionsEngine:ToggleConfigWindow()

            return
        elseif button == "RightButton" then
            if QuestieConfigFrame:IsShown() then
                QuestieConfigFrame:Hide()
            end

            if QuestieOptionsEngine:IsShown() then
                QuestieOptionsEngine:ToggleConfigWindow()
            end
            QuestieJourney:ToggleJourneyWindow()

            return
        end
    end)

    questieIcon:SetScript("OnEnter", function(self)
        if InCombatLockdown() then
            if GameTooltip:IsShown() then
                GameTooltip:Hide()
                return
            end
        end
        GameTooltip._owner = self
        GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
        GameTooltip:AddDoubleLine(Questie:Colorize("Questie", "gold"), Questie:Colorize(QuestieLib:GetAddonVersionString(), "gray"))
        GameTooltip:AddLine(" ")
        GameTooltip:AddDoubleLine(Questie:Colorize(l10n("Left Click"), "lightBlue"), Questie:Colorize(l10n("Toggle Options"), "white"))
        GameTooltip:AddDoubleLine(Questie:Colorize(l10n("Right Click"), "lightBlue"), Questie:Colorize(l10n("Toggle My Journey"), "white"))
        GameTooltip:AddLine(" ")
        GameTooltip:AddDoubleLine(
            Questie:Colorize(l10n("Left Click + Hold"), "lightBlue"),
            Questie:Colorize(l10n("Drag while Unlocked"), "white")
        )
        GameTooltip:AddDoubleLine(
            Questie:Colorize(l10n("Ctrl + Left Click + Hold"), "lightBlue"),
            Questie:Colorize(l10n("Drag while Locked"), "white")
        )

        if IsAddOnLoaded("TomTom") then
            GameTooltip:AddLine(" ")
            GameTooltip:AddLine(Questie:Colorize(l10n("Questie Tracker Integrations"), "gold"))
            GameTooltip:AddLine(" ")
            GameTooltip:AddDoubleLine(
                Questie:Colorize(l10n("TomTom"), "lightBlue"),
                Questie:Colorize(l10n("Ctrl + Left Click or Right Click a Quest Title"), "white")
            )
        end

        GameTooltip:Show()

        TrackerFadeTicker.Unfade(self)
    end)

    questieIcon:SetScript("OnLeave", function(self)
        if GameTooltip:IsShown() then
            GameTooltip:Hide()
        end

        TrackerFadeTicker.Fade(self)
    end)

    questieIcon:SetScript("OnDragStart", TrackerBaseFrame.OnDragStart)
    questieIcon:SetScript("OnDragStop", TrackerBaseFrame.OnDragStop)

    questieIcon:Hide()
    headerFrame.questieIcon = questieIcon

    -- Questie Tracked Quests Settings
    local trackedQuests = CreateFrame("Button", nil, trackerBaseFrame)
    trackedQuests:SetPoint("TOPLEFT", questieIcon, "TOPLEFT", 10, 0)

    -- Questie Tracked Quests Label
    trackedQuests.label = headerFrame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    trackedQuests.label:SetPoint("TOPLEFT", headerFrame, "TOPLEFT", 0, 0)

    trackedQuests.SetMode = function(self, mode)
        if mode ~= self.mode then
            self.mode = mode
        end
    end

    if Questie.db.char.isTrackerExpanded then
        trackedQuests:SetMode(1)
    else
        trackedQuests:SetMode(0)
    end

    trackedQuests:EnableMouse(true)
    trackedQuests:RegisterForDrag("LeftButton")
    trackedQuests:RegisterForClicks("RightButtonUp", "LeftButtonUp")

    trackedQuests:SetScript("OnClick", function(self)
        if InCombatLockdown() then
            return
        end

        if self.mode == 1 then
            Questie.Debug(Questie.DEBUG_DEVELOP, "[TrackerHeaderFrame:OnClick] - Tracker Minimized")

            self:SetMode(0)
            Questie.db.char.isTrackerExpanded = false
        else
            Questie.Debug(Questie.DEBUG_DEVELOP, "[TrackerHeaderFrame:OnClick] - Tracker Maximized")

            self:SetMode(1)
            Questie.db.char.isTrackerExpanded = true
        end

        QuestieCombatQueue:Queue(function()
            OnTrackedQuestClick()
        end)
    end)

    trackedQuests:SetScript("OnDragStart", TrackerBaseFrame.OnDragStart)
    trackedQuests:SetScript("OnDragStop", TrackerBaseFrame.OnDragStop)
    trackedQuests:SetScript("OnEnter", TrackerFadeTicker.Unfade)
    trackedQuests:SetScript("OnLeave", TrackerFadeTicker.Fade)

    trackedQuests:Hide()

    headerFrame.trackedQuests = trackedQuests

    if Questie.db.profile.trackerHeaderEnabled or (not TrackerUtils.HasQuest()) then
        headerFrame:SetSize(1, Questie.db.profile.trackerFontSizeHeader) -- Width is updated later on
    else
        headerFrame:SetSize(1, 1)
    end

    headerFrame:SetFrameLevel(0)

    headerFrame:Hide()

    TrackerHeaderFrame.headerFrame = headerFrame

    return headerFrame
end

function TrackerHeaderFrame:Update()
    local trackerFontSizeHeader = Questie.db.profile.trackerFontSizeHeader
    local trackerFontSizeZone = Questie.db.profile.trackerFontSizeZone

    if Questie.db.profile.trackerHeaderEnabled or (not TrackerUtils.HasQuest()) then
        headerFrame:ClearAllPoints()
        -- siikk: Einstellungs-Zahnrad oben rechts im Fenster
        local zs = trackerFontSizeHeader + 6
        headerFrame.questieIcon.texture:SetWidth(zs)
        headerFrame.questieIcon.texture:SetHeight(zs)

        headerFrame.questieIcon:ClearAllPoints()
        headerFrame.questieIcon:SetWidth(zs)
        headerFrame.questieIcon:SetHeight(zs)
        headerFrame.questieIcon:SetAlpha(1)
        headerFrame.questieIcon:SetFrameLevel(headerFrame:GetFrameLevel() + 5)
        headerFrame.questieIcon:Show()

        headerFrame.trackedQuests.label:SetFont(LSM30:Fetch("font", Questie.db.profile.trackerFontHeader), trackerFontSizeHeader, Questie.db.profile.trackerFontOutline)

        local maxQuestAmount = "/" .. C_QuestLog.GetMaxNumQuestsCanAccept()

        if Questie.db.char.isTrackerExpanded then
            local activeQuests = QuestLogCache.GetQuestCount()
            headerFrame.trackedQuests.label:SetText("|cffe03030siikk|r-|cffb266ffQuesthilfe|r" .. l10n(": ") .. "|cffffd100" .. tostring(activeQuests) .. maxQuestAmount .. "|r")
        else
            headerFrame.trackedQuests.label:SetText("|cffe03030siikk|r-|cffb266ffQuesthilfe|r" .. " +")
        end

        headerFrame.trackedQuests.label:ClearAllPoints()
        headerFrame.trackedQuests.label:SetPoint("TOPLEFT", headerFrame, "TOPLEFT", 8, 0)
        headerFrame.trackedQuests:SetWidth(headerFrame.trackedQuests.label:GetUnboundedStringWidth())
        headerFrame.trackedQuests:SetHeight(trackerFontSizeHeader)
        headerFrame.trackedQuests:ClearAllPoints()
        headerFrame.trackedQuests:SetPoint("TOPLEFT", headerFrame, "TOPLEFT", 8, 0)
        headerFrame.trackedQuests:Show()

        headerFrame:SetWidth(headerFrame.trackedQuests.label:GetUnboundedStringWidth() + trackerFontSizeHeader)
        headerFrame:SetHeight(trackerFontSizeHeader + 5)
        headerFrame:Show()

        TrackerHeaderFrame.PositionTrackerHeaderFrame(headerFrame, trackerBaseFrame)
        do
            local pt = headerFrame:GetPoint(1)
            if type(pt) == "string" and pt:find("^BOTTOM") then
                headerFrame.questieIcon:SetPoint("BOTTOMRIGHT", trackerBaseFrame, "BOTTOMRIGHT", -6, 2)
            else
                headerFrame.questieIcon:SetPoint("TOPRIGHT", trackerBaseFrame, "TOPRIGHT", -6, -7)
            end
        end

        QuestieCompat.SetResizeBounds(trackerBaseFrame, headerFrame.trackedQuests.label:GetUnboundedStringWidth() + zs + 16, trackerFontSizeHeader)
    else
        headerFrame:Hide()

        headerFrame.questieIcon.texture:SetWidth(trackerFontSizeZone)
        headerFrame.questieIcon.texture:SetHeight(trackerFontSizeZone)

        headerFrame.questieIcon:ClearAllPoints()
        headerFrame.questieIcon:SetWidth(trackerFontSizeZone)
        headerFrame.questieIcon:SetHeight(trackerFontSizeZone)
        headerFrame.questieIcon:SetAlpha(0)

        if Questie.db.profile.moveHeaderToBottom then
            headerFrame.questieIcon:SetPoint("BOTTOMRIGHT", trackerBaseFrame, "BOTTOMRIGHT", -4, 8)
        else
            headerFrame.questieIcon:SetPoint("TOPRIGHT", trackerBaseFrame, "TOPRIGHT", -4, -8)
        end

        headerFrame.questieIcon:Show()

        headerFrame.trackedQuests:Hide()
    end
end

function TrackerHeaderFrame.PositionTrackerHeaderFrame()
    if Questie.db.profile.moveHeaderToBottom then
        -- Move tracker header to the bottom
        headerFrame:SetPoint("BOTTOMLEFT", trackerBaseFrame, "BOTTOMLEFT", 0, 5)
    else
        if Questie.db.char.isTrackerExpanded then
            -- Move tracker header to the top
            headerFrame:SetPoint("TOPLEFT", trackerBaseFrame, "TOPLEFT", 0, -10)
        else
            -- Tracker minimized. Move tracker header to the bottom
            headerFrame:SetPoint("BOTTOMLEFT", trackerBaseFrame, "BOTTOMLEFT", 0, 5)
        end
    end
end
