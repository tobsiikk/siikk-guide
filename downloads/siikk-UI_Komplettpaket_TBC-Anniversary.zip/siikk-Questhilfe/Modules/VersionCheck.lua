-- This file does not use the module system, so it names its own load-timing interval.
QuestieLoader:StampLoadBoundary()

local addonName, _ = ...

-- Check addon is not renamed to avoid conflicts in global name space.
-- siikk-Questhilfe: Fork von Questie (GPLv3). Läuft nicht zusammen mit dem Original-Questie.
do
    local qOn = false
    local ok, st = pcall(C_AddOns and C_AddOns.GetAddOnEnableState or GetAddOnEnableState, "Questie", UnitName("player"))
    if ok and type(st) == "number" and st > 0 then qOn = true end
    if not ok then ok, st = pcall(GetAddOnEnableState, UnitName("player"), "Questie"); if ok and type(st) == "number" and st > 0 then qOn = true end end
    if qOn and addonName == "siikk-Questhilfe" then
        C_Timer.After(5, function()
            DEFAULT_CHAT_FRAME:AddMessage("|cffe03030siikk|r-|cffb266ffQuesthilfe|r: Das Original-Addon |cffffd100Questie|r ist auch aktiv. Bitte nur eines von beiden benutzen – siikk-Questhilfe ist für diese Sitzung aus.")
        end)
        return
    end
end
if addonName ~= "siikk-Questhilfe" then
    local msg = {"You have renamed siikk-Questhilfe addon.", "This is restricted to avoid issues.", "Please remove '" .. addonName .. "'",
        "and reinstall the original version."}
    StaticPopupDialogs["QUESTIE_ADDON_NAME_ERROR"] = {
        text = "|cffff0000ERROR|r\n" .. msg[1] .. "\n" .. msg[2] .. "\n\n" .. msg[3] .. "\n" .. msg[4],
        button2 = "OK",
        hasEditBox = false,
        whileDead = true,
    }

    C_Timer.After(4, function()
        DEFAULT_CHAT_FRAME:AddMessage("---------------------------------")
        DEFAULT_CHAT_FRAME:AddMessage("|cffff0000ERROR|r: |cff42f5ad" .. msg[1] .. "|r")
        DEFAULT_CHAT_FRAME:AddMessage("|cffff0000ERROR|r: |cff42f5ad" .. msg[2] .. "|r")
        DEFAULT_CHAT_FRAME:AddMessage("|cffff0000ERROR|r: |cff42f5ad" .. msg[3] .. "|r")
        DEFAULT_CHAT_FRAME:AddMessage("|cffff0000ERROR|r: |cff42f5ad" .. msg[4] .. "|r")
        DEFAULT_CHAT_FRAME:AddMessage("---------------------------------")
        error("ERROR: " .. msg[1] .. " " .. msg[2] .. " " .. msg[3])
    end)
    StaticPopup_Show("QUESTIE_ADDON_NAME_ERROR")
    return
end

if Questie then
    C_Timer.After(4, function()
        error("ERROR!! -> siikk-Questhilfe already loaded! Please only have one siikk-Questhilfe installed!")
        for _ = 1, 10 do
            DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000ERROR!!|r -> siikk-Questhilfe already loaded! Please only have one siikk-Questhilfe installed!")
        end
    end);
    error("ERROR!! -> siikk-Questhilfe already loaded! Please only have one siikk-Questhilfe installed!")
    DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000ERROR!!|r -> siikk-Questhilfe already loaded! Please only have one siikk-Questhilfe installed!")
    Questie = {}
    return
end

--Initialized below
---@class Questie : AceAddon, AceConsole-3.0, AceEvent-3.0, AceTimer-3.0, AceComm-3.0, AceBucket-3.0
Questie = LibStub("AceAddon-3.0"):NewAddon("siikk-Questhilfe", "AceConsole-3.0", "AceEvent-3.0", "AceTimer-3.0", "AceComm-3.0", "AceBucket-3.0")

Questie.API = {
    isReady = false,
}

-- preinit placeholder to stop tukui crashing from literally force-removing one of our features no matter what users select in the config ui
Questie.db = {profile = {minimap = {hide = false}}}

-- prevent multiple warnings for the same ID, not sure the best place to put this
Questie._sessionWarnings = {}

-- Forever shares Retail's project ID, but uses Classic content. Detect it by interface version instead.
local interfaceVersion = select(4, GetBuildInfo())
---@type boolean
Questie.IsForever = interfaceVersion >= 16000 and interfaceVersion < 17000

--- Addon is running on Classic MoP client
---@type boolean
Questie.IsMoP = WOW_PROJECT_ID == WOW_PROJECT_MISTS_CLASSIC

--- Addon is running on Classic Cata client
---@type boolean
Questie.IsCata = WOW_PROJECT_ID == WOW_PROJECT_CATACLYSM_CLASSIC

--- Addon is running on Classic Wotlk client
---@type boolean
Questie.IsWotlk = WOW_PROJECT_ID == WOW_PROJECT_WRATH_CLASSIC

--- Addon is running on Classic TBC client
---@type boolean
Questie.IsTBC = WOW_PROJECT_ID == WOW_PROJECT_BURNING_CRUSADE_CLASSIC

--- Uses Classic content: Era, its seasons, or Forever. API availability must be checked separately.
---@type boolean
Questie.IsClassic = Questie.IsForever or WOW_PROJECT_ID == WOW_PROJECT_CLASSIC

--- Addon is running on Classic "Vanilla" client and on Era realm (non-seasonal)
---@type boolean
Questie.IsEra = Questie.IsClassic and (not C_Seasons.HasActiveSeason())

-- See https://warcraft.wiki.gg/wiki/API_C_Seasons.GetActiveSeason

--- Addon is running on Classic "Vanilla" client and on Season of Mastery realm specifically
---@type boolean
Questie.IsSoM = Questie.IsClassic and C_Seasons.HasActiveSeason() and (C_Seasons.GetActiveSeason() == Enum.SeasonID.SeasonOfMastery)

--- Addon is running on Classic "Vanilla" client and on Season of Discovery realm specifically
---@type boolean
Questie.IsSoD = Questie.IsClassic and C_Seasons.HasActiveSeason() and (C_Seasons.GetActiveSeason() == Enum.SeasonID.SeasonOfDiscovery)

--- Addon is running on Classic "WotLK" client and on a Titan Forged realm specifically
---@type boolean
Questie.IsTitanReforged = Questie.IsWotlk and C_Seasons.HasActiveSeason() and (C_Seasons.GetActiveSeason() == 109) -- There is no entry in Enum.SeasonID for this

--- Addon is running on Classic "Vanilla" client and on Classic Anniversary realm ( )
---@type boolean
Questie.IsAnniversaryEra = Questie.IsClassic and C_Seasons.HasActiveSeason() and (C_Seasons.GetActiveSeason() == Enum.SeasonID.Fresh)

--- Addon is running on Classic "Vanilla" client and on Classic Anniversary realm ( )
---@type boolean
Questie.IsAnniversaryTBC = Questie.IsTBC and C_Seasons.HasActiveSeason() and (C_Seasons.GetActiveSeason() == Enum.SeasonID.Fresh)

--- Addon is running on Classic "Vanilla" client and on Classic Anniversary Hardcore realm
---@type boolean
Questie.IsAnniversaryHardcore = Questie.IsClassic and C_Seasons.HasActiveSeason() and (C_Seasons.GetActiveSeason() == Enum.SeasonID.FreshHardcore)

--- Addon is running on a HardCore realm specifically
---@type boolean
Questie.IsHardcore = C_GameRules and C_GameRules.IsHardcoreActive()

--- Addon is running on a Chinese realm
---@type boolean
Questie.IsChinaRegion = GetCurrentRegion() == 5

--- Addon is running on EU realm
---@type boolean
Questie.IsEURegion = GetCurrentRegion() == 3
