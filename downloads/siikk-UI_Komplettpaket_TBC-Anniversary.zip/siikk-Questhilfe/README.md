# siikk-Questhilfe

Quest-Helfer für World of Warcraft Classic, TBC Anniversary und WoW: Forever im siikk-Design.

**siikk-Questhilfe ist ein Fork von [Questie](https://github.com/Questie/Questie).**
Alle Funktionen, die Logik und die Questdaten stammen von Questie und seinen Mitwirkenden
(Aero, Logon, Muehe, TheCrux/BreakBB, Drejjmit, Dyaxler, Cheeq, TechnoHunter, Yttrium und viele mehr).
Geändert wurden nur Name, Logo und Aussehen (Tracker im siikkUI-Stil, goldene Rahmen, eigenes Symbol).

Lizenz: GPLv3 (siehe `LICENSE.md` und `gpl-3.0.md`), wie vom Questie-Team für Forks vorgesehen.
Name und Logo von Questie werden in diesem Fork nicht verwendet.

## Benötigt
- **QuestieDB** (die Questdatenbank des Questie-Teams) als eigener Addon-Ordner.
- Das Original-Addon *Questie* darf nicht gleichzeitig aktiv sein.

## Befehle
- `/qh` oder `/questhilfe` – Einstellungen und Befehle
