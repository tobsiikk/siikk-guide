-- siikk-Auktionshaus · Einführung beim ersten Start (/ah intro)
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local Y = "|cffffd100"
siikkIntro("siikk-Auktionshaus", "|cffe03030siikk|r-|cffffd100Auktionshaus|r", "Interface\\AddOns\\" .. ADDON .. "\\Media\\siikk_ah_icon", {
    { L"Willkommen beim siikk-Auktionshaus",
      L"Dein Helfer fürs Auktionshaus. Öffnest du das Auktionshaus, erscheint das siikk-Fenster " .. Y .. L"rechts daneben|r – mit vier Reitern: Preise, Verkaufen, Kaufen und Übersicht.\n\n" ..
      L"• Oben im Auktionshaus blendet der Knopf " .. Y .. L"siikkAH|r das Fenster ein oder aus.\n\n" ..
      L"• Der Minimap-Knopf (Edelsteine) öffnet es auch ohne Auktionshaus – dann kannst du Preise nachschlagen und deine Übersicht ansehen.\n\n" ..
      L"• Tipp: Starte beim ersten Besuch gleich einen " .. Y .. L"Komplett-Scan|r, dann kennt siikk die Preise." },
    { L"Preise",
      "• " .. Y .. L"Komplett-Scan|r: liest alle Angebote auf einmal. Blizzard erlaubt das nur alle 15 Minuten – ist er gesperrt, startet automatisch der " .. Y .. L"Seiten-Scan|r (langsamer, Seite für Seite).\n\n" ..
      L"• Gespeichert werden " .. Y .. L"Marktwert|r (typischer Preis pro Stück) und " .. Y .. L"günstigstes Angebot|r – für alle deine Charaktere auf diesem Realm.\n\n" ..
      L"• Suchfeld: Gegenstand eintippen, schon siehst du Marktwert, günstigsten Preis und wie alt die Daten sind.\n\n" ..
      "• " .. Y .. L"Tooltip|r: Maus über einen Gegenstand – überall im Spiel stehen niedrigster Preis (Stück und ganzer Stapel), 2. Preis und Marktwert vom letzten Scan dabei.\n\n" ..
      L"• Wer mag, kann den Preis zusätzlich direkt auf die Taschen-Felder legen: " .. Y .. L"/ah taschen|r." },
    { L"Verkaufen",
      L"• Links alle verkaufbaren Gegenstände aus deinen Taschen, die wertvollsten oben.\n\n" ..
      "• " .. Y .. L"Anklicken|r: der Preis steht automatisch 1 Kupfer unter dem günstigsten Angebot. " .. Y .. L"AH prüfen|r holt den aktuellen Preis direkt vom Auktionshaus.\n\n" ..
      L"• Preis pro Stück, " .. Y .. L"Stapelgröße|r, " .. Y .. L"Anzahl Stapel|r (" .. Y .. L"Max|r = alles) und " .. Y .. L"Dauer|r (12 / 24 / 48 Std) wählen – Kaution und Gesamtpreis siehst du sofort.\n\n" ..
      "• " .. Y .. L"Einstellen|r: ein Klick = ein Auftrag (Blizzard erlaubt keinen Automatik-Verkauf)." },
    { L"Kaufen",
      L"• Namen eingeben, " .. Y .. L"Suchen|r – die Angebote stehen sortiert nach Preis pro Stück.\n\n" ..
      L"• Die letzte Spalte vergleicht mit dem Marktwert: " .. L"|cff33ff33grün|r = Schnäppchen (unter 80 %), |cffff6060rot|r = teuer.\n\n" ..
      L"• Angebot anklicken, dann " .. Y .. L"Kaufen|r – siikk prüft vorher, ob das Angebot noch da ist.\n\n" ..
      "• " .. Y .. L"+ Liste|r merkt sich den Suchbegriff in deiner " .. Y .. L"Einkaufsliste|r (bis 8). Klick = suchen, Rechtsklick = entfernen." },
    { L"Übersicht & Befehle",
      "• " .. Y .. L"Übersicht|r: Verkäufe von heute, 7 Tagen, 30 Tagen und gesamt – mit Umsatz und Gewinn nach 5 % Auktionshaus-Gebühr und Kaution. Darunter jeder einzelne Verkauf.\n" ..
      L"  Erkannt werden Verkäufe, während du online bist.\n\n" ..
      Y .. L"/ah|r – Fenster ein/aus\n" .. Y .. L"/ah scan|r – Komplett-Scan\n" .. Y .. L"/ah tooltip|r – Marktwert im Tooltip an/aus\n" .. Y .. L"/ah taschen|r – Preis zusätzlich auf den Taschen-Feldern an/aus\n" .. Y .. L"/ah intro|r – diese Einführung · " .. Y .. L"/ah neu|r – was ist neu\n\n" ..
      L"Minimap-Knopf: " .. Y .. L"Linksklick|r Fenster · " .. Y .. L"Rechtsklick|r Komplett-Scan · " .. Y .. L"Ziehen|r verschiebt den Knopf." },
}, function() return siikkAH_DB end, "/ah intro")
