-- siikkAH · Auktionshaus-Helfer im siikk-Design (Classic / TBC Anniversary / Forever)
-- Kern: Datenbank, Preise scannen, Marktwerte, Tooltip, Verkaufs-Protokoll
local ADDON, NS = ...
local L = siikkL or function(s) return s end
NS.VERSION = "2.0"
-- Altes (Classic-)Auktionshaus mit QueryAuctionItems? Forever nutzt das neue Auktionshaus (C_AuctionHouse) –
-- dort gibt es die alten Funktionen und Ereignisse nicht; siikk scannt dort (noch) nicht.
NS.ALT_AH = type(QueryAuctionItems) == "function" and type(GetAuctionItemInfo) == "function"

local function safe(fn, ...) if type(fn) ~= "function" then return nil end local r = { pcall(fn, ...) }; if r[1] then return select(2, unpack(r)) end end
NS.safe = safe
function NS.msg(t) DEFAULT_CHAT_FRAME:AddMessage(L"|cffe03030siikk|r-|cffffd100Auktionshaus|r: " .. tostring(t)) end
function NS.geld(c)
    c = math.floor((c or 0) + 0.5)
    if GetCoinTextureString then return GetCoinTextureString(c) end
    return string.format("%dg %ds %dc", math.floor(c / 10000), math.floor(c / 100) % 100, c % 100)
end
-- Preisangabe für Listen: ab 1 Gold immer Gold und Silber (Kupfer weggelassen), darunter Silber und Kupfer
local GI, SI, KI = "|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:2:0|t", "|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:2:0|t", "|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:2:0|t"
function NS.geldKurz(c)
    if not c then return "|cff777777–|r" end
    c = math.floor(c + 0.5)
    local g, s, k = math.floor(c / 10000), math.floor(c / 100) % 100, c % 100
    if g > 0 then return g .. GI .. " " .. s .. SI end
    if s > 0 then return s .. SI .. " " .. k .. KI end
    return k .. KI
end
function NS.alterKurz(t)
    if not t then return "–" end
    local s = time() - t
    if s < 3600 then return math.floor(s / 60) .. "m" end
    if s < 86400 then return math.floor(s / 3600) .. "h" end
    return math.floor(s / 86400) .. "T"
end
function NS.alter(t)
    if not t then return "nie" end
    local s = time() - t
    if s < 3600 then return math.floor(s / 60) .. L" Min" end
    if s < 86400 then return math.floor(s / 3600) .. L" Std" end
    return math.floor(s / 86400) .. " Tg"
end

---------------------------------------------------------------------------
-- Datenbank (Preise pro Realm + Fraktion, für alle Charaktere gemeinsam)
---------------------------------------------------------------------------
local function realmKey() return (GetRealmName() or "?") .. "-" .. (UnitFactionGroup("player") or "?") end
function NS.DB()
    siikkAH_DB = siikkAH_DB or {}
    local db = siikkAH_DB
    db.preise = db.preise or {}; db.verkauf = db.verkauf or {}; db.offen = db.offen or {}
    db.liste = db.liste or {}; db.einst = db.einst or {}; db.scanZeit = db.scanZeit or {}; db.namen = db.namen or {}
    local k = realmKey()
    db.preise[k] = db.preise[k] or {}; db.verkauf[k] = db.verkauf[k] or {}; db.offen[k] = db.offen[k] or {}; db.liste[k] = db.liste[k] or {}
    return db, k
end
function NS.Preise() local db, k = NS.DB(); return db.preise[k] end
function NS.Einst() local db = NS.DB(); return db.einst end

-- Marktwert eines Gegenstands (pro Stück): Median des letzten Scans, sonst niedrigster Preis
function NS.Markt(id)
    if not id then return nil end
    local p = NS.Preise()[id]
    if not p then return nil end
    return p.m or p.l, p.l, p.t, p.n
end
function NS.ItemId(link)
    if type(link) == "number" then return link end
    if type(link) ~= "string" then return nil end
    return tonumber(link:match("item:(%d+)"))
end
function NS.Name(id)
    local n = GetItemInfo(id)
    if n then return n end
    local db = NS.DB(); return db.namen[id]
end

---------------------------------------------------------------------------
-- Auswertung einer Liste von Angeboten (aus Komplett-Scan oder Suche)
---------------------------------------------------------------------------
local function median(t)
    table.sort(t); local n = #t
    if n == 0 then return nil end
    -- nur die günstigeren 60 % zählen, damit Wucherpreise den Markt nicht verzerren
    local m = math.max(1, math.floor(n * 0.6))
    local h = math.floor((m + 1) / 2)
    return t[h]
end
function NS.Auswerten(sammlung, ganzerScan)
    local P, db = NS.Preise(), NS.DB()
    local jetzt, anzahl = time(), 0
    for id, preise in pairs(sammlung.preise) do
        local alt = P[id] or {}
        local m = median(preise)
        P[id] = { m = m, l = preise[1], l2 = preise[2], n = #preise, t = jetzt, a = alt.m }
        if sammlung.namen[id] then db.namen[id] = sammlung.namen[id] end
        anzahl = anzahl + 1
    end
    if ganzerScan then local _, k = NS.DB(); db.scanZeit[k] = jetzt end
    if NS.TaschenNeu then pcall(NS.TaschenNeu) end
    return anzahl
end
local function neueSammlung() return { preise = {}, namen = {} } end
NS.neueSammlung = neueSammlung
function NS.Aufnehmen(sammlung, i)
    local name, _, count, _, _, _, _, _, _, buyout, _, _, _, owner, _, _, itemId = GetAuctionItemInfo("list", i)
    if not itemId or not buyout or buyout <= 0 then return end
    count = (count and count > 0) and count or 1
    local t = sammlung.preise[itemId]
    if not t then t = {}; sammlung.preise[itemId] = t end
    t[#t + 1] = buyout / count
    if name and name ~= "" then sammlung.namen[itemId] = name end
end

---------------------------------------------------------------------------
-- Scans
---------------------------------------------------------------------------
local scan = { aktiv = false }
NS.scan = scan
local ev = CreateFrame("Frame")
NS.ev = ev

function NS.KannKomplett()
    local _, all = CanSendAuctionQuery()
    return all and true or false
end
function NS.ScanStatus()
    if scan.aktiv then
        if scan.art == "komplett" then return L"Komplett-Scan läuft … " .. (scan.i or 0) .. " / " .. (scan.gesamt or "?") end
        return L"Seiten-Scan läuft … Seite " .. ((scan.seite or 0) + 1) .. " / " .. (scan.seiten or "?")
    end
    local db, k = NS.DB()
    local n = 0; for _ in pairs(NS.Preise()) do n = n + 1 end
    return L"Letzter Scan: vor " .. NS.alter(db.scanZeit[k]) .. " · " .. n .. L" Gegenstände bekannt"
end

-- Komplett-Scan (alle Angebote auf einmal, laut Blizzard nur alle 15 Minuten möglich)
function NS.KomplettScan()
    if scan.aktiv then return end
    if not (AuctionFrame and AuctionFrame:IsShown()) then NS.msg(L"Bitte zuerst das Auktionshaus öffnen.") return end
    if not NS.KannKomplett() then
        NS.msg(L"Komplett-Scan ist gerade gesperrt (Blizzard erlaubt ihn nur alle 15 Minuten). Ich starte den Seiten-Scan.")
        return NS.SeitenScan()
    end
    scan.aktiv, scan.art, scan.sammlung, scan.i, scan.gesamt, scan.warte = true, "komplett", neueSammlung(), 0, nil, true
    NS.kaufSuche = false
    QueryAuctionItems("", nil, nil, 0, false, nil, true, false, nil)
    NS.msg(L"Komplett-Scan gestartet – das Spiel kann kurz stocken.")
    if NS.UIUpdate then NS.UIUpdate() end
end
-- Seiten-Scan (jede Seite einzeln, langsamer, aber immer möglich)
function NS.SeitenScan()
    if scan.aktiv then return end
    if not (AuctionFrame and AuctionFrame:IsShown()) then NS.msg(L"Bitte zuerst das Auktionshaus öffnen.") return end
    scan.aktiv, scan.art, scan.sammlung, scan.seite, scan.seiten, scan.warte = true, "seiten", neueSammlung(), 0, nil, false
    scan.naechste = 0
    if NS.UIUpdate then NS.UIUpdate() end
end
function NS.ScanAbbrechen()
    if not scan.aktiv then return end
    local n = NS.Auswerten(scan.sammlung, false)
    scan.aktiv = false
    NS.msg(L"Scan abgebrochen – " .. n .. L" Gegenstände wurden trotzdem gespeichert.")
    if NS.UIUpdate then NS.UIUpdate() end
end

ev:SetScript("OnUpdate", function(_, el)
    if not scan.aktiv then return end
    if not (AuctionFrame and AuctionFrame:IsShown()) then NS.ScanAbbrechen() return end
    if scan.art == "komplett" then
        if scan.warte or not scan.gesamt then return end
        -- in Häppchen auswerten, damit das Spiel nicht einfriert
        local bis = math.min(scan.gesamt, scan.i + 400)
        for i = scan.i + 1, bis do NS.Aufnehmen(scan.sammlung, i) end
        scan.i = bis
        if scan.i >= scan.gesamt then
            local n = NS.Auswerten(scan.sammlung, true)
            scan.aktiv = false
            NS.msg(L"Komplett-Scan fertig: " .. scan.gesamt .. L" Angebote, " .. n .. L" verschiedene Gegenstände.")
        end
        if NS.UIUpdate then NS.UIUpdate() end
    else
        if scan.warte then return end
        scan.naechste = (scan.naechste or 0) - el
        if scan.naechste > 0 then return end
        if not CanSendAuctionQuery() then return end
        scan.warte = true
        QueryAuctionItems("", nil, nil, scan.seite, false, nil, false, false, nil)
    end
end)

-- Nur Ereignisse anmelden, die es im Spiel gibt (Forever kennt z. B. AUCTION_ITEM_LIST_UPDATE nicht)
local function anmelden(e)
    if C_EventUtils and C_EventUtils.IsEventValid and not C_EventUtils.IsEventValid(e) then return end
    pcall(ev.RegisterEvent, ev, e)
end
anmelden("ADDON_LOADED"); anmelden("CHAT_MSG_SYSTEM"); anmelden("AUCTION_HOUSE_SHOW"); anmelden("AUCTION_HOUSE_CLOSED")
if NS.ALT_AH then anmelden("AUCTION_ITEM_LIST_UPDATE"); anmelden("AUCTION_OWNED_LIST_UPDATE") end

-- Systemmeldungen „verkauft“ / „abgelaufen“ als Suchmuster
local function muster(fmt)
    if type(fmt) ~= "string" then return nil end
    return "^" .. fmt:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1"):gsub("%%%%s", "(.+)") .. "$"
end

ev:SetScript("OnEvent", function(_, event, a1)
    if event == "ADDON_LOADED" and a1 == ADDON then
        NS.DB()
        if NS.TooltipInit then NS.TooltipInit() end
    elseif event == "AUCTION_ITEM_LIST_UPDATE" then
        if scan.aktiv and scan.art == "komplett" and scan.warte then
            local _, total = GetNumAuctionItems("list")
            if total and total > 0 then scan.gesamt = GetNumAuctionItems("list"); scan.warte = false end
        elseif scan.aktiv and scan.art == "seiten" and scan.warte then
            local n, total = GetNumAuctionItems("list")
            for i = 1, n do NS.Aufnehmen(scan.sammlung, i) end
            scan.seiten = math.max(1, math.ceil((total or 0) / 50))
            scan.seite = scan.seite + 1
            scan.warte = false; scan.naechste = 0.3
            if scan.seite >= scan.seiten or n == 0 then
                local cnt = NS.Auswerten(scan.sammlung, true)
                scan.aktiv = false
                NS.msg(L"Seiten-Scan fertig: " .. cnt .. L" verschiedene Gegenstände.")
            end
            if NS.UIUpdate then NS.UIUpdate() end
        end
        if NS.OnListe then NS.OnListe() end
    elseif event == "AUCTION_OWNED_LIST_UPDATE" then
        if NS.OnEigene then NS.OnEigene() end
    elseif event == "AUCTION_HOUSE_SHOW" then
        if not NS.ALT_AH then
            if not NS.hinweisNeuesAH then NS.hinweisNeuesAH = true
                NS.msg(L"Forever nutzt das neue Auktionshaus – Preise scannen und das siikk-Fenster gibt es dort noch nicht. Das Verkaufs-Protokoll läuft weiter.") end
            return
        end
        if NS.OnAHShow then NS.OnAHShow() end
    elseif event == "AUCTION_HOUSE_CLOSED" then
        if scan.aktiv then NS.ScanAbbrechen() end
    elseif event == "CHAT_MSG_SYSTEM" and type(a1) == "string" then
        local verkauft = muster(ERR_AUCTION_SOLD_S); local abgelaufen = muster(ERR_AUCTION_EXPIRED_S)
        local name = verkauft and a1:match(verkauft)
        if name then NS.Verkauft(name) return end
        name = abgelaufen and a1:match(abgelaufen)
        if name then NS.Abgelaufen(name) end
    end
end)

---------------------------------------------------------------------------
-- Verkaufs-Protokoll
---------------------------------------------------------------------------
function NS.Eingestellt(name, id, stueck, preis, kaution, stapel)
    local db, k = NS.DB()
    local o = db.offen[k]
    for _ = 1, (stapel or 1) do
        o[#o + 1] = { name = name, id = id, n = stueck, p = preis, k = (kaution or 0) / math.max(1, stapel or 1), t = time() }
    end
end
local function entnehmen(name)
    local db, k = NS.DB()
    local o = db.offen[k]
    for i, e in ipairs(o) do if e.name == name then return table.remove(o, i) end end
end
function NS.Verkauft(name)
    local db, k = NS.DB()
    local e = entnehmen(name) or { name = name, n = 1, p = 0, k = 0 }
    local erl = math.floor((e.p or 0) * 0.95)
    table.insert(db.verkauf[k], 1, { t = time(), name = name, id = e.id, n = e.n, p = e.p, g = erl - (e.k or 0), art = "verkauft" })
    while #db.verkauf[k] > 500 do table.remove(db.verkauf[k]) end
    NS.msg(L"|cff33ff33Verkauft:|r " .. name .. ((e.p or 0) > 0 and (L" für " .. NS.geld(e.p)) or ""))
    if NS.UIUpdate then NS.UIUpdate() end
end
function NS.Abgelaufen(name)
    local db, k = NS.DB()
    local e = entnehmen(name) or { name = name, n = 1, p = 0, k = 0 }
    table.insert(db.verkauf[k], 1, { t = time(), name = name, id = e.id, n = e.n, p = 0, g = -(e.k or 0), art = "abgelaufen" })
    if NS.UIUpdate then NS.UIUpdate() end
end
function NS.Bilanz(tage)
    local db, k = NS.DB()
    local grenze = tage and (time() - tage * 86400) or 0
    local umsatz, gewinn, anzahl = 0, 0, 0
    for _, v in ipairs(db.verkauf[k]) do
        if v.t >= grenze then
            if v.art == "verkauft" then umsatz = umsatz + (v.p or 0); anzahl = anzahl + 1 end
            gewinn = gewinn + (v.g or 0)
        end
    end
    return umsatz, gewinn, anzahl
end

---------------------------------------------------------------------------
-- Tooltip: Marktwert anzeigen
---------------------------------------------------------------------------
-- Stapelgröße, wenn der Tooltip zu einem Taschenfeld gehört (Blizzard-Taschen oder siikk-Taschenfenster)
local function taschenAnzahl(tt, id)
    local o = tt.GetOwner and tt:GetOwner()
    if type(o) ~= "table" or not o.GetID then return 1 end
    local bag, slot = o.bag, o.slot
    if not bag then local par = o.GetParent and o:GetParent(); bag = par and par.GetID and par:GetID() end
    slot = slot or o:GetID()
    if type(bag) ~= "number" or type(slot) ~= "number" or slot < 1 then return 1 end
    local cid, cnt
    if C_Container and C_Container.GetContainerItemInfo then
        local t = C_Container.GetContainerItemInfo(bag, slot); if t then cid, cnt = t.itemID, t.stackCount end
    elseif GetContainerItemInfo then
        local _, c, _, _, _, _, l = GetContainerItemInfo(bag, slot); cnt = c; cid = l and tonumber(l:match("item:(%d+)"))
    end
    if cid == id and type(cnt) == "number" and cnt > 1 then return cnt end
    return 1
end
local function tipZeilen(tt, link)
    local e = NS.Einst()
    if e.tooltip == false then return end
    local id = NS.ItemId(link)
    if not id or tt.siikkAHid == id then return end
    tt.siikkAHid = id
    local p = NS.Preise()[id]
    tt:AddLine(" ")
    tt:AddLine(L"|cffe03030siikk|r-|cffffd100Auktionshaus|r", 1, 1, 1)
    if not p or not p.l then
        tt:AddLine(L"   Noch kein Preis – beim nächsten Scan im Auktionshaus", 0.6, 0.6, 0.6)
        tt:Show(); return
    end
    local ok, n = pcall(taschenAnzahl, tt, id); if not ok or type(n) ~= "number" then n = 1 end
    tt:AddDoubleLine(L"   Niedrigster Preis (Stück)", NS.geld(p.l), 1, 0.82, 0, 1, 1, 1)
    if n > 1 then tt:AddDoubleLine(L"   Niedrigster Preis (Stapel × " .. n .. ")", NS.geld(p.l * n), 1, 0.82, 0, 1, 1, 1) end
    if p.l2 then tt:AddDoubleLine(L"   2. Preis (Stück)", NS.geld(p.l2), 0.8, 0.8, 0.8, 1, 1, 1) end
    if p.m and math.floor(p.m) ~= math.floor(p.l) then tt:AddDoubleLine(L"   Marktwert (Stück)", NS.geld(p.m), 0.8, 0.8, 0.8, 1, 1, 1) end
    tt:AddDoubleLine("   " .. (p.n or "?") .. L" Angebote", L"Scan vor " .. NS.alter(p.t), 0.55, 0.55, 0.55, 0.55, 0.55, 0.55)
    tt:Show()
end
function NS.TooltipInit()
    if NS.tipAn then return end
    NS.tipAn = true
    for _, tt in ipairs({ GameTooltip, ItemRefTooltip }) do
        if tt and tt.HookScript then
            pcall(tt.HookScript, tt, "OnTooltipCleared", function(s) s.siikkAHid = nil end)
            -- beide Wege (alter und neuer Tooltip-Mechanismus); doppelte Zeilen verhindert siikkAHid
            pcall(tt.HookScript, tt, "OnTooltipSetItem", function(s) local _, link = s:GetItem(); if link then tipZeilen(s, link) end end)
        end
    end
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tt)
            if tt and tt.GetItem then local _, link = tt:GetItem(); if link then tipZeilen(tt, link) end end
        end)
    end
end

-- Befehle
SLASH_SIIKKAH1, SLASH_SIIKKAH2 = "/ah", "/siikkah"
SlashCmdList.SIIKKAH = function(arg)
    arg = (arg or ""):lower()
    if arg == "neu" or arg == "neuigkeiten" then if SiikkNeuAPI and SiikkNeuAPI["siikk-Auktionshaus"] then SiikkNeuAPI["siikk-Auktionshaus"]() end
    elseif arg == "intro" or arg == "info" then if SiikkIntroAPI and SiikkIntroAPI["siikk-Auktionshaus"] then SiikkIntroAPI["siikk-Auktionshaus"]() end
    elseif not NS.ALT_AH and (arg == "scan" or arg == "") then
        NS.msg(L"Forever nutzt das neue Auktionshaus – Preise scannen und das siikk-Fenster gibt es dort noch nicht. Das Verkaufs-Protokoll läuft weiter.")
    elseif arg == "scan" then NS.KomplettScan()
    elseif arg == "taschen" or arg == "preise" then local e = NS.Einst(); e.taschen = not (e.taschen == true); NS.msg(L"Auktionspreise direkt auf den Taschen-Feldern " .. (e.taschen and "an" or "aus") .. L" (im Tooltip stehen sie immer)."); if NS.TaschenNeu then NS.TaschenNeu() end
    elseif arg == "tooltip" then local e = NS.Einst(); e.tooltip = (e.tooltip == false); NS.msg(L"Marktwert im Tooltip " .. (e.tooltip ~= false and "an" or "aus") .. ".")
    elseif NS.Umschalten then NS.Umschalten()
    end
end
