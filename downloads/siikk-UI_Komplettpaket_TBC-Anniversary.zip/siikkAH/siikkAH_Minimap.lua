-- siikk-Auktionshaus · eigener Minimap-Knopf
local ADDON, NS = ...
local MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\Media\\"
-- eigener Minimap-Knopf
siikkMinimapKnopf("siikk-Auktionshaus", "|cffe03030siikk|r-|cffffd100Auktionshaus|r", MEDIA .. "siikk_ah_icon",
    function() local db = NS.DB(); db.mm = db.mm or {}; return db.mm end,
    function() NS.Umschalten() end,
    function() if NS.ahOffen() then NS.KomplettScan() else NS.msg("Scannen geht nur am Auktionshaus.") end end,
    { "Linksklick: Fenster ein/aus (auch ohne Auktionshaus: Preise & Übersicht)", "Rechtsklick: Komplett-Scan (am Auktionshaus)" }, 250)
