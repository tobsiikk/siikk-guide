-- siikk-Auktionshaus · „Was ist neu?“ – erzeugt aus tools/changelog.py (nicht von Hand ändern)
siikkNeu("siikk-Auktionshaus", "|cffe03030siikk|r-|cffffd100Auktionshaus|r", "Interface\\AddOns\\siikkAH\\Media\\siikk_ah_icon", "1.3",
{
    { version = "1.3", datum = "31.10.2026", punkte = { "Neu: Fenster „Was ist neu?“ nach jedem Update (wieder öffnen: /ah neu)." } },
    { version = "1.2", datum = "31.10.2026", punkte = { "Neu: Einführung beim ersten Start (/ah intro)." } },
    { version = "1.1", datum = "31.10.2026", punkte = { "Neuer Name: siikk-Auktionshaus.", "Eigener Minimap-Knopf (Edelsteine): Fenster auch ohne Auktionshaus – Preise nachschlagen, Übersicht ansehen." } },
    { version = "1.0", datum = "31.10.2026", punkte = { "Erste Version: Preise scannen, schnell verkaufen, schnell kaufen mit Einkaufsliste, Verkaufs-Übersicht, Marktwert im Tooltip." } }
}, function() return siikkAH_DB end, "/ah neu")
