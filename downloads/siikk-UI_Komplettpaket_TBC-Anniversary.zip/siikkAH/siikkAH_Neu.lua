-- siikk-Auktionshaus · „Was ist neu?“ – erzeugt aus tools/changelog.py (nicht von Hand ändern)
local L = siikkL or function(s) return s end
siikkNeu("siikk-Auktionshaus", "|cffe03030siikk|r-|cffffd100Auktionshaus|r", "Interface\\AddOns\\siikkAH\\Media\\siikk_ah_icon", "1.8",
{
    { version = "1.8", datum = "02.11.2026", punkte = { L"Neu: Sprache wählbar – Deutsch, English, Русский, Français, Español. Mit /sprache für alle siikk-Addons auf einmal umschalten (startet in der Sprache deines WoW)." } },
    { version = "1.7", datum = "31.10.2026", punkte = { L"Auktionspreise jetzt übersichtlich im Infofenster (Tooltip): niedrigster Preis pro Stück und für den ganzen Stapel, 2. Preis, Marktwert, Anzahl Angebote und Alter des Scans.", L"Gegenstände ohne Preis zeigen „Noch kein Preis – beim nächsten Scan“.", L"Die kleinen Preise direkt auf den Taschen-Feldern sind jetzt standardmäßig aus (an mit /ah taschen)." } },
    { version = "1.6", datum = "31.10.2026", punkte = { L"Neu: Auf jedem Gegenstand in deinen Taschen steht oben rechts der niedrigste Auktionspreis pro Stück vom letzten Scan (z. B. 12g, 3g50, 49s).", L"Klappt mit dem Taschenfenster der siikk-Oberfläche und mit den normalen Blizzard-Taschen; nach jedem Scan aktualisiert.", L"An/aus: /ah taschen." } },
    { version = "1.5", datum = "31.10.2026", punkte = { L"Reiter Preise: Spalten „1. Preis“ (günstigstes Angebot) und „2. Preis“ (zweitgünstigstes) – so siehst du sofort, ob das billigste ein Schnäppchen ist.", L"Preise immer mit Gold und Silber (unter 1 Gold: Silber und Kupfer).", L"Tooltip zeigt Marktwert, 1. und 2. Preis. Der 2. Preis erscheint nach dem nächsten Scan." } },
    { version = "1.4", datum = "31.10.2026", punkte = { L"Reiter Preise: Spaltenköpfe Marktwert, Günstigst, Anzahl Angebote und Alter – Maus darüber erklärt jede Spalte.", L"Sind Marktwert und günstigstes Angebot gleich (z. B. nur ein Angebot), steht dort „= Markt“ statt zweimal derselbe Preis.", L"Preise kürzer: ab 1 Gold ohne Kupfer, ab 100 Gold nur Gold – nichts wird mehr abgeschnitten." } },
    { version = "1.3", datum = "31.10.2026", punkte = { L"Neu: Fenster „Was ist neu?“ nach jedem Update (wieder öffnen: /ah neu)." } },
    { version = "1.2", datum = "31.10.2026", punkte = { L"Neu: Einführung beim ersten Start (/ah intro)." } },
    { version = "1.1", datum = "31.10.2026", punkte = { L"Neuer Name: siikk-Auktionshaus.", L"Eigener Minimap-Knopf (Edelsteine): Fenster auch ohne Auktionshaus – Preise nachschlagen, Übersicht ansehen." } },
    { version = "1.0", datum = "31.10.2026", punkte = { L"Erste Version: Preise scannen, schnell verkaufen, schnell kaufen mit Einkaufsliste, Verkaufs-Übersicht, Marktwert im Tooltip." } }
}, function() return siikkAH_DB end, "/ah neu")
