-- siikkAH · Oberfläche: Fenster neben dem Auktionshaus mit vier Reitern
local ADDON, NS = ...
local safe, geld = NS.safe, NS.geld
local GOLD = { 0.85, 0.65, 0.15 }
local LILA = "|cffb266ff"
local MEDIA = "Interface\\AddOns\\siikkAH\\Media\\"

local function bagSlots(b) if C_Container and C_Container.GetContainerNumSlots then return C_Container.GetContainerNumSlots(b) or 0 end return GetContainerNumSlots(b) or 0 end
local function bagInfo(b, s)
    if C_Container and C_Container.GetContainerItemInfo then
        local t = C_Container.GetContainerItemInfo(b, s)
        if t then return t.iconFileID, t.stackCount, t.isLocked, t.quality, t.hyperlink, t.itemID, t.isBound end
        return
    end
    local tex, cnt, locked, q, _, _, link, _, _, id = GetContainerItemInfo(b, s)
    return tex, cnt, locked, q, link, id
end
local function aufnehmen(b, s) if C_Container and C_Container.PickupContainerItem then C_Container.PickupContainerItem(b, s) else PickupContainerItem(b, s) end end

-- gebunden? (Seelengebunden / Questgegenstand) – über die API oder einen versteckten Tooltip
local scanTip = CreateFrame("GameTooltip", "siikkAHScanTip", nil, "GameTooltipTemplate")
local function gebunden(b, s, bound)
    if bound ~= nil then return bound end
    if C_Item and C_Item.IsBound and ItemLocation and ItemLocation.CreateFromBagAndSlot then
        local ok, r = pcall(C_Item.IsBound, ItemLocation:CreateFromBagAndSlot(b, s))
        if ok then return r end
    end
    scanTip:SetOwner(UIParent, "ANCHOR_NONE"); scanTip:ClearLines()
    pcall(scanTip.SetBagItem, scanTip, b, s)
    for i = 2, math.min(6, scanTip:NumLines()) do
        local fs = _G["siikkAHScanTipTextLeft" .. i]; local t = fs and fs:GetText()
        if t and (t == ITEM_SOULBOUND or t == ITEM_BIND_QUEST or t == ITEM_ACCOUNTBOUND or t == ITEM_CONJURED) then return true end
    end
    return false
end

---------------------------------------------------------------------------
-- Grundfenster
---------------------------------------------------------------------------
local F = CreateFrame("Frame", "siikkAHFenster", UIParent, "BackdropTemplate")
NS.F = F
F:SetSize(430, 440); F:Hide(); F:SetFrameStrata("HIGH"); F:EnableMouse(true); F:SetClampedToScreen(true)
F:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
F:SetBackdropColor(0.03, 0.02, 0.05, 0.94); F:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
F.logo = F:CreateTexture(nil, "BORDER", nil, -8); F.logo:SetPoint("CENTER", 0, -10); F.logo:SetSize(300, 300); F.logo:SetAlpha(0.12)
F.kopf = F:CreateTexture(nil, "BORDER"); F.kopf:SetPoint("TOPLEFT", 4, -4); F.kopf:SetPoint("TOPRIGHT", -4, -4); F.kopf:SetHeight(24); F.kopf:SetColorTexture(0.315, 0.19, 0.45, 0.8)
F.linie = F:CreateTexture(nil, "ARTWORK"); F.linie:SetPoint("TOPLEFT", F.kopf, "BOTTOMLEFT"); F.linie:SetPoint("TOPRIGHT", F.kopf, "BOTTOMRIGHT"); F.linie:SetHeight(1); F.linie:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], 1)
F.titel = F:CreateFontString(nil, "OVERLAY", "GameFontNormal"); F.titel:SetPoint("LEFT", F.kopf, "LEFT", 8, 0)
F.titel:SetText("|cffe03030siikk|r-|cffffd100Auktionshaus|r  |cff999999v" .. NS.VERSION .. "|r")
F.zu = CreateFrame("Button", nil, F, "UIPanelCloseButton"); F.zu:SetPoint("TOPRIGHT", 0, 0); F.zu:SetScale(0.8)
F.zu:SetScript("OnClick", function() F:Hide(); NS.Einst().zu = true end)
F.status = F:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); F.status:SetPoint("BOTTOMLEFT", 10, 8); F.status:SetPoint("BOTTOMRIGHT", -10, 8); F.status:SetJustifyH("LEFT")

local function knopf(parent, text, w, h)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate"); b:SetSize(w or 100, h or 22); b:SetText(text); return b
end
local function text(parent, vorlage, ...) local fs = parent:CreateFontString(nil, "OVERLAY", vorlage or "GameFontHighlightSmall"); if ... then fs:SetPoint(...) end; fs:SetJustifyH("LEFT"); return fs end
local function eingabe(parent, w, zahl)
    local e = CreateFrame("EditBox", nil, parent, "InputBoxTemplate"); e:SetSize(w, 20); e:SetAutoFocus(false)
    if zahl then e:SetNumeric(true) end
    e:SetScript("OnEscapePressed", e.ClearFocus); e:SetScript("OnEnterPressed", e.ClearFocus); return e
end
local function kasten(parent)
    local k = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    k:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    k:SetBackdropColor(0, 0, 0, 0.45); k:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 0.8); return k
end
-- Geld-Eingabe: Gold / Silber / Kupfer
local function geldEingabe(parent)
    local g = CreateFrame("Frame", nil, parent); g:SetSize(170, 22)
    local function feld(x, w, sym)
        local e = eingabe(g, w, true); e:SetPoint("LEFT", x, 0)
        local t = g:CreateTexture(nil, "ARTWORK"); t:SetSize(12, 12); t:SetPoint("LEFT", e, "RIGHT", 2, 0); t:SetTexture("Interface\\MoneyFrame\\UI-" .. sym .. "Icon")
        return e
    end
    g.gold = feld(6, 52, "Gold"); g.silber = feld(80, 26, "Silver"); g.kupfer = feld(126, 26, "Copper")
    g.silber:SetMaxLetters(2); g.kupfer:SetMaxLetters(2)
    function g:Get() return (tonumber(self.gold:GetText()) or 0) * 10000 + (tonumber(self.silber:GetText()) or 0) * 100 + (tonumber(self.kupfer:GetText()) or 0) end
    function g:Set(c)
        c = math.max(0, math.floor((c or 0) + 0.5))
        self.gold:SetText(tostring(math.floor(c / 10000))); self.silber:SetText(tostring(math.floor(c / 100) % 100)); self.kupfer:SetText(tostring(c % 100))
    end
    for _, e in ipairs({ g.gold, g.silber, g.kupfer }) do e:HookScript("OnTextChanged", function(_, user) if user and g.OnChange then g.OnChange() end end) end
    return g
end

-- Zeilen-Liste mit Mausrad
local function liste(parent, zeilen, hoehe, spalten)
    local L = kasten(parent); L.zeilen, L.offset, L.daten = {}, 0, {}
    L:SetHeight(zeilen * hoehe + 6)
    for i = 1, zeilen do
        local z = CreateFrame("Button", nil, L); z:SetHeight(hoehe)
        z:SetPoint("TOPLEFT", 3, -3 - (i - 1) * hoehe); z:SetPoint("TOPRIGHT", -3, -3 - (i - 1) * hoehe)
        z.hl = z:CreateTexture(nil, "HIGHLIGHT"); z.hl:SetAllPoints(); z.hl:SetColorTexture(1, 0.82, 0, 0.12)
        z.sel = z:CreateTexture(nil, "BACKGROUND"); z.sel:SetAllPoints(); z.sel:SetColorTexture(1, 0.82, 0, 0.25); z.sel:Hide()
        z.icon = z:CreateTexture(nil, "ARTWORK"); z.icon:SetSize(hoehe - 4, hoehe - 4); z.icon:SetPoint("LEFT", 2, 0)
        z.sp = {}
        for j, s in ipairs(spalten) do
            local fs = z:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); fs:SetJustifyH(s.rechts and "RIGHT" or "LEFT")
            fs:SetPoint("LEFT", s.x, 0); fs:SetWidth(s.w); if fs.SetWordWrap then fs:SetWordWrap(false) end
            z.sp[j] = fs
        end
        z:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        z:SetScript("OnClick", function(self, btn) if self.eintrag and L.OnKlick then L.OnKlick(self.eintrag, btn) end end)
        z:SetScript("OnEnter", function(self)
            if self.eintrag and self.eintrag.link then GameTooltip:SetOwner(self, "ANCHOR_RIGHT"); GameTooltip:SetHyperlink(self.eintrag.link); GameTooltip:Show() end
        end)
        z:SetScript("OnLeave", function() GameTooltip:Hide() end)
        L.zeilen[i] = z
    end
    L:EnableMouseWheel(true)
    L:SetScript("OnMouseWheel", function(self, d)
        self.offset = math.max(0, math.min(math.max(0, #self.daten - #self.zeilen), self.offset - d * 3)); self:Zeichnen()
    end)
    function L:Setzen(daten) self.daten = daten or {}; self.offset = math.min(self.offset, math.max(0, #self.daten - #self.zeilen)); self:Zeichnen() end
    function L:Zeichnen()
        for i, z in ipairs(self.zeilen) do
            local e = self.daten[i + self.offset]
            z.eintrag = e
            if e then
                z.icon:SetTexture(e.icon); z.icon:Show()
                for j, fs in ipairs(z.sp) do fs:SetText(e[j] or "") end
                z.sel:SetShown(self.gewaehlt ~= nil and self.gewaehlt == e.schluessel)
                z:Show()
            else z:Hide() end
        end
    end
    return L
end

---------------------------------------------------------------------------
-- Reiter
---------------------------------------------------------------------------
local seiten, reiter = {}, {}
local REITER = { "Preise", "Verkaufen", "Kaufen", "Übersicht" }
local function zeige(n)
    if (n == 2 or n == 3) and not (AuctionFrame and AuctionFrame:IsShown()) then NS.msg("Verkaufen und Kaufen gehen nur direkt am Auktionshaus.") return end
    NS.Einst().reiter = n
    for i, s in ipairs(seiten) do s:SetShown(i == n) end
    for i, b in ipairs(reiter) do
        local fs = b.GetFontString and b:GetFontString()
        local farb = type(fs) == "table" and fs.SetTextColor
        if i == n then b:LockHighlight(); if farb then fs:SetTextColor(1, 0.82, 0) end else b:UnlockHighlight(); if farb then fs:SetTextColor(0.8, 0.8, 0.8) end end
    end
    if seiten[n].Auffrischen then seiten[n].Auffrischen() end
end
NS.Zeige = zeige
for i, name in ipairs(REITER) do
    local b = knopf(F, name, 100, 22); b:SetPoint("TOPLEFT", 8 + (i - 1) * 104, -34)
    b:SetScript("OnClick", function() zeige(i) end); reiter[i] = b
    local s = CreateFrame("Frame", nil, F); s:SetPoint("TOPLEFT", 8, -62); s:SetPoint("BOTTOMRIGHT", -8, 24); s:Hide(); seiten[i] = s
end

---------------------------------------------------------------------------
-- 1) Preise
---------------------------------------------------------------------------
do
    local S = seiten[1]
    local komplett = knopf(S, "Komplett-Scan", 130); komplett:SetPoint("TOPLEFT", 0, 0)
    komplett:SetScript("OnClick", function() NS.KomplettScan() end)
    komplett:SetScript("OnEnter", function(b) GameTooltip:SetOwner(b, "ANCHOR_TOP"); GameTooltip:SetText("Komplett-Scan"); GameTooltip:AddLine("Liest alle Angebote auf einmal ein. Blizzard erlaubt das nur alle 15 Minuten – sonst startet der langsamere Seiten-Scan.", 1, 1, 1, true); GameTooltip:Show() end)
    komplett:SetScript("OnLeave", function() GameTooltip:Hide() end)
    local seitenB = knopf(S, "Seiten-Scan", 110); seitenB:SetPoint("LEFT", komplett, "RIGHT", 6, 0)
    seitenB:SetScript("OnClick", function() NS.SeitenScan() end)
    local stopp = knopf(S, "Abbrechen", 90); stopp:SetPoint("LEFT", seitenB, "RIGHT", 6, 0)
    stopp:SetScript("OnClick", function() NS.ScanAbbrechen() end)
    local st = text(S, "GameFontHighlightSmall", "TOPLEFT", 2, -30); st:SetWidth(410)
    local such = eingabe(S, 200); such:SetPoint("TOPLEFT", 6, -50)
    local hint = text(S, "GameFontDisableSmall", "LEFT", such, "LEFT", 4, 0); hint:SetText("Gegenstand suchen …")
    -- Spalten: Gegenstand · Marktwert (typischer Preis) · Günstigstes Angebot · Anzahl Angebote · Alter der Daten
    local L = liste(S, 11, 22, { { x = 26, w = 158 }, { x = 186, w = 84, rechts = true }, { x = 272, w = 84, rechts = true }, { x = 358, w = 24, rechts = true }, { x = 384, w = 28, rechts = true } })
    L:SetPoint("TOPLEFT", 0, -92); L:SetPoint("RIGHT", 0, 0)
    local function kopfText(t, rechtsVon, tip)
        local b = CreateFrame("Frame", nil, S); b:SetSize(84, 14); b:EnableMouse(true)
        local fs = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); fs:SetAllPoints(); fs:SetText(t); fs:SetJustifyH(rechtsVon and "RIGHT" or "LEFT")
        b:SetScript("OnEnter", function(x) GameTooltip:SetOwner(x, "ANCHOR_TOP"); GameTooltip:SetText(t); GameTooltip:AddLine(tip, 1, 1, 1, true); GameTooltip:Show() end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        return b
    end
    local h1 = kopfText("Gegenstand", false, "Name des Gegenstands – Maus darüber zeigt den Tooltip."); h1:SetPoint("BOTTOMLEFT", L, "TOPLEFT", 30, 3)
    local h2 = kopfText("Marktwert", true, "Typischer Preis pro Stück (Mittelwert der günstigeren Angebote). Bei nur einem Angebot gleich dem günstigsten Preis."); h2:SetPoint("BOTTOMLEFT", L, "TOPLEFT", 189, 3)
    local h3 = kopfText("Günstigst", true, "Das billigste Angebot pro Stück beim letzten Scan."); h3:SetPoint("BOTTOMLEFT", L, "TOPLEFT", 275, 3)
    local h4 = kopfText("Anz.", true, "Wie viele Angebote es beim letzten Scan gab."); h4:SetWidth(30); h4:SetPoint("BOTTOMLEFT", L, "TOPLEFT", 355, 3)
    local h5 = kopfText("Alter", true, "Wie alt die Preise sind."); h5:SetWidth(34); h5:SetPoint("BOTTOMLEFT", L, "TOPLEFT", 381, 3)
    local function fuellen()
        local q = (such:GetText() or ""):lower()
        local d = {}
        if q ~= "" then
            local db = NS.DB()
            for id, p in pairs(NS.Preise()) do
                local n = NS.Name(id) or db.namen[id] or ("#" .. id)
                if n:lower():find(q, 1, true) then
                    local gleich = p.l and p.m and math.floor(p.l) == math.floor(p.m)
                    d[#d + 1] = { n, NS.geldKurz(p.m), gleich and "|cff777777= Markt|r" or NS.geldKurz(p.l), tostring(p.n or "?"), NS.alterKurz(p.t), icon = GetItemIcon and GetItemIcon(id), link = select(2, GetItemInfo(id)) or ("item:" .. id), schluessel = id }
                    if #d >= 300 then break end
                end
            end
            table.sort(d, function(a, b) return a[1] < b[1] end)
        end
        L:Setzen(d)
    end
    such:SetScript("OnTextChanged", function(s) hint:SetShown((s:GetText() or "") == ""); fuellen() end)
    S.Status = function()
        st:SetText(NS.ScanStatus() .. (NS.KannKomplett() and "  ·  |cff33ff33Komplett-Scan bereit|r" or "  ·  |cffaaaaaaKomplett-Scan gesperrt|r"))
        stopp:SetEnabled(NS.scan.aktiv); komplett:SetEnabled(not NS.scan.aktiv); seitenB:SetEnabled(not NS.scan.aktiv)
    end
    S.Auffrischen = function()
        S.Status()
        if not NS.scan.aktiv then fuellen() end
    end
end

---------------------------------------------------------------------------
-- 2) Verkaufen
---------------------------------------------------------------------------
do
    local S = seiten[2]
    local L = liste(S, 9, 22, { { x = 26, w = 200 }, { x = 230, w = 34, rechts = true }, { x = 268, w = 140, rechts = true } })
    L:SetPoint("TOPLEFT", 0, 0); L:SetPoint("RIGHT", 0, 0)
    local D = kasten(S); D:SetPoint("TOPLEFT", L, "BOTTOMLEFT", 0, -6); D:SetPoint("BOTTOMRIGHT", 0, 0)
    local icon = D:CreateTexture(nil, "ARTWORK"); icon:SetSize(30, 30); icon:SetPoint("TOPLEFT", 8, -8)
    local name = text(D, "GameFontNormal", "LEFT", icon, "RIGHT", 6, 6); name:SetWidth(330)
    local markt = text(D, "GameFontHighlightSmall", "LEFT", icon, "RIGHT", 6, -9); markt:SetWidth(340)
    local lP = text(D, "GameFontNormalSmall", "TOPLEFT", 10, -48); lP:SetText("Preis pro Stück")
    local preis = geldEingabe(D); preis:SetPoint("TOPLEFT", 4, -60)
    local lS = text(D, "GameFontNormalSmall", "TOPLEFT", 196, -48); lS:SetText("Stapelgröße")
    local stapel = eingabe(D, 40, true); stapel:SetPoint("TOPLEFT", 202, -60)
    local lA = text(D, "GameFontNormalSmall", "TOPLEFT", 270, -48); lA:SetText("Anzahl Stapel")
    local anzahl = eingabe(D, 40, true); anzahl:SetPoint("TOPLEFT", 276, -60)
    local maxB = knopf(D, "Max", 40, 20); maxB:SetPoint("LEFT", anzahl, "RIGHT", 4, 0)
    local dauer, dauerB = 2, {}
    for i, t in ipairs({ "12 Std", "24 Std", "48 Std" }) do
        local b = knopf(D, t, 64, 20); b:SetPoint("TOPLEFT", 8 + (i - 1) * 68, -88)
        b:SetScript("OnClick", function() dauer = i; NS.Einst().dauer = i; for j, x in ipairs(dauerB) do if j == i then x:LockHighlight() else x:UnlockHighlight() end end; S.Kaution() end)
        dauerB[i] = b
    end
    local kaution = text(D, "GameFontHighlightSmall", "TOPLEFT", 216, -92); kaution:SetWidth(190)
    local gesamt = text(D, "GameFontHighlightSmall", "TOPLEFT", 10, -116); gesamt:SetWidth(240)
    local pruefen = knopf(D, "AH prüfen", 90); pruefen:SetPoint("BOTTOMRIGHT", -112, 8)
    local einstellen = knopf(D, "Einstellen", 100); einstellen:SetPoint("BOTTOMRIGHT", -8, 8)
    local sel -- gewählter Taschenplatz { bag, slot, id, name, link, gesamt, max }

    local function rechne()
        if not sel then gesamt:SetText(""); return end
        local p, st, an = preis:Get(), tonumber(stapel:GetText()) or 1, tonumber(anzahl:GetText()) or 1
        gesamt:SetText("Sofortkauf je Stapel: " .. geld(p * st) .. "  ·  gesamt " .. geld(p * st * an))
    end
    preis.OnChange = rechne
    stapel:HookScript("OnTextChanged", function(_, u) if u then rechne() end end)
    anzahl:HookScript("OnTextChanged", function(_, u) if u then rechne() end end)
    function S.Kaution()
        if not sel then kaution:SetText(""); return end
        local k
        if CalculateAuctionDeposit and GetAuctionSellItemInfo and GetAuctionSellItemInfo() then
            k = safe(CalculateAuctionDeposit, dauer, tonumber(stapel:GetText()) or 1, tonumber(anzahl:GetText()) or 1) or safe(CalculateAuctionDeposit, dauer)
        end
        kaution:SetText(k and ("Kaution: " .. geld(k)) or "|cff999999Kaution: beim Einstellen|r")
    end
    maxB:SetScript("OnClick", function()
        if not sel then return end
        local st = tonumber(stapel:GetText()) or 1
        anzahl:SetText(tostring(math.max(1, math.floor(sel.gesamt / math.max(1, st))))); rechne()
    end)

    -- Preisvorschlag: 1 Kupfer unter dem günstigsten fremden Angebot, sonst Marktwert, sonst Händlerpreis × 3
    local function vorschlag(id)
        local m, l = NS.Markt(id)
        if l then return math.max(1, l - 1), m end
        if m then return m, m end
        local vk = select(11, GetItemInfo(id))
        return (vk and vk > 0) and vk * 3 or 10000, nil
    end
    local function waehle(e)
        sel = e; L.gewaehlt = e.schluessel; L:Zeichnen()
        icon:SetTexture(e.icon); name:SetText(e.link or e.name)
        local p, m = vorschlag(e.id)
        preis:Set(p)
        markt:SetText(m and ("Marktwert " .. geld(m) .. " pro Stück") or "|cff999999Noch kein Marktwert – „AH prüfen“ oder Scan|r")
        stapel:SetText(tostring(math.min(e.gesamt, e.max or 1))); anzahl:SetText("1")
        rechne(); S.Kaution()
    end
    L.OnKlick = function(e) waehle(e) end

    local function taschen()
        local agg, d = {}, {}
        for b = 0, 4 do
            for s = 1, bagSlots(b) do
                local tex, cnt, _, q, link, id, bound = bagInfo(b, s)
                if tex and id and not gebunden(b, s, bound) then
                    local a = agg[id]
                    if not a then
                        local n, _, _, _, _, _, _, maxSt = GetItemInfo(link or id)
                        a = { id = id, name = n or "?", link = link, icon = tex, gesamt = 0, max = maxSt or 1, plaetze = {}, q = q }
                        agg[id] = a
                    end
                    a.gesamt = a.gesamt + (cnt or 1); a.plaetze[#a.plaetze + 1] = { b, s, cnt or 1 }
                end
            end
        end
        for id, a in pairs(agg) do
            local m = NS.Markt(id)
            local c = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[a.q or 1]
            a[1] = (c and c.hex or "") .. a.name .. "|r"; a[2] = tostring(a.gesamt); a[3] = m and geld(m) or "|cff777777–|r"
            a.schluessel = id; d[#d + 1] = a
        end
        table.sort(d, function(x, y) return (NS.Markt(x.id) or 0) * x.gesamt > (NS.Markt(y.id) or 0) * y.gesamt end)
        L:Setzen(d)
        if sel then local neu = agg[sel.id]; if neu then sel = neu else sel = nil; L.gewaehlt = nil; icon:SetTexture(nil); name:SetText("Gegenstand in der Liste anklicken"); markt:SetText(""); rechne(); S.Kaution() end end
    end
    S.Auffrischen = function() taschen(); if not sel then name:SetText("Gegenstand in der Liste anklicken") end end

    -- AH prüfen: genau diesen Gegenstand suchen und den Preis anpassen
    pruefen:SetScript("OnClick", function()
        if not sel then return end
        if not CanSendAuctionQuery() then NS.msg("Kurz warten – das Auktionshaus nimmt gerade keine Anfrage an.") return end
        NS.pruefen = sel.id; NS.kaufSuche = false
        QueryAuctionItems(sel.name, nil, nil, 0, false, nil, false, true, nil)
    end)
    NS.PruefErgebnis = function()
        if not sel or NS.pruefen ~= sel.id then return end
        NS.pruefen = nil
        local samm, ich, low = NS.neueSammlung(), UnitName("player"), nil
        local n = GetNumAuctionItems("list")
        for i = 1, n do
            local _, _, cnt, _, _, _, _, _, _, buy, _, _, _, owner, _, _, id = GetAuctionItemInfo("list", i)
            if id == sel.id and buy and buy > 0 then
                NS.Aufnehmen(samm, i)
                if owner ~= ich then local u = buy / math.max(1, cnt or 1); if not low or u < low then low = u end end
            end
        end
        NS.Auswerten(samm, false)
        if low then preis:Set(math.max(1, math.floor(low) - 1)); NS.msg(sel.name .. ": günstigstes Angebot " .. geld(low) .. " – Preis auf 1 Kupfer darunter gesetzt.")
        else NS.msg(sel.name .. ": keine fremden Angebote gefunden – Preis bleibt.") end
        local m = NS.Markt(sel.id); markt:SetText(m and ("Marktwert " .. geld(m) .. " pro Stück") or "")
        rechne()
    end

    -- Einstellen: legt den Gegenstand in den Verkaufsplatz und stellt ein (ein Klick = ein Auftrag)
    einstellen:SetScript("OnClick", function()
        if not sel then return end
        local p, st, an = preis:Get(), tonumber(stapel:GetText()) or 1, tonumber(anzahl:GetText()) or 1
        if p <= 0 then NS.msg("Bitte einen Preis eingeben.") return end
        st = math.max(1, math.min(st, sel.max or 1, sel.gesamt)); an = math.max(1, math.min(an, math.floor(sel.gesamt / st)))
        local platz = sel.plaetze[1]
        if not platz then return end
        ClearCursor(); aufnehmen(platz[1], platz[2]); ClickAuctionSellItemButton(); ClearCursor()
        if not GetAuctionSellItemInfo() then NS.msg("Der Gegenstand konnte nicht in den Verkaufsplatz gelegt werden.") return end
        local kaut = safe(CalculateAuctionDeposit, dauer, st, an) or safe(CalculateAuctionDeposit, dauer) or 0
        local buy = p * st
        local bid = math.max(1, math.floor(buy * (NS.Einst().gebot or 0.95)))
        local ok, err = pcall(PostAuction, bid, buy, dauer, st, an)
        if ok then
            NS.Eingestellt(sel.name, sel.id, st, buy, kaut, an)
            NS.msg("Eingestellt: " .. an .. " × " .. st .. " " .. sel.name .. " für je " .. geld(buy))
            if C_Timer then C_Timer.After(1.5, taschen) end
        else NS.msg("Einstellen fehlgeschlagen: " .. tostring(err)) end
    end)
    S.Init = function() dauer = NS.Einst().dauer or 2; dauerB[dauer]:LockHighlight() end
end

---------------------------------------------------------------------------
-- 3) Kaufen
---------------------------------------------------------------------------
do
    local S = seiten[3]
    local such = eingabe(S, 190); such:SetPoint("TOPLEFT", 6, 0)
    local hint = text(S, "GameFontDisableSmall", "LEFT", such, "LEFT", 4, 0); hint:SetText("Name eingeben …")
    such:SetScript("OnTextChanged", function(s) hint:SetShown((s:GetText() or "") == "") end)
    local los = knopf(S, "Suchen", 70); los:SetPoint("LEFT", such, "RIGHT", 6, 0)
    local merk = knopf(S, "+ Liste", 64); merk:SetPoint("LEFT", los, "RIGHT", 4, 0)
    local zur, vor = knopf(S, "<", 26), knopf(S, ">", 26); zur:SetPoint("LEFT", merk, "RIGHT", 6, 0); vor:SetPoint("LEFT", zur, "RIGHT", 2, 0)
    local L = liste(S, 11, 22, { { x = 26, w = 150 }, { x = 178, w = 30, rechts = true }, { x = 210, w = 76, rechts = true }, { x = 288, w = 78, rechts = true }, { x = 368, w = 40, rechts = true } })
    L:SetPoint("TOPLEFT", 0, -28); L:SetPoint("RIGHT", 0, 0)
    local info = text(S, "GameFontHighlightSmall", "TOPLEFT", L, "BOTTOMLEFT", 4, -6); info:SetWidth(300)
    local kauf = knopf(S, "Kaufen", 100); kauf:SetPoint("TOPRIGHT", L, "BOTTOMRIGHT", 0, -4); kauf:Disable()
    local lt = text(S, "GameFontNormalSmall", "TOPLEFT", L, "BOTTOMLEFT", 4, -34); lt:SetText("Einkaufsliste (Rechtsklick = entfernen):")
    local chips = {}
    for i = 1, 8 do
        local b = knopf(S, "", 100, 20); b:SetPoint("TOPLEFT", L, "BOTTOMLEFT", ((i - 1) % 4) * 104, -50 - math.floor((i - 1) / 4) * 24)
        b:RegisterForClicks("LeftButtonUp", "RightButtonUp"); chips[i] = b
    end
    local seite, aktuell, gewaehlt = 0, "", nil

    local function suche(t, s)
        if not CanSendAuctionQuery() then NS.msg("Kurz warten – das Auktionshaus nimmt gerade keine Anfrage an.") return end
        aktuell, seite, gewaehlt = t, s or 0, nil; L.gewaehlt = nil; kauf:Disable()
        NS.kaufSuche = true
        QueryAuctionItems(t, nil, nil, seite, false, nil, false, false, nil)
        info:SetText("Suche läuft …")
    end
    los:SetScript("OnClick", function() such:ClearFocus(); suche(such:GetText() or "", 0) end)
    such:SetScript("OnEnterPressed", function(s) s:ClearFocus(); suche(s:GetText() or "", 0) end)
    zur:SetScript("OnClick", function() if seite > 0 then suche(aktuell, seite - 1) end end)
    vor:SetScript("OnClick", function() suche(aktuell, seite + 1) end)
    local function chipsZeigen()
        local db, k = NS.DB(); local l = db.liste[k]
        for i, b in ipairs(chips) do
            local e = l[i]
            if e then b:SetText(e); b:Show()
                b:SetScript("OnClick", function(_, btn) if btn == "RightButton" then table.remove(l, i); chipsZeigen() else such:SetText(e); suche(e, 0) end end)
            else b:Hide() end
        end
    end
    merk:SetScript("OnClick", function()
        local t = such:GetText() or ""; if t == "" then return end
        local db, k = NS.DB(); local l = db.liste[k]
        for _, v in ipairs(l) do if v == t then return end end
        if #l >= 8 then table.remove(l, 1) end
        l[#l + 1] = t; chipsZeigen()
    end)

    NS.KaufErgebnis = function()
        if not NS.kaufSuche then return end
        local n, total = GetNumAuctionItems("list")
        local d, samm, ich = {}, NS.neueSammlung(), UnitName("player")
        for i = 1, n do
            local name, tex, cnt, q, _, _, _, _, _, buy, _, _, _, owner, _, _, id = GetAuctionItemInfo("list", i)
            if name and buy and buy > 0 then
                NS.Aufnehmen(samm, i)
                cnt = math.max(1, cnt or 1)
                local stk = buy / cnt
                local m = NS.Markt(id)
                local pct = m and m > 0 and math.floor(stk / m * 100 + 0.5)
                local farbe = pct and (pct <= 80 and "|cff33ff33" or (pct >= 130 and "|cffff6060" or "|cffdddddd")) or "|cff777777"
                local c = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q or 1]
                d[#d + 1] = { (c and c.hex or "") .. name .. "|r" .. (owner == ich and " |cff999999(du)|r" or ""), tostring(cnt), geld(stk), geld(buy), farbe .. (pct and (pct .. "%") or "–") .. "|r",
                    icon = tex, link = GetAuctionItemLink("list", i), index = i, buy = buy, name = name, stk = stk, schluessel = i, eigen = owner == ich }
            end
        end
        NS.Auswerten(samm, false)
        table.sort(d, function(a, b) return a.stk < b.stk end)
        L:Setzen(d)
        local seiten_ = math.max(1, math.ceil((total or 0) / 50))
        info:SetText((total or 0) .. " Angebote · Seite " .. (seite + 1) .. "/" .. seiten_ .. "  ·  " .. LILA .. "grün|r = Schnäppchen")
        zur:SetEnabled(seite > 0); vor:SetEnabled(seite + 1 < seiten_)
    end
    L.OnKlick = function(e)
        gewaehlt = e; L.gewaehlt = e.schluessel; L:Zeichnen()
        kauf:SetText("Kaufen: " .. geld(e.buy)); kauf:SetWidth(170); kauf:SetEnabled(not e.eigen)
    end
    kauf:SetScript("OnClick", function()
        if not gewaehlt then return end
        -- Sicherheitsprüfung: steht an der Stelle noch dasselbe Angebot?
        local name, _, _, _, _, _, _, _, _, buy = GetAuctionItemInfo("list", gewaehlt.index)
        if name ~= gewaehlt.name or buy ~= gewaehlt.buy then NS.msg("Das Angebot hat sich geändert – bitte neu suchen.") return end
        if GetMoney() < buy then NS.msg("Nicht genug Gold.") return end
        PlaceAuctionBid("list", gewaehlt.index, buy)
        NS.msg("Gekauft: " .. gewaehlt.name .. " für " .. geld(buy))
        gewaehlt = nil; L.gewaehlt = nil; kauf:Disable(); kauf:SetText("Kaufen"); kauf:SetWidth(100)
        if C_Timer then C_Timer.After(0.8, function() if CanSendAuctionQuery() then suche(aktuell, seite) end end) end
    end)
    S.Auffrischen = chipsZeigen
end

---------------------------------------------------------------------------
-- 4) Übersicht
---------------------------------------------------------------------------
do
    local S = seiten[4]
    local K = kasten(S); K:SetPoint("TOPLEFT", 0, 0); K:SetPoint("RIGHT", 0, 0); K:SetHeight(92)
    local z = {}
    for i, t in ipairs({ "Heute", "7 Tage", "30 Tage", "Gesamt" }) do
        local l = text(K, "GameFontNormalSmall", "TOPLEFT", 10, -8 - (i - 1) * 18); l:SetText(t)
        z[i] = text(K, "GameFontHighlightSmall", "TOPLEFT", 80, -8 - (i - 1) * 18); z[i]:SetWidth(330)
    end
    local aktiv = text(S, "GameFontHighlightSmall", "TOPLEFT", 4, -100); aktiv:SetWidth(410)
    local L = liste(S, 11, 22, { { x = 4, w = 60 }, { x = 66, w = 190 }, { x = 258, w = 72, rechts = true }, { x = 332, w = 76, rechts = true } })
    L:SetPoint("TOPLEFT", 0, -118); L:SetPoint("RIGHT", 0, 0)
    for _, zz in ipairs(L.zeilen) do zz.icon:Hide(); zz.icon.Show = function() end end
    S.Auffrischen = function()
        for i, tage in ipairs({ 1, 7, 30, false }) do
            local um, gw, n = NS.Bilanz(tage or nil)
            z[i]:SetText(n .. " verkauft · Umsatz " .. geld(um) .. " · Gewinn " .. (gw >= 0 and "" or "|cffff6060-|r") .. geld(math.abs(gw)))
        end
        local db, k = NS.DB()
        local offen, wert = #db.offen[k], 0
        for _, e in ipairs(db.offen[k]) do wert = wert + (e.p or 0) end
        aktiv:SetText("Laufende Auktionen: " .. offen .. " · Wert " .. geld(wert) .. "  |cff999999(Gewinn nach 5 % AH-Gebühr und Kaution)|r")
        local d = {}
        for i, v in ipairs(db.verkauf[k]) do
            if i > 200 then break end
            d[#d + 1] = { date("%d.%m. %H:%M", v.t), (v.art == "verkauft" and "|cff33ff33" or "|cffaaaaaa") .. (v.n and v.n > 1 and (v.n .. "× ") or "") .. v.name .. "|r",
                v.art == "verkauft" and geld(v.p) or "|cffaaaaaaabgelaufen|r", ((v.g or 0) >= 0 and "|cff33ff33+|r" or "|cffff6060-|r") .. geld(math.abs(v.g or 0)), schluessel = i }
        end
        L:Setzen(d)
    end
end

---------------------------------------------------------------------------
-- Anbindung an das Auktionshaus
---------------------------------------------------------------------------
local schalter
local function anbinden()
    if not AuctionFrame or F.angebunden then return end
    F.angebunden = true
    F:ClearAllPoints(); F:SetPoint("TOPLEFT", AuctionFrame, "TOPRIGHT", -6, -12)
    schalter = CreateFrame("Button", nil, AuctionFrame, "UIPanelButtonTemplate"); schalter:SetSize(80, 22)
    schalter:SetPoint("TOPRIGHT", AuctionFrame, "TOPRIGHT", -44, -14); schalter:SetText("|cffe03030siikk|r|cffffd100AH|r")
    schalter:SetScript("OnClick", function() if F:IsShown() then F:Hide(); NS.Einst().zu = true else F:Show(); NS.Einst().zu = false end end)
    AuctionFrame:HookScript("OnHide", function() F:Hide() end)
end
local function ahOffen() return AuctionFrame and AuctionFrame:IsShown() end
NS.ahOffen = ahOffen
function NS.Umschalten()
    if ahOffen() then anbinden(); F:ClearAllPoints(); F:SetPoint("TOPLEFT", AuctionFrame, "TOPRIGHT", -6, -12); F:SetShown(not F:IsShown()) return end
    if F:IsShown() then F:Hide() return end
    -- ohne Auktionshaus: frei in der Bildschirmmitte (Preise nachschlagen, Übersicht ansehen)
    F:ClearAllPoints(); F:SetPoint("CENTER", UIParent, "CENTER", 0, 40)
    F:SetMovable(true); F:RegisterForDrag("LeftButton")
    F:SetScript("OnDragStart", function(s) if not ahOffen() then s:StartMoving() end end); F:SetScript("OnDragStop", F.StopMovingOrSizing)
    local logo = (UnitFactionGroup("player") == "Alliance") and "allianz_hd" or "horde_rot_hd"
    F.logo:SetTexture(MEDIA .. logo)
    if seiten[2].Init and not F.init then F.init = true; seiten[2].Init() end
    F:Show(); local r = NS.Einst().reiter or 1; if r == 2 or r == 3 then r = 1 end; zeige(r)
end
NS.OnAHShow = function()
    if not AuctionFrame then if C_Timer then C_Timer.After(0.1, NS.OnAHShow) end return end
    anbinden(); F:ClearAllPoints(); F:SetPoint("TOPLEFT", AuctionFrame, "TOPRIGHT", -6, -12)
    local logo = (UnitFactionGroup("player") == "Alliance") and "allianz_hd" or "horde_rot_hd"
    F.logo:SetTexture(MEDIA .. logo)
    if seiten[2].Init and not F.init then F.init = true; seiten[2].Init() end
    if not NS.Einst().zu then F:Show() end
    zeige(NS.Einst().reiter or 1)
end
NS.OnListe = function()
    if NS.scan.aktiv then return end
    if NS.pruefen and NS.PruefErgebnis then NS.PruefErgebnis() return end
    if NS.kaufSuche and NS.KaufErgebnis and F:IsShown() and (NS.Einst().reiter or 1) == 3 then NS.KaufErgebnis() end
end
NS.UIUpdate = function()
    if not F:IsShown() then return end
    F.status:SetText(NS.ScanStatus())
    local n = NS.Einst().reiter or 1
    if seiten[n] and seiten[n].Auffrischen and (n ~= 2) then seiten[n].Auffrischen() end
end
F:SetScript("OnShow", function() NS.UIUpdate() end)
local tick = 0
F:SetScript("OnUpdate", function(_, el) tick = tick + el; if tick > 1 then tick = 0; F.status:SetText(NS.ScanStatus()); if (NS.Einst().reiter or 1) == 1 then seiten[1].Status() end end end)
-- Taschen geändert → Verkaufen-Liste auffrischen
local bagEv = CreateFrame("Frame")
bagEv:RegisterEvent("BAG_UPDATE_DELAYED"); bagEv:RegisterEvent("BAG_UPDATE")
bagEv:SetScript("OnEvent", function() if F:IsShown() and (NS.Einst().reiter or 1) == 2 then seiten[2].Auffrischen() end end)

