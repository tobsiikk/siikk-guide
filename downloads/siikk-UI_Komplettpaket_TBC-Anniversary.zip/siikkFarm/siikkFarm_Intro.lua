-- siikk-Farmhelfer · Einführung beim ersten Start (/farm intro)
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local Y = "|cffffd100"
siikkIntro("siikk-Farmhelfer", "|cffe03030siikk|r-|cffffd100Farmhelfer|r", NS.MEDIA .. "siikk_farm_icon", {
    { L"Willkommen beim siikk-Farmhelfer",
      L"Der Farmhelfer zeigt dir auf einen Blick, was beim Farmen wichtig ist.\n\n" ..
      L"• Kräuter, Erze & Steine, Stoff, Leder, Kochzutaten & Fisch, Elementar- und Verzauberkunst-Material " .. Y .. L"leuchten|r in deinen Taschen und im Beutefenster – jede Sorte in ihrer eigenen Farbe.\n\n" ..
      L"• Im " .. Y .. L"Tooltip|r steht, wofür der Gegenstand gut ist, z. B. „Stoff – für Erste Hilfe & Schneiderei“." },
    { L"Hinweis beim Fund",
      L"Fährst du mit der Maus über ein " .. Y .. L"Kraut|r, eine " .. Y .. L"Erzader|r oder einen " .. Y .. L"häutbaren Gegner|r, blinkt oben am Bildschirm ein Hinweis mit dem Namen auf – mit kurzem Ton.\n\n" ..
      L"• Zum Finden auf der Minimap nutzt du Blizzards " .. Y .. L"Kräutersuche|r bzw. " .. Y .. L"Mineraliensuche|r. Was dort angezeigt wird, können Addons leider nicht selbst auslesen." },
    { L"Einstellen & Befehle",
      Y .. L"/farm|r – Einstellungen: welche Sorten leuchten, Taschen, Beute, Tooltip, Pulsieren, Hinweis und Ton\n" ..
      Y .. L"/farm an|r / " .. Y .. L"/farm aus|r – alles an oder aus\n" .. Y .. L"/farm intro|r – diese Einführung · " .. Y .. L"/farm neu|r – was ist neu\n\n" ..
      L"Minimap-Knopf: " .. Y .. L"Linksklick|r = Einstellungen, " .. Y .. L"Rechtsklick|r = an/aus." },
}, function() return rawget(_G, "siikkFarm_DB") end, "/farm intro")
