-- siikk-Farmhelfer · erkennt Farm-Gegenstände (Kräuter, Erze, Stoff, Leder, Kochzutaten & Fisch, Elementar, Verzauberung)
-- lässt sie in Taschen und Beute aufleuchten, schreibt in den Tooltip wofür sie gut sind
-- und gibt einen Hinweis, wenn die Maus über einem Kraut, einer Erzader oder einem häutbaren Gegner ist.
local ADDON, NS = ...
local L = siikkL or function(s) return s end
NS.VERSION = "1.2"
NS.MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\Media\\"
local Y = "|cffffd100"
function NS.msg(t) print(L"|cffe03030siikk|r-|cffffd100Farmhelfer|r: " .. t) end

-- Kategorien -----------------------------------------------------------------
NS.KATS = {
    { key = "kraeuter",     name = L"Kräuter",               wofuer = L"Kraut – für Alchemie",                       farbe = { .3, 1, .3 } },
    { key = "erz",          name = L"Erze & Steine",         wofuer = L"Erz/Stein – für Schmiedekunst & Ingenieurskunst", farbe = { 1, .62, .2 } },
    { key = "stoff",        name = L"Stoff",                 wofuer = L"Stoff – für Erste Hilfe & Schneiderei",       farbe = { .6, .82, 1 } },
    { key = "leder",        name = L"Leder & Bälge",         wofuer = L"Leder – für Lederverarbeitung",               farbe = { .85, .58, .3 } },
    { key = "kochen",       name = L"Kochzutaten & Fisch",   wofuer = L"Zutat – für Kochen",                          farbe = { 1, .42, .42 } },
    { key = "elementar",    name = L"Elementar",             wofuer = L"Elementar – für viele Berufe",                farbe = { .3, .92, 1 } },
    { key = "verzauberung", name = L"Verzauberkunst",        wofuer = L"Verzauberkunst-Material",                     farbe = { .78, .48, 1 } },
}
NS.KAT = {}; for _, k in ipairs(NS.KATS) do NS.KAT[k.key] = k end

-- Handwerkswaren (Klasse 7): Unterklasse → Kategorie
local UNTER = { [5] = "stoff", [6] = "leder", [7] = "erz", [8] = "kochen", [9] = "kraeuter", [10] = "elementar", [12] = "verzauberung" }
-- feste Listen für Dinge, die das Spiel anders einordnet (roher Fisch ist „Essen“, manche Kräuter/Erze „Handwerkswaren“)
local LISTE = {
    kraeuter = { 765, 785, 2447, 2449, 2450, 2452, 2453, 3355, 3356, 3357, 3358, 3369, 3818, 3819, 3820, 3821, 4625, 8831, 8836, 8838, 8839, 8845, 8846,
        13463, 13464, 13465, 13466, 13467, 13468, 19726 },
    erz = { 2770, 2771, 2772, 2775, 2776, 3858, 7911, 10620, 11370, 2835, 2836, 2838, 7912, 12365, 2840, 2841, 3575, 3576, 3577, 3859, 3860, 6037, 12359, 11371 },
    stoff = { 2589, 2592, 4306, 4338, 14047, 14256 },
    leder = { 2318, 2319, 4234, 4304, 8170, 783, 4232, 4235, 8169, 8171, 15417, 15419, 17012 },
    kochen = { 6291, 6303, 6289, 6317, 6361, 6308, 6362, 4603, 8365, 13754, 13756, 13758, 13759, 13760, 13888, 13889, 7974, 21071, 21153,
        769, 2672, 2673, 2674, 2675, 2677, 3173, 3667, 3712, 3730, 3731, 4655, 5503, 5504, 12037, 12202, 12203, 12204, 12205, 12206, 12207, 12208, 2251, 723, 729, 730, 731, 1015, 1080, 1468, 3685, 5465, 5466, 5467, 5468, 5469, 5470, 5471 },
    elementar = { 7067, 7068, 7069, 7070, 7075, 7076, 7077, 7078, 7079, 7080, 7081, 7082, 12803, 12808 },
    verzauberung = { 10938, 10939, 10940, 10978, 10998, 11082, 11083, 11084, 11134, 11135, 11137, 11138, 11139, 11174, 11175, 11176, 11177, 11178, 14343, 14344, 16202, 16203, 16204, 20725 },
}
local FEST = {}
for kat, ids in pairs(LISTE) do for _, id in ipairs(ids) do FEST[id] = kat end end

local cache = {}
function NS.Kategorie(id)
    id = tonumber(id); if not id then return nil end
    if cache[id] ~= nil then return cache[id] or nil end
    local kat = FEST[id]
    if not kat and GetItemInfoInstant then
        local ok, _, _, _, _, _, klasse, unter = pcall(GetItemInfoInstant, id)
        if ok and klasse == 7 then kat = UNTER[unter] end
    end
    cache[id] = kat or false
    return kat
end
function NS.IdAusLink(link) return type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil end

-- Einstellungen ----------------------------------------------------------------
local STANDARD = { taschen = true, beute = true, tooltip = true, welt = true, ton = true, pulsieren = true }
function NS.DB()
    local db = rawget(_G, "siikkFarm_DB")
    if type(db) ~= "table" then db = {}; siikkFarm_DB = db end
    for k, v in pairs(STANDARD) do if db[k] == nil then db[k] = v end end
    db.kats = db.kats or {}
    for _, k in ipairs(NS.KATS) do if db.kats[k.key] == nil then db.kats[k.key] = true end end
    return db
end
-- Kategorie an? (nil = nicht farmbar oder abgeschaltet)
function NS.Aktiv(id)
    local kat = NS.Kategorie(id)
    if kat and NS.DB().kats[kat] then return NS.KAT[kat] end
end

-- Tooltip-Zeile ---------------------------------------------------------------
local function tooltipZeile(tt)
    if not NS.DB().tooltip or not tt or not tt.GetItem then return end
    local _, link = tt:GetItem()
    local k = NS.Aktiv(NS.IdAusLink(link))
    if k then tt:AddLine(("|cff%02x%02x%02x• %s|r"):format(math.floor(k.farbe[1] * 255), math.floor(k.farbe[2] * 255), math.floor(k.farbe[3] * 255), k.wofuer)); tt:Show() end
end
if GameTooltip and GameTooltip.HookScript then
    pcall(GameTooltip.HookScript, GameTooltip, "OnTooltipSetItem", tooltipZeile)
    if ItemRefTooltip then pcall(ItemRefTooltip.HookScript, ItemRefTooltip, "OnTooltipSetItem", tooltipZeile) end
end
if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
    pcall(TooltipDataProcessor.AddTooltipPostCall, Enum.TooltipDataType.Item, function(tt) if tt == GameTooltip then tooltipZeile(tt) end end)
end

-- Hinweis, wenn die Maus über einem Kraut, einer Erzader oder einem häutbaren Gegner ist ----------
-- Solche Tooltips haben in der zweiten Zeile den Beruf (Kräuterkunde, Bergbau, Kürschnerei).
local BERUF = {
    kraeuter = { "Kräuterkunde", "Herbalism", "Травничество", "Herboristerie", "Herboristería" },
    erz = { "Bergbau", "Mining", "Горное дело", "Minage", "Minería" },
    leder = { "Kürschnerei", "Skinning", "Снятие шкур", "Dépeçage", "Desuello" },
}
-- häutbare Gegner zeigen Blizzards eigene, schon übersetzte Zeile (z. B. „Kürschnerbar“) – die gleich mit aufnehmen
for kat, g in pairs({ leder = "UNIT_SKINNABLE_LEATHER", kraeuter = "UNIT_SKINNABLE_HERB", erz = "UNIT_SKINNABLE_ROCK" }) do
    local t = rawget(_G, g); if type(t) == "string" and t ~= "" then table.insert(BERUF[kat], t) end
end
function NS.WeltKategorie(zeilen)
    for i = 2, #zeilen do
        local t = zeilen[i]
        if type(t) == "string" and not (issecretvalue and issecretvalue(t)) then   -- Forever: geschützte Texte nie anfassen
            for kat, namen in pairs(BERUF) do
                for _, n in ipairs(namen) do if t:find(n, 1, true) then return kat end end
            end
        end
    end
end
local zuletzt = {}
local function weltTooltip(tt)
    local db = NS.DB(); if not db.welt or tt ~= GameTooltip then return end
    if tt.GetItem then local _, link = tt:GetItem(); if link then return end end
    local zeilen = {}
    for i = 1, math.min(4, tt:NumLines() or 0) do
        local fs = rawget(_G, "GameTooltipTextLeft" .. i); zeilen[i] = fs and fs:GetText()
    end
    local kat = NS.WeltKategorie(zeilen)
    if not kat or not db.kats[kat] then return end
    local name = zeilen[1] or "?"
    local t = GetTime and GetTime() or 0
    if zuletzt[name] and t - zuletzt[name] < 8 then return end
    zuletzt[name] = t
    if NS.Hinweis then NS.Hinweis(name, NS.KAT[kat]) end
end
if GameTooltip and GameTooltip.HookScript then pcall(GameTooltip.HookScript, GameTooltip, "OnShow", weltTooltip) end
NS.WeltTooltip = weltTooltip

-- Befehle ------------------------------------------------------------------------
SLASH_SIIKKFARM1 = "/farm"; SLASH_SIIKKFARM2 = "/siikkfarm"
SlashCmdList.SIIKKFARM = function(m)
    m = (m or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    local db = NS.DB()
    if m == "an" or m == "aus" then
        local an = (m == "an"); db.taschen = an; db.beute = an; db.welt = an
        NS.msg(an and L"Leuchten und Hinweise an." or L"Leuchten und Hinweise aus.")
        if NS.Auffrischen then NS.Auffrischen() end
    elseif m == "intro" then local api = rawget(_G, "SiikkIntroAPI"); if api and api["siikk-Farmhelfer"] then api["siikk-Farmhelfer"]() end
    elseif m == "neu" then local api = rawget(_G, "SiikkNeuAPI"); if api and api["siikk-Farmhelfer"] then api["siikk-Farmhelfer"]() end
    elseif m == "hilfe" or m == "help" then
        NS.msg(L"Befehle:")
        print(Y .. L"/farm|r – Einstellungen · " .. Y .. L"/farm an|r / " .. Y .. L"aus|r – Leuchten und Hinweise an/aus · " .. Y .. L"/farm intro|r · " .. Y .. L"/farm neu|r")
    else if NS.Optionen then NS.Optionen() end end
end
