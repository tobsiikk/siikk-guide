-- siikk-Farmhelfer · Leuchten in Taschen und Beutefenster, Hinweis-Banner bei Kraut/Erz/Kürschnern
local ADDON, NS = ...
local L = siikkL or function(s) return s end

-- Leuchtrahmen an einem Feld --------------------------------------------------------
local alle = {}          -- alle Leuchtrahmen (für das gemeinsame Pulsieren)
local function rahmen(b)
    local g = rawget(b, "siikkFarmGlow")
    if g then return g end
    g = CreateFrame("Frame", nil, b)
    g:SetAllPoints(b); g:SetFrameLevel((b.GetFrameLevel and b:GetFrameLevel() or 1) + 3); g:EnableMouse(false)
    g.t = g:CreateTexture(nil, "OVERLAY")
    g.t:SetTexture("Interface\\Buttons\\UI-ActionButton-Border"); g.t:SetBlendMode("ADD")
    local w = b.GetWidth and b:GetWidth() or 36
    if type(w) ~= "number" or w <= 0 then w = 36 end
    g.t:SetSize(w * 1.8, w * 1.8); g.t:SetPoint("CENTER", b, "CENTER", 0, 0)
    g:Hide()
    b.siikkFarmGlow = g; alle[#alle + 1] = g
    return g
end
function NS.Feld(b, id)
    if type(b) ~= "table" or not b.CreateTexture then return end
    local k = id and NS.Aktiv(id)
    if not k then local g = rawget(b, "siikkFarmGlow"); if g then g:Hide() end return end
    local g = rahmen(b)
    g.t:SetVertexColor(k.farbe[1], k.farbe[2], k.farbe[3]); g:Show()
end
local function aus(b) local g = type(b) == "table" and rawget(b, "siikkFarmGlow"); if g then g:Hide() end end

-- gemeinsames Pulsieren
local puls = CreateFrame("Frame"); local zeit = 0
puls:SetScript("OnUpdate", function(_, el)
    zeit = zeit + el
    local a = NS.DB().pulsieren and (.45 + .45 * math.sin(zeit * 4)) or .8
    for _, g in ipairs(alle) do if g:IsShown() then g.t:SetAlpha(a) end end
end)

-- Taschen ------------------------------------------------------------------------------
local function itemId(bag, slot)
    if C_Container and C_Container.GetContainerItemID then return C_Container.GetContainerItemID(bag, slot) end
    if GetContainerItemID then return GetContainerItemID(bag, slot) end
    local link = GetContainerItemLink and GetContainerItemLink(bag, slot)
    return NS.IdAusLink(link)
end
-- Taschenfenster der siikk-Oberfläche ruft das für jedes Feld auf
SiikkTaschenFeldHooks = rawget(_G, "SiikkTaschenFeldHooks") or {}
table.insert(SiikkTaschenFeldHooks, function(b, bag, slot, id)
    if not NS.DB().taschen then aus(b) return end
    NS.Feld(b, id or (bag and slot and itemId(bag, slot)))
end)
-- normale Blizzard-Taschen
local function blizzTasche(frame)
    if type(frame) ~= "table" or not frame.GetName then return end
    local name, bag = frame:GetName(), frame:GetID()
    for i = 1, (frame.size or 36) do
        local b = _G[name .. "Item" .. i]
        if b then
            if NS.DB().taschen then NS.Feld(b, itemId(bag, b:GetID())) else aus(b) end
        end
    end
end
if type(rawget(_G, "ContainerFrame_Update")) == "function" then hooksecurefunc("ContainerFrame_Update", blizzTasche) end

-- Beutefenster -----------------------------------------------------------------------
local function beute()
    for i = 1, (LOOTFRAME_NUMBUTTONS or 4) do
        local b = rawget(_G, "LootButton" .. i)
        if b then
            local slot = b.slot or (b.GetSlotIndex and b:GetSlotIndex())
            local link = slot and GetLootSlotLink and GetLootSlotLink(slot)
            if NS.DB().beute and b:IsShown() and link then NS.Feld(b, NS.IdAusLink(link)) else aus(b) end
        end
    end
end
NS.Beute = beute
if type(rawget(_G, "LootFrame_Update")) == "function" then hooksecurefunc("LootFrame_Update", beute) end
local ev = CreateFrame("Frame"); ev:RegisterEvent("LOOT_OPENED"); ev:RegisterEvent("LOOT_SLOT_CLEARED")
ev:SetScript("OnEvent", function() if C_Timer and C_Timer.After then C_Timer.After(0, beute) else beute() end end)

function NS.Auffrischen()
    local s = rawget(_G, "SiikkUITaschenNeu"); if type(s) == "function" then pcall(s) end
    for i = 1, (NUM_CONTAINER_FRAMES or 13) do
        local f = rawget(_G, "ContainerFrame" .. i)
        if f and f:IsShown() then pcall(blizzTasche, f) end
    end
    pcall(beute)
end

-- Hinweis-Banner (Kraut, Erzader, häutbarer Gegner unter der Maus) -------------------------
local ban = CreateFrame("Frame", "siikkFarmHinweis", UIParent, "BackdropTemplate")
ban:SetSize(240, 34); ban:SetPoint("TOP", UIParent, "TOP", 0, -150); ban:SetFrameStrata("HIGH"); ban:Hide(); ban:EnableMouse(false)
if ban.SetBackdrop then
    ban:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 2 })
    ban:SetBackdropColor(.03, .02, .05, .85)
end
ban.ic = ban:CreateTexture(nil, "ARTWORK"); ban.ic:SetSize(24, 24); ban.ic:SetPoint("LEFT", 6, 0); ban.ic:SetTexture(NS.MEDIA .. "siikk_farm_icon")
ban.t = ban:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); ban.t:SetPoint("LEFT", ban.ic, "RIGHT", 8, 0)
local banZeit = 0
ban:SetScript("OnUpdate", function(s, el)
    banZeit = banZeit + el
    local a = 1
    if banZeit < .2 then a = banZeit / .2 elseif banZeit > 2.6 then a = math.max(0, 1 - (banZeit - 2.6) / .6) end
    s:SetAlpha(a)
    if s.SetBackdropBorderColor and s.farbe then
        local p = .5 + .5 * math.sin(banZeit * 10)
        s:SetBackdropBorderColor(s.farbe[1], s.farbe[2], s.farbe[3], .4 + .6 * p)
    end
    if banZeit > 3.2 then s:Hide() end
end)
function NS.Hinweis(name, k)
    ban.farbe = k.farbe
    ban.t:SetText(("|cff%02x%02x%02x%s|r"):format(math.floor(k.farbe[1] * 255), math.floor(k.farbe[2] * 255), math.floor(k.farbe[3] * 255), name))
    local w = ban.t.GetStringWidth and ban.t:GetStringWidth() or 150
    if type(w) ~= "number" or w <= 0 then w = 150 end
    ban:SetWidth(w + 52)
    banZeit = 0; ban:SetAlpha(0); ban:Show()
    if NS.DB().ton and PlaySound then pcall(PlaySound, (SOUNDKIT and SOUNDKIT.MAP_PING) or 3175) end
end
