-- siikk-Farmhelfer · Minimap-Knopf
local ADDON, NS = ...
local L = siikkL or function(s) return s end
NS.Knopf = siikkMinimapKnopf("siikk-Farmhelfer", "|cffe03030siikk|r-|cffffd100Farmhelfer|r", NS.MEDIA .. "siikk_farm_icon",
    function() local db = NS.DB(); db.mm = db.mm or {}; return db.mm end,
    function() NS.Optionen() end,
    function() SlashCmdList.SIIKKFARM(NS.DB().taschen and "aus" or "an") end,
    { L"Linksklick: Einstellungen", L"Rechtsklick: Leuchten und Hinweise an/aus" }, 275)
