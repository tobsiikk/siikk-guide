-- siikk-Farmhelfer · „Was ist neu?“ – erzeugt aus tools/changelog.py (nicht von Hand ändern)
local L = siikkL or function(s) return s end
siikkNeu("siikk-Farmhelfer", "|cffe03030siikk|r-|cffffd100Farmhelfer|r", "Interface\\AddOns\\siikkFarm\\Media\\siikk_farm_icon", "1.2",
{
    { version = "1.2", datum = "07.11.2026", punkte = { L"Neu: Schriftgröße einstellbar – mit /schrift öffnet sich ein Fenster mit einem Regler für alle siikk-Addons und je einem pro Addon (70–160 %)." } },
    { version = "1.1", datum = "05.11.2026", punkte = { L"Forever: Fehler bei geschützten Tooltip-Zeilen behoben." } },
    { version = "1.0", datum = "02.11.2026", punkte = { L"Neues Addon: Kräuter, Erze & Steine, Stoff, Leder, Kochzutaten & Fisch, Elementar- und Verzauberkunst-Material leuchten in Taschen und Beutefenster – jede Sorte in eigener Farbe.", L"Im Tooltip steht, wofür der Gegenstand gut ist (z. B. Stoff – für Erste Hilfe & Schneiderei).", L"Hinweis mit Ton, wenn die Maus über einem Kraut, einer Erzader oder einem häutbaren Gegner ist.", L"Einstellungen mit /farm: welche Sorten, Taschen, Beute, Tooltip, Pulsieren, Hinweis und Ton." } }
}, function() return rawget(_G, "siikkFarm_DB") end, "/farm neu")
