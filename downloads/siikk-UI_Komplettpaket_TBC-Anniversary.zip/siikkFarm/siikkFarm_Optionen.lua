-- siikk-Farmhelfer · Einstellungen (/farm)
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local GOLD = { .85, .65, .15 }
local f

local function bauen()
    f = CreateFrame("Frame", "siikkFarmOptionen", UIParent, "BackdropTemplate")
    f:SetSize(460, 380); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG"); f:SetClampedToScreen(true)
    f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    f:SetBackdropColor(.03, .02, .05, .96); f:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
    f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
    tinsert(UISpecialFrames, "siikkFarmOptionen")
    local kopf = f:CreateTexture(nil, "BORDER"); kopf:SetPoint("TOPLEFT", 4, -4); kopf:SetPoint("TOPRIGHT", -4, -4); kopf:SetHeight(28); kopf:SetColorTexture(.315, .19, .45, .8)
    local ic = f:CreateTexture(nil, "OVERLAY"); ic:SetSize(22, 22); ic:SetPoint("LEFT", kopf, "LEFT", 6, 0); ic:SetTexture(NS.MEDIA .. "siikk_farm_icon")
    local tt = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); tt:SetPoint("LEFT", ic, "RIGHT", 6, 0); tt:SetText(L"|cffe03030siikk|r-|cffffd100Farmhelfer|r  |cff999999v" .. NS.VERSION .. "|r")
    local zu = CreateFrame("Button", nil, f, "UIPanelCloseButton"); zu:SetPoint("TOPRIGHT", 0, 0)
    f.haken = {}
    local function haken(x, y, text, get, set, farbe)
        local cb = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate"); cb:SetSize(24, 24); cb:SetPoint("TOPLEFT", x, y)
        cb.l = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); cb.l:SetPoint("LEFT", cb, "RIGHT", 4, 1); cb.l:SetWidth(180); cb.l:SetJustifyH("LEFT")
        cb.l:SetText(farbe and ("|cff%02x%02x%02x%s|r"):format(math.floor(farbe[1] * 255), math.floor(farbe[2] * 255), math.floor(farbe[3] * 255), text) or text)
        cb:SetScript("OnClick", function(s) set(s:GetChecked() and true or false); NS.Auffrischen() end)
        cb.get = get; f.haken[#f.haken + 1] = cb
    end
    local h1 = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); h1:SetPoint("TOPLEFT", 20, -44); h1:SetText(L"Diese Gegenstände leuchten auf:")
    for i, k in ipairs(NS.KATS) do
        local sp, zl = (i - 1) % 2, math.floor((i - 1) / 2)
        haken(18 + sp * 220, -62 - zl * 26, k.name, function() return NS.DB().kats[k.key] end, function(v) NS.DB().kats[k.key] = v end, k.farbe)
    end
    local h2 = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); h2:SetPoint("TOPLEFT", 20, -176); h2:SetText(L"Wo und wie:")
    local o = {
        { "taschen", L"In den Taschen leuchten" }, { "beute", L"Im Beutefenster leuchten" },
        { "tooltip", L"Im Tooltip sagen, wofür" }, { "pulsieren", L"Pulsieren (sonst fest)" },
        { "welt", L"Hinweis: Maus über Kraut/Erz/Kürschnern" }, { "ton", L"Ton beim Hinweis" },
    }
    for i, e in ipairs(o) do
        local sp, zl = (i - 1) % 2, math.floor((i - 1) / 2)
        haken(18 + sp * 220, -194 - zl * 26, e[2], function() return NS.DB()[e[1]] end, function(v) NS.DB()[e[1]] = v end)
    end
    local hinw = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); hinw:SetPoint("TOPLEFT", 20, -280); hinw:SetWidth(420); hinw:SetJustifyH("LEFT")
    hinw:SetText(L"Tipp: Blizzards Kräuter- und Erzsuche (Minimap) zeigt Fundorte. Fährst du mit der Maus über ein Kraut oder eine Ader, blinkt oben ein Hinweis mit dem Namen.")
    local t = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); t:SetSize(150, 22); t:SetPoint("BOTTOMLEFT", 14, 12); t:SetText(L"Hinweis testen")
    t:SetScript("OnClick", function() NS.Hinweis(L"Kupferader", NS.KAT.erz) end)
    local z = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); z:SetSize(120, 22); z:SetPoint("BOTTOMRIGHT", -14, 12); z:SetText(L"Schließen")
    z:SetScript("OnClick", function() f:Hide() end)
end

function NS.Optionen()
    if not f then bauen() end
    if f:IsShown() then f:Hide() return end
    for _, cb in ipairs(f.haken) do cb:SetChecked(cb.get() and true or false) end
    f:Show()
end
