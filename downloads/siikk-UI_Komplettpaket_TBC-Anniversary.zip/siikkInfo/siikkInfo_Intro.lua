-- siikk-Infoleiste · Einführung beim ersten Start (/il intro)
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local Y = "|cffffd100"
siikkIntro("siikk-Infoleiste", "|cffe03030siikk|r-|cffffd100Infoleiste|r", NS.MEDIA .. "siikk_info_icon", {
    { L"Willkommen bei der siikk-Infoleiste",
      L"Oben links siehst du jetzt eine kleine Leiste im siikk-Design mit allem Wichtigen auf einen Blick – nur so breit wie nötig.\n\n" ..
      "• " .. Y .. L"Maus darüber|r: jeder Eintrag zeigt ein Infofenster mit Details.\n\n" ..
      "• " .. Y .. L"Klicken|r: Ort öffnet die Weltkarte, Gold und Taschen öffnen die Taschen, die Uhr den Kalender.\n\n" ..
      "• " .. Y .. L"Ziehen|r: die Leiste mit der Maus an jeden Platz schieben (gesperrt: Shift + Ziehen)." },
    { L"Was die Leiste zeigt",
      "• " .. Y .. L"Ort|r mit Koordinaten – farbig: grün freundlich, rot feindlich, orange umkämpft, blau Zufluchtsort\n" ..
      "• " .. Y .. L"Gold|r – im Infofenster Gewinn dieser Sitzung und das Gold aller deiner Charaktere auf dem Realm\n" ..
      "• " .. Y .. L"Haltbarkeit|r – schlechtestes Teil in %, jedes Teil einzeln und die Reparaturkosten\n" ..
      "• " .. Y .. L"Taschen|r – freie Plätze\n" ..
      "• " .. Y .. L"Ehre|r – Ehren- und Arenapunkte, Siege heute und gesamt\n" ..
      L"• Auf Wunsch zusätzlich " .. Y .. L"FPS & Latenz|r und " .. Y .. L"Uhr|r (in den Einstellungen anhaken – die siikk-Oberfläche zeigt beides schon)" },
    { L"Erfahrung",
      L"Der Eintrag " .. Y .. L"Stufe|r zeigt deinen Fortschritt in % und den Erholungsbonus (lila).\n\n" ..
      L"Im Infofenster:\n" ..
      L"• Spielzeit gesamt, auf dieser Stufe und in dieser Sitzung\n" ..
      L"• EP dieser Stufe, Erholt, EP bis zur nächsten Stufe, EP dieser Sitzung\n" ..
      "• " .. Y .. L"Kills bis zur Stufe|r (nach deinem letzten Kill) und " .. Y .. L"Quests bis zur Stufe|r (nach deiner letzten Quest)\n" ..
      "• " .. Y .. L"EP pro Stunde|r und " .. Y .. L"Zeit bis zur Stufe|r – einmal im Tempo der ganzen Stufe, einmal im Tempo dieser Sitzung" },
    { L"Einstellungen & Befehle",
      L"Mit " .. Y .. L"/il|r oder Linksklick auf den Minimap-Knopf: jeden Eintrag einzeln an/aus, Leiste sperren, Position zurücksetzen, Deckkraft.\n\n" ..
      Y .. L"/il|r – Einstellungen\n" .. Y .. "/il an|r / " .. Y .. L"/il aus|r – Leiste an oder aus\n" .. Y .. L"/il sperren|r – Leiste festmachen · " .. Y .. L"/il reset|r – zurück nach oben links\n" ..
      Y .. L"/il intro|r – diese Einführung · " .. Y .. L"/il neu|r – was ist neu\n\n" ..
      L"Minimap-Knopf: " .. Y .. L"Linksklick|r Einstellungen · " .. Y .. L"Rechtsklick|r Leiste ein/aus · " .. Y .. L"Ziehen|r verschiebt den Knopf." },
}, function() return rawget(_G, "siikkInfo_DB") end, "/il intro")
