-- siikk-Infoleiste · Leiste am Bildschirmrand mit Ort, Gold, Haltbarkeit, Taschen, Ehre, Erfahrung, Leistung und Uhr
local ADDON, NS = ...
local L = siikkL or function(s) return s end
NS.VERSION = "1.3"
NS.MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\Media\\"
local Y, W, G, R, LILA = "|cffffd100", "|cffffffff", "|cff33ff33", "|cffff6060", "|cffb266ff"
local GOLD = { .85, .65, .15 }
function NS.msg(t) print(L"|cffe03030siikk|r-|cffffd100Infoleiste|r: " .. t) end

-- Einstellungen ------------------------------------------------------------
NS.BLOECKE = { "ort", "gold", "haltbarkeit", "taschen", "ehre", "erfahrung", "leistung", "uhr" }
NS.NAMEN = { ort = L"Ort & Koordinaten", gold = L"Gold", haltbarkeit = L"Haltbarkeit", taschen = L"Taschenplatz", ehre = L"Ehre",
    erfahrung = L"Erfahrung", leistung = L"FPS & Latenz", uhr = L"Uhr" }
local STANDARD = { an = true, alpha = .85, gesperrt = false }
local AUS = { leistung = true, uhr = true }   -- FPS/Latenz und Uhr zeigt die siikk-Oberfläche schon – standardmäßig aus
NS.STANDARD = STANDARD
function NS.DB()
    local db = rawget(_G, "siikkInfo_DB")
    if type(db) ~= "table" then db = {}; siikkInfo_DB = db end
    for k, v in pairs(STANDARD) do if db[k] == nil then db[k] = v end end
    db.zeigen = db.zeigen or {}
    for _, k in ipairs(NS.BLOECKE) do if db.zeigen[k] == nil then db.zeigen[k] = not AUS[k] end end
    if (db.v or 1) < 2 then   -- Umstieg von 1.0: kompakte Leiste, FPS/Uhr aus
        db.v = 2; db.zeigen.leistung = false; db.zeigen.uhr = false; db.pos = nil; db.platz = nil
    end
    db.chars = db.chars or {}
    return db
end

-- Formate ---------------------------------------------------------------
local function punkte(n)
    n = math.floor((n or 0) + .5)
    local neg = n < 0; if neg then n = -n end
    local s = tostring(n):reverse():gsub("(%d%d%d)", "%1."):reverse():gsub("^%.", "")
    return (neg and "-" or "") .. s
end
NS.punkte = punkte
local function prozent(a, b) if not b or b == 0 then return "0 %" end return (("%.1f"):format(a / b * 100):gsub("%.", ",")) .. " %" end
NS.prozent = prozent
local function zeit(s)
    if not s or s ~= s or s == math.huge or s < 0 then return "unbekannt" end
    s = math.floor(s)
    local t, h, m = math.floor(s / 86400), math.floor(s % 86400 / 3600), math.floor(s % 3600 / 60)
    local x = s % 60
    if t > 0 then return (L"%d T %d Std %d Min %d s"):format(t, h, m, x) end
    if h > 0 then return (L"%d Std %d Min %d s"):format(h, m, x) end
    if m > 0 then return (L"%d Min %d s"):format(m, x) end
    return x .. " s"
end
NS.zeit = zeit
local GI, SI, CI = "|TInterface\\MoneyFrame\\UI-GoldIcon:12:12:2:0|t", "|TInterface\\MoneyFrame\\UI-SilverIcon:12:12:2:0|t", "|TInterface\\MoneyFrame\\UI-CopperIcon:12:12:2:0|t"
local function geld(c, kurz)
    c = math.floor(c or 0); local neg = c < 0; if neg then c = -c end
    local g, s, k = math.floor(c / 10000), math.floor(c % 10000 / 100), c % 100
    local t
    if g > 0 then t = punkte(g) .. GI .. " " .. s .. SI .. (kurz and "" or (" " .. k .. CI))
    elseif s > 0 then t = s .. SI .. " " .. k .. CI
    else t = k .. CI end
    return (neg and "-" or "") .. t
end
NS.geld = geld
local function api(t, n) local tab = rawget(_G, t); return type(tab) == "table" and tab[n] or nil end

-- Leiste -----------------------------------------------------------------
local Leiste = CreateFrame("Frame", "siikkInfoLeiste", UIParent, "BackdropTemplate")
NS.Leiste = Leiste
Leiste:SetHeight(24); Leiste:SetFrameStrata("LOW"); Leiste:SetFrameLevel(5)
Leiste:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8" })
Leiste:SetMovable(true); Leiste:SetClampedToScreen(true); Leiste:EnableMouse(true); Leiste:RegisterForDrag("LeftButton")
local function ziehenStart() if not NS.DB().gesperrt or IsShiftKeyDown() then Leiste:StartMoving() end end
local function ziehenEnde()
    Leiste:StopMovingOrSizing()
    local p, _, rp, x, y = Leiste:GetPoint(1)
    NS.DB().punkt = { p, rp, x, y }
end
Leiste:SetScript("OnDragStart", ziehenStart); Leiste:SetScript("OnDragStop", ziehenEnde)
local B = {}   -- Blöcke nach Schlüssel
NS.B = B

local function anordnen()
    local db = NS.DB()
    -- nur so breit wie der Inhalt
    local x = 8
    for _, k in ipairs(NS.BLOECKE) do
        local b = B[k]
        if b and db.zeigen[k] then b:ClearAllPoints(); b:SetPoint("LEFT", Leiste, "LEFT", x, 0); b:Show(); x = x + b:GetWidth() + 16 elseif b then b:Hide() end
    end
    Leiste:SetWidth(math.max(40, x - 8))
end
NS.anordnen = anordnen

local function block(k, icon, tipp, klick, coords)
    local b = CreateFrame("Button", nil, Leiste); b:SetHeight(20); b:RegisterForClicks("AnyUp")
    b:RegisterForDrag("LeftButton"); b:SetScript("OnDragStart", ziehenStart); b:SetScript("OnDragStop", ziehenEnde)
    b.ic = b:CreateTexture(nil, "ARTWORK"); b.ic:SetSize(15, 15); b.ic:SetPoint("LEFT", 0, 0); b.ic:SetTexture(icon)
    if coords then b.ic:SetTexCoord(unpack(coords)) else b.ic:SetTexCoord(.08, .92, .08, .92) end
    b.t = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); b.t:SetPoint("LEFT", b.ic, "RIGHT", 4, 0)
    local hl = b:CreateTexture(nil, "HIGHLIGHT"); hl:SetAllPoints(); hl:SetColorTexture(1, .82, .1, .12)
    function b.setze(text)
        if b.alt == text then return end
        b.alt = text; b.t:SetText(text)
        local w = 0; local ok, sw = pcall(b.t.GetStringWidth, b.t); if ok and type(sw) == "number" then w = sw end
        local neu = math.floor(w + 21)
        if b.breite ~= neu then b.breite = neu; b:SetWidth(neu); anordnen() end
    end
    b:SetScript("OnEnter", function(s)
        local top = Leiste:GetTop(); local unten = top and UIParent:GetHeight() and top < UIParent:GetHeight() / 2
        GameTooltip:SetOwner(s, unten and "ANCHOR_TOP" or "ANCHOR_NONE")
        if not unten then GameTooltip:ClearAllPoints(); GameTooltip:SetPoint("TOPLEFT", s, "BOTTOMLEFT", 0, -6) end
        tipp(GameTooltip)
        GameTooltip:AddLine(NS.DB().gesperrt and L"Shift + Ziehen: Leiste verschieben" or L"Ziehen: Leiste verschieben", .45, .45, .45)
        GameTooltip:Show(); s.tippOffen = true
    end)
    b:SetScript("OnLeave", function(s) s.tippOffen = nil; GameTooltip:Hide() end)
    if klick then b:SetScript("OnClick", klick) end
    B[k] = b
    return b
end
local function tipKopf(tt, titel) tt:AddLine(titel, 1, .82, 0) end
local function zeile(tt, a, b, r, g, bl) tt:AddDoubleLine(a, b, 1, .82, 0, r or 1, g or 1, bl or 1) end

-- Ort & Koordinaten
local function koordinaten()
    local mapF, posF = api("C_Map", "GetBestMapForUnit"), api("C_Map", "GetPlayerMapPosition")
    if not (mapF and posF) then return end
    local ok, m = pcall(mapF, "player"); if not ok or not m then return end
    local ok2, p = pcall(posF, m, "player"); if not ok2 or type(p) ~= "table" then return end
    local ok3, x, y = pcall(p.GetXY, p); if not ok3 or not x or (x == 0 and y == 0) then return end
    return x * 100, y * 100
end
local PVPFARBE = { sanctuary = "|cff69ccf0", friendly = "|cff33ff33", hostile = "|cffff4040", contested = "|cffffa040", arena = "|cffff4040", combat = "|cffff4040" }
local function ortText()
    local z = (GetMinimapZoneText and GetMinimapZoneText()) or (GetZoneText and GetZoneText()) or "?"
    local pv = GetZonePVPInfo and GetZonePVPInfo()
    local x, y = koordinaten()
    return (PVPFARBE[pv or ""] or Y) .. z .. "|r" .. (x and (W .. " (" .. math.floor(x) .. ", " .. math.floor(y) .. ")|r") or "")
end
block("ort", "Interface\\Icons\\INV_Misc_Map_01", function(tt)
    tipKopf(tt, L"Ort")
    zeile(tt, L"Gebiet", (GetZoneText and GetZoneText()) or "?")
    local sub = GetSubZoneText and GetSubZoneText(); if sub and sub ~= "" then zeile(tt, L"Ort", sub) end
    local x, y = koordinaten()
    local function k(v) return (("%.1f"):format(v):gsub("%.", ",")) end
    zeile(tt, L"Koordinaten", x and (k(x) .. " / " .. k(y)) or L"– (in Instanzen nicht verfügbar)")
    local pv = GetZonePVPInfo and GetZonePVPInfo()
    local art = ({ sanctuary = L"Zufluchtsort", friendly = "freundlich", hostile = "feindlich", contested = L"umkämpft", arena = "Arena", combat = L"Kampfgebiet" })[pv or ""]
    if art then zeile(tt, L"Gebietsart", art) end
    tt:AddLine(" "); tt:AddLine(L"Linksklick: Weltkarte", .6, .6, .6)
end, function()
    if ToggleWorldMap then ToggleWorldMap() elseif WorldMapFrame then if WorldMapFrame:IsShown() then HideUIPanel(WorldMapFrame) else ShowUIPanel(WorldMapFrame) end end
end)

-- Gold
local start = { geld = nil }
local function charKey() return (GetRealmName and GetRealmName() or "?") .. " · " .. (UnitName("player") or "?") end
local function geldMerken()
    local db = NS.DB(); local _, kl = UnitClass("player")
    db.chars[charKey()] = { geld = GetMoney(), klasse = kl, realm = GetRealmName and GetRealmName(), name = UnitName("player"), fraktion = UnitFactionGroup and UnitFactionGroup("player") }
end
block("gold", "Interface\\MoneyFrame\\UI-GoldIcon", function(tt)
    tipKopf(tt, L"Gold")
    local jetzt = GetMoney()
    zeile(tt, L"Dieser Charakter", geld(jetzt))
    if start.geld then
        local d = jetzt - start.geld
        zeile(tt, L"Diese Sitzung", (d >= 0 and "+" or "") .. geld(d), d >= 0 and .3 or 1, d >= 0 and 1 or .4, d >= 0 and .3 or .4)
    end
    local realm = GetRealmName and GetRealmName()
    local liste, summe = {}, 0
    for _, c in pairs(NS.DB().chars) do if c.realm == realm then liste[#liste + 1] = c; summe = summe + (c.geld or 0) end end
    if #liste > 1 then
        table.sort(liste, function(a, b) return (a.geld or 0) > (b.geld or 0) end)
        tt:AddLine(" "); tt:AddLine(L"Alle Charaktere auf " .. (realm or "?"), 1, .82, 0)
        for _, c in ipairs(liste) do
            local f = (rawget(_G, "RAID_CLASS_COLORS") or {})[c.klasse or ""]
            tt:AddDoubleLine(c.name or "?", geld(c.geld), f and f.r or 1, f and f.g or 1, f and f.b or 1, 1, 1, 1)
        end
        zeile(tt, L"Gesamt", geld(summe))
    end
    tt:AddLine(" "); tt:AddLine(L"Linksklick: Taschen öffnen", .6, .6, .6)
end, function() if ToggleAllBags then ToggleAllBags() elseif OpenAllBags then OpenAllBags() end end, { 0, 1, 0, 1 })

-- Haltbarkeit
local SLOTS = { { 1, L"Kopf" }, { 3, L"Schultern" }, { 5, L"Brust" }, { 6, L"Taille" }, { 7, L"Beine" }, { 8, L"Füße" }, { 9, L"Handgelenke" }, { 10, L"Hände" }, { 16, L"Waffenhand" }, { 17, L"Schildhand" }, { 18, L"Distanz" } }
local scan
local function reparatur(slot)
    if not scan then scan = CreateFrame("GameTooltip", "siikkInfoScan", UIParent, "GameTooltipTemplate"); scan:SetOwner(UIParent, "ANCHOR_NONE") end
    local ok, _, _, kosten = pcall(scan.SetInventoryItem, scan, "player", slot)
    if ok and type(kosten) == "number" then return kosten end
    return 0
end
local function haltbarkeit()
    local min, alle = nil, {}
    for _, s in ipairs(SLOTS) do
        local c, m = GetInventoryItemDurability(s[1])
        if c and m and m > 0 then local p = c / m * 100; alle[#alle + 1] = { s[2], p, s[1] }; if not min or p < min then min = p end end
    end
    return min, alle
end
local function pFarbe(p) if p < 25 then return R elseif p < 60 then return "|cffffa040" end return G end
block("haltbarkeit", "Interface\\Icons\\Trade_BlackSmithing", function(tt)
    tipKopf(tt, L"Haltbarkeit")
    local _, alle = haltbarkeit()
    local kosten = 0
    for _, a in ipairs(alle) do
        local r, g, b = 1, 1, 1; if a[2] < 25 then r, g, b = 1, .4, .4 elseif a[2] < 60 then r, g, b = 1, .63, .25 end
        tt:AddDoubleLine(a[1], math.floor(a[2] + .5) .. " %", 1, .82, 0, r, g, b)
        kosten = kosten + reparatur(a[3])
    end
    if #alle == 0 then tt:AddLine(L"Keine Ausrüstung mit Haltbarkeit angelegt.", .7, .7, .7) end
    if kosten > 0 then tt:AddLine(" "); zeile(tt, L"Reparatur ca.", geld(kosten)) end
end)

-- Taschen
local function frei()
    local f, gesamt = 0, 0
    for bag = 0, 4 do
        local n, typ
        if C_Container and C_Container.GetContainerNumFreeSlots then n, typ = C_Container.GetContainerNumFreeSlots(bag) else n, typ = GetContainerNumFreeSlots(bag) end
        local slots = (C_Container and C_Container.GetContainerNumSlots) and C_Container.GetContainerNumSlots(bag) or (GetContainerNumSlots and GetContainerNumSlots(bag)) or 0
        if (typ or 0) == 0 then f = f + (n or 0); gesamt = gesamt + (slots or 0) end
    end
    return f, gesamt
end
block("taschen", "Interface\\Icons\\INV_Misc_Bag_08", function(tt)
    tipKopf(tt, L"Taschen")
    local f, g = frei()
    zeile(tt, L"Freie Plätze", f .. " von " .. g)
    tt:AddLine(" "); tt:AddLine(L"Linksklick: Taschen öffnen", .6, .6, .6)
end, function() if ToggleAllBags then ToggleAllBags() elseif OpenAllBags then OpenAllBags() end end)

-- Ehre
local function waehrung(ids, namen)
    local ci = api("C_CurrencyInfo", "GetCurrencyInfo")
    if ci then for _, id in ipairs(ids) do local ok, t = pcall(ci, id); if ok and type(t) == "table" and t.name and t.name ~= "" then return t.quantity or 0 end end end
    -- Suche in der Währungsliste nach dem Namen
    local n = api("C_CurrencyInfo", "GetCurrencyListSize"); local li = api("C_CurrencyInfo", "GetCurrencyListInfo")
    if n and li then
        local ok, anz = pcall(n)
        for i = 1, (ok and anz or 0) do
            local ok2, t = pcall(li, i)
            if ok2 and type(t) == "table" and t.name and not t.isHeader then
                for _, nm in ipairs(namen) do if t.name == nm then return t.quantity or 0 end end
            end
        end
    end
end
local function ehre()
    if GetHonorCurrency then local ok, v = pcall(GetHonorCurrency); if ok and type(v) == "number" then return v end end
    local retail = WOW_PROJECT_ID and WOW_PROJECT_MAINLINE and WOW_PROJECT_ID == WOW_PROJECT_MAINLINE
    return waehrung(retail and { 1792 } or { 1901 }, { "Ehrenpunkte", "Ehre", "Honor Points", "Honor" })
end
local function arena()
    if GetArenaCurrency then local ok, v = pcall(GetArenaCurrency); if ok and type(v) == "number" then return v end end
    if WOW_PROJECT_ID and WOW_PROJECT_MAINLINE and WOW_PROJECT_ID == WOW_PROJECT_MAINLINE then return end
    return waehrung({ 1900 }, { "Arenapunkte", "Arena Points" })
end
local function pvpIcon() return (UnitFactionGroup and UnitFactionGroup("player") == "Alliance") and "Interface\\TargetingFrame\\UI-PVP-Alliance" or "Interface\\TargetingFrame\\UI-PVP-Horde" end
block("ehre", pvpIcon(), function(tt)
    tipKopf(tt, L"Ehre")
    local e = ehre(); zeile(tt, L"Ehrenpunkte", e and punkte(e) or "–")
    local a = arena(); if a then zeile(tt, L"Arenapunkte", punkte(a)) end
    if GetPVPSessionStats then local ok, hk = pcall(GetPVPSessionStats); if ok and hk then zeile(tt, L"Ehrenhafte Siege heute", punkte(hk)) end end
    if GetPVPLifetimeStats then local ok, hk = pcall(GetPVPLifetimeStats); if ok and hk then zeile(tt, L"Ehrenhafte Siege gesamt", punkte(hk)) end end
end, nil, { 0, .62, 0, .62 })

-- Erfahrung
local XP = { sitzungStart = GetTime(), sitzungEP = 0, letzteEP = nil, letzteMax = nil, kill = nil, quest = nil,
    gesamt = nil, stufe = nil, basis = nil }
NS.XP = XP
local function maxStufe()
    if IsXPUserDisabled and IsXPUserDisabled() then return true end
    local m = (GetMaxPlayerLevel and GetMaxPlayerLevel()) or rawget(_G, "MAX_PLAYER_LEVEL")
    return type(m) == "number" and UnitLevel("player") >= m
end
local function gespielt()   -- Gesamt, diese Stufe (Sekunden, laufend)
    if not XP.basis then return nil, nil end
    local d = GetTime() - XP.basis
    return XP.gesamt + d, XP.stufe + d
end
NS.gespielt = gespielt
local function erfahrungText()
    if maxStufe() then return Y .. L"Stufe " .. UnitLevel("player") .. "|r " .. W .. L"(max)|r" end
    local cur, max = UnitXP("player"), UnitXPMax("player")
    local rest = GetXPExhaustion and GetXPExhaustion() or nil
    return Y .. L"Stufe " .. UnitLevel("player") .. "|r " .. W .. prozent(cur, max) .. "|r" .. (rest and rest > 0 and (" " .. LILA .. "+" .. prozent(rest, max) .. " erholt|r") or "")
end
local function proStunde(ep, sek) if not sek or sek < 60 then return 0 end return ep / sek * 3600 end
block("erfahrung", "Interface\\Icons\\Spell_Holy_HolyBolt", function(tt)
    tipKopf(tt, L"Erfahrung")
    local gesamt, stufe = gespielt()
    local sitzung = GetTime() - XP.sitzungStart
    zeile(tt, L"Spielzeit gesamt", gesamt and zeit(gesamt) or L"wird abgefragt …")
    zeile(tt, L"Spielzeit diese Stufe", stufe and zeit(stufe) or L"wird abgefragt …")
    zeile(tt, L"Spielzeit diese Sitzung", zeit(sitzung))
    if maxStufe() then tt:AddLine(" "); tt:AddLine(L"Du hast die höchste Stufe erreicht.", .6, 1, .6); return end
    local cur, max = UnitXP("player"), UnitXPMax("player")
    local rest = (GetXPExhaustion and GetXPExhaustion()) or 0
    local fehlt = max - cur
    tt:AddLine(" ")
    zeile(tt, L"EP für diese Stufe", punkte(max))
    zeile(tt, L"Erholt", punkte(rest) .. (rest > 0 and (" (" .. prozent(rest, max) .. ")") or ""), .7, .45, 1)
    zeile(tt, L"EP diese Stufe", punkte(cur) .. " (" .. prozent(cur, max) .. ")")
    zeile(tt, L"EP bis zur nächsten Stufe", punkte(fehlt) .. " (" .. prozent(fehlt, max) .. ")")
    zeile(tt, L"EP diese Sitzung", punkte(XP.sitzungEP))
    zeile(tt, L"Kills bis zur Stufe", XP.kill and (punkte(math.ceil(fehlt / XP.kill)) .. L"  |cff999999(letzter Kill " .. punkte(XP.kill) .. " EP)|r") or "unbekannt")
    zeile(tt, L"Quests bis zur Stufe", XP.quest and (punkte(math.ceil(fehlt / XP.quest)) .. L"  |cff999999(letzte Quest " .. punkte(XP.quest) .. " EP)|r") or "unbekannt")
    tt:AddLine(" ")
    local rStufe = stufe and proStunde(cur, stufe) or 0
    local rSitz = proStunde(XP.sitzungEP, sitzung)
    zeile(tt, L"EP pro Stunde (diese Stufe)", stufe and punkte(rStufe) or "–")
    zeile(tt, L"EP pro Stunde (diese Sitzung)", punkte(rSitz))
    zeile(tt, L"Zeit bis zur Stufe (Stufentempo)", rStufe > 0 and zeit(fehlt / rStufe * 3600) or "unbekannt", .3, 1, .3)
    zeile(tt, L"Zeit bis zur Stufe (Sitzungstempo)", rSitz > 0 and zeit(fehlt / rSitz * 3600) or "unbekannt", .3, 1, .3)
end)

-- Leistung
local function speicherTop()
    local A = rawget(_G, "C_AddOns") or {}
    local upd = rawget(_G, "UpdateAddOnMemoryUsage"); local mem = rawget(_G, "GetAddOnMemoryUsage")
    local num = A.GetNumAddOns or rawget(_G, "GetNumAddOns"); local info = A.GetAddOnInfo or rawget(_G, "GetAddOnInfo")
    local loaded = A.IsAddOnLoaded or rawget(_G, "IsAddOnLoaded")
    if not (upd and mem and num and info) then return {}, 0 end
    pcall(upd)
    local t, summe = {}, 0
    for i = 1, num() do
        local n, titel = info(i)
        if n and (not loaded or loaded(i)) then local ok, kb = pcall(mem, i); if ok and type(kb) == "number" and kb > 0 then t[#t + 1] = { (titel and titel ~= "" and titel) or n, kb }; summe = summe + kb end end
    end
    table.sort(t, function(a, b) return a[2] > b[2] end)
    return t, summe
end
local function mb(kb) if kb >= 1024 then return (("%.1f"):format(kb / 1024):gsub("%.", ",")) .. " MB" end return math.floor(kb) .. " KB" end
local function msFarbe(ms) if ms > 300 then return R elseif ms > 150 then return "|cffffa040" end return G end
block("leistung", "Interface\\Icons\\Spell_Nature_Lightning", function(tt)
    tipKopf(tt, L"Leistung")
    local _, _, heim, welt = GetNetStats()
    zeile(tt, L"Bilder pro Sekunde", math.floor(GetFramerate() + .5) .. " fps")
    zeile(tt, L"Latenz (Chat, Handel)", (heim or 0) .. " ms")
    zeile(tt, L"Latenz (Kampf, Welt)", (welt or heim or 0) .. " ms")
    local t, summe = speicherTop()
    if #t > 0 then
        tt:AddLine(" "); zeile(tt, L"Speicher aller Addons", mb(summe))
        for i = 1, math.min(8, #t) do tt:AddDoubleLine("   " .. t[i][1], mb(t[i][2]), .8, .8, .8, 1, 1, 1) end
    end
end)

-- Uhr
local TAGE = { L"Sonntag", L"Montag", L"Dienstag", L"Mittwoch", L"Donnerstag", L"Freitag", L"Samstag" }
block("uhr", "Interface\\Icons\\INV_Misc_PocketWatch_01", function(tt)
    tipKopf(tt, L"Uhr")
    local d = date("*t")
    zeile(tt, L"Heute", TAGE[d.wday] .. ", " .. date("%d.%m.%Y"))
    zeile(tt, L"Ortszeit", date("%H:%M:%S"))
    if GetGameTime then local h, m = GetGameTime(); zeile(tt, L"Serverzeit", ("%02d:%02d"):format(h, m)) end
    if ToggleCalendar then tt:AddLine(" "); tt:AddLine(L"Linksklick: Kalender", .6, .6, .6) end
end, function() if ToggleCalendar then pcall(ToggleCalendar) end end)

-- Aktualisieren -----------------------------------------------------------
function NS.Aktualisieren(nur)
    local db = NS.DB()
    if (not nur or nur == "ort") and db.zeigen.ort then B.ort.setze(ortText()) end
    if (not nur or nur == "gold") and db.zeigen.gold then B.gold.setze(W .. geld(GetMoney(), true) .. "|r") end
    if (not nur or nur == "haltbarkeit") and db.zeigen.haltbarkeit then
        local m = haltbarkeit(); B.haltbarkeit.setze(m and (pFarbe(m) .. math.floor(m + .5) .. " %|r") or (W .. "–|r"))
    end
    if (not nur or nur == "taschen") and db.zeigen.taschen then
        local f, g = frei(); B.taschen.setze((f <= 3 and R or W) .. f .. "|r|cff999999/" .. g .. "|r")
    end
    if (not nur or nur == "ehre") and db.zeigen.ehre then local e = ehre(); B.ehre.setze(W .. (e and punkte(e) or "–") .. "|r") end
    if (not nur or nur == "erfahrung") and db.zeigen.erfahrung then B.erfahrung.setze(erfahrungText()) end
    if (not nur or nur == "leistung") and db.zeigen.leistung then
        local _, _, heim, welt = GetNetStats(); local ms = math.max(heim or 0, welt or 0)
        B.leistung.setze(W .. math.floor(GetFramerate() + .5) .. "|r|cff999999 fps|r  " .. msFarbe(ms) .. ms .. "|r|cff999999 ms|r")
    end
    if (not nur or nur == "uhr") and db.zeigen.uhr then B.uhr.setze(W .. date("%H:%M") .. "|r") end
end

-- Position und Aussehen
function NS.Aussehen()
    local db = NS.DB()
    Leiste:ClearAllPoints()
    local pt = db.punkt
    if type(pt) == "table" and pt[1] then Leiste:SetPoint(pt[1], UIParent, pt[2], pt[3], pt[4])
    else Leiste:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 4, -4) end
    Leiste:SetBackdropColor(.03, .02, .05, db.alpha)
    Leiste:SetShown(db.an)
    anordnen()
end
function NS.Umschalten(an)
    local db = NS.DB(); if an == nil then an = not db.an end
    db.an = an; NS.Aussehen()
    NS.msg(an and L"Leiste |cff33ff33an|r." or L"Leiste |cffff6060aus|r.")
    if NS.OptAktualisieren then NS.OptAktualisieren() end
end

-- Spielzeit leise abfragen (ohne die Chat-Meldung)
local leise = false
local function spielzeitAbfragen()
    if not RequestTimePlayed then return end
    leise = true
    local alt = rawget(_G, "ChatFrame_DisplayTimePlayed")
    if alt then ChatFrame_DisplayTimePlayed = function() end; NS.altDisplay = alt end
    RequestTimePlayed()
end

-- EP-Meldungen: letzter Kill / letzte Quest (aus den Blizzard-Texten, damit jede Sprache passt)
local function muster(fmt)
    if type(fmt) ~= "string" then return end
    local p = fmt:gsub("%%(%d?)%$?([sd])", "\001%2")
    p = p:gsub("[%(%)%.%+%-%*%?%[%]%^%$%%]", "%%%0")
    p = p:gsub("\001s", "(.-)"):gsub("\001d", "(%%d+)")
    return "^" .. p
end
local function zahlAus(text, fmt)
    local m = muster(fmt); if not m then return end
    local a, b, c = text:match(m)
    for _, v in ipairs({ a, b, c }) do local n = tonumber(v); if n then return n end end
end
function NS.EPMeldung(text)
    if type(text) ~= "string" then return end
    local n = zahlAus(text, rawget(_G, "COMBATLOG_XPGAIN_FIRSTPERSON")) or zahlAus(text, rawget(_G, "COMBATLOG_XPGAIN_EXHAUSTION1"))
    if n then XP.kill = n return end
    n = zahlAus(text, rawget(_G, "COMBATLOG_XPGAIN_FIRSTPERSON_UNNAMED")) or zahlAus(text, rawget(_G, "COMBATLOG_XPGAIN_QUEST"))
    if n then XP.quest = n end
end

local ev = CreateFrame("Frame")
for _, e in ipairs({ "PLAYER_LOGIN", "PLAYER_ENTERING_WORLD", "ZONE_CHANGED", "ZONE_CHANGED_INDOORS", "ZONE_CHANGED_NEW_AREA", "PLAYER_MONEY",
    "UPDATE_INVENTORY_DURABILITY", "BAG_UPDATE", "PLAYER_XP_UPDATE", "PLAYER_LEVEL_UP", "UPDATE_EXHAUSTION", "TIME_PLAYED_MSG",
    "CHAT_MSG_COMBAT_XP_GAIN", "HONOR_CURRENCY_UPDATE", "CURRENCY_DISPLAY_UPDATE", "PLAYER_PVP_KILLS_CHANGED" }) do
    pcall(ev.RegisterEvent, ev, e)
end
ev:SetScript("OnEvent", function(_, e, a1, a2)
    if e == "PLAYER_LOGIN" then
        start.geld = GetMoney(); XP.letzteEP, XP.letzteMax = UnitXP("player"), UnitXPMax("player")
        B.ehre.ic:SetTexture(pvpIcon())
        geldMerken(); NS.Aussehen(); NS.Aktualisieren()
        if C_Timer then C_Timer.After(3, spielzeitAbfragen) end
    elseif e == "PLAYER_ENTERING_WORLD" or e:find("^ZONE_") then NS.Aktualisieren("ort")
    elseif e == "PLAYER_MONEY" then geldMerken(); NS.Aktualisieren("gold")
    elseif e == "UPDATE_INVENTORY_DURABILITY" then NS.Aktualisieren("haltbarkeit")
    elseif e == "BAG_UPDATE" then NS.Aktualisieren("taschen")
    elseif e == "PLAYER_XP_UPDATE" then
        local cur, max = UnitXP("player"), UnitXPMax("player")
        if XP.letzteEP then
            local g = (cur >= XP.letzteEP) and (cur - XP.letzteEP) or ((XP.letzteMax or 0) - XP.letzteEP + cur)
            if g > 0 then XP.sitzungEP = XP.sitzungEP + g end
        end
        XP.letzteEP, XP.letzteMax = cur, max
        NS.Aktualisieren("erfahrung")
    elseif e == "PLAYER_LEVEL_UP" then
        if XP.basis then local g = gespielt(); XP.gesamt, XP.stufe, XP.basis = g, 0, GetTime() end
        NS.Aktualisieren("erfahrung")
    elseif e == "UPDATE_EXHAUSTION" then NS.Aktualisieren("erfahrung")
    elseif e == "TIME_PLAYED_MSG" then
        XP.gesamt, XP.stufe, XP.basis = a1 or 0, a2 or 0, GetTime()
        if leise then leise = false; if NS.altDisplay then local alt = NS.altDisplay; NS.altDisplay = nil; if C_Timer then C_Timer.After(0, function() ChatFrame_DisplayTimePlayed = alt end) else ChatFrame_DisplayTimePlayed = alt end end end
    elseif e == "CHAT_MSG_COMBAT_XP_GAIN" then NS.EPMeldung(a1)
    else NS.Aktualisieren("ehre") end
end)

-- regelmäßig: Koordinaten (0,2 s), Uhr und Leistung (1 s); offene Tooltips frisch halten
local t1, t2 = 0, 0
Leiste:SetScript("OnUpdate", function(_, el)
    t1 = t1 + el; t2 = t2 + el
    if t1 >= .2 then t1 = 0; if NS.DB().zeigen.ort then B.ort.setze(ortText()) end end
    if t2 >= 1 then
        t2 = 0; NS.Aktualisieren("leistung"); NS.Aktualisieren("uhr")
        for _, b in pairs(B) do if b.tippOffen and b:IsMouseOver() then local f = b:GetScript("OnEnter"); f(b) end end
    end
end)

-- Befehle -----------------------------------------------------------------
SLASH_SIIKKINFO1 = "/infoleiste"; SLASH_SIIKKINFO2 = "/il"
SlashCmdList.SIIKKINFO = function(m)
    m = (m or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    if m == "" then if NS.Optionen then NS.Optionen() end
    elseif m == "an" then NS.Umschalten(true)
    elseif m == "aus" then NS.Umschalten(false)
    elseif m == "reset" then NS.DB().punkt = nil; NS.Aussehen(); NS.msg(L"Leiste wieder oben links.")
    elseif m == "sperren" then local db = NS.DB(); db.gesperrt = not db.gesperrt; NS.msg(db.gesperrt and L"Leiste gesperrt (Shift + Ziehen verschiebt trotzdem)." or L"Leiste entsperrt – einfach ziehen."); if NS.OptAktualisieren then NS.OptAktualisieren() end
    elseif m == "intro" then local f = SiikkIntroAPI and SiikkIntroAPI["siikk-Infoleiste"]; if f then f() end
    elseif m == "neu" then local f = SiikkNeuAPI and SiikkNeuAPI["siikk-Infoleiste"]; if f then f() end
    else
        NS.msg(L"Befehle:")
        print(Y .. L"/il|r – Einstellungen · " .. Y .. "/il an|r / " .. Y .. L"aus|r – Leiste an/aus · " .. Y .. L"/il sperren|r – festmachen · " .. Y .. L"/il reset|r – zurück nach oben links")
        print(Y .. L"/il intro|r – Einführung · " .. Y .. L"/il neu|r – was ist neu")
    end
end
