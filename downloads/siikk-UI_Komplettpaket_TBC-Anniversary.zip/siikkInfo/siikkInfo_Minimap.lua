-- siikk-Infoleiste · eigener Minimap-Knopf
local ADDON, NS = ...
local L = siikkL or function(s) return s end
siikkMinimapKnopf("siikk-Infoleiste", "|cffe03030siikk|r-|cffffd100Infoleiste|r", NS.MEDIA .. "siikk_info_icon",
    function() local db = NS.DB(); db.mm = db.mm or {}; return db.mm end,
    function() NS.Optionen() end,
    function() NS.Umschalten() end,
    { L"Linksklick: Einstellungen", L"Rechtsklick: Leiste ein/aus" }, 330)
