-- siikk-Infoleiste · „Was ist neu?“ – erzeugt aus tools/changelog.py (nicht von Hand ändern)
local L = siikkL or function(s) return s end
siikkNeu("siikk-Infoleiste", "|cffe03030siikk|r-|cffffd100Infoleiste|r", "Interface\\AddOns\\siikkInfo\\Media\\siikk_info_icon", "1.3",
{
    { version = "1.3", datum = "02.11.2026", punkte = { L"Neu: Sprache wählbar – Deutsch, English, Русский, Français, Español. Mit /sprache für alle siikk-Addons auf einmal umschalten (startet in der Sprache deines WoW)." } },
    { version = "1.2", datum = "31.10.2026", punkte = { L"Leiste ohne goldenen Rand – nur noch der dunkle, leicht durchsichtige Hintergrund." } },
    { version = "1.1", datum = "31.10.2026", punkte = { L"Leiste ist jetzt nur so breit wie ihr Inhalt, mit Goldrand – sie geht nicht mehr über den ganzen Bildschirm.", L"Frei verschiebbar: einfach ziehen (/il sperren macht sie fest, /il reset bringt sie zurück nach oben links).", L"FPS, Latenz und Uhr sind standardmäßig aus (zeigt die siikk-Oberfläche schon) – in den Einstellungen wieder anhakbar.", L"Minimap und Buffs werden nicht mehr verschoben.", L"Ehre: Ehren- und Arenapunkte werden jetzt auch in TBC Anniversary gefunden." } },
    { version = "1.0", datum = "31.10.2026", punkte = { L"Neues Addon: Infoleiste oben am Bildschirm im siikk-Design.", L"Ort mit Koordinaten, Gold (mit Sitzungsgewinn und allen Charakteren), Haltbarkeit mit Reparaturkosten, freie Taschenplätze, Ehre, FPS & Latenz, Uhr.", L"Erfahrung mit großem Infofenster: Spielzeit, EP, Erholt, Kills und Quests bis zur Stufe, EP pro Stunde und Zeit bis zur Stufe.", L"Einstellungen mit /il – oben oder unten, jeder Eintrag einzeln an/aus, Deckkraft." } }
}, function() return rawget(_G, "siikkInfo_DB") end, "/il neu")
