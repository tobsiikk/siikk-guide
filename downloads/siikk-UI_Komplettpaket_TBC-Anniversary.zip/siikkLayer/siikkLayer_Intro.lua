-- siikk-Layer · Einführung beim ersten Start (/layer intro)
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local Y = "|cffffd100"
siikkIntro("siikk-Layer", "|cffe03030siikk|r-|cffffd100Layer|r", NS.MEDIA .. "siikk_layer_icon", {
    { L"Willkommen bei siikk-Layer",
      L"In WoW Forever gibt es keine festen Realms mehr. Damit nicht zu viele Spieler an einem Ort sind, teilt das Spiel die Welt in mehrere Kopien – die " .. Y .. L"Layer|r.\n\n" ..
      L"siikk-Layer zeigt dir, auf welchem Layer du gerade bist. Die kleine Anzeige sitzt unter der Minimap, zum Beispiel: " .. Y .. L"Layer 18853|r.\n\n" ..
      L"• Wechselst du den Layer (z. B. weil dich jemand in die Gruppe einlädt), bekommst du einen Hinweis und die Anzeige leuchtet kurz grün." },
    { L"So wird gemessen",
      L"Jeder NPC trägt eine Kennung, in der die Nummer seines Layers steckt. siikk-Layer liest sie, wenn du einen NPC ins Ziel nimmst, mit der Maus darüberfährst oder seine Namensplakette siehst.\n\n" ..
      L"• Sobald " .. Y .. L"zwei verschiedene NPCs|r dieselbe Nummer liefern, steht der Layer fest.\n\n" ..
      L"• Die Nummer gilt immer für eine Zone. In einer anderen Zone hat derselbe Layer eine andere Nummer – nach einem Zonenwechsel wird neu gemessen.\n\n" ..
      L"• In Dungeons und Schlachtfeldern gibt es keine Layer." },
    { L"Mit der Gilde",
      L"Haben deine Gildenmitglieder oder deine Gruppe auch siikk-Layer, seht ihr gegenseitig, wer in derselben Zone auf welchem Layer ist – im Tooltip der Anzeige und mit " .. Y .. L"/layer|r.\n\n" ..
      L"• Die Anzeige zeigt dann auch „2/3“: dein Layer ist der zweite von drei bekannten in dieser Zone.\n\n" ..
      L"• Teilen kannst du in den Einstellungen abschalten." },
    { L"Befehle",
      Y .. L"/layer|r – aktuellen Layer und Gildenmitglieder im Chat\n" .. Y .. L"/layer optionen|r – Einstellungen\n" ..
      Y .. L"/layer leiste|r – Anzeige ein/aus · " .. Y .. L"/layer sperren|r – Anzeige fest/verschiebbar\n" ..
      Y .. L"/layer reset|r – neu messen\n" .. Y .. L"/layer intro|r – diese Einführung · " .. Y .. L"/layer neu|r – was ist neu\n\n" ..
      L"Anzeige: " .. Y .. L"Linksklick|r = im Chat ausgeben, " .. Y .. L"Rechtsklick|r = Einstellungen, " .. Y .. L"Ziehen|r = verschieben." },
}, function() return rawget(_G, "siikkLayer_DB") end, "/layer intro")
