-- siikk-Layer · kleine Anzeige „Layer 18853“ (verschiebbar) mit Tooltip
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local Y, G, GR, LILA = "|cffffd100", "|cff33ff33", "|cff999999", "|cffb98cff"

local f = CreateFrame("Button", "siikkLayerLeiste", UIParent, "BackdropTemplate")
f:SetSize(120, 22); f:SetFrameStrata("MEDIUM"); f:SetClampedToScreen(true); f:Hide()
f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
f:SetBackdropColor(.03, .02, .05, .82); f:SetBackdropBorderColor(0, 0, 0, .9)
f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton"); f:RegisterForClicks("LeftButtonUp", "RightButtonUp")
local ic = f:CreateTexture(nil, "ARTWORK"); ic:SetSize(16, 16); ic:SetPoint("LEFT", 4, 0); ic:SetTexture(NS.MEDIA .. "siikk_layer_icon")
local tx = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); tx:SetPoint("LEFT", ic, "RIGHT", 5, 0)
local glanz = f:CreateTexture(nil, "OVERLAY"); glanz:SetAllPoints(); glanz:SetColorTexture(.2, 1, .3, 0)
NS.Leiste = f

local function position()
    local p = NS.DB().pos
    f:ClearAllPoints()
    if type(p) == "table" and p[1] then f:SetPoint(p[1], UIParent, p[1], p[2] or 0, p[3] or 0)
    else f:SetPoint("TOP", Minimap, "BOTTOM", 0, -18) end
end
f:SetScript("OnDragStart", function(s) if not NS.DB().gesperrt then s:StartMoving() end end)
f:SetScript("OnDragStop", function(s)
    s:StopMovingOrSizing()
    local p, _, _, x, y = s:GetPoint()
    NS.DB().pos = { p or "CENTER", x or 0, y or 0 }
end)
f:SetScript("OnClick", function(_, btn)
    if btn == "RightButton" then if NS.Optionen then NS.Optionen() end else NS.Info() end
end)

local function tooltip(s)
    GameTooltip:SetOwner(s, "ANCHOR_BOTTOM")
    GameTooltip:AddLine(L"|cffe03030siikk|r-|cffffd100Layer|r")
    local st = NS.Stand()
    if st.instanz then GameTooltip:AddLine(L"In Dungeons und Schlachtfeldern gibt es keine Layer.", .8, .8, .8, true)
    elseif not st.id then
        GameTooltip:AddLine(L"Noch nicht erkannt.", 1, .4, .4)
        GameTooltip:AddLine(L"Fahr mit der Maus über zwei NPCs oder nimm sie ins Ziel – dann steht der Layer fest.", .8, .8, .8, true)
    else
        GameTooltip:AddDoubleLine(L"Zone", st.zone or "?", .8, .8, .8, 1, 1, 1)
        GameTooltip:AddDoubleLine(L"Layer-ID", tostring(st.id), .8, .8, .8, .2, 1, .2)
        local nr, von = NS.Nummer()
        if von and von > 1 then GameTooltip:AddDoubleLine(L"Bekannte Layer hier", (L"%d von %d"):format(nr, von), .8, .8, .8, 1, 1, 1) end
        GameTooltip:AddDoubleLine(L"Gemessene NPCs", tostring(st.beobachtet or 0), .8, .8, .8, 1, 1, 1)
    end
    local gleich, anders = NS.AndereHier()
    if #gleich > 0 or #anders > 0 then
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine(L"Gilde und Gruppe in dieser Zone", 1, .82, 0)
        if #gleich > 0 then GameTooltip:AddLine(G .. L"Gleicher Layer:|r " .. table.concat(gleich, ", "), 1, 1, 1, true) end
        for _, a in ipairs(anders) do GameTooltip:AddLine((L"|cffff9933Layer %s:|r %s"):format(a.id, a.name), 1, 1, 1, true) end
    end
    if #NS.verlauf > 0 then
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine(L"Letzte Layerwechsel", 1, .82, 0)
        for i = #NS.verlauf, math.max(1, #NS.verlauf - 3), -1 do
            local v = NS.verlauf[i]
            GameTooltip:AddLine(("%s  %s: %s → %s"):format(v.zeit, v.zone or "?", v.alt, v.neu), .8, .8, .8)
        end
    end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine(L"Linksklick: im Chat ausgeben · Rechtsklick: Einstellungen", .6, .6, .6)
    if not NS.DB().gesperrt then GameTooltip:AddLine(L"Ziehen: verschieben", .6, .6, .6) end
    GameTooltip:Show()
end
f:SetScript("OnEnter", tooltip)
f:SetScript("OnLeave", function() GameTooltip:Hide() end)

function NS.Anzeigen()
    local db = NS.DB()
    if not db.leiste then f:Hide() return end
    local st = NS.Stand()
    local t
    if st.instanz then t = GR .. L"Layer: Instanz|r"
    elseif st.id then
        local nr, von = NS.Nummer()
        t = LILA .. L"Layer|r " .. G .. st.id .. "|r" .. ((von and von > 1) and (GR .. " (" .. nr .. "/" .. von .. ")|r") or "")
    else t = LILA .. L"Layer|r " .. GR .. "?|r" end
    tx:SetText(t)
    local w = tx.GetStringWidth and tx:GetStringWidth() or 80
    if type(w) ~= "number" or w <= 0 then w = 80 end
    f:SetWidth(w + 32)
    f:Show()
    local ok, ueber = pcall(function() return f:IsMouseOver() and GameTooltip:IsOwned(f) end)
    if ok and ueber == true then tooltip(f) end
end

-- kurzes grünes Aufleuchten bei einem Layerwechsel
local blink = 0
f:SetScript("OnUpdate", function(_, el)
    if blink <= 0 then return end
    blink = blink - el
    glanz:SetColorTexture(.2, 1, .3, math.max(0, blink) * .35)
end)
function NS.Blinken() blink = 1.6 end

local ev = CreateFrame("Frame"); ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function() position(); NS.Anzeigen() end)
NS.LeistePosition = position
