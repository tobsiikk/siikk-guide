-- siikk-Layer · Minimap-Knopf
local ADDON, NS = ...
local L = siikkL or function(s) return s end
NS.Knopf = siikkMinimapKnopf("siikk-Layer", "|cffe03030siikk|r-|cffffd100Layer|r", NS.MEDIA .. "siikk_layer_icon",
    function() local db = NS.DB(); db.mm = db.mm or {}; return db.mm end,
    function() NS.Info() end,
    function() NS.Optionen() end,
    { L"Linksklick: aktuellen Layer im Chat ausgeben", L"Rechtsklick: Einstellungen" }, 250)
