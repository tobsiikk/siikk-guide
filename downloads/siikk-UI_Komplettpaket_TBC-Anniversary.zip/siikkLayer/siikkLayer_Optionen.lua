-- siikk-Layer · Einstellungen
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local GOLD = { .85, .65, .15 }
local f

local function bauen()
    f = CreateFrame("Frame", "siikkLayerOptionen", UIParent, "BackdropTemplate")
    f:SetSize(400, 250); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG"); f:SetClampedToScreen(true)
    f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    f:SetBackdropColor(.03, .02, .05, .96); f:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
    f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
    tinsert(UISpecialFrames, "siikkLayerOptionen")
    local kopf = f:CreateTexture(nil, "BORDER"); kopf:SetPoint("TOPLEFT", 4, -4); kopf:SetPoint("TOPRIGHT", -4, -4); kopf:SetHeight(28); kopf:SetColorTexture(.315, .19, .45, .8)
    local ic = f:CreateTexture(nil, "OVERLAY"); ic:SetSize(22, 22); ic:SetPoint("LEFT", kopf, "LEFT", 6, 0); ic:SetTexture(NS.MEDIA .. "siikk_layer_icon")
    local tt = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); tt:SetPoint("LEFT", ic, "RIGHT", 6, 0); tt:SetText(L"|cffe03030siikk|r-|cffffd100Layer|r  |cff999999v" .. NS.VERSION .. "|r")
    local zu = CreateFrame("Button", nil, f, "UIPanelCloseButton"); zu:SetPoint("TOPRIGHT", 0, 0)
    f.haken = {}
    local function haken(y, text, key)
        local cb = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate"); cb:SetSize(24, 24); cb:SetPoint("TOPLEFT", 18, y)
        cb.l = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); cb.l:SetPoint("LEFT", cb, "RIGHT", 4, 1); cb.l:SetText(text); cb.l:SetWidth(330); cb.l:SetJustifyH("LEFT")
        cb:SetScript("OnClick", function(s) NS.DB()[key] = s:GetChecked() and true or false; NS.Anzeigen(); if key == "teilen" and NS.DB().teilen then NS.Melden(true) end end)
        cb.key = key; f.haken[#f.haken + 1] = cb
    end
    haken(-42, L"Layer-Anzeige zeigen", "leiste")
    haken(-70, L"Anzeige sperren (nicht verschiebbar)", "gesperrt")
    haken(-98, L"Hinweis im Chat bei Layerwechsel", "hinweis")
    haken(-126, L"Ton bei Layerwechsel", "ton")
    haken(-154, L"Layer mit Gilde und Gruppe teilen (nur mit siikk-Layer)", "teilen")
    local r = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); r:SetSize(150, 22); r:SetPoint("BOTTOMLEFT", 14, 12); r:SetText(L"Position zurücksetzen")
    r:SetScript("OnClick", function() NS.DB().pos = nil; NS.LeistePosition() end)
    local z = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); z:SetSize(120, 22); z:SetPoint("BOTTOMRIGHT", -14, 12); z:SetText(L"Schließen")
    z:SetScript("OnClick", function() f:Hide() end)
end

function NS.Optionen()
    if not f then bauen() end
    if f:IsShown() then f:Hide() return end
    local db = NS.DB()
    for _, cb in ipairs(f.haken) do cb:SetChecked(db[cb.key] and true or false) end
    f:Show()
end
