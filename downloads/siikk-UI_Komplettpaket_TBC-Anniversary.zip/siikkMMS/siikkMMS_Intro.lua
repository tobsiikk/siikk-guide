-- siikk-Minimapsammler · Einführung beim ersten Start (/sammler intro)
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local Y = "|cffffd100"
siikkIntro("siikk-Minimapsammler", "|cffe03030siikk|r-|cffffd100Minimapsammler|r", NS.MEDIA .. "siikk_mms_icon", {
    { L"Willkommen beim siikk-Minimapsammler",
      L"Viele Addons legen einen eigenen Knopf an die Minimap – schnell wird es dort voll.\n\n" ..
      L"Der Minimapsammler räumt auf: Alle Addon-Knöpfe verschwinden von der Minimap und stecken jetzt in " .. Y .. L"einem einzigen Knopf|r.\n\n" ..
      "• " .. Y .. L"Linksklick|r auf den Sammler-Knopf: ein Klappmenü mit allen Addons öffnet sich – jedes mit Symbol und Namen.\n\n" ..
      L"• Im Menü funktioniert jeder Eintrag genau wie vorher sein Knopf: Linksklick, Rechtsklick und der Tooltip beim Drüberfahren." },
    { L"Einstellen",
      "• " .. Y .. L"Rechtsklick|r auf den Sammler-Knopf (oder " .. Y .. L"/sammler optionen|r): Liste aller gefundenen Addon-Knöpfe.\n" ..
      L"  Ohne Haken bleibt ein Knopf ganz normal an der Minimap.\n\n" ..
      "• " .. Y .. L"Nach Klick zuklappen|r: das Menü schließt sich nach einem Linksklick auf einen Eintrag.\n\n" ..
      L"• Ab 12 Addons zeigt das Menü zwei Spalten.\n\n" ..
      L"• Erkannt werden die Knöpfe fast aller Addons (alle mit LibDBIcon, alle siikk-Addons und die meisten anderen runden Minimap-Knöpfe)." },
    { L"Befehle",
      Y .. L"/sammler|r – Klappmenü öffnen\n" .. Y .. L"/sammler optionen|r – welche Knöpfe eingesammelt werden\n" ..
      Y .. L"/sammler an|r / " .. Y .. L"/sammler aus|r – einsammeln an oder aus (aus = alle Knöpfe zurück an die Minimap)\n" ..
      Y .. L"/sammler intro|r – diese Einführung · " .. Y .. L"/sammler neu|r – was ist neu\n\n" ..
      L"Sammler-Knopf: " .. Y .. L"Ziehen|r verschiebt ihn um die Minimap." },
}, function() return rawget(_G, "siikkMMS_DB") end, "/sammler intro")
