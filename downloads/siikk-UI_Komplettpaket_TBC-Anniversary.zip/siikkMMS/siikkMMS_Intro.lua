-- siikk-Minimapsammler · Einführung beim ersten Start (/sammler intro)
local ADDON, NS = ...
local Y = "|cffffd100"
siikkIntro("siikk-Minimapsammler", "|cffe03030siikk|r-|cffffd100Minimapsammler|r", NS.MEDIA .. "siikk_mms_icon", {
    { "Willkommen beim siikk-Minimapsammler",
      "Viele Addons legen einen eigenen Knopf an die Minimap – schnell wird es dort voll.\n\n" ..
      "Der Minimapsammler räumt auf: Alle Addon-Knöpfe verschwinden von der Minimap und stecken jetzt in " .. Y .. "einem einzigen Knopf|r.\n\n" ..
      "• " .. Y .. "Linksklick|r auf den Sammler-Knopf: ein Klappmenü mit allen Addons öffnet sich – jedes mit Symbol und Namen.\n\n" ..
      "• Im Menü funktioniert jeder Eintrag genau wie vorher sein Knopf: Linksklick, Rechtsklick und der Tooltip beim Drüberfahren." },
    { "Einstellen",
      "• " .. Y .. "Rechtsklick|r auf den Sammler-Knopf (oder " .. Y .. "/sammler optionen|r): Liste aller gefundenen Addon-Knöpfe.\n" ..
      "  Ohne Haken bleibt ein Knopf ganz normal an der Minimap.\n\n" ..
      "• " .. Y .. "Nach Klick zuklappen|r: das Menü schließt sich nach einem Linksklick auf einen Eintrag.\n\n" ..
      "• Ab 12 Addons zeigt das Menü zwei Spalten.\n\n" ..
      "• Erkannt werden die Knöpfe fast aller Addons (alle mit LibDBIcon, alle siikk-Addons und die meisten anderen runden Minimap-Knöpfe)." },
    { "Befehle",
      Y .. "/sammler|r – Klappmenü öffnen\n" .. Y .. "/sammler optionen|r – welche Knöpfe eingesammelt werden\n" ..
      Y .. "/sammler an|r / " .. Y .. "/sammler aus|r – einsammeln an oder aus (aus = alle Knöpfe zurück an die Minimap)\n" ..
      Y .. "/sammler intro|r – diese Einführung · " .. Y .. "/sammler neu|r – was ist neu\n\n" ..
      "Sammler-Knopf: " .. Y .. "Ziehen|r verschiebt ihn um die Minimap." },
}, function() return rawget(_G, "siikkMMS_DB") end, "/sammler intro")
