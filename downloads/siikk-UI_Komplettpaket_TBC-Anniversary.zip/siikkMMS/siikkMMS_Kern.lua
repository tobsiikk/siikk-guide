-- siikk-Minimapsammler · sammelt die Minimap-Knöpfe aller Addons in einem einzigen Knopf mit Klappmenü
local ADDON, NS = ...
NS.VERSION = "1.0"
NS.MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\Media\\"
local GOLD = { .85, .65, .15 }
local Y = "|cffffd100"
function NS.msg(t) print("|cffe03030siikk|r-|cffffd100Minimapsammler|r: " .. t) end

local STANDARD = { an = true, schliessen = true, spalten = 12 }
function NS.DB()
    local db = rawget(_G, "siikkMMS_DB")
    if type(db) ~= "table" then db = {}; siikkMMS_DB = db end
    for k, v in pairs(STANDARD) do if db[k] == nil then db[k] = v end end
    db.lassen = db.lassen or {}   -- Knöpfe, die an der Minimap bleiben sollen
    return db
end

-- Welche Knöpfe sind Addon-Knöpfe? -----------------------------------------
local NIE = { "^Minimap", "^MiniMap", "^GameTime", "^TimeManager", "^QueueStatus", "^ExpansionLanding", "^GarrisonLanding",
    "^AddonCompartment", "^HybridMinimap", "^TobsiikkHelferMinimapSchild", "^TobsiikkHelferUhr", "^siikkMM_siikkMinimapsammler", "^LFG", "^Battlefield" }
local function verboten(n) for _, m in ipairs(NIE) do if n:find(m) then return true end end return false end
local RAND = { [136430] = true, [136467] = true }   -- MiniMap-TrackingBorder (Datei-Nummern)
local function hatRand(b)
    for _, r in ipairs({ b:GetRegions() }) do
        if r.GetObjectType and r:GetObjectType() == "Texture" then
            local ok, t = pcall(r.GetTexture, r)
            if ok and t then
                if type(t) == "number" and RAND[t] then return true end
                if type(t) == "string" and t:lower():find("trackingborder") then return true end
            end
        end
    end
end
local function libIcon()
    local ls = rawget(_G, "LibStub")
    if type(ls) == "table" and ls.GetLibrary then local ok, l = pcall(ls.GetLibrary, ls, "LibDBIcon-1.0", true); if ok then return l end end
end
local function istKnopf(b)
    if type(b) ~= "table" or not b.GetObjectType or not b.GetName then return false end
    local n = b:GetName(); if type(n) ~= "string" or verboten(n) then return false end
    local typ = b:GetObjectType(); if typ ~= "Button" and typ ~= "Frame" and typ ~= "CheckButton" then return false end
    if n:find("^LibDBIcon10_") or n:find("^siikkMM_") or n == "TobsiikkHelferMinimap" then return true end
    local ok, w, h = pcall(function() return b:GetWidth(), b:GetHeight() end)
    if not ok or type(w) ~= "number" or w < 18 or w > 44 or math.abs(w - h) > 6 then return false end
    return hatRand(b) and true or false
end

-- Anzeigename
local function anzeigeName(b)
    local n = b:GetName() or "?"
    local api = rawget(_G, "SiikkMinimapAPI")
    if type(api) == "table" then
        for id in pairs(api) do if n == "siikkMM_" .. id:gsub("[^%w]", "") then return id end end
    end
    if n == "TobsiikkHelferMinimap" then return "siikk-Oberfläche" end
    local lib = libIcon()
    if lib and type(lib.objects) == "table" then for name, obj in pairs(lib.objects) do if obj == b then return name end end end
    n = n:gsub("^LibDBIcon10_", ""):gsub("_?[Mm]ini[Mm]ap[Bb]utton$", ""):gsub("_?[Mm]ini[Mm]ap$", ""):gsub("_?[Bb]utton$", "")
    return n ~= "" and n or (b:GetName() or "?")
end
NS.anzeigeName = anzeigeName

-- Fenster mit den Knöpfen -----------------------------------------------
local Fenster = CreateFrame("Frame", "siikkMMSFenster", UIParent, "BackdropTemplate")
NS.Fenster = Fenster
Fenster:SetFrameStrata("DIALOG"); Fenster:SetClampedToScreen(true); Fenster:EnableMouse(true); Fenster:Hide()
Fenster:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
Fenster:SetBackdropColor(.03, .02, .05, .95); Fenster:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
tinsert(UISpecialFrames, "siikkMMSFenster")
local kopf = Fenster:CreateFontString(nil, "OVERLAY", "GameFontNormal"); kopf:SetPoint("TOPLEFT", 10, -8)
local linie = Fenster:CreateTexture(nil, "ARTWORK"); linie:SetHeight(1); linie:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], .6)
linie:SetPoint("TOPLEFT", 6, -26); linie:SetPoint("TOPRIGHT", -6, -26)
local leer = Fenster:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); leer:SetPoint("TOPLEFT", 10, -36); leer:SetWidth(200); leer:SetJustifyH("LEFT")
leer:SetText("Noch keine Addon-Knöpfe gefunden.")

local Samm = {}      -- Name → Eintrag { b, name, alt = {...} }
NS.Samm = Samm
local Zeilen = {}
local ZH, ZB = 30, 190

local function zeileNeu(i)
    local z = CreateFrame("Button", nil, Fenster); z:SetSize(ZB, ZH); z:RegisterForClicks("AnyUp")
    local hl = z:CreateTexture(nil, "HIGHLIGHT"); hl:SetAllPoints(); hl:SetColorTexture(1, .82, .1, .14)
    z.t = z:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); z.t:SetPoint("LEFT", 38, 0); z.t:SetPoint("RIGHT", -4, 0); z.t:SetJustifyH("LEFT")
    z:SetScript("OnClick", function(s, mb)
        local b = s.knopf; if not b then return end
        if b:GetScript("OnClick") then b:Click(mb)
        else local up = b:GetScript("OnMouseUp"); if up then up(b, mb) end end
        if NS.DB().schliessen and mb == "LeftButton" then Fenster:Hide() end
    end)
    z:SetScript("OnEnter", function(s) local b = s.knopf; local f = b and b:GetScript("OnEnter"); if f then pcall(f, b) end end)
    z:SetScript("OnLeave", function(s) local b = s.knopf; local f = b and b:GetScript("OnLeave"); if f then pcall(f, b) end end)
    Zeilen[i] = z
    return z
end

-- Knopf einsammeln / zurückgeben
local function ordnen() end
local function einsammeln(b)
    local name = b:GetName()
    if Samm[name] then return end
    local e = { b = b, name = anzeigeName(b), alt = { parent = b:GetParent(), strata = b:GetFrameStrata(), punkte = {},
        sp = b.SetPoint, cap = b.ClearAllPoints, ds = b:GetScript("OnDragStart"), de = b:GetScript("OnDragStop") } }
    for i = 1, b:GetNumPoints() do e.alt.punkte[i] = { b:GetPoint(i) } end
    Samm[name] = e
    b:SetParent(Fenster); b:SetFrameStrata("DIALOG")
    b:SetScript("OnDragStart", nil); b:SetScript("OnDragStop", nil)
    -- Addons setzen ihre Knöpfe gern selbst wieder an die Minimap – das fangen wir ab
    b.SetPoint = function() end; b.ClearAllPoints = function() end
    if not e.hooked then
        e.hooked = true
        b:HookScript("OnShow", function() if Fenster:IsShown() then ordnen() end end)
        b:HookScript("OnHide", function() if Fenster:IsShown() then ordnen() end end)
    end
end
local function zurueck(name)
    local e = Samm[name]; if not e then return end
    local b, a = e.b, e.alt
    b.SetPoint = nil; b.ClearAllPoints = nil
    b:SetParent(a.parent or Minimap); b:SetFrameStrata(a.strata or "MEDIUM")
    b:ClearAllPoints(); for _, p in ipairs(a.punkte) do pcall(b.SetPoint, b, unpack(p)) end
    b:SetScript("OnDragStart", a.ds); b:SetScript("OnDragStop", a.de)
    if b.Anwenden then pcall(b.Anwenden) end
    Samm[name] = nil
end
NS.zurueck = zurueck

-- alle Kandidaten finden (Minimap und ihre üblichen Eltern)
function NS.Kandidaten()
    local t, gesehen = {}, {}
    local function such(par)
        if type(par) ~= "table" or not par.GetChildren then return end
        for _, c in ipairs({ par:GetChildren() }) do
            if istKnopf(c) and not gesehen[c] then gesehen[c] = true; t[#t + 1] = c end
        end
    end
    such(Minimap); such(rawget(_G, "MinimapBackdrop")); such(rawget(_G, "MinimapCluster"))
    local lib = libIcon()
    if lib and type(lib.objects) == "table" then for _, b in pairs(lib.objects) do if istKnopf(b) and not gesehen[b] then gesehen[b] = true; t[#t + 1] = b end end end
    for _, e in pairs(Samm) do if not gesehen[e.b] then gesehen[e.b] = true; t[#t + 1] = e.b end end
    return t
end

function NS.Scannen()
    local db = NS.DB()
    for _, b in ipairs(NS.Kandidaten()) do
        local n = b:GetName()
        if db.an and not db.lassen[n] then einsammeln(b) elseif Samm[n] then zurueck(n) end
    end
    if not db.an then for n in pairs(Samm) do zurueck(n) end end
    if Fenster:IsShown() then ordnen() end
end

ordnen = function()
    local liste = {}
    for _, e in pairs(Samm) do if e.b:IsShown() then liste[#liste + 1] = e end end
    table.sort(liste, function(a, b) return a.name:lower() < b.name:lower() end)
    local spalten = (#liste > (NS.DB().spalten or 12)) and 2 or 1
    local proSpalte = math.ceil(#liste / spalten)
    for i, e in ipairs(liste) do
        local z = Zeilen[i] or zeileNeu(i)
        local sp, zl = math.floor((i - 1) / math.max(proSpalte, 1)), (i - 1) % math.max(proSpalte, 1)
        z:ClearAllPoints(); z:SetPoint("TOPLEFT", Fenster, "TOPLEFT", 6 + sp * (ZB + 6), -32 - zl * ZH)
        z.knopf = e.b; z.t:SetText(e.name); z:Show()
        e.alt.cap(e.b); e.alt.sp(e.b, "LEFT", z, "LEFT", 2, 0)
        e.b:SetFrameLevel(z:GetFrameLevel() + 3)
    end
    for i = #liste + 1, #Zeilen do Zeilen[i]:Hide(); Zeilen[i].knopf = nil end
    leer:SetShown(#liste == 0)
    kopf:SetText("|cffe03030siikk|r-|cffffd100Addons|r  |cff999999(" .. #liste .. ")|r")
    Fenster:SetSize(math.max(ZB, spalten * (ZB + 6) - 6) + 12, 40 + math.max(1, proSpalte) * ZH)
end
NS.ordnen = ordnen

function NS.Oeffnen(anker)
    if Fenster:IsShown() then Fenster:Hide() return end
    NS.Scannen(); ordnen()
    Fenster:ClearAllPoints()
    if anker then
        local x, y = anker:GetCenter(); local w, h = UIParent:GetWidth(), UIParent:GetHeight()
        local rechts, oben = (x or 0) > w / 2, (y or 0) > h / 2
        Fenster:SetPoint((oben and "TOP" or "BOTTOM") .. (rechts and "RIGHT" or "LEFT"), anker, (oben and "BOTTOM" or "TOP") .. (rechts and "LEFT" or "RIGHT"), 0, 0)
    else Fenster:SetPoint("CENTER") end
    Fenster:Show()
end

-- Ereignisse: mehrmals scannen, weil Addons ihre Knöpfe zu unterschiedlichen Zeiten anlegen
local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN"); ev:RegisterEvent("ADDON_LOADED")
local eingeloggt = false
ev:SetScript("OnEvent", function(_, e)
    if e == "PLAYER_LOGIN" then
        eingeloggt = true; NS.Scannen()
        if C_Timer then for _, s in ipairs({ 1, 4, 10, 30, 60 }) do C_Timer.After(s, NS.Scannen) end end
    elseif e == "ADDON_LOADED" and eingeloggt and C_Timer then C_Timer.After(1, NS.Scannen) end
end)

-- Befehle
SLASH_SIIKKMMS1 = "/sammler"; SLASH_SIIKKMMS2 = "/mms"
SlashCmdList.SIIKKMMS = function(m)
    m = (m or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    if m == "" then NS.Oeffnen(NS.Knopf)
    elseif m == "optionen" or m == "einstellungen" then if NS.Optionen then NS.Optionen() end
    elseif m == "an" then NS.DB().an = true; NS.Scannen(); NS.msg("Knöpfe werden eingesammelt.")
    elseif m == "aus" then NS.DB().an = false; NS.Scannen(); NS.msg("Alle Knöpfe wieder an der Minimap.")
    elseif m == "intro" then local f = SiikkIntroAPI and SiikkIntroAPI["siikk-Minimapsammler"]; if f then f() end
    elseif m == "neu" then local f = SiikkNeuAPI and SiikkNeuAPI["siikk-Minimapsammler"]; if f then f() end
    else
        NS.msg("Befehle:")
        print(Y .. "/sammler|r – Klappmenü öffnen · " .. Y .. "/sammler optionen|r – welche Knöpfe eingesammelt werden")
        print(Y .. "/sammler an|r / " .. Y .. "aus|r – einsammeln an/aus · " .. Y .. "/sammler intro|r · " .. Y .. "/sammler neu|r")
    end
end
