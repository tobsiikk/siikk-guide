-- siikk-Minimapsammler · der eine Knopf an der Minimap
local ADDON, NS = ...
NS.Knopf = siikkMinimapKnopf("siikk-Minimapsammler", "|cffe03030siikk|r-|cffffd100Minimapsammler|r", NS.MEDIA .. "siikk_mms_icon",
    function() local db = NS.DB(); db.mm = db.mm or {}; return db.mm end,
    function() NS.Oeffnen(NS.Knopf) end,
    function() NS.Optionen() end,
    { "Linksklick: alle Addon-Knöpfe aufklappen", "Rechtsklick: einstellen, welche Knöpfe eingesammelt werden" }, 225)
