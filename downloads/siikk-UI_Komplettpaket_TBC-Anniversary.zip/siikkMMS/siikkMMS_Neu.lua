-- siikk-Minimapsammler · „Was ist neu?“ – erzeugt aus tools/changelog.py (nicht von Hand ändern)
siikkNeu("siikk-Minimapsammler", "|cffe03030siikk|r-|cffffd100Minimapsammler|r", "Interface\\AddOns\\siikkMMS\\Media\\siikk_mms_icon", "1.0",
{
    { version = "1.0", datum = "31.10.2026", punkte = { "Neues Addon: alle Minimap-Knöpfe deiner Addons in einem einzigen Knopf.", "Linksklick klappt ein Menü mit allen Addons auf – Symbol und Name, Klicks und Tooltips wie gewohnt.", "Rechtsklick (oder /sammler optionen): auswählen, welche Knöpfe trotzdem an der Minimap bleiben.", "Ab 12 Addons zwei Spalten; /sammler aus gibt alle Knöpfe an die Minimap zurück." } }
}, function() return rawget(_G, "siikkMMS_DB") end, "/sammler neu")
