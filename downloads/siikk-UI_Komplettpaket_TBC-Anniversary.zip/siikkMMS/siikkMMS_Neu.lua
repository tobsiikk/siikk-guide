-- siikk-Minimapsammler · „Was ist neu?“ – erzeugt aus tools/changelog.py (nicht von Hand ändern)
local L = siikkL or function(s) return s end
siikkNeu("siikk-Minimapsammler", "|cffe03030siikk|r-|cffffd100Minimapsammler|r", "Interface\\AddOns\\siikkMMS\\Media\\siikk_mms_icon", "1.2",
{
    { version = "1.2", datum = "07.11.2026", punkte = { L"Neu: Schriftgröße einstellbar – mit /schrift öffnet sich ein Fenster mit einem Regler für alle siikk-Addons und je einem pro Addon (70–160 %)." } },
    { version = "1.1", datum = "02.11.2026", punkte = { L"Neu: Sprache wählbar – Deutsch, English, Русский, Français, Español. Mit /sprache für alle siikk-Addons auf einmal umschalten (startet in der Sprache deines WoW)." } },
    { version = "1.0", datum = "31.10.2026", punkte = { L"Neues Addon: alle Minimap-Knöpfe deiner Addons in einem einzigen Knopf.", L"Linksklick klappt ein Menü mit allen Addons auf – Symbol und Name, Klicks und Tooltips wie gewohnt.", L"Rechtsklick (oder /sammler optionen): auswählen, welche Knöpfe trotzdem an der Minimap bleiben.", L"Ab 12 Addons zwei Spalten; /sammler aus gibt alle Knöpfe an die Minimap zurück." } }
}, function() return rawget(_G, "siikkMMS_DB") end, "/sammler neu")
