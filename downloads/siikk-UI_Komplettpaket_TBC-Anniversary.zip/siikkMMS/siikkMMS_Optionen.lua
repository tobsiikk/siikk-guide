-- siikk-Minimapsammler · Einstellungen: welche Knöpfe eingesammelt werden
local ADDON, NS = ...
local GOLD = { .85, .65, .15 }
local f, haken = nil, {}

local function bauen()
    f = CreateFrame("Frame", "siikkMMSOptionen", UIParent, "BackdropTemplate")
    f:SetSize(460, 200); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG"); f:SetClampedToScreen(true)
    f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    f:SetBackdropColor(.03, .02, .05, .96); f:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
    f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
    tinsert(UISpecialFrames, "siikkMMSOptionen")
    local kopf = f:CreateTexture(nil, "BORDER"); kopf:SetPoint("TOPLEFT", 4, -4); kopf:SetPoint("TOPRIGHT", -4, -4); kopf:SetHeight(28); kopf:SetColorTexture(.315, .19, .45, .8)
    local ic = f:CreateTexture(nil, "OVERLAY"); ic:SetSize(22, 22); ic:SetPoint("LEFT", kopf, "LEFT", 6, 0); ic:SetTexture(NS.MEDIA .. "siikk_mms_icon")
    local tt = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); tt:SetPoint("LEFT", ic, "RIGHT", 6, 0); tt:SetText("|cffe03030siikk|r-|cffffd100Minimapsammler|r  |cff999999v" .. NS.VERSION .. "|r")
    local zu = CreateFrame("Button", nil, f, "UIPanelCloseButton"); zu:SetPoint("TOPRIGHT", 0, 0)
    local function haken1(x, y, text, get, set)
        local cb = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate"); cb:SetSize(24, 24); cb:SetPoint("TOPLEFT", x, y)
        cb.l = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); cb.l:SetPoint("LEFT", cb, "RIGHT", 4, 1); cb.l:SetText(text); cb.l:SetWidth(180); cb.l:SetJustifyH("LEFT")
        cb:SetScript("OnClick", function(s) set(s:GetChecked() and true or false); NS.Scannen() end)
        cb.get = get; return cb
    end
    f.fest = {
        haken1(18, -42, "Knöpfe einsammeln", function() return NS.DB().an end, function(v) NS.DB().an = v end),
        haken1(240, -42, "Nach Klick zuklappen", function() return NS.DB().schliessen end, function(v) NS.DB().schliessen = v end),
    }
    f.h = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); f.h:SetPoint("TOPLEFT", 20, -78); f.h:SetText("Diese Knöpfe kommen ins Klappmenü (ohne Haken = bleibt an der Minimap):")
    local z = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); z:SetSize(120, 22); z:SetPoint("BOTTOMRIGHT", -14, 12); z:SetText("Schließen")
    z:SetScript("OnClick", function() f:Hide() end)
end

local function fuellen()
    local db = NS.DB()
    for _, cb in ipairs(f.fest) do cb:SetChecked(cb.get() and true or false) end
    local liste = NS.Kandidaten()
    table.sort(liste, function(a, b) return NS.anzeigeName(a):lower() < NS.anzeigeName(b):lower() end)
    for i, b in ipairs(liste) do
        local cb = haken[i]
        if not cb then
            cb = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate"); cb:SetSize(22, 22)
            cb.l = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); cb.l:SetPoint("LEFT", cb, "RIGHT", 2, 1); cb.l:SetWidth(180); cb.l:SetJustifyH("LEFT")
            cb:SetScript("OnClick", function(s) NS.DB().lassen[s.name] = (not s:GetChecked()) or nil; NS.Scannen() end)
            haken[i] = cb
        end
        local sp, zl = (i - 1) % 2, math.floor((i - 1) / 2)
        cb:ClearAllPoints(); cb:SetPoint("TOPLEFT", f, "TOPLEFT", 18 + sp * 220, -98 - zl * 24)
        cb.name = b:GetName(); cb.l:SetText(NS.anzeigeName(b)); cb:SetChecked(not db.lassen[cb.name]); cb:Show()
    end
    for i = #liste + 1, #haken do haken[i]:Hide() end
    f:SetHeight(150 + math.ceil(math.max(#liste, 1) / 2) * 24)
end

function NS.Optionen()
    if not f then bauen() end
    if f:IsShown() then f:Hide() else fuellen(); f:Show() end
end
