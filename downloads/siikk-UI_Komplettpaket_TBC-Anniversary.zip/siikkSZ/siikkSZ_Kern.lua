-- siikk-Schadenszahlen · eigene Schadenszahlen über dem Gegner im siikk-Stil
-- Anniversary / Classic / Forever: eigene Zahlen aus dem Kampflog, an der Namensplakette des Gegners.
-- Midnight und Forever: Blizzard gibt Addons dort keinen Kampflog – schon der Versuch löst „wurde geblockt“ aus.
-- Dort wird nur die Schrift der Blizzard-Zahlen ersetzt.
local ADDON, NS = ...
local L = siikkL or function(s) return s end
NS.VERSION = "1.6"
local MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\Media\\"
NS.MEDIA = MEDIA
NS.SCHRIFT = MEDIA .. "Poppins-BoldItalic.ttf"
local BUILD = select(4, GetBuildInfo())
NS.FOREVER = type(BUILD) == "number" and BUILD >= 16000 and BUILD < 20000
-- NS.MIDNIGHT = Kampflog gesperrt (Midnight ab 12.0 und Forever); dann nur Blizzard-Schrift
NS.MIDNIGHT = (WOW_PROJECT_ID ~= nil and WOW_PROJECT_MAINLINE ~= nil and WOW_PROJECT_ID == WOW_PROJECT_MAINLINE)
    or (type(BUILD) == "number" and BUILD >= 120000) or NS.FOREVER
local Y = "|cffffd100"
function NS.msg(t) print(L"|cffe03030siikk|r-|cffffd100Schadenszahlen|r: " .. t) end

-- Auswahl-Listen -------------------------------------------------------------
-- Schriften: mitgelieferte (SIL OFL, Ordner Media) und die WoW-eigenen. kyr = hat kyrillische Zeichen.
-- faktor gleicht sehr breite/schmale Schriften aus, damit 100 % überall ähnlich groß wirkt.
NS.SCHRIFTEN = {
    { id = "poppins", name = "Poppins (siikk)", pfad = MEDIA .. "Poppins-BoldItalic.ttf", datei = "Poppins-BoldItalic.ttf" },
    { id = "bangers", name = "Bangers (Comic)", pfad = MEDIA .. "Bangers-Regular.ttf", datei = "Bangers-Regular.ttf", faktor = 1.12 },
    { id = "russo", name = "Russo One", pfad = MEDIA .. "RussoOne-Regular.ttf", datei = "RussoOne-Regular.ttf", kyr = true },
    { id = "cinzel", name = "Cinzel (Serif)", pfad = MEDIA .. "Cinzel-Bold.ttf", datei = "Cinzel-Bold.ttf" },
    { id = "oswald", name = "Oswald", pfad = MEDIA .. "Oswald-Bold.ttf", datei = "Oswald-Bold.ttf", kyr = true, faktor = 1.1 },
    { id = "pixel", name = "Press Start 2P (Pixel)", pfad = MEDIA .. "PressStart2P-Regular.ttf", datei = "PressStart2P-Regular.ttf", kyr = true, faktor = .62 },
    { id = "friz", name = "Friz Quadrata (WoW)", pfad = "Fonts\\FRIZQT__.TTF", wow = true },
    { id = "arialn", name = "Arial Narrow (WoW)", pfad = "Fonts\\ARIALN.TTF", wow = true, faktor = 1.05 },
    { id = "skurri", name = "Skurri (WoW)", pfad = "Fonts\\skurri.ttf", wow = true },
    { id = "morpheus", name = "Morpheus (WoW)", pfad = "Fonts\\MORPHEUS.TTF", wow = true },
}
local SCHRIFT_NACH_ID = {}
for _, s in ipairs(NS.SCHRIFTEN) do SCHRIFT_NACH_ID[s.id] = s end
function NS.Schrift(id) return SCHRIFT_NACH_ID[id] or SCHRIFT_NACH_ID.poppins end
-- Schrift mit kyrillischen Zeichen für Wörter (Russisch), wenn die gewählte keine hat
local function kyrSchrift() return (GetLocale and GetLocale() == "ruRU") and "Fonts\\FRIZQT__.TTF" or "Fonts\\FRIZQT___CYR.TTF" end
NS.KYR_SCHRIFT = kyrSchrift

NS.KONTUREN = {
    { id = "keine", name = L"Keine", flag = "" },
    { id = "duenn", name = L"Dünn", flag = "OUTLINE" },
    { id = "dick", name = L"Dick", flag = "THICKOUTLINE" },
    { id = "sehrdick", name = L"Sehr dick", flag = "THICKOUTLINE", extra = true },
}
NS.MUSTER = {
    { id = "aufsteigen", name = L"Aufsteigen", tipp = L"Gerade nach oben, nebeneinander versetzt (bisheriges Verhalten)." },
    { id = "bogen", name = L"Bogen / Fontäne", tipp = L"Fliegen abwechselnd links und rechts im Bogen nach außen und fallen herab." },
    { id = "faecher", name = L"Fächer", tipp = L"Steigen in zufälliger Richtung fächerförmig nach oben." },
    { id = "stapel", name = L"Stapel / Liste", tipp = L"Neue Zahlen schieben die älteren ordentlich nach oben – wie eine Liste." },
    { id = "seitlich", name = L"Seitlich", tipp = L"Rollen abwechselnd zur Seite hinaus." },
    { id = "explosion", name = L"Explosion", tipp = L"Springen vom Ziel weg in alle Richtungen und verblassen schnell." },
    { id = "fallen", name = L"Herabfallen", tipp = L"Hüpfen kurz hoch und fallen mit Schwerkraft nach unten." },
}
NS.KRITANIM = {
    { id = "pop", name = L"Pop", tipp = L"Springen groß ins Bild und schrumpfen schnell auf ihre Größe." },
    { id = "wackeln", name = L"Wackeln", tipp = L"Kurz aufpoppen und hin und her wackeln." },
    { id = "pulsieren", name = L"Pulsieren", tipp = L"Werden im Takt größer und kleiner." },
    { id = "keine", name = L"Keine", tipp = L"Krits erscheinen ohne eigene Bewegung – nur größer." },
}
NS.FARBMODI = {
    { id = "schule", name = L"Je Magieschule", tipp = L"Schatten lila, Feuer orange, Frost hellblau, Natur grün, Arkan rosa, Heilig hellgelb, körperlich weiß." },
    { id = "eine", name = L"Eine Farbe", tipp = L"Alle Zahlen in deiner Farbe (Feld „Eigene Farbe“)." },
    { id = "klasse", name = L"Klassenfarbe", tipp = L"Alle Zahlen in der Farbe deiner Klasse." },
    { id = "regenbogen", name = L"Regenbogen", tipp = L"Jeder Treffer etwas weiter im Farbkreis – ein sanfter Verlauf." },
}
NS.FORMATE = {
    { id = "roh" }, { id = "punkte" }, { id = "kurz" },   -- Namen siehe unten (NS.zahl)
}

-- Einstellungen ------------------------------------------------------------
-- Standard = Aussehen von v1.2, damit sich nach dem Update nichts ungefragt ändert.
local STANDARD = {
    an = true, groesse = 1.0, kritGroesse = 1.6, leuchten = true, ausrufe = true,
    pet = true, dotsKlein = true, verfehlt = true, heilung = false, mitte = true, blizzSchrift = true,
    -- neu in 1.3
    vorlage = "siikk", schrift = "poppins", kontur = "dick", schatten = true,
    farbModus = "schule", farbe = { 1, 1, 1 }, kritFarbe = { 1, .82, .1 }, heilFarbe = { .3, 1, .45 },
    muster = "aufsteigen", kritAnim = "pop", hopsen = true, tempo = 1.0, streuung = 1.0,
    format = "punkte", icon = false, zusammenfassen = false, maxZahlen = 40,
}
NS.STANDARD = STANDARD
local GUELTIG = {}   -- erlaubte Werte der Auswahl-Felder
local function gueltigMachen(key, liste) GUELTIG[key] = {}; for _, e in ipairs(liste) do GUELTIG[key][e.id] = true end end
gueltigMachen("schrift", NS.SCHRIFTEN); gueltigMachen("kontur", NS.KONTUREN); gueltigMachen("muster", NS.MUSTER)
gueltigMachen("kritAnim", NS.KRITANIM); gueltigMachen("farbModus", NS.FARBMODI); gueltigMachen("format", NS.FORMATE)
local BEREICH = { groesse = { .5, 2 }, kritGroesse = { 1, 2.5 }, tempo = { .5, 2 }, streuung = { 0, 2 }, maxZahlen = { 10, 80 } }

local function kopie(v)
    if type(v) ~= "table" then return v end
    local t = {}; for k, x in pairs(v) do t[k] = x end; return t
end
NS.kopie = kopie
local function farbeOk(c) return type(c) == "table" and type(c[1]) == "number" and type(c[2]) == "number" and type(c[3]) == "number" end

local geprueft   -- die zuletzt geprüfte Tabelle (NS.DB wird bei jedem Treffer gerufen)
function NS.DB()
    local db = rawget(_G, "siikkSZ_DB")
    if type(db) ~= "table" then db = {}; siikkSZ_DB = db end
    if db == geprueft then return db end
    -- Übernahme der Einstellungen aus 1.2
    if db.format == nil and db.kurz ~= nil then db.format = db.kurz and "kurz" or "punkte" end
    if db.farbModus == nil and db.farben == false then db.farbModus = "eine"; db.farbe = { 1, 1, 1 } end
    db.kurz, db.farben = nil, nil
    for k, v in pairs(STANDARD) do
        if db[k] == nil or type(db[k]) ~= type(v) then db[k] = kopie(v) end
    end
    for k, ok in pairs(GUELTIG) do if not ok[db[k]] then db[k] = STANDARD[k] end end
    for k, b in pairs(BEREICH) do db[k] = math.min(b[2], math.max(b[1], db[k])) end
    for _, k in ipairs({ "farbe", "kritFarbe", "heilFarbe" }) do if not farbeOk(db[k]) then db[k] = kopie(STANDARD[k]) end end
    geprueft = db
    return db
end
function NS.DBNeuPruefen() geprueft = nil; return NS.DB() end

-- Auf Standard zurücksetzen (Minimap-Knopf, Intro-Status und gemerkte Blizzard-Einstellungen bleiben)
function NS.Zuruecksetzen()
    local db = NS.DB()
    for k, v in pairs(STANDARD) do db[k] = kopie(v) end
    NS.DBNeuPruefen()
    NS.BlizzardAnpassen()
    if NS.OptAktualisieren then NS.OptAktualisieren() end
end

-- Stil-Vorlagen: setzen Aussehen und Bewegung, nicht Farben, Format oder was angezeigt wird
NS.VORLAGE_KEYS = { "schrift", "groesse", "kritGroesse", "kontur", "schatten", "leuchten", "ausrufe", "muster", "kritAnim", "hopsen", "tempo", "streuung" }
NS.VORLAGEN = {
    { id = "siikk", name = L"siikk (Standard)", tipp = L"Fett und kursiv mit dicker Kontur, goldene Krits mit Leuchten.",
      werte = { schrift = "poppins", groesse = 1.0, kritGroesse = 1.6, kontur = "dick", schatten = true, leuchten = true, ausrufe = true, muster = "aufsteigen", kritAnim = "pop", hopsen = true, tempo = 1.0, streuung = 1.0 } },
    { id = "klassisch", name = L"Klassisch", tipp = L"Wie die Blizzard-Zahlen: Friz Quadrata, dünne Kontur, ohne Leuchten.",
      werte = { schrift = "friz", groesse = 1.0, kritGroesse = 1.5, kontur = "duenn", schatten = true, leuchten = false, ausrufe = false, muster = "aufsteigen", kritAnim = "pop", hopsen = true, tempo = 1.0, streuung = .6 } },
    { id = "minimal", name = L"Minimal", tipp = L"Klein und schlicht, ohne Leuchten und Extras.",
      werte = { schrift = "arialn", groesse = .8, kritGroesse = 1.2, kontur = "duenn", schatten = false, leuchten = false, ausrufe = false, muster = "stapel", kritAnim = "keine", hopsen = false, tempo = 1.2, streuung = .5 } },
    { id = "episch", name = L"Episch", tipp = L"Groß, sehr dicke Kontur, riesige pulsierende Krits mit Leuchten.",
      werte = { schrift = "russo", groesse = 1.3, kritGroesse = 2.2, kontur = "sehrdick", schatten = true, leuchten = true, ausrufe = true, muster = "faecher", kritAnim = "pulsieren", hopsen = true, tempo = .9, streuung = 1.2 } },
    { id = "comic", name = L"Comic", tipp = L"Comic-Schrift mit sehr dicker Kontur, Zahlen hüpfen im Bogen, Krits wackeln.",
      werte = { schrift = "bangers", groesse = 1.2, kritGroesse = 1.8, kontur = "sehrdick", schatten = true, leuchten = false, ausrufe = true, muster = "bogen", kritAnim = "wackeln", hopsen = true, tempo = 1.0, streuung = 1.2 } },
    { id = "retro", name = L"Retro / Pixel", tipp = L"Pixel-Schrift wie in alten Spielen, Zahlen stapeln sich.",
      werte = { schrift = "pixel", groesse = 1.0, kritGroesse = 1.5, kontur = "duenn", schatten = true, leuchten = false, ausrufe = true, muster = "stapel", kritAnim = "wackeln", hopsen = false, tempo = 1.0, streuung = 1.0 } },
    { id = "elegant", name = L"Elegant", tipp = L"Serifenschrift, ruhig im Fächer, sanft leuchtende Krits.",
      werte = { schrift = "cinzel", groesse = 1.05, kritGroesse = 1.4, kontur = "duenn", schatten = true, leuchten = true, ausrufe = false, muster = "faecher", kritAnim = "pulsieren", hopsen = false, tempo = .8, streuung = .7 } },
    { id = "explosiv", name = L"Explosiv", tipp = L"Zahlen springen in alle Richtungen weg.",
      werte = { schrift = "oswald", groesse = 1.1, kritGroesse = 1.8, kontur = "dick", schatten = true, leuchten = true, ausrufe = true, muster = "explosion", kritAnim = "pop", hopsen = true, tempo = 1.1, streuung = 1.0 } },
}
local VORLAGE_NACH_ID = {}
for _, v in ipairs(NS.VORLAGEN) do VORLAGE_NACH_ID[v.id] = v end
function NS.VorlageAnwenden(id)
    local v = VORLAGE_NACH_ID[id]; if not v then return false end
    local db = NS.DB()
    for _, k in ipairs(NS.VORLAGE_KEYS) do db[k] = v.werte[k] end
    db.vorlage = id
    if NS.OptAktualisieren then NS.OptAktualisieren() end
    return true
end
-- Passt alles noch zur gewählten Vorlage? (sonst „angepasst“)
function NS.VorlageUnveraendert()
    local db = NS.DB(); local v = VORLAGE_NACH_ID[db.vorlage]; if not v then return false end
    for _, k in ipairs(NS.VORLAGE_KEYS) do
        local a, b = db[k], v.werte[k]
        if type(a) == "number" then if math.abs(a - b) > .001 then return false end elseif a ~= b then return false end
    end
    return true
end
function NS.Vorlage(id) return VORLAGE_NACH_ID[id] end

-- Farben -------------------------------------------------------------------
-- je Magieschule (wie in der Vorschau: Schatten lila, Feuer orange, Krit gold)
local SCHULE = {
    [1] = { 1, 1, 1 },          -- körperlich
    [2] = { 1, .9, .5 },        -- Heilig
    [4] = { 1, .54, .16 },      -- Feuer
    [8] = { .55, 1, .35 },      -- Natur
    [16] = { .5, .85, 1 },      -- Frost
    [32] = { .77, .55, 1 },     -- Schatten
    [64] = { 1, .5, 1 },        -- Arkan
}
local GRAU = { .75, .75, .75 }
local band = (bit and bit.band) or function(a, b)
    local r, p = 0, 1
    while a > 0 and b > 0 do
        if a % 2 == 1 and b % 2 == 1 then r = r + p end
        a, b, p = math.floor(a / 2), math.floor(b / 2), p * 2
    end
    return r
end
local function schulFarbe(schule)
    if type(schule) ~= "number" or schule == 0 then return SCHULE[1] end
    if SCHULE[schule] then return SCHULE[schule] end
    for _, b in ipairs({ 32, 4, 16, 64, 8, 2, 1 }) do if band(schule, b) > 0 then return SCHULE[b] end end
    return SCHULE[1]
end
NS.SchulFarbe = schulFarbe

local function hsv(h, s, v)
    local i = math.floor(h * 6) % 6; local f = h * 6 - math.floor(h * 6)
    local p, q, t = v * (1 - s), v * (1 - f * s), v * (1 - (1 - f) * s)
    if i == 0 then return v, t, p elseif i == 1 then return q, v, p elseif i == 2 then return p, v, t
    elseif i == 3 then return p, q, v elseif i == 4 then return t, p, v end
    return v, p, q
end
local regenbogen = 0
local KLASSE = { 1, 1, 1 }
local function klassenFarbe()
    local k
    if UnitClass then k = select(2, UnitClass("player")) end
    local t = (rawget(_G, "CUSTOM_CLASS_COLORS") or rawget(_G, "RAID_CLASS_COLORS") or {})[k or ""]
    if type(t) == "table" and t.r then KLASSE[1], KLASSE[2], KLASSE[3] = t.r, t.g, t.b end
    return KLASSE
end
-- Farbe eines Treffers (art: normal/dot/pet/krit/heil/info)
function NS.Farbe(schule, art)
    local db = NS.DB()
    if art == "info" then return GRAU[1], GRAU[2], GRAU[3] end
    if art == "heil" then local c = db.heilFarbe; return c[1], c[2], c[3] end
    if art == "krit" then local c = db.kritFarbe; return c[1], c[2], c[3] end
    local m = db.farbModus
    if m == "eine" then local c = db.farbe; return c[1], c[2], c[3]
    elseif m == "klasse" then local c = klassenFarbe(); return c[1], c[2], c[3]
    elseif m == "regenbogen" then regenbogen = (regenbogen + .045) % 1; return hsv(regenbogen, .62, 1) end
    local c = schulFarbe(schule); return c[1], c[2], c[3]
end

-- Zahlen: 12345 · 12.345 (EN 12,345) · 12,3k (EN 12.3k)
local function trenner()
    if siikkSprache and siikkSprache() == "en" then return ",", "." end
    return ".", ","
end
function NS.zahl(n, fmt)
    fmt = fmt or NS.DB().format
    local tausend, dez = trenner()
    if fmt == "kurz" then
        if n >= 1e6 then return (("%.1f"):format(n / 1e6):gsub("%.", dez)) .. L" Mio" end
        if n >= 1e4 then return (("%.1f"):format(n / 1e3):gsub("%.", dez)) .. "k" end
    end
    local s = tostring(math.floor(n + 0.5))
    if fmt == "roh" then return s end
    local r = s:reverse():gsub("(%d%d%d)", "%1" .. tausend):reverse()
    if r:sub(1, 1) == tausend then r = r:sub(2) end
    return r
end
-- Namen der Zahlenformate in der Schreibweise der gewählten Sprache (EN: 12,345 / 12.3k)
for _, e in ipairs(NS.FORMATE) do e.name = NS.zahl(12345, e.id) end

-- Anzeige -----------------------------------------------------------------
local Ebene = CreateFrame("Frame", "siikkSZEbene", UIParent)
Ebene:SetAllPoints(UIParent); Ebene:SetFrameStrata("LOW")
local Akt, Pool = {}, {}
NS.Akt, NS.Pool = Akt, Pool
NS.erzeugt = 0   -- wie viele Zahl-Rahmen es insgesamt gibt (Test: Pool wächst nicht unbegrenzt)
local SPUREN = { 0, -48, 46, -26, 28, -64, 62, -10 }
local spur, seite = 0, 1
local DUNKEL = { .07, .03, .09 }
local KONTUR_VERSATZ = { { 2, 2 }, { -2, 2 }, { 2, -2 }, { -2, -2 } }

local function neuesFeld()
    local f = table.remove(Pool)
    if f then return f end
    NS.erzeugt = NS.erzeugt + 1
    f = CreateFrame("Frame", nil, Ebene); f:SetSize(2, 2)
    f.g = f:CreateTexture(nil, "BACKGROUND"); f.g:SetTexture(MEDIA .. "glow"); f.g:SetBlendMode("ADD"); f.g:SetPoint("CENTER")
    f.t = f:CreateFontString(nil, "OVERLAY"); f.t:SetPoint("CENTER")
    f.icon = f:CreateTexture(nil, "ARTWORK"); f.icon:SetPoint("RIGHT", f.t, "LEFT", -3, 0); f.icon:SetTexCoord(.08, .92, .08, .92); f.icon:Hide()
    f.funken = {}
    for i = 1, 6 do
        local p = f:CreateTexture(nil, "ARTWORK"); p:SetTexture(MEDIA .. "glow"); p:SetBlendMode("ADD"); p:SetSize(9, 9)
        p:SetVertexColor(1, .82, .2); f.funken[i] = p
    end
    return f
end
-- „Sehr dick“: vier dunkle Kopien hinter der Zahl (einmal je Rahmen angelegt, danach wiederverwendet)
local function konturKopien(f, an, schrift, groesse, flag, text)
    if not an then
        if f.kopien then for _, k in ipairs(f.kopien) do k:Hide() end end
        return
    end
    if not f.kopien then
        f.kopien = {}
        for i, v in ipairs(KONTUR_VERSATZ) do
            local k = f:CreateFontString(nil, "ARTWORK"); k:SetPoint("CENTER", f.t, "CENTER", v[1], v[2]); f.kopien[i] = k
        end
    end
    for _, k in ipairs(f.kopien) do
        k:SetFont(schrift, groesse, flag); k:SetShadowOffset(0, 0); k:SetText(text)
        k:SetTextColor(DUNKEL[1], DUNKEL[2], DUNKEL[3]); k:Show()
    end
end

local function platte(unit)
    if not (C_NamePlate and C_NamePlate.GetNamePlateForUnit) then return end
    local ok, p = pcall(C_NamePlate.GetNamePlateForUnit, unit)
    if ok and type(p) == "table" and p.IsShown and p:IsShown() then return p end
end
-- Namensplaketten von Gegnern dürfen Addons nicht vermessen (GetCenter & Co. sind gesperrt).
-- Die Zahlen werden deshalb nur an der Plakette verankert (SetPoint) – das ist erlaubt.
local PLATTE_HOEHE = 16   -- Abstand über der Mitte der Plakette
local function mittePunkt()
    return UIParent:GetWidth() / 2, UIParent:GetHeight() / 2 + 110
end

local Plaketten = {}   -- GUID → Einheit (nameplateN)
NS.Plaketten = Plaketten

local function hatKyrillisch(s) return s:find("[\208\209][\128-\191]") ~= nil end

-- Schriftart, Größe und Kontur auf eine Zahl anwenden
local function schriftSetzen(f, text, groesse, db)
    local s = NS.Schrift(db.schrift)
    local pfad = s.pfad
    if not s.kyr and hatKyrillisch(text) then pfad = kyrSchrift() end
    local kontur = db.kontur
    local flag = (kontur == "keine" and "") or (kontur == "duenn" and "OUTLINE") or "THICKOUTLINE"
    -- WoW-Schrift fehlt (z. B. andere Sprachversion des Spiels)? Dann die siikk-Schrift
    if f.t:SetFont(pfad, groesse, flag) == false then pfad = NS.SCHRIFT; f.t:SetFont(pfad, groesse, flag) end
    if db.schatten then f.t:SetShadowColor(DUNKEL[1], DUNKEL[2], DUNKEL[3], .9); f.t:SetShadowOffset(2, -2)
    else f.t:SetShadowOffset(0, 0) end
    f.t:SetText(text)
    konturKopien(f, kontur == "sehrdick", pfad, groesse, flag, text)
end

local function textBreite(f, text, groesse)
    local ok, w = pcall(f.t.GetStringWidth, f.t)
    if not ok or type(w) ~= "number" or w <= 0 then w = #text * groesse * .62 end
    return w
end

local function leuchtenAn(f, text, groesse)
    f.g:Show(); f.g:SetVertexColor(1, .62, .1)
    f.g:SetSize(textBreite(f, text, groesse) * 1.6 + 40, groesse * 2.4)
    for i, sp in ipairs(f.funken) do
        sp:Show(); local w = (i / #f.funken) * math.pi * 2 + math.random() * .5
        sp.dx, sp.dy = math.cos(w), math.sin(w) * .6
    end
end

-- Bahn einer Zahl je Muster festlegen (beim Erscheinen)
local function bahnStarten(f, krit, db, anker, hoehe)
    local m, s = db.muster, db.streuung
    f.muster, f.streu = m, s
    f.ox, f.oy, f.steig = 0, krit and 34 or 6, krit and 26 or 64
    seite = -seite; f.seite = seite
    local basis = krit and 1.8 or 1.4
    if m == "aufsteigen" then
        spur = spur % #SPUREN + 1
        f.ox = krit and 0 or SPUREN[spur] * s
    elseif m == "faecher" then
        f.w = (math.random() * 2 - 1) * math.min(1.25, .75 * s + .05)
    elseif m == "explosion" then
        f.w = math.random() * math.pi * 2; basis = basis * .75
    elseif m == "fallen" then
        f.vx = seite * (12 + math.random() * 45 * s)
    elseif m == "seitlich" then
        f.ry = (math.random() * 2 - 1) * 14 * s
    elseif m == "stapel" then
        -- ältere Zahlen am selben Ziel eine Zeile nach oben schieben
        for _, a in ipairs(Akt) do
            if a.muster == "stapel" and a.anker == anker then a.zielY = (a.zielY or 0) + hoehe end
        end
        f.cy, f.zielY = 0, 0
        f.oy = krit and 14 or 6
    end
    f.dauer = basis / db.tempo
end

local function ease(x) return 1 - (1 - x) * (1 - x) end
local function easeKubisch(x) local y = 1 - x; return 1 - y * y * y end

-- Position relativ zum Ziel zur Zeit t (p = Anteil der Lebensdauer)
local function bahn(f, t, p, el)
    local m, s = f.muster, f.streu
    if m == "bogen" then
        return f.seite * (16 + 100 * s) * p, f.oy + 78 * math.sin(math.pi * p) - 50 * p * p
    elseif m == "faecher" then
        local d = 105 * ease(p)
        return math.sin(f.w) * d, f.oy + math.cos(f.w) * d
    elseif m == "stapel" then
        f.cy = f.cy + (f.zielY - f.cy) * math.min(1, (el or 0) * 14)
        return 0, f.oy + f.cy + 8 * p
    elseif m == "seitlich" then
        return f.seite * (18 + (90 + 70 * s) * ease(p)), f.oy + f.ry + 10 * p
    elseif m == "explosion" then
        local d = (45 + 70 * s) * easeKubisch(p)
        return math.cos(f.w) * d, f.oy + 8 + math.sin(f.w) * d * .75
    elseif m == "fallen" then
        local z = p * 1.25
        return f.vx * z, f.oy + 30 + 85 * z - 150 * z * z
    end
    return f.ox, f.oy + f.steig * ease(p)
end

-- Zusammenfassen: gleiche Fähigkeit am selben Ziel innerhalb von 0,2 s
local SAMMEL_ZEIT = 0.2
local function sammelSuchen(key)
    if not key then return end
    local jetzt = GetTime()
    for i = #Akt, 1, -1 do
        local a = Akt[i]
        if a.sammelKey == key and jetzt - a.sammelT0 <= SAMMEL_ZEIT then return a end
    end
end

-- art: "normal" | "krit" | "dot" | "pet" | "info" | "heil" | "heilkrit"
-- opt (optional): { icon = Textur, key = Sammel-Schlüssel, menge = Zahl, erzwingen = true (Vorschau: auch ohne Plakette) }
local LEER = {}
function NS.Zeigen(text, r, g, b, art, guid, opt)
    local db = NS.DB()
    opt = opt or LEER
    local unit = guid and Plaketten[guid]
    local p = unit and platte(unit)
    local bx, by
    if not p then
        if not db.mitte and not opt.erzwingen then return end
        bx, by = mittePunkt(); unit = nil
    end
    local krit = (art == "krit" or art == "heilkrit")

    -- Zusammenfassen: vorhandene Zahl hochzählen statt eine neue zu zeigen
    if db.zusammenfassen and opt.key and opt.menge then
        local a = sammelSuchen(opt.key)
        if a then
            a.summe, a.anzahl = a.summe + opt.menge, a.anzahl + 1
            local tx = (art == "heil" or art == "heilkrit") and "+" .. NS.zahl(a.summe) or NS.zahl(a.summe)
            if krit and db.ausrufe then tx = tx .. "!" end
            tx = tx .. " x" .. a.anzahl
            schriftSetzen(a, tx, a.groesse, db)
            a.popNeu = GetTime()
            return a
        end
    end

    local max = db.maxZahlen
    while #Akt >= max do local alt = table.remove(Akt, 1); alt:Hide(); Pool[#Pool + 1] = alt end
    local f = neuesFeld()
    local groesse = 24 * db.groesse * (NS.Schrift(db.schrift).faktor or 1)
    if krit then groesse = groesse * db.kritGroesse
    elseif art == "dot" then groesse = groesse * (db.dotsKlein and .8 or 1)
    elseif art == "pet" then groesse = groesse * .85
    elseif art == "info" then groesse = groesse * .75 end
    local skal = 1
    if groesse > 60 then skal = groesse / 60; groesse = 60 end
    groesse = math.floor(groesse + .5)
    f:ClearAllPoints()
    schriftSetzen(f, text, groesse, db)
    f.t:SetTextColor(r, g, b)
    f.skal, f.groesse = skal, groesse
    -- Zauber-Symbol links neben der Zahl
    if db.icon and opt.icon then
        f.icon:SetTexture(opt.icon); f.icon:SetSize(groesse * .9, groesse * .9); f.icon:Show()
    else f.icon:Hide() end
    local anker = guid or "mitte"
    f.anker = anker
    bahnStarten(f, krit, db, anker, groesse * skal * 1.1)
    f.istKrit = krit
    f.kritAnim = krit and db.kritAnim or (db.hopsen and "hops" or "keine")
    f.glow = krit and db.leuchten
    if f.glow then leuchtenAn(f, text, groesse)
    else f.g:Hide(); for _, sp in ipairs(f.funken) do sp:Hide() end end
    f.unit, f.guid, f.plate, f.bx, f.by = unit, guid, p, bx, by
    f.t0 = GetTime(); f.popNeu = nil
    f.sammelKey, f.sammelT0, f.summe, f.anzahl = opt.key, f.t0, opt.menge or 0, 1
    f:SetAlpha(0); f:Show()
    Akt[#Akt + 1] = f
    return f
end

-- Größe/Versatz der Krit-Animation (bzw. des kleinen Hüpfers normaler Treffer)
local function animation(f, t)
    local a = f.kritAnim
    if a == "pop" then
        if t < .18 then return 1.9 + (1 - 1.9) * ease(t / .18), 0 end
    elseif a == "wackeln" then
        local sc = 1
        if t < .12 then sc = 1.4 + (1 - 1.4) * ease(t / .12) end
        if t < .55 then return sc, math.sin(t * 46) * 7 * (1 - t / .55) end
        return sc, 0
    elseif a == "pulsieren" then
        local sc = 1
        if t < .15 then sc = 1.45 + (1 - 1.45) * ease(t / .15) end
        return sc * (1 + .16 * math.abs(math.sin(t * 8))), 0
    elseif a == "hops" then
        if t < .1 then return 1.25 + (1 - 1.25) * ease(t / .1), 0 end
    end
    return 1, 0
end

local function aktualisieren(_, el)
    local n = #Akt
    if n == 0 then return end
    local jetzt = GetTime()
    for i = n, 1, -1 do
        local f = Akt[i]
        local t = jetzt - f.t0
        if t >= f.dauer then
            f:Hide(); table.remove(Akt, i); Pool[#Pool + 1] = f
        else
            local frei = true
            if f.plate then
                -- Plakette weg (Mob tot, außer Sicht)? Dann Zahl ausblenden statt irgendwo stehen zu lassen
                if not (f.unit and UnitGUID(f.unit) == f.guid and platte(f.unit) == f.plate) then
                    f.plate = nil; f.t0 = jetzt - f.dauer
                else frei = false end
            end
            local p = t / f.dauer
            local sc, wx = animation(f, t)
            if f.popNeu then   -- zusammengefasst: kurz nachfedern
                local tp = jetzt - f.popNeu
                if tp < .12 then sc = sc * (1.2 - .2 * ease(tp / .12)) else f.popNeu = nil end
            end
            sc = sc * f.skal
            local x, y = bahn(f, t, p, el)
            x = x + wx
            if frei then x, y = x + (f.bx or 0), y + (f.by or 0) else y = y + PLATTE_HOEHE end
            local aus = math.min(.5, f.dauer * .35)
            local a = 1
            if t < .06 then a = t / .06 elseif t > f.dauer - aus then a = (f.dauer - t) / aus end
            if f.muster == "explosion" then a = a * (1 - .5 * p) end
            f:SetScale(sc); f:ClearAllPoints()
            if frei then f:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x / sc, y / sc)
            elseif not pcall(f.SetPoint, f, "CENTER", f.plate, "CENTER", x / sc, y / sc) then
                -- Verankern verboten (sollte nicht vorkommen): dann in der Bildschirmmitte weiter
                f.plate = nil; f.bx, f.by = mittePunkt()
                f:SetPoint("CENTER", UIParent, "BOTTOMLEFT", (f.bx + x) / sc, (f.by + y - PLATTE_HOEHE) / sc)
            end
            f:SetAlpha(a)
            if f.glow then
                local q = math.min(t / .7, 1)
                local ga = (1 - q) * .75
                if f.kritAnim == "pulsieren" then ga = (.35 + .4 * math.abs(math.sin(t * 8))) * (1 - p) end
                f.g:SetAlpha(ga)
                local d = 18 + 70 * ease(math.min(t / .55, 1))
                local fa = math.max(0, 1 - t / .55)
                for _, sp in ipairs(f.funken) do
                    sp:ClearAllPoints(); sp:SetPoint("CENTER", f, "CENTER", sp.dx * d / sc, sp.dy * d / sc)
                    sp:SetAlpha(fa)
                end
            end
        end
    end
end
if not NS.MIDNIGHT then Ebene:SetScript("OnUpdate", aktualisieren) else Ebene:Hide() end

-- Zauber-Symbol (Classic Era liefert im Kampflog oft keine Zauber-ID, dann über den Namen)
local ANGRIFF = "Interface\\Icons\\INV_Sword_04"
local function symbol(id, name)
    local fn = (C_Spell and C_Spell.GetSpellTexture) or GetSpellTexture
    if not fn then return end
    if type(id) == "number" and id > 0 then local ok, t = pcall(fn, id); if ok and t then return t end end
    if type(name) == "string" and name ~= "" then local ok, t = pcall(fn, name); if ok and t then return t end end
end
NS.Symbol = symbol

-- Ein Treffer: Farbe, Text und Zusammenfassen an einer Stelle (Kampflog und Vorschau)
local TREFFER_OPT = {}
function NS.Treffer(menge, schule, art, guid, key, icon, erzwingen)
    local db = NS.DB()
    local heil = (art == "heil" or art == "heilkrit")
    local r, g, b = NS.Farbe(schule, heil and "heil" or art)
    local text = NS.zahl(menge)
    if heil then text = "+" .. text end
    if (art == "krit" or art == "heilkrit") and db.ausrufe then text = text .. "!" end
    local o = TREFFER_OPT   -- wiederverwendet: kein neuer Table je Treffer
    o.icon, o.key, o.menge, o.erzwingen = icon, key, menge, erzwingen
    return NS.Zeigen(text, r, g, b, art, guid, o)
end

-- Kampflog ----------------------------------------------------------------
local MEIN = COMBATLOG_OBJECT_AFFILIATION_MINE or 0x1
local PET = (COMBATLOG_OBJECT_TYPE_PET or 0x1000) + (COMBATLOG_OBJECT_TYPE_GUARDIAN or 0x2000)
local VERFEHLT = {
    MISS = L"Verfehlt", DODGE = L"Ausgewichen", PARRY = L"Pariert", BLOCK = L"Geblockt", RESIST = L"Widerstanden",
    IMMUNE = L"Immun", ABSORB = L"Absorbiert", EVADE = L"Entkommen", REFLECT = L"Reflektiert", DEFLECT = L"Abgelenkt", DEFLECTED = L"Abgelenkt",
}
local ich
local SCHADEN = { RANGE_DAMAGE = true, SPELL_DAMAGE = true, SPELL_PERIODIC_DAMAGE = true, SPELL_BUILDING_DAMAGE = true, DAMAGE_SHIELD = true, DAMAGE_SPLIT = true }
local VERF = { SPELL_MISSED = true, RANGE_MISSED = true, SPELL_PERIODIC_MISSED = true, DAMAGE_SHIELD_MISSED = true }

function NS.Kampflog(_, sub, _, sG, _, sF, _, dG, _, _, _, a12, a13, a14, a15, a16, a17, a18, a19, a20, a21)
    local db = NS.DB()
    if not db.an or NS.MIDNIGHT then return end
    ich = ich or UnitGUID("player")
    local vonMir = (sG == ich)
    local vomPet = (not vonMir) and type(sF) == "number" and band(sF, MEIN) > 0 and band(sF, PET) > 0
    if not vonMir and not (vomPet and db.pet) then return end
    if dG == ich and not sub:find("HEAL") then return end
    local menge, schule, krit, art, key, icon
    if sub == "SWING_DAMAGE" then
        menge, schule, krit = a12, a14, a18
        key = "swing"; if db.icon then icon = ANGRIFF end
    elseif SCHADEN[sub] then
        menge, schule, krit = a15, a14, a21
        key = (a12 and a12 ~= 0) and a12 or a13
        if db.icon then icon = symbol(a12, a13) end
    elseif sub == "SWING_MISSED" or VERF[sub] then
        if not db.verfehlt then return end
        local typ = (sub == "SWING_MISSED") and a12 or a15
        local c = GRAU
        NS.Zeigen(VERFEHLT[typ] or tostring(typ or L"Verfehlt"), c[1], c[2], c[3], "info", dG); return
    elseif sub == "SPELL_HEAL" or sub == "SPELL_PERIODIC_HEAL" then
        if not db.heilung then return end
        local eff = (a15 or 0) - (a16 or 0); if eff <= 0 then return end
        local hArt = a18 and "heilkrit" or "heil"
        local k = "h:" .. tostring((a12 and a12 ~= 0) and a12 or a13) .. ":" .. tostring(dG) .. ":" .. hArt
        NS.Treffer(eff, nil, hArt, dG, k, db.icon and symbol(a12, a13) or nil); return
    else return end
    if type(menge) ~= "number" or menge <= 0 then return end
    if krit then art = "krit"
    elseif vomPet then art = "pet"
    elseif sub == "SPELL_PERIODIC_DAMAGE" then art = "dot"
    else art = "normal" end
    key = tostring(key) .. ":" .. tostring(dG) .. ":" .. art .. (vomPet and ":p" or "")
    NS.Treffer(menge, schule, art, dG, key, icon)
end

-- Blizzard-Zahlen über dem Gegner aus-/einschalten (nur Anniversary/Classic/Forever)
local BLIZZ = { "floatingCombatTextCombatDamage", "floatingCombatTextPetMeleeDamage", "floatingCombatTextPetSpellDamage", "floatingCombatTextCombatHealing" }
local function cvar(n) if C_CVar and C_CVar.GetCVar then return C_CVar.GetCVar(n) end; if GetCVar then return GetCVar(n) end end
local function cvarSetzen(n, v) if C_CVar and C_CVar.SetCVar then pcall(C_CVar.SetCVar, n, v) elseif SetCVar then pcall(SetCVar, n, v) end end
function NS.BlizzardAnpassen()
    if NS.MIDNIGHT then return end
    local db = NS.DB()
    if db.an then
        db.blizz = db.blizz or {}
        for _, n in ipairs(BLIZZ) do
            local v = cvar(n)
            if v ~= nil and db.blizz[n] == nil then db.blizz[n] = v end
            if n ~= "floatingCombatTextCombatHealing" or db.heilung then cvarSetzen(n, "0") end
        end
        if not db.heilung and db.blizz.floatingCombatTextCombatHealing then cvarSetzen("floatingCombatTextCombatHealing", db.blizz.floatingCombatTextCombatHealing) end
    elseif db.blizz then
        for n, v in pairs(db.blizz) do cvarSetzen(n, v) end
        db.blizz = nil
    end
end

function NS.Umschalten(an)
    local db = NS.DB()
    if an == nil then an = not db.an end
    db.an = an
    NS.BlizzardAnpassen()
    if NS.MIDNIGHT then NS.msg(L"In Midnight und Forever gibt Blizzard Addons keinen Kampflog – hier wird nur die Schrift der Blizzard-Zahlen ersetzt.") return end
    NS.msg(an and L"eigene Schadenszahlen |cff33ff33an|r." or L"eigene Schadenszahlen |cffff6060aus|r – Blizzard-Zahlen sind wieder da.")
    if NS.OptAktualisieren then NS.OptAktualisieren() end
end

-- Vorschau: Beispielzahlen über dem Ziel (ohne Ziel/Plakette in der Bildschirmmitte) mit den aktuellen Einstellungen
local I = "Interface\\Icons\\"
local VORSCHAU = {
    { 0, 412, 32, "normal", "sb", I .. "Spell_Shadow_ShadowBolt" },
    { .22, 186, 32, "dot", "kor", I .. "Spell_Shadow_AbominationExplosion" },
    { .45, 94, 4, "normal", "feu", I .. "Spell_Fire_Immolation" },
    { .62, 63, 64, "normal", "arc", I .. "Spell_Nature_StarFall" },
    { .7, 63, 64, "normal", "arc", I .. "Spell_Nature_StarFall" },
    { .78, 63, 64, "normal", "arc", I .. "Spell_Nature_StarFall" },
    { .95, 1248, 32, "krit", "sbk", I .. "Spell_Shadow_ShadowBolt" },
    { 1.15, 57, 1, "pet", "pet", I .. "Spell_Shadow_SummonImp" },
    { 1.3, "info" },
    { 1.5, 186, 32, "dot", "kor", I .. "Spell_Shadow_AbominationExplosion" },
    { 1.7, 231, 16, "normal", "fro", I .. "Spell_Frost_FrostBolt02" },
    { 1.9, 23456, 4, "krit", "feuk", I .. "Spell_Fire_FireBolt02" },
    { 2.1, 148, 8, "normal", "nat", I .. "Spell_Nature_StarFall" },
}
function NS.Vorschau()
    if NS.MIDNIGHT then NS.msg(L"Die Vorschau gibt es nur in Anniversary und Classic.") return end
    local guid = UnitGUID("target")
    local db = NS.DB()
    for _, z in ipairs(VORSCHAU) do
        local function los()
            if z[2] == "info" then
                if db.verfehlt then NS.Zeigen(L"Widerstanden", GRAU[1], GRAU[2], GRAU[3], "info", guid, { erzwingen = true }) end
            elseif z[4] ~= "pet" or db.pet then
                NS.Treffer(z[2], z[3], z[4], guid, "v:" .. z[5], z[6], true)
            end
        end
        if C_Timer and z[1] > 0 then C_Timer.After(z[1], los) else los() end
    end
    if db.heilung then
        local function h() NS.Treffer(320, nil, "heil", guid, "v:heil", I .. "Spell_Holy_Heal", true) end
        if C_Timer then C_Timer.After(1.05, h) else h() end
    end
end

-- Ereignisse --------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED"); ev:RegisterEvent("PLAYER_LOGIN")
if not NS.MIDNIGHT then ev:RegisterEvent("NAME_PLATE_UNIT_ADDED"); ev:RegisterEvent("NAME_PLATE_UNIT_REMOVED") end
-- Falls Blizzard trotzdem etwas sperrt: genau sagen, was (für die Fehlersuche)
pcall(ev.RegisterEvent, ev, "ADDON_ACTION_FORBIDDEN"); pcall(ev.RegisterEvent, ev, "ADDON_ACTION_BLOCKED")
if not NS.MIDNIGHT and type(CombatLogGetCurrentEventInfo) == "function" then pcall(ev.RegisterEvent, ev, "COMBAT_LOG_EVENT_UNFILTERED") end
ev:SetScript("OnEvent", function(_, e, a1, ...)
    if e == "ADDON_ACTION_FORBIDDEN" or e == "ADDON_ACTION_BLOCKED" then
        if a1 == ADDON then NS.msg(L"Blizzard hat gesperrt: " .. tostring(select(1, ...) or "?")) end
    elseif e == "COMBAT_LOG_EVENT_UNFILTERED" then
        if CombatLogGetCurrentEventInfo then NS.Kampflog(CombatLogGetCurrentEventInfo()) end
    elseif e == "NAME_PLATE_UNIT_ADDED" then
        local g = a1 and UnitGUID(a1); if g then Plaketten[g] = a1 end
    elseif e == "NAME_PLATE_UNIT_REMOVED" then
        for g, u in pairs(Plaketten) do if u == a1 then Plaketten[g] = nil end end
    elseif e == "ADDON_LOADED" and a1 == ADDON then
        -- gewählte Schrift auch für die Blizzard-Zahlen (gilt ab dem nächsten Einloggen)
        local db = NS.DBNeuPruefen()
        -- Forever: schon das Setzen dieser Blizzard-Variable führt dort zu „wurde geblockt“
        if db.blizzSchrift and not NS.FOREVER then DAMAGE_TEXT_FONT = NS.Schrift(db.schrift).pfad end
    elseif e == "PLAYER_LOGIN" then
        ich = UnitGUID("player")
        NS.BlizzardAnpassen()
    end
end)

-- Befehle -----------------------------------------------------------------
SLASH_SIIKKSZ1 = "/sz"; SLASH_SIIKKSZ2 = "/schadenszahlen"
SlashCmdList.SIIKKSZ = function(m)
    m = (m or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    local w = m:match("^stil%s+(%S+)$")
    if m == "" then if NS.Optionen then NS.Optionen() end
    elseif m == "an" then NS.Umschalten(true)
    elseif m == "aus" then NS.Umschalten(false)
    elseif m == "test" or m == "vorschau" then NS.Vorschau()
    elseif m == "intro" then local f = SiikkIntroAPI and SiikkIntroAPI["siikk-Schadenszahlen"]; if f then f() end
    elseif m == "neu" then local f = SiikkNeuAPI and SiikkNeuAPI["siikk-Schadenszahlen"]; if f then f() end
    elseif m == "reset" or m == "standard" then NS.Zuruecksetzen(); NS.msg(L"Einstellungen auf Standard zurückgesetzt.")
    elseif w then
        if NS.VorlageAnwenden(w) then NS.msg(L"Stil-Vorlage: " .. Y .. NS.Vorlage(w).name .. "|r")
        else local t = {}; for _, v in ipairs(NS.VORLAGEN) do t[#t + 1] = v.id end; NS.msg(L"Stil-Vorlagen: " .. table.concat(t, ", ")) end
    else
        NS.msg(L"Befehle:")
        print(Y .. L"/sz|r – Einstellungen · " .. Y .. "/sz an|r / " .. Y .. L"aus|r – eigene Zahlen an/aus · " .. Y .. L"/sz test|r – Vorschau")
        print(Y .. L"/sz stil <name>|r – Stil-Vorlage (siikk, klassisch, minimal, episch, comic, retro, elegant, explosiv) · " .. Y .. L"/sz reset|r – Standard")
        print(Y .. L"/sz intro|r – Einführung · " .. Y .. L"/sz neu|r – was ist neu")
    end
end
