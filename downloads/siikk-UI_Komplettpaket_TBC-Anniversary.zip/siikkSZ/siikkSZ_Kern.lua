-- siikk-Schadenszahlen · eigene Schadenszahlen über dem Gegner im siikk-Stil
-- Anniversary / Classic / Forever: eigene Zahlen aus dem Kampflog, an der Namensplakette des Gegners.
-- Midnight: Blizzard gibt Addons dort keinen Kampflog mehr – dann wird nur die Schrift der Blizzard-Zahlen ersetzt.
local ADDON, NS = ...
local L = siikkL or function(s) return s end
NS.VERSION = "1.2"
local MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\Media\\"
NS.MEDIA = MEDIA
NS.SCHRIFT = MEDIA .. "Poppins-BoldItalic.ttf"
NS.MIDNIGHT = (WOW_PROJECT_ID ~= nil and WOW_PROJECT_MAINLINE ~= nil and WOW_PROJECT_ID == WOW_PROJECT_MAINLINE)
local Y = "|cffffd100"
function NS.msg(t) print(L"|cffe03030siikk|r-|cffffd100Schadenszahlen|r: " .. t) end

-- Einstellungen ------------------------------------------------------------
local STANDARD = {
    an = true, groesse = 1.0, kritGroesse = 1.6, leuchten = true, ausrufe = true, farben = true,
    pet = true, dotsKlein = true, verfehlt = true, heilung = false, kurz = false, mitte = true, blizzSchrift = true,
}
NS.STANDARD = STANDARD
function NS.DB()
    local db = rawget(_G, "siikkSZ_DB")
    if type(db) ~= "table" then db = {}; siikkSZ_DB = db end
    for k, v in pairs(STANDARD) do if db[k] == nil then db[k] = v end end
    return db
end

-- Farben je Magieschule (wie in der Vorschau: Schatten lila, Feuer orange, Krit gold)
local SCHULE = {
    [1] = { 1, 1, 1 },          -- körperlich
    [2] = { 1, .9, .5 },        -- Heilig
    [4] = { 1, .54, .16 },      -- Feuer
    [8] = { .55, 1, .35 },      -- Natur
    [16] = { .5, .85, 1 },      -- Frost
    [32] = { .77, .55, 1 },     -- Schatten
    [64] = { 1, .5, 1 },        -- Arkan
}
local GOLD = { 1, .82, .1 }
local HEIL = { .3, 1, .45 }
local GRAU = { .75, .75, .75 }
local function farbe(schule)
    if not schule or schule == 0 then return SCHULE[1] end
    if SCHULE[schule] then return SCHULE[schule] end
    for _, b in ipairs({ 32, 4, 16, 64, 8, 2, 1 }) do if bit.band(schule, b) > 0 then return SCHULE[b] end end
    return SCHULE[1]
end

-- Zahlen: 1.248 · kurz 12,5k
local function punkte(n)
    local s = tostring(math.floor(n + 0.5))
    local r = s:reverse():gsub("(%d%d%d)", "%1."):reverse()
    return (r:gsub("^%.", ""))
end
function NS.zahl(n)
    if NS.DB().kurz then
        if n >= 1e6 then return (("%.1f"):format(n / 1e6):gsub("%.", ",")) .. L" Mio" end
        if n >= 1e4 then return (("%.1f"):format(n / 1e3):gsub("%.", ",")) .. "k" end
    end
    return punkte(n)
end

-- Anzeige -----------------------------------------------------------------
local Ebene = CreateFrame("Frame", "siikkSZEbene", UIParent)
Ebene:SetAllPoints(UIParent); Ebene:SetFrameStrata("LOW")
local Akt, Pool = {}, {}
local MAX = 40
local SPUREN = { 0, -48, 46, -26, 28, -64, 62, -10 }
local spur = 0

local function neuesFeld()
    local f = table.remove(Pool)
    if f then return f end
    f = CreateFrame("Frame", nil, Ebene); f:SetSize(2, 2)
    f.g = f:CreateTexture(nil, "BACKGROUND"); f.g:SetTexture(MEDIA .. "glow"); f.g:SetBlendMode("ADD"); f.g:SetPoint("CENTER")
    f.t = f:CreateFontString(nil, "OVERLAY"); f.t:SetPoint("CENTER")
    f.funken = {}
    for i = 1, 6 do
        local p = f:CreateTexture(nil, "ARTWORK"); p:SetTexture(MEDIA .. "glow"); p:SetBlendMode("ADD"); p:SetSize(9, 9)
        p:SetVertexColor(1, .82, .2); f.funken[i] = p
    end
    return f
end

local function platte(unit)
    if not (C_NamePlate and C_NamePlate.GetNamePlateForUnit) then return end
    local ok, p = pcall(C_NamePlate.GetNamePlateForUnit, unit)
    if ok and type(p) == "table" and p.IsShown and p:IsShown() then return p end
end
-- Namensplaketten von Gegnern dürfen Addons nicht vermessen (GetCenter & Co. sind gesperrt).
-- Die Zahlen werden deshalb nur an der Plakette verankert (SetPoint) – das ist erlaubt.
local PLATTE_HOEHE = 16   -- Abstand über der Mitte der Plakette
local function mittePunkt()
    return UIParent:GetWidth() / 2, UIParent:GetHeight() / 2 + 110
end

local Plaketten = {}   -- GUID → Einheit (nameplateN)

-- art: "normal" | "krit" | "dot" | "pet" | "info" | "heil"
function NS.Zeigen(text, r, g, b, art, guid)
    local db = NS.DB()
    local unit = guid and Plaketten[guid]
    local p = unit and platte(unit)
    local bx, by
    if not p then
        if not db.mitte then return end
        bx, by = mittePunkt(); unit = nil
    end
    if #Akt >= MAX then local alt = table.remove(Akt, 1); alt:Hide(); Pool[#Pool + 1] = alt end
    local f = neuesFeld()
    local krit = (art == "krit")
    local groesse = 24 * db.groesse
    if krit then groesse = groesse * db.kritGroesse
    elseif art == "dot" then groesse = groesse * (db.dotsKlein and .8 or 1)
    elseif art == "pet" then groesse = groesse * .85
    elseif art == "info" then groesse = groesse * .75 end
    local skal = 1
    if groesse > 60 then skal = groesse / 60; groesse = 60 end
    -- Poppins hat keine kyrillischen Zeichen: Wörter („Verfehlt“ …) auf Russisch in einer Schrift mit Kyrillisch
    local schrift = NS.SCHRIFT
    if art == "info" and siikkSprache and siikkSprache() == "ru" then schrift = (GetLocale and GetLocale() == "ruRU") and "Fonts\\FRIZQT__.TTF" or "Fonts\\FRIZQT___CYR.TTF" end
    f.t:SetFont(schrift, groesse, "THICKOUTLINE")
    f.t:SetShadowColor(.07, .03, .09, .9); f.t:SetShadowOffset(2, -2)
    f:ClearAllPoints()
    f.t:SetText(text); f.t:SetTextColor(r, g, b)
    f.skal = skal
    spur = spur % #SPUREN + 1
    f.ox = krit and 0 or SPUREN[spur]
    f.oy = krit and 34 or 6
    f.steig = krit and 26 or 64
    f.dauer = krit and 1.8 or (art == "info" and 1.1 or 1.4)
    f.pop = krit and 1.9 or 1.25
    f.popZeit = krit and .18 or .1
    f.krit = krit and db.leuchten
    if f.krit then
        f.g:Show(); f.g:SetVertexColor(1, .62, .1); local ok, w = pcall(f.t.GetStringWidth, f.t)
        if not ok or type(w) ~= "number" or w <= 0 then w = #text * groesse * .62 end
        f.g:SetSize(w * 1.6 + 40, groesse * 2.4)
        for i, sp in ipairs(f.funken) do
            sp:Show(); local w = (i / #f.funken) * math.pi * 2 + math.random() * .5
            sp.dx, sp.dy = math.cos(w), math.sin(w) * .6
        end
    else
        f.g:Hide(); for _, sp in ipairs(f.funken) do sp:Hide() end
    end
    f.unit, f.guid, f.plate, f.bx, f.by = unit, guid, p, bx, by
    f.t0 = GetTime()
    f:SetAlpha(0); f:Show()
    Akt[#Akt + 1] = f
end

local function ease(x) return 1 - (1 - x) * (1 - x) end
Ebene:SetScript("OnUpdate", function()
    if #Akt == 0 then return end
    local jetzt = GetTime()
    for i = #Akt, 1, -1 do
        local f = Akt[i]
        local t = jetzt - f.t0
        if t >= f.dauer then
            f:Hide(); table.remove(Akt, i); Pool[#Pool + 1] = f
        else
            local frei = true
            if f.plate then
                -- Plakette weg (Mob tot, außer Sicht)? Dann Zahl ausblenden statt irgendwo stehen zu lassen
                if not (f.unit and UnitGUID(f.unit) == f.guid and platte(f.unit) == f.plate) then
                    f.plate = nil; f.t0 = jetzt - f.dauer
                else frei = false end
            end
            local sc = 1
            if t < f.popZeit then sc = f.pop + (1 - f.pop) * ease(t / f.popZeit) end
            sc = sc * f.skal
            local x = f.ox
            local y = f.oy + f.steig * ease(t / f.dauer)
            if frei then x, y = x + (f.bx or 0), y + (f.by or 0) else y = y + PLATTE_HOEHE end
            local a = 1
            if t < .06 then a = t / .06 elseif t > f.dauer - .5 then a = (f.dauer - t) / .5 end
            f:SetScale(sc); f:ClearAllPoints()
            if frei then f:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x / sc, y / sc)
            elseif not pcall(f.SetPoint, f, "CENTER", f.plate, "CENTER", x / sc, y / sc) then
                -- Verankern verboten (sollte nicht vorkommen): dann in der Bildschirmmitte weiter
                f.plate = nil; f.bx, f.by = mittePunkt()
                f:SetPoint("CENTER", UIParent, "BOTTOMLEFT", (f.bx + x) / sc, (f.by + y - PLATTE_HOEHE) / sc)
            end
            f:SetAlpha(a)
            if f.krit then
                local q = math.min(t / .7, 1)
                f.g:SetAlpha((1 - q) * .75)
                for _, sp in ipairs(f.funken) do
                    local d = 18 + 70 * ease(math.min(t / .55, 1))
                    sp:ClearAllPoints(); sp:SetPoint("CENTER", f, "CENTER", sp.dx * d / sc, sp.dy * d / sc)
                    sp:SetAlpha(math.max(0, 1 - t / .55))
                end
            end
        end
    end
end)

-- Kampflog ----------------------------------------------------------------
local MEIN = COMBATLOG_OBJECT_AFFILIATION_MINE or 0x1
local PET = (COMBATLOG_OBJECT_TYPE_PET or 0x1000) + (COMBATLOG_OBJECT_TYPE_GUARDIAN or 0x2000)
local VERFEHLT = {
    MISS = L"Verfehlt", DODGE = L"Ausgewichen", PARRY = L"Pariert", BLOCK = L"Geblockt", RESIST = L"Widerstanden",
    IMMUNE = L"Immun", ABSORB = L"Absorbiert", EVADE = L"Entkommen", REFLECT = L"Reflektiert", DEFLECT = L"Abgelenkt", DEFLECTED = L"Abgelenkt",
}
local ich
local SCHADEN = { RANGE_DAMAGE = true, SPELL_DAMAGE = true, SPELL_PERIODIC_DAMAGE = true, SPELL_BUILDING_DAMAGE = true, DAMAGE_SHIELD = true, DAMAGE_SPLIT = true }
local VERF = { SPELL_MISSED = true, RANGE_MISSED = true, SPELL_PERIODIC_MISSED = true, DAMAGE_SHIELD_MISSED = true }

function NS.Kampflog(_, sub, _, sG, _, sF, _, dG, _, _, _, a12, a13, a14, a15, a16, a17, a18, a19, a20, a21)
    local db = NS.DB()
    if not db.an or NS.MIDNIGHT then return end
    ich = ich or UnitGUID("player")
    local vonMir = (sG == ich)
    local vomPet = (not vonMir) and type(sF) == "number" and bit.band(sF, MEIN) > 0 and bit.band(sF, PET) > 0
    if not vonMir and not (vomPet and db.pet) then return end
    if dG == ich and not sub:find("HEAL") then return end
    local menge, schule, krit, art
    if sub == "SWING_DAMAGE" then menge, schule, krit = a12, a14, a18
    elseif SCHADEN[sub] then menge, schule, krit = a15, a14, a21
    elseif sub == "SWING_MISSED" or VERF[sub] then
        if not db.verfehlt then return end
        local typ = (sub == "SWING_MISSED") and a12 or a15
        local c = GRAU
        NS.Zeigen(VERFEHLT[typ] or tostring(typ or L"Verfehlt"), c[1], c[2], c[3], "info", dG); return
    elseif sub == "SPELL_HEAL" or sub == "SPELL_PERIODIC_HEAL" then
        if not db.heilung then return end
        local eff = (a15 or 0) - (a16 or 0); if eff <= 0 then return end
        NS.Zeigen("+" .. NS.zahl(eff), HEIL[1], HEIL[2], HEIL[3], a18 and "krit" or "normal", dG); return
    else return end
    if type(menge) ~= "number" or menge <= 0 then return end
    local c = db.farben and farbe(schule) or SCHULE[1]
    if krit then
        art = "krit"; c = GOLD
    elseif vomPet then art = "pet"
    elseif sub == "SPELL_PERIODIC_DAMAGE" then art = "dot"
    else art = "normal" end
    local text = NS.zahl(menge)
    if krit and db.ausrufe then text = text .. "!" end
    NS.Zeigen(text, c[1], c[2], c[3], art, dG)
end

-- Blizzard-Zahlen über dem Gegner aus-/einschalten (nur Anniversary/Classic/Forever)
local BLIZZ = { "floatingCombatTextCombatDamage", "floatingCombatTextPetMeleeDamage", "floatingCombatTextPetSpellDamage", "floatingCombatTextCombatHealing" }
local function cvar(n) if C_CVar and C_CVar.GetCVar then return C_CVar.GetCVar(n) end; if GetCVar then return GetCVar(n) end end
local function cvarSetzen(n, v) if C_CVar and C_CVar.SetCVar then pcall(C_CVar.SetCVar, n, v) elseif SetCVar then pcall(SetCVar, n, v) end end
function NS.BlizzardAnpassen()
    if NS.MIDNIGHT then return end
    local db = NS.DB()
    if db.an then
        db.blizz = db.blizz or {}
        for _, n in ipairs(BLIZZ) do
            local v = cvar(n)
            if v ~= nil and db.blizz[n] == nil then db.blizz[n] = v end
            if n ~= "floatingCombatTextCombatHealing" or db.heilung then cvarSetzen(n, "0") end
        end
        if not db.heilung and db.blizz.floatingCombatTextCombatHealing then cvarSetzen("floatingCombatTextCombatHealing", db.blizz.floatingCombatTextCombatHealing) end
    elseif db.blizz then
        for n, v in pairs(db.blizz) do cvarSetzen(n, v) end
        db.blizz = nil
    end
end

function NS.Umschalten(an)
    local db = NS.DB()
    if an == nil then an = not db.an end
    db.an = an
    NS.BlizzardAnpassen()
    if NS.MIDNIGHT then NS.msg(L"In Midnight gibt Blizzard Addons keinen Kampflog – hier wird nur die Schrift der Blizzard-Zahlen ersetzt.") return end
    NS.msg(an and L"eigene Schadenszahlen |cff33ff33an|r." or L"eigene Schadenszahlen |cffff6060aus|r – Blizzard-Zahlen sind wieder da.")
    if NS.OptAktualisieren then NS.OptAktualisieren() end
end

-- Vorschau
function NS.Vorschau()
    if NS.MIDNIGHT then NS.msg(L"Die Vorschau gibt es nur in Anniversary, Classic und Forever.") return end
    local guid = UnitGUID("target")
    local db = NS.DB()
    local S, F = farbe(32), farbe(4)
    local liste = {
        { 0, "412", S, "normal" }, { .25, "186", S, "dot" }, { .5, "94", F, "normal" },
        { .8, NS.zahl(1248) .. (db.ausrufe and "!" or ""), GOLD, "krit" }, { 1.2, L"Widerstanden", GRAU, "info" }, { 1.45, "186", S, "dot" },
    }
    if db.pet then liste[#liste + 1] = { 1.0, "57", { 1, 1, 1 }, "pet" } end
    for _, z in ipairs(liste) do
        local function los() local c = db.farben and z[3] or (z[4] == "krit" and GOLD or SCHULE[1]); NS.Zeigen(z[2], c[1], c[2], c[3], z[4], guid) end
        if C_Timer and z[1] > 0 then C_Timer.After(z[1], los) else los() end
    end
end

-- Ereignisse --------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED"); ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("NAME_PLATE_UNIT_ADDED"); ev:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
if not NS.MIDNIGHT then pcall(ev.RegisterEvent, ev, "COMBAT_LOG_EVENT_UNFILTERED") end
ev:SetScript("OnEvent", function(_, e, a1)
    if e == "COMBAT_LOG_EVENT_UNFILTERED" then
        if CombatLogGetCurrentEventInfo then NS.Kampflog(CombatLogGetCurrentEventInfo()) end
    elseif e == "NAME_PLATE_UNIT_ADDED" then
        local g = a1 and UnitGUID(a1); if g then Plaketten[g] = a1 end
    elseif e == "NAME_PLATE_UNIT_REMOVED" then
        for g, u in pairs(Plaketten) do if u == a1 then Plaketten[g] = nil end end
    elseif e == "ADDON_LOADED" and a1 == ADDON then
        -- Schrift auch für die Blizzard-Zahlen (gilt ab dem nächsten Einloggen)
        if NS.DB().blizzSchrift then DAMAGE_TEXT_FONT = NS.SCHRIFT end
    elseif e == "PLAYER_LOGIN" then
        ich = UnitGUID("player")
        NS.BlizzardAnpassen()
    end
end)

-- Befehle -----------------------------------------------------------------
SLASH_SIIKKSZ1 = "/sz"; SLASH_SIIKKSZ2 = "/schadenszahlen"
SlashCmdList.SIIKKSZ = function(m)
    m = (m or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    if m == "" then if NS.Optionen then NS.Optionen() end
    elseif m == "an" then NS.Umschalten(true)
    elseif m == "aus" then NS.Umschalten(false)
    elseif m == "test" or m == "vorschau" then NS.Vorschau()
    elseif m == "intro" then local f = SiikkIntroAPI and SiikkIntroAPI["siikk-Schadenszahlen"]; if f then f() end
    elseif m == "neu" then local f = SiikkNeuAPI and SiikkNeuAPI["siikk-Schadenszahlen"]; if f then f() end
    else
        NS.msg(L"Befehle:")
        print(Y .. L"/sz|r – Einstellungen · " .. Y .. "/sz an|r / " .. Y .. L"aus|r – eigene Zahlen an/aus · " .. Y .. L"/sz test|r – Vorschau")
        print(Y .. L"/sz intro|r – Einführung · " .. Y .. L"/sz neu|r – was ist neu")
    end
end
