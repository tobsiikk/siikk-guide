-- siikk-Schadenszahlen · eigener Minimap-Knopf
local ADDON, NS = ...
local L = siikkL or function(s) return s end
siikkMinimapKnopf("siikk-Schadenszahlen", "|cffe03030siikk|r-|cffffd100Schadenszahlen|r", NS.MEDIA .. "siikk_sz_icon",
    function() local db = NS.DB(); db.mm = db.mm or {}; return db.mm end,
    function() NS.Optionen() end,
    function() NS.Vorschau() end,
    NS.FOREVER and { L"In Forever ohne Funktion – Linksklick: Info" }
        or NS.MIDNIGHT and { L"Linksklick: Einstellungen (Schrift und Größe der Blizzard-Zahlen)" }
        or { L"Linksklick: Einstellungen", L"Rechtsklick: Vorschau (über deinem Ziel)" }, 290)
