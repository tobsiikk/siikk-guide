-- siikk-Schadenszahlen · „Was ist neu?“ – erzeugt aus tools/changelog.py (nicht von Hand ändern)
local L = siikkL or function(s) return s end
siikkNeu("siikk-Schadenszahlen", "|cffe03030siikk|r-|cffffd100Schadenszahlen|r", "Interface\\AddOns\\siikkSZ\\Media\\siikk_sz_icon", "1.2",
{
    { version = "1.2", datum = "02.11.2026", punkte = { L"Neu: Sprache wählbar – Deutsch, English, Русский, Français, Español. Mit /sprache für alle siikk-Addons auf einmal umschalten (startet in der Sprache deines WoW)." } },
    { version = "1.1", datum = "31.10.2026", punkte = { L"Fehler behoben: „NamePlate:GetCenter() … Can't measure restricted regions“ beim Treffen eines Gegners.", L"Die Zahlen werden jetzt direkt an der Namensplakette verankert statt sie zu vermessen – sie folgen dem Mob weiterhin.", L"Verschwindet die Namensplakette (Mob tot oder außer Sicht), blenden die Zahlen sauber aus." } },
    { version = "1.0", datum = "31.10.2026", punkte = { L"Neues Addon: schönere Schadenszahlen über dem Gegner im siikk-Stil – fette, kursive Schrift mit dunkler Kontur.", L"Farben je Magieschule (Schatten lila, Feuer orange …), Krits in Gold mit „!“, Leuchten und Funken.", L"Begleiter-Schaden und DoT-Ticks kleiner, Verfehlt/Widerstanden in Grau, auf Wunsch deine Heilung in Grün.", L"Einstellungen mit /sz, Vorschau mit /sz test. In Midnight wird nur die Schrift der Blizzard-Zahlen ersetzt." } }
}, function() return rawget(_G, "siikkSZ_DB") end, "/sz neu")
