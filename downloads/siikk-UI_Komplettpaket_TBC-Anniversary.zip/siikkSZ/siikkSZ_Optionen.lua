-- siikk-Schadenszahlen · Einstellungsfenster (/sz)
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local GOLD = { .85, .65, .15 }
local f

local function kasten(fr)
    fr:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    fr:SetBackdropColor(.03, .02, .05, .96); fr:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
end

local haken, regler, auswahlen, farbfelder = {}, {}, {}, {}
NS.OptHaken, NS.OptRegler, NS.OptAuswahl, NS.OptFarben = haken, regler, auswahlen, farbfelder

local function tooltip(fr, titel, tipp)
    if not tipp then return end
    fr:SetScript("OnEnter", function(s) GameTooltip:SetOwner(s, "ANCHOR_RIGHT"); GameTooltip:AddLine(titel, 1, .82, 0); GameTooltip:AddLine(tipp, 1, 1, 1, true); GameTooltip:Show() end)
    fr:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

local VORLAGE_KEY = {}
for _, k in ipairs(NS.VORLAGE_KEYS) do VORLAGE_KEY[k] = true end
-- nach jeder Änderung: abhängige Anzeigen (Vorlage „angepasst“, Hinweise) auffrischen
local function geaendert(key)
    if key == "an" or key == "heilung" then NS.BlizzardAnpassen() end
    if VORLAGE_KEY[key] or key == "vorlage" then for _, a in ipairs(auswahlen) do if a.key == "vorlage" then a:Auffrischen() end end end
    if f and f.musterInfo then f.musterInfo:Auffrischen() end
end

local function hakenNeu(par, x, y, key, text, tipp)
    local cb = CreateFrame("CheckButton", nil, par, "UICheckButtonTemplate")
    cb:SetSize(24, 24); cb:SetPoint("TOPLEFT", x, y)
    local l = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); l:SetPoint("LEFT", cb, "RIGHT", 4, 1); l:SetText(text)
    cb:SetScript("OnClick", function(s)
        NS.DB()[key] = s:GetChecked() and true or false
        if key == "blizzSchrift" then NS.msg(L"Die Schrift der Blizzard-Zahlen ändert sich nach dem nächsten Einloggen.") end
        geaendert(key)
    end)
    tooltip(cb, text, tipp)
    cb.key = key; haken[#haken + 1] = cb
    return cb
end

-- Regler: gespeichert wird Anzeigewert / teiler (Prozent-Regler: teiler 100)
local function reglerNeu(par, x, y, key, text, min, max, schritt, teiler, einheit, beiAenderung, tipp)
    schritt, teiler, einheit = schritt or 5, teiler or 100, einheit or " %"
    local l = par:CreateFontString(nil, "OVERLAY", "GameFontNormal"); l:SetPoint("TOPLEFT", x, y); l:SetText(text)
    local wert = par:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); wert:SetPoint("TOPRIGHT", par, "TOPLEFT", x + 220, y)
    local s = CreateFrame("Slider", nil, par, "BackdropTemplate")
    s:SetOrientation("HORIZONTAL"); s:SetSize(220, 12); s:SetPoint("TOPLEFT", x, y - 18)
    s:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    s:SetBackdropColor(.12, .08, .16, 1); s:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .8)
    local th = s:CreateTexture(nil, "OVERLAY"); th:SetColorTexture(1, .82, .1, 1); th:SetSize(10, 16); s:SetThumbTexture(th)
    s:SetMinMaxValues(min, max); s:SetValueStep(schritt); if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
    s.anzeigen = function(v) wert:SetText(math.floor(v + .5) .. einheit) end
    s:SetScript("OnValueChanged", function(_, v)
        v = math.floor(v / schritt + .5) * schritt
        s.anzeigen(v)
        if s.laden then return end
        NS.DB()[key] = v / teiler
        if beiAenderung then beiAenderung(v / teiler) end
        geaendert(key)
    end)
    tooltip(s, text, tipp)
    s.key = key; s.wert = wert; s.teiler = teiler; regler[#regler + 1] = s
    return s
end

-- Auswahl-Liste (eigene, statt UIDropDownMenu – läuft in allen Clients gleich)
local liste
local function listeSchliessen() if liste then liste:Hide() end end
NS.ListeSchliessen = listeSchliessen
local function listeOeffnen(knopf, eintraege, aktiv, waehlen, schriftVorschau)
    if not liste then
        liste = CreateFrame("Frame", "siikkSZListe", UIParent, "BackdropTemplate")
        liste:SetFrameStrata("FULLSCREEN_DIALOG"); liste:EnableMouse(true); kasten(liste)
        liste.knoepfe = {}
        tinsert(UISpecialFrames, "siikkSZListe")
    end
    if liste:IsShown() and liste.besitzer == knopf then liste:Hide() return end
    liste.besitzer = knopf
    for i, e in ipairs(eintraege) do
        local b = liste.knoepfe[i]
        if not b then
            b = CreateFrame("Button", nil, liste); b:SetSize(220, 20); b:SetPoint("TOPLEFT", 6, -6 - (i - 1) * 21)
            b:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
            b.fs = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); b.fs:SetPoint("LEFT", 8, 0); b.fs:SetJustifyH("LEFT")
            liste.knoepfe[i] = b
        end
        local txt = (e.id == aktiv and "|cffffd100» " or "") .. e.name .. (e.id == aktiv and " «|r" or "")
        if schriftVorschau then
            -- Schriftnamen in der jeweiligen Schrift zeigen (fehlt sie, bleibt die normale)
            if b.fs:SetFont(NS.Schrift(e.id).pfad, 14, "OUTLINE") == false then b.fs:SetFontObject(GameFontHighlight) end
            b.eigeneSchrift = true
        elseif b.eigeneSchrift then b.fs:SetFontObject(GameFontHighlight); b.eigeneSchrift = nil end
        b.fs:SetText(txt)
        b:SetScript("OnClick", function() liste:Hide(); waehlen(e.id) end)
        tooltip(b, e.name, e.tipp)
        if not e.tipp then b:SetScript("OnEnter", nil); b:SetScript("OnLeave", nil) end
        b:Show()
    end
    for i = #eintraege + 1, #liste.knoepfe do liste.knoepfe[i]:Hide() end
    liste:SetSize(232, #eintraege * 21 + 12)
    liste:ClearAllPoints(); liste:SetPoint("TOPLEFT", knopf, "BOTTOMLEFT", 0, -2)
    liste:Show()
end

local function auswahlNeu(par, x, y, key, text, eintraege, opt)
    opt = opt or {}
    local l = par:CreateFontString(nil, "OVERLAY", "GameFontNormal"); l:SetPoint("TOPLEFT", x, y); l:SetText(text)
    local b = CreateFrame("Button", nil, par, "BackdropTemplate")
    b:SetSize(220, 22); b:SetPoint("TOPLEFT", x, y - 16)
    b:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    b:SetBackdropColor(.12, .08, .16, 1); b:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .8)
    b:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
    b.fs = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); b.fs:SetPoint("LEFT", 8, 0); b.fs:SetJustifyH("LEFT")
    local pfeil = b:CreateFontString(nil, "OVERLAY", "GameFontNormal"); pfeil:SetPoint("RIGHT", -8, 0); pfeil:SetText("v")
    b.key, b.eintraege = key, eintraege
    function b:Auffrischen()
        local db = NS.DB(); local name = "?"
        for _, e in ipairs(eintraege) do if e.id == db[key] then name = e.name end end
        if key == "vorlage" and not NS.VorlageUnveraendert() then name = name .. L" |cff999999(angepasst)|r" end
        self.fs:SetText(name)
    end
    local function waehlen(id)
        if key == "vorlage" then NS.VorlageAnwenden(id) else NS.DB()[key] = id end
        if opt.beiWahl then opt.beiWahl(id) end
        b:Auffrischen(); geaendert(key)
        if NS.OptAktualisieren then NS.OptAktualisieren() end
        if opt.vorschau and not NS.MIDNIGHT and not (InCombatLockdown and InCombatLockdown()) then NS.Vorschau() end
    end
    b.Waehlen = waehlen
    b:SetScript("OnClick", function(s) listeOeffnen(s, eintraege, NS.DB()[key], waehlen, opt.schriftVorschau) end)
    tooltip(b, text, opt.tipp)
    auswahlen[#auswahlen + 1] = b
    return b
end

-- Farbwähler: neue API (SetupColorPickerAndShow) oder alte (func / previousValues)
local function farbWaehler(c, fertig)
    local r, g, b = c[1], c[2], c[3]
    local function setzen(nr, ng, nb) c[1], c[2], c[3] = nr, ng, nb; fertig() end
    local cpf = rawget(_G, "ColorPickerFrame"); if not cpf then return end
    if cpf.SetupColorPickerAndShow then
        cpf:SetupColorPickerAndShow({
            r = r, g = g, b = b, hasOpacity = false,
            swatchFunc = function() setzen(cpf:GetColorRGB()) end,
            cancelFunc = function() setzen(r, g, b) end,
        })
    else
        cpf:Hide()
        cpf.hasOpacity, cpf.opacityFunc = false, nil
        cpf.previousValues = { r, g, b }
        cpf.func = function() setzen(cpf:GetColorRGB()) end
        cpf.cancelFunc = function() setzen(r, g, b) end
        cpf:SetColorRGB(r, g, b)
        if ShowUIPanel then ShowUIPanel(cpf) else cpf:Show() end
    end
end
NS.FarbWaehler = farbWaehler

local function farbfeldNeu(par, x, y, key, text, tipp)
    local b = CreateFrame("Button", nil, par, "BackdropTemplate")
    b:SetSize(22, 22); b:SetPoint("TOPLEFT", x, y)
    b:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    b:SetBackdropColor(0, 0, 0, 1); b:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
    b.farbe = b:CreateTexture(nil, "ARTWORK"); b.farbe:SetPoint("TOPLEFT", 3, -3); b.farbe:SetPoint("BOTTOMRIGHT", -3, 3)
    local l = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); l:SetPoint("LEFT", b, "RIGHT", 8, 0); l:SetText(text)
    b.key = key
    function b:Auffrischen() local c = NS.DB()[key]; self.farbe:SetColorTexture(c[1], c[2], c[3], 1) end
    b:SetScript("OnClick", function(s) farbWaehler(NS.DB()[key], function() s:Auffrischen() end) end)
    tooltip(b, text, tipp)
    farbfelder[#farbfelder + 1] = b
    return b
end

function NS.OptAktualisieren()
    if not f then return end
    local db = NS.DB()
    for _, cb in ipairs(haken) do cb:SetChecked(db[cb.key] and true or false) end
    for _, s in ipairs(regler) do
        local v = (db[s.key] or 1) * s.teiler
        s.laden = true; s:SetValue(v); s.laden = nil; s.anzeigen(v)
    end
    for _, a in ipairs(auswahlen) do a:Auffrischen() end
    for _, b in ipairs(farbfelder) do b:Auffrischen() end
    if f.musterInfo then f.musterInfo:Auffrischen() end
end

local function ueberschrift(par, x, y, text)
    local h = par:CreateFontString(nil, "OVERLAY", "GameFontNormal"); h:SetPoint("TOPLEFT", x, y); h:SetText(text); return h
end

local function seiteAussehen(p)
    auswahlNeu(p, 18, -8, "vorlage", L"Stil-Vorlage", NS.VORLAGEN, { vorschau = true,
        tipp = L"Ein Klick setzt Schrift, Größe, Kontur, Leuchten und Bewegung auf einmal. Danach kannst du alles einzeln weiter ändern." })
    auswahlNeu(p, 18, -60, "schrift", L"Schriftart", NS.SCHRIFTEN, { schriftVorschau = true, vorschau = true,
        tipp = L"Für Wörter wie „Ausgewichen“ auf Russisch wird bei Schriften ohne kyrillische Zeichen automatisch Friz Quadrata verwendet." })
    auswahlNeu(p, 18, -112, "kontur", L"Kontur", NS.KONTUREN, { vorschau = true })
    hakenNeu(p, 14, -166, "schatten", L"Schatten")
    hakenNeu(p, 14, -192, "leuchten", L"Krits mit Leuchten und Funken")
    hakenNeu(p, 14, -218, "ausrufe", L"„!“ hinter Krits")
    hakenNeu(p, 14, -244, "icon", L"Zauber-Symbol neben der Zahl", L"Kleines Symbol der Fähigkeit links neben der Zahl.")
    reglerNeu(p, 290, -8, "groesse", L"Schriftgröße", 50, 200)
    reglerNeu(p, 290, -60, "kritGroesse", L"Krit-Größe", 100, 250, 5, 100, " %", nil, L"Wie viel größer Krits als normale Treffer sind.")
end

local function seiteBewegung(p)
    auswahlNeu(p, 18, -8, "muster", L"Muster (Bewegung der Zahlen)", NS.MUSTER, { vorschau = true })
    auswahlNeu(p, 18, -60, "kritAnim", L"Krit-Animation", NS.KRITANIM, { vorschau = true })
    hakenNeu(p, 14, -114, "hopsen", L"Normale Treffer hüpfen kurz auf", L"Kleiner Hüpfer, wenn eine Zahl erscheint. Aus = ganz ruhig.")
    local info = p:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); info:SetPoint("TOPLEFT", 18, -150); info:SetWidth(240); info:SetJustifyH("LEFT")
    function info:Auffrischen()
        local db = NS.DB(); local m, k
        for _, e in ipairs(NS.MUSTER) do if e.id == db.muster then m = e end end
        for _, e in ipairs(NS.KRITANIM) do if e.id == db.kritAnim then k = e end end
        self:SetText((m and ("|cffffd100" .. m.name .. ":|r " .. m.tipp) or "") .. "\n\n" .. (k and ("|cffffd100" .. L"Krits" .. " – " .. k.name .. ":|r " .. k.tipp) or ""))
    end
    f.musterInfo = info
    reglerNeu(p, 290, -8, "tempo", L"Geschwindigkeit", 50, 200, 5, 100, " %", nil, L"Höher = Zahlen sind schneller wieder weg.")
    reglerNeu(p, 290, -60, "streuung", L"Streuung", 0, 200, 5, 100, " %", nil, L"Wie weit die Zahlen auseinanderfliegen.")
    reglerNeu(p, 290, -112, "maxZahlen", L"Höchstens gleichzeitig", 10, 80, 5, 1, "", nil, L"Mehr Zahlen auf einmal werden nicht gezeigt – die älteste macht Platz.")
end

local function seiteFarben(p)
    auswahlNeu(p, 18, -8, "farbModus", L"Farben", NS.FARBMODI, { vorschau = true })
    farbfeldNeu(p, 18, -62, "farbe", L"Eigene Farbe", L"Für den Modus „Eine Farbe“.")
    farbfeldNeu(p, 18, -92, "kritFarbe", L"Krit-Farbe", L"Standard: Gold.")
    farbfeldNeu(p, 18, -122, "heilFarbe", L"Heilung", L"Standard: Grün.")
    local hinweis = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); hinweis:SetPoint("TOPLEFT", 18, -156); hinweis:SetWidth(240); hinweis:SetJustifyH("LEFT")
    hinweis:SetText(L"Verfehlt, Widerstanden & Co. bleiben grau. Schaden an dir zeigt weiterhin Blizzard.")
    auswahlNeu(p, 290, -8, "format", L"Zahlenformat", NS.FORMATE, { vorschau = true,
        tipp = L"12345 · mit Tausenderpunkten (Englisch: Komma) · kurz ab 10.000 (12,3k) und 1 Mio." })
    hakenNeu(p, 286, -62, "zusammenfassen", L"Treffer zusammenfassen", L"Mehrere Treffer derselben Fähigkeit innerhalb von 0,2 Sekunden werden zu einer Zahl mit „x3“.")
end

local function seiteAllgemein(p)
    hakenNeu(p, 14, -6, "an", L"Eigene Schadenszahlen anzeigen", L"Blendet die Blizzard-Zahlen über dem Gegner aus und zeigt stattdessen die siikk-Zahlen.")
    ueberschrift(p, 18, -44, L"Was angezeigt wird")
    hakenNeu(p, 14, -62, "pet", L"Schaden deines Begleiters", L"Wichtel, Leerwandler, Wildtier … etwas kleiner.")
    hakenNeu(p, 14, -88, "dotsKlein", L"DoT-Ticks kleiner", L"Verderbnis, Feuerbrand & Co. stören so weniger.")
    hakenNeu(p, 14, -114, "verfehlt", L"Verfehlt / Widerstanden / Immun")
    hakenNeu(p, 14, -140, "heilung", L"Deine Heilung (grün)")
    hakenNeu(p, 286, -62, "mitte", L"Ohne Namensplakette: Bildschirmmitte", L"Ist die Namensplakette des Gegners aus, erscheinen die Zahlen über der Mitte des Bildschirms.")
    hakenNeu(p, 286, -88, "blizzSchrift", L"Gewählte Schrift auch für Blizzard-Zahlen", L"z. B. Heilung und Schaden an dir selbst. Gilt ab dem nächsten Einloggen.")
    local tip = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); tip:SetPoint("TOPLEFT", 18, -186); tip:SetWidth(520); tip:SetJustifyH("LEFT")
    tip:SetText(L"Tipp: Mit |cffffd100V|r schaltest du die Namensplaketten der Gegner ein – dann stehen die Zahlen direkt über dem Mob.")
end

local REITER = {
    { id = "allgemein", name = L"Allgemein", bauen = seiteAllgemein },
    { id = "aussehen", name = L"Aussehen", bauen = seiteAussehen },
    { id = "bewegung", name = L"Bewegung", bauen = seiteBewegung },
    { id = "farben", name = L"Farben & Zahlen", bauen = seiteFarben },
}
NS.REITER = REITER

function NS.ReiterZeigen(id)
    if not f or not f.seiten then return end
    for _, r in ipairs(REITER) do
        local an = (r.id == id)
        f.seiten[r.id]:SetShown(an)
        f.reiterKnopf[r.id]:SetText(an and ("|cffffd100" .. r.name .. "|r") or r.name)
    end
    f.aktiverReiter = id
    listeSchliessen()
end

local function bauen()
    f = CreateFrame("Frame", "siikkSZOptionen", UIParent, "BackdropTemplate")
    f:SetSize(560, NS.FOREVER and 170 or NS.MIDNIGHT and 330 or 430); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG"); kasten(f)
    f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton"); f:SetClampedToScreen(true)
    f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetScript("OnHide", function() listeSchliessen() end)
    tinsert(UISpecialFrames, "siikkSZOptionen")
    local kopf = f:CreateTexture(nil, "BORDER"); kopf:SetPoint("TOPLEFT", 4, -4); kopf:SetPoint("TOPRIGHT", -4, -4); kopf:SetHeight(28); kopf:SetColorTexture(.315, .19, .45, .8)
    local linie = f:CreateTexture(nil, "ARTWORK"); linie:SetPoint("TOPLEFT", kopf, "BOTTOMLEFT"); linie:SetPoint("TOPRIGHT", kopf, "BOTTOMRIGHT"); linie:SetHeight(1); linie:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], 1)
    local ic = f:CreateTexture(nil, "OVERLAY"); ic:SetSize(22, 22); ic:SetPoint("LEFT", kopf, "LEFT", 6, 0); ic:SetTexture(NS.MEDIA .. "siikk_sz_icon")
    local tt = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); tt:SetPoint("LEFT", ic, "RIGHT", 6, 0); tt:SetText(L"|cffe03030siikk|r-|cffffd100Schadenszahlen|r  |cff999999v" .. NS.VERSION .. "|r")
    local zu = CreateFrame("Button", nil, f, "UIPanelCloseButton"); zu:SetPoint("TOPRIGHT", 0, 0)

    if NS.FOREVER then
        local t = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); t:SetPoint("TOPLEFT", 20, -48); t:SetWidth(520); t:SetJustifyH("LEFT")
        t:SetText(L"In |cffffd100WoW Forever|r lässt Blizzard Addons weder an den Kampflog noch an die Schrift der Schadenszahlen. siikk-Schadenszahlen ist hier deshalb ohne Funktion – du siehst Blizzards normale Zahlen.\n\nDu kannst das Addon für Forever in der Addon-Liste ausschalten. In Anniversary und Classic läuft es mit allen Funktionen.")
    elseif NS.MIDNIGHT then
        local t = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); t:SetPoint("TOPLEFT", 20, -48); t:SetWidth(520); t:SetJustifyH("LEFT")
        t:SetText(L"In |cffffd100Midnight|r und |cffffd100Forever|r lässt Blizzard Addons nicht an den Kampflog. Eigene Zahlen mit Farben und Krit-Leuchten gibt es deshalb nur in Anniversary und Classic.\n\nHier ersetzt siikk die |cffffd100Schrift|r der Blizzard-Zahlen und du kannst ihre Größe ändern.")
        hakenNeu(f, 18, -136, "blizzSchrift", L"siikk-Schrift für die Blizzard-Zahlen", L"Gilt ab dem nächsten Einloggen.")
        auswahlNeu(f, 22, -170, "schrift", L"Schriftart", NS.SCHRIFTEN, { schriftVorschau = true, beiWahl = function()
            NS.msg(L"Die Schrift der Blizzard-Zahlen ändert sich nach dem nächsten Einloggen.") end })
        reglerNeu(f, 290, -170, "groesse", L"Größe der Blizzard-Zahlen", 50, 200, 5, 100, " %", function(v)
            if C_CVar and C_CVar.SetCVar then pcall(C_CVar.SetCVar, "WorldTextScale", v) elseif SetCVar then pcall(SetCVar, "WorldTextScale", v) end
        end)
    else
        f.seiten, f.reiterKnopf = {}, {}
        for i, r in ipairs(REITER) do
            local k = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); k:SetSize(128, 22); k:SetPoint("TOPLEFT", 16 + (i - 1) * 132, -40)
            k:SetText(r.name); k:SetScript("OnClick", function() NS.ReiterZeigen(r.id); NS.DB().reiter = r.id end)
            f.reiterKnopf[r.id] = k
            local s = CreateFrame("Frame", nil, f); s:SetPoint("TOPLEFT", 0, -72); s:SetSize(560, 300)
            f.seiten[r.id] = s
            r.bauen(s)
        end
        local v = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); v:SetSize(150, 24); v:SetPoint("BOTTOMLEFT", 16, 14); v:SetText(L"Vorschau")
        v:SetScript("OnClick", function() NS.Vorschau() end)
        f.vorschauKnopf = v
    end
    local s = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); s:SetSize(200, 24); s:SetPoint("BOTTOM", 0, 14); s:SetText(L"Auf Standard zurücksetzen")
    s:SetScript("OnClick", function() NS.Zuruecksetzen() end)
    f.standardKnopf = s
    local z = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); z:SetSize(150, 24); z:SetPoint("BOTTOMRIGHT", -16, 14); z:SetText(L"Schließen")
    z:SetScript("OnClick", function() f:Hide() end)
    f:Hide()   -- neu erzeugte Rahmen sind sichtbar; NS.Optionen zeigt es gleich wieder
    if f.seiten then
        local r = NS.DB().reiter
        local ok = false; for _, x in ipairs(REITER) do if x.id == r then ok = true end end
        NS.ReiterZeigen(ok and r or "aussehen")
    end
end

function NS.Optionen()
    if not f then bauen() end
    if f:IsShown() then f:Hide() else NS.OptAktualisieren(); f:Show() end
end
