-- siikk-Schadenszahlen · Einstellungsfenster (/sz)
local ADDON, NS = ...
local L = siikkL or function(s) return s end
local GOLD = { .85, .65, .15 }
local f

local function kasten(fr)
    fr:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    fr:SetBackdropColor(.03, .02, .05, .96); fr:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
end

local haken, regler = {}, {}

local function hakenNeu(par, x, y, key, text, tipp)
    local cb = CreateFrame("CheckButton", nil, par, "UICheckButtonTemplate")
    cb:SetSize(24, 24); cb:SetPoint("TOPLEFT", x, y)
    local l = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); l:SetPoint("LEFT", cb, "RIGHT", 4, 1); l:SetText(text)
    cb:SetScript("OnClick", function(s)
        NS.DB()[key] = s:GetChecked() and true or false
        if key == "an" or key == "heilung" then NS.BlizzardAnpassen() end
        if key == "blizzSchrift" then NS.msg(L"Die Schrift der Blizzard-Zahlen ändert sich nach dem nächsten Einloggen.") end
    end)
    if tipp then
        cb:SetScript("OnEnter", function(s) GameTooltip:SetOwner(s, "ANCHOR_RIGHT"); GameTooltip:AddLine(text, 1, .82, 0); GameTooltip:AddLine(tipp, 1, 1, 1, true); GameTooltip:Show() end)
        cb:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    cb.key = key; haken[#haken + 1] = cb
    return cb
end

local function reglerNeu(par, x, y, key, text, min, max, beiAenderung)
    local l = par:CreateFontString(nil, "OVERLAY", "GameFontNormal"); l:SetPoint("TOPLEFT", x, y); l:SetText(text)
    local wert = par:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); wert:SetPoint("TOPRIGHT", par, "TOPLEFT", x + 220, y)
    local s = CreateFrame("Slider", nil, par, "BackdropTemplate")
    s:SetOrientation("HORIZONTAL"); s:SetSize(220, 12); s:SetPoint("TOPLEFT", x, y - 18)
    s:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    s:SetBackdropColor(.12, .08, .16, 1); s:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .8)
    local th = s:CreateTexture(nil, "OVERLAY"); th:SetColorTexture(1, .82, .1, 1); th:SetSize(10, 16); s:SetThumbTexture(th)
    s:SetMinMaxValues(min, max); s:SetValueStep(5); if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
    s:SetScript("OnValueChanged", function(_, v)
        v = math.floor(v / 5 + .5) * 5
        wert:SetText(v .. " %")
        NS.DB()[key] = v / 100
        if beiAenderung then beiAenderung(v / 100) end
    end)
    s.key = key; s.wert = wert; regler[#regler + 1] = s
    return s
end

function NS.OptAktualisieren()
    if not f then return end
    local db = NS.DB()
    for _, cb in ipairs(haken) do cb:SetChecked(db[cb.key] and true or false) end
    for _, s in ipairs(regler) do s:SetValue((db[s.key] or 1) * 100); s.wert:SetText(math.floor((db[s.key] or 1) * 100 + .5) .. " %") end
end

local function bauen()
    f = CreateFrame("Frame", "siikkSZOptionen", UIParent, "BackdropTemplate")
    f:SetSize(520, NS.MIDNIGHT and 300 or 470); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG"); kasten(f)
    f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton"); f:SetClampedToScreen(true)
    f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
    tinsert(UISpecialFrames, "siikkSZOptionen")
    local kopf = f:CreateTexture(nil, "BORDER"); kopf:SetPoint("TOPLEFT", 4, -4); kopf:SetPoint("TOPRIGHT", -4, -4); kopf:SetHeight(28); kopf:SetColorTexture(.315, .19, .45, .8)
    local linie = f:CreateTexture(nil, "ARTWORK"); linie:SetPoint("TOPLEFT", kopf, "BOTTOMLEFT"); linie:SetPoint("TOPRIGHT", kopf, "BOTTOMRIGHT"); linie:SetHeight(1); linie:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], 1)
    local ic = f:CreateTexture(nil, "OVERLAY"); ic:SetSize(22, 22); ic:SetPoint("LEFT", kopf, "LEFT", 6, 0); ic:SetTexture(NS.MEDIA .. "siikk_sz_icon")
    local tt = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); tt:SetPoint("LEFT", ic, "RIGHT", 6, 0); tt:SetText(L"|cffe03030siikk|r-|cffffd100Schadenszahlen|r  |cff999999v" .. NS.VERSION .. "|r")
    local zu = CreateFrame("Button", nil, f, "UIPanelCloseButton"); zu:SetPoint("TOPRIGHT", 0, 0)

    if NS.MIDNIGHT then
        local t = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); t:SetPoint("TOPLEFT", 20, -48); t:SetWidth(480); t:SetJustifyH("LEFT")
        t:SetText(L"In |cffffd100Midnight|r lässt Blizzard Addons nicht mehr an den Kampflog. Eigene Zahlen mit Farben und Krit-Leuchten gibt es deshalb nur in Anniversary, Classic und Forever.\n\nHier ersetzt siikk die |cffffd100Schrift|r der Blizzard-Zahlen und du kannst ihre Größe ändern.")
        hakenNeu(f, 18, -140, "blizzSchrift", L"siikk-Schrift für die Blizzard-Zahlen", L"Gilt ab dem nächsten Einloggen.")
        reglerNeu(f, 22, -186, "groesse", L"Größe der Blizzard-Zahlen", 50, 200, function(v)
            if C_CVar and C_CVar.SetCVar then pcall(C_CVar.SetCVar, "WorldTextScale", v) elseif SetCVar then pcall(SetCVar, "WorldTextScale", v) end
        end)
    else
        hakenNeu(f, 18, -44, "an", L"Eigene Schadenszahlen anzeigen", L"Blendet die Blizzard-Zahlen über dem Gegner aus und zeigt stattdessen die siikk-Zahlen.")
        reglerNeu(f, 22, -84, "groesse", L"Größe", 50, 200)
        reglerNeu(f, 272, -84, "kritGroesse", L"Krit-Größe", 100, 250)
        local h = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); h:SetPoint("TOPLEFT", 20, -134); h:SetText(L"Aussehen")
        hakenNeu(f, 18, -152, "leuchten", L"Krits mit Leuchten und Funken")
        hakenNeu(f, 18, -178, "ausrufe", L"„!“ hinter Krits")
        hakenNeu(f, 18, -204, "farben", L"Farben je Magieschule", L"Schatten lila, Feuer orange, Frost hellblau, Natur grün, Arkan rosa, Heilig hellgelb. Aus = alles weiß, Krits gold.")
        hakenNeu(f, 18, -230, "kurz", L"Kurze Zahlen (12,5k statt 12.500)")
        hakenNeu(f, 18, -256, "blizzSchrift", L"siikk-Schrift auch für Blizzard-Zahlen", L"z. B. Heilung und Schaden an dir selbst. Gilt ab dem nächsten Einloggen.")
        local h2 = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); h2:SetPoint("TOPLEFT", 270, -134); h2:SetText(L"Was angezeigt wird")
        hakenNeu(f, 268, -152, "pet", L"Schaden deines Begleiters", L"Wichtel, Leerwandler, Wildtier … etwas kleiner.")
        hakenNeu(f, 268, -178, "dotsKlein", L"DoT-Ticks kleiner", L"Verderbnis, Feuerbrand & Co. stören so weniger.")
        hakenNeu(f, 268, -204, "verfehlt", L"Verfehlt / Widerstanden / Immun")
        hakenNeu(f, 268, -230, "heilung", L"Deine Heilung (grün)")
        hakenNeu(f, 268, -256, "mitte", L"Ohne Namensplakette: Bildschirmmitte", L"Ist die Namensplakette des Gegners aus, erscheinen die Zahlen über der Mitte des Bildschirms.")
        local tip = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); tip:SetPoint("TOPLEFT", 20, -300); tip:SetWidth(480); tip:SetJustifyH("LEFT")
        tip:SetText(L"Tipp: Mit |cffffd100V|r schaltest du die Namensplaketten der Gegner ein – dann stehen die Zahlen direkt über dem Mob.")
        local v = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); v:SetSize(140, 24); v:SetPoint("BOTTOMLEFT", 16, 14); v:SetText(L"Vorschau")
        v:SetScript("OnClick", function() NS.Vorschau() end)
    end
    local s = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); s:SetSize(140, 24); s:SetPoint("BOTTOM", 0, 14); s:SetText(L"Standard")
    s:SetScript("OnClick", function()
        local db = NS.DB(); for k, v in pairs(NS.STANDARD) do db[k] = v end
        NS.BlizzardAnpassen(); NS.OptAktualisieren()
    end)
    local z = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); z:SetSize(140, 24); z:SetPoint("BOTTOMRIGHT", -16, 14); z:SetText(L"Schließen")
    z:SetScript("OnClick", function() f:Hide() end)
end

function NS.Optionen()
    if not f then bauen() end
    if f:IsShown() then f:Hide() else NS.OptAktualisieren(); f:Show() end
end
