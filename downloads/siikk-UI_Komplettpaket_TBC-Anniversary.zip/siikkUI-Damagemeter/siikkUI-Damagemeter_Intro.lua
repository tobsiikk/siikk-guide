-- siikk-Damagemeter · Einführung beim ersten Start (/meter intro)
local L = siikkL or function(s) return s end
local ADDON = ...
local Y = "|cffffd100"
siikkIntro("siikk-Damagemeter", "|cffe03030siikk|r-|cffffd100Damagemeter|r", "Interface\\AddOns\\" .. ADDON .. "\\Media\\siikk_dm_icon", {
    { L"Willkommen beim siikk-Damagemeter",
      L"Der Damagemeter zeigt dir nach jedem Kampf, wer wie viel " .. Y .. L"Schaden|r gemacht, " .. Y .. L"geheilt|r oder " .. Y .. L"Aggro|r gezogen hat – für dich, deine Gruppe und deinen Schlachtzug. Begleiter (z. B. dein Wichtel) zählen zu ihrem Besitzer.\n\n" ..
      L"• Jeder Balken in Klassenfarbe mit Klassensymbol.\n\n" ..
      L"• Läuft mit jeder Oberfläche – mit der siikk-Oberfläche zusammen übernimmt er, der eingebaute Messer startet dann nicht.\n\n" ..
      L"• An der Minimap hat er seinen eigenen Knopf (gekreuzte Schwerter)." },
    { L"Das Fenster",
      "• " .. Y .. L"Reiter oben|r: Schaden · Heilung · Aggro.\n\n" ..
      "• " .. Y .. L"Kampf / Gesamt|r: nur der letzte Kampf oder alles seit dem Zurücksetzen.\n\n" ..
      "• " .. Y .. L"Maus über einen Spieler|r: Aufschlüsselung nach Fähigkeiten, die stärkste oben.\n\n" ..
      "• " .. Y .. L"Verschieben|r: an der Kopfzeile ziehen. " .. Y .. L"Größe|r: am Griff unten rechts.\n\n" ..
      "• " .. Y .. L"+|r öffnet bis zu 3 weitere Fenster – z. B. Schaden und Heilung nebeneinander. " .. Y .. L"Reset|r setzt alle Werte zurück." },
    { L"Aggro",
      L"• Im Reiter " .. Y .. L"Aggro|r siehst du, wie nah jeder an der Bedrohung des Tanks ist.\n\n" ..
      L"• Ab 80 % blinkt dein Balken rot – Zeit, kurz langsamer zu machen.\n\n" ..
      "• " .. Y .. L"Klick auf einen Namen|r visiert diesen Spieler an – auch im Kampf." },
    { L"Minimap-Knopf & Befehle",
      L"Minimap-Knopf: " .. Y .. L"Linksklick|r Fenster an/aus · " .. Y .. L"Rechtsklick|r Schaden → Heilung → Aggro · " .. Y .. L"Shift+Linksklick|r zurücksetzen · " .. Y .. L"Ziehen|r verschiebt den Knopf.\n\n" ..
      Y .. L"/meter|r – an/aus\n" .. Y .. L"/meter schaden|r · " .. Y .. L"heilung|r · " .. Y .. L"aggro|r – Reiter wechseln\n" ..
      Y .. L"/meter kampf|r · " .. Y .. L"gesamt|r – Zeitraum\n" .. Y .. L"/meter 2|r · " .. Y .. "3|r · " .. Y .. L"4|r – weitere Fenster\n" ..
      Y .. L"/meter reset|r – zurücksetzen\n" .. Y .. L"/meter intro|r – diese Einführung · " .. Y .. L"/meter neu|r – was ist neu\n\n" ..
      L"Mit der siikk-Oberfläche: " .. Y .. L"/th addons|r schaltet den Damagemeter und seinen Minimap-Knopf an oder aus." },
}, function() return DamagemeterTobsiikkDB end, "/meter intro")

do -- /meter intro
    local alt = SlashCmdList.SIIKKUIDM
    SlashCmdList.SIIKKUIDM = function(input)
        local a = (input or ""):lower():match("^%s*(.-)%s*$")
        if a == "intro" or a == "info" or a == "einführung" then SiikkIntroAPI["siikk-Damagemeter"]() return end
        if a == "neu" or a == "neuigkeiten" then if SiikkNeuAPI and SiikkNeuAPI["siikk-Damagemeter"] then SiikkNeuAPI["siikk-Damagemeter"]() end return end
        if alt then alt(input) end
    end
end
