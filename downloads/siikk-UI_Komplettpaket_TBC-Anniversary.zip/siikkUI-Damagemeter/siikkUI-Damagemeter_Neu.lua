-- siikk-Damagemeter · „Was ist neu?“ – erzeugt aus tools/changelog.py (nicht von Hand ändern)
local L = siikkL or function(s) return s end
siikkNeu("siikk-Damagemeter", "|cffe03030siikk|r-|cffffd100Damagemeter|r", "Interface\\AddOns\\siikkUI-Damagemeter\\Media\\siikk_dm_icon", "2.6",
{
    { version = "2.6", datum = "02.11.2026", punkte = { L"Neu: Sprache wählbar – Deutsch, English, Русский, Français, Español. Mit /sprache für alle siikk-Addons auf einmal umschalten (startet in der Sprache deines WoW)." } },
    { version = "2.5", datum = "31.10.2026", punkte = { L"Neu: Fenster „Was ist neu?“ nach jedem Update (wieder öffnen: /meter neu)." } },
    { version = "2.4", datum = "31.10.2026", punkte = { L"Neu: Einführung beim ersten Start (/meter intro)." } },
    { version = "2.3", datum = "31.10.2026", punkte = { L"Neuer Name: siikk-Damagemeter.", L"Eigener Minimap-Knopf (gekreuzte Schwerter): Linksklick an/aus, Rechtsklick Schaden → Heilung → Aggro, Shift+Linksklick zurücksetzen." } },
    { version = "2.2", datum = "31.10.2026", punkte = { L"siikkUI-Schild oben auf dem Messer, neue Standard-Position." } }
}, function() return DamagemeterTobsiikkDB end, "/meter neu")
