-- siikkUI
-- /th öffnet die Einstellungen, /th hilfe zeigt alle Befehle

local ADDON, NS = ...
NS = NS or {}
NS.GOLD = NS.GOLD or { .85, .65, .15 } -- Rahmenfarbe für alle Teile (änderbar im Reiter „Rahmen & Chat“)

-- Fraktions-Logo (Horde/Allianz) – EIN Schalter für alle Stellen: Chat, Zauberleiste, Lebensleisten, Aktionsleisten, Tooltip, Charakterfenster
NS.logos = {}
NS.ALLIANZ = { { "Interface\\AddOns\\siikkUI\\Media\\allianz_hd", 0, 1, 0, 1 }, { "Interface\\Timer\\Alliance-Logo", 0, 1, 0, 1 }, { "Interface\\BattlefieldFrame\\Battleground-Alliance", 0, 1, 0, 1 }, { "Interface\\TargetingFrame\\UI-PVP-Alliance", 0, .625, 0, .625 } }
NS.zeichenArt = function()
  local d = rawget(_G, "TobsiikkHelferDB"); local z = type(d) == "table" and d.zeichen
  if z == "horde" or z == "allianz" then return z end
  local ok, f = pcall(UnitFactionGroup, "player")
  return (ok and f == "Alliance") and "allianz" or "horde"
end
NS.paintLogo = function(e)
  local t = e.tex
  if NS.zeichenArt() == "horde" then
    t:SetTexture(e.horde, nil, nil, "TRILINEAR")
    if e.tc8 then t:SetTexCoord((unpack or table.unpack)(e.tc8)) elseif e.tc then t:SetTexCoord((unpack or table.unpack)(e.tc)) else t:SetTexCoord(0, 1, 0, 1) end
  else
    local base = NS.ALLIANZ[#NS.ALLIANZ]
    for _, a in ipairs(NS.ALLIANZ) do local ok = t:SetTexture(a[1], nil, nil, "TRILINEAR"); if ok ~= false and t:GetTexture() then base = a; break end end
    if base == NS.ALLIANZ[#NS.ALLIANZ] then t:SetTexture(base[1], nil, nil, "TRILINEAR") end
    -- Ausschnitt an die Form der Fläche anpassen (breit/hoch), damit das Wappen nicht verzerrt wird
    local l, r, o, u = base[2], base[3], base[4], base[5]
    local a = e.a or 1
    if a > 1 then local h = (u - o) / a; local m = (o + u) / 2; o, u = m - h / 2, m + h / 2
    elseif a < 1 then local w = (r - l) * a; local m = (l + r) / 2; l, r = m - w / 2, m + w / 2 end
    t:SetTexCoord(l, r, o, u)
  end
end
NS.addLogo = function(tex, hordePath, opt)
  local e = { tex = tex, horde = hordePath }
  if type(opt) == "table" then e.tc, e.tc8, e.a = opt.tc, opt.tc8, opt.a end
  NS.logos[#NS.logos + 1] = e
  pcall(NS.paintLogo, e)
  return e
end
NS.applyZeichen = function()
  for _, e in ipairs(NS.logos) do pcall(NS.paintLogo, e) end
  if NS.applyLebenZeichen then pcall(NS.applyLebenZeichen) end
end
local f = CreateFrame("Frame")
local DB

local DEFAULTS = { aggro = true, aggroTon = true, aggroSchwelle = 85, erinnerungKlang = 2, erinnerungTon = true, nachtTon = true, nachtKlang = 5, gesundheitsstein = true, beschwoeren = true, nacht = true, cc = true, seelendieb = true, erinnerung = true, tooltip = true, splitterMax = 25, minimapWinkel = 220, minimapAus = false, castbar = true, castbarBlizzAus = true, scale = {}, dotAus = {}, schwelle = 5, splitter = true, seelenstein = true, dots = true, gesperrt = false, pos = {}, bank = nil, bankZeit = nil }

-- Standard-Anordnung (von Tobsiikk vorgegeben): so stehen alle verschiebbaren Teile nach dem ersten Start.
-- Alles bleibt verschiebbar; „Plätze zurücksetzen“ stellt wieder genau diese Anordnung her.
local STANDARD_POS = { ["erfahrung"] = { "BOTTOM", "BOTTOM", -2.962, 3.555, }, ["menueleiste"] = { "BOTTOMRIGHT", "BOTTOMRIGHT", -248.294, 4.592, }, ["gruppe"] = { "LEFT", "LEFT", 0, 4.938, }, ["rahmen_begleiter"] = { "CENTER", "BOTTOMLEFT", 395.740, 382.518, }, ["questpfeil"] = { "TOP", "TOP", 0, -140.000, }, ["rahmen_zielziel"] = { "TOPLEFT", "BOTTOMLEFT", 1414.444, 397.518, }, ["klassen_debuffs"] = { "TOPLEFT", "BOTTOMLEFT", 674.593, 315.406, }, ["levelzeit"] = { "TOPRIGHT", "TOPRIGHT", -170.072, -88.518, }, ["aktionsleiste"] = { "BOTTOM", "BOTTOM", 0.593, 24.370, }, ["leistung"] = { "BOTTOMRIGHT", "BOTTOMRIGHT", -16.444, 56.593, }, ["beute"] = { "CENTER", "BOTTOMLEFT", 1161.604, 685.432, }, ["aggro"] = { "CENTER", "BOTTOMLEFT", 947.871, 718.888, }, ["tooltip"] = { "BOTTOMRIGHT", "BOTTOMRIGHT", -195.259, 73.777, }, ["seitenleiste"] = { "CENTER", "BOTTOMLEFT", 1831.366, 465.185, }, ["rahmen_spieler"] = { "CENTER", "CENTER", -304.362, -116.049, }, ["zauberleiste"] = { "CENTER", "CENTER", 8.296, -91.481, }, ["raid"] = { "TOPLEFT", "TOPLEFT", 2.714, -3.719, }, ["rahmen_ziel"] = { "CENTER", "CENTER", 294.485, -115.391, }, ["klassen_erinnerung"] = { "CENTER", "CENTER", -59.851, 57.555, }, ["klassen_cooldowns"] = { "CENTER", "CENTER", -101.925, -129.259, }, }
local STANDARD_SCALE = { ["beute"] = 0.9, ["aggro"] = 0.8, ["gruppe"] = 0.9, ["seitenleiste"] = 0.8, ["rahmen_zielziel"] = 0.8, ["rahmen_spieler"] = 0.9, ["raid"] = 0.7, ["rahmen_begleiter"] = 0.8, ["rahmen_ziel"] = 0.9, }
local function kopie(t) local o = {}; for i, v in pairs(t) do o[i] = v end return o end
local function standardLayout(alles)
  if type(DB.pos) ~= "table" then DB.pos = {} end
  if type(DB.scale) ~= "table" then DB.scale = {} end
  for k, v in pairs(STANDARD_POS) do if alles or DB.pos[k] == nil then DB.pos[k] = kopie(v) end end
  for k, v in pairs(STANDARD_SCALE) do if alles or DB.scale[k] == nil then DB.scale[k] = v end end
end
NS.standardLayout = function(alles) if DB then standardLayout(alles) end end
local extraFrames = {} -- weitere verschieb- und skalierbare Symbole
-- Beschriftungen unter den Symbolen: nur im Platzier-Modus sichtbar (die Bilder reichen)
local labels = {}
local function regLabel(fs) labels[#labels + 1] = fs; fs:Hide(); return fs end
-- Timer im Bild: in den letzten 3 Sekunden rot blinken
local function blinkTimer(fs, rem)
  if type(rem) == "number" and rem > 0 and rem < 3 then
    fs:SetTextColor(1, .15, .15); fs:SetAlpha((math.floor(GetTime() * 4) % 2 == 0) and 1 or .25)
  else fs:SetTextColor(1, 1, 1); fs:SetAlpha(1) end
end
NS.blinkTimer = blinkTimer
local shardSpace -- wird weiter unten gesetzt

local function msg(t) DEFAULT_CHAT_FRAME:AddMessage("|cffe03030siikk|r|cffffd100UI|r: " .. t) end
local KLAENGE = {
  { name = "Quest fehlgeschlagen", key = "IG_QUEST_FAILED", id = 847 },
  { name = "Wecker-Hinweis", key = "ALARM_CLOCK_WARNING_2", id = 12867 },
  { name = "Karten-Ping", key = "MAP_PING", id = 3175 },
  { name = "Flüstern (leise)", key = "TELL_MESSAGE", id = 3081 },
  { name = "Raidwarnung (laut)", key = "RAID_WARNING", id = 8959 },
}
local function klang(i, mal, abstand)
  local k = KLAENGE[i] or KLAENGE[1]
  local id = (SOUNDKIT and SOUNDKIT[k.key]) or k.id
  local function spiel() if PlaySound then pcall(PlaySound, id, "Master") end end
  spiel()
  for n = 1, (mal or 1) - 1 do
    if C_Timer and C_Timer.After then C_Timer.After(n * (abstand or 0.8), spiel) end
  end
  return k.name
end
local function pass(ok, ...) if ok then return ... end end
local function safe(fn, ...) if not fn then return nil end return pass(pcall(fn, ...)) end
local function isSecret(v) return issecretvalue and issecretvalue(v) or false end

---------------------------------------------------------------------------
-- Gegenstände zählen
---------------------------------------------------------------------------
local SOUL_SHARD = 6265
local HEALTHSTONES = { 22103, 22104, 22105, 5512, 19004, 19005, 5511, 19006, 19007, 5509, 19008, 19009, 5510, 19010, 19011, 9421, 19012, 19013 }
local SOULSTONES = { 22116, 5232, 16892, 16893, 16895, 16896 }
local SOULSTONE_BUFFS = { 27239, 20707, 20762, 20763, 20764, 20765 }
local CREATE_HEALTHSTONE = { 27230, 6201, 6202, 5699, 11729, 11730 }
local CREATE_SOULSTONE = { 27238, 20757, 20756, 20755, 20752, 693 }

local function count(id)
  local n = safe(GetItemCount, id) or (C_Item and safe(C_Item.GetItemCount, id)) or 0
  return n or 0
end
local function anyItem(list) for _, id in ipairs(list) do if count(id) > 0 then return true end end return false end
local function knowsAny(list)
  for _, id in ipairs(list) do
    local k = safe(IsPlayerSpell, id) or safe(IsSpellKnown, id) or (C_SpellBook and safe(C_SpellBook.IsSpellKnown, id))
    if k then return true end
  end
  return false
end
local function itemOnCooldown(list)
  for _, id in ipairs(list) do
    local fn = (C_Container and C_Container.GetItemCooldown) or GetItemCooldown
    if fn then
      local start, dur = safe(fn, id)
      if start and not isSecret(start) and start > 0 and dur and dur > 1.5 then return true end
    end
  end
  return false
end
local function hasSoulstoneBuff()
  for _, id in ipairs(SOULSTONE_BUFFS) do
    if C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID then
      local a = safe(C_UnitAuras.GetPlayerAuraBySpellID, id)
      if a then return true end
    end
  end
  return false
end

---------------------------------------------------------------------------
-- 1) Seelensplitter-Anzeige
---------------------------------------------------------------------------
local shard = CreateFrame("Button", "TobsiikkHelferSplitter", UIParent, "BackdropTemplate")
shard:SetSize(44, 44)
shard:SetMovable(true); shard:EnableMouse(true); shard:RegisterForDrag("LeftButton")
shard:SetClampedToScreen(true)
shard.icon = shard:CreateTexture(nil, "ARTWORK"); shard.icon:SetAllPoints()
shard.icon:SetTexture((C_Item and C_Item.GetItemIconByID and safe(C_Item.GetItemIconByID, SOUL_SHARD)) or 134075)
shard.num = shard:CreateFontString(nil, "OVERLAY", "NumberFontNormalLarge")
shard.num:SetPoint("BOTTOMRIGHT", -2, 2)
shard.warn = shard:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
shard.warn:SetPoint("TOP", shard, "BOTTOM", 0, -3); shard.warn:SetJustifyH("CENTER"); regLabel(shard.warn)
shard:SetScript("OnDragStart", function(s) if not DB.gesperrt then s:StartMoving() end end)
shard:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); local p, _, rp, x, y = s:GetPoint(); DB.pos.splitter = { p, rp, x, y } end)
shard.scaleKey = "splitter"
shard:SetScript("OnEnter", function(s)
  GameTooltip:SetOwner(s, "ANCHOR_RIGHT")
  GameTooltip:AddLine("Seelensplitter: " .. count(SOUL_SHARD))
  GameTooltip:AddLine("Rot unter " .. DB.schwelle .. " (ändern mit /th schwelle Zahl)", 1, 1, 1)
  GameTooltip:AddLine(DB.gesperrt and "Gesperrt (/th entsperren zum Verschieben)" or "Ziehen zum Verschieben", .7, .7, .7)
  GameTooltip:Show()
end)
shard:SetScript("OnLeave", function() GameTooltip:Hide() end)

local function updateShard()
  if not DB.splitter then shard:Hide() return end
  shard:Show()
  local n = count(SOUL_SHARD)
  shard.num:SetText(n)
  if n < DB.schwelle then shard.num:SetTextColor(1, .2, .2); shard.icon:SetVertexColor(1, .5, .5)
  else shard.num:SetTextColor(1, 1, 1); shard.icon:SetVertexColor(1, 1, 1) end
  -- Erinnerungen nur außerhalb des Kampfes
  if InCombatLockdown() then return end
  local lines = {}
  if not DB.gesundheitsstein and knowsAny(CREATE_HEALTHSTONE) and not anyItem(HEALTHSTONES) then table.insert(lines, "|cffff6644Kein Gesundheitsstein!|r") end
  local soulFull, free = false, 99
  if shardSpace then soulFull, free = shardSpace() end
  if soulFull then table.insert(lines, "|cffff8800Splitter-Tasche voll!|r")
  elseif free == 0 then table.insert(lines, "|cffff8800Taschen voll – Splitter gehen verloren!|r")
  elseif n >= (DB.splitterMax or 25) then table.insert(lines, "|cffffd100Genug Splitter (" .. n .. ")|r") end
  shard.warn:SetText(table.concat(lines, "\n"))
end

---------------------------------------------------------------------------
-- 1b) Seelenstein-Anzeige (Klick: benutzen oder herstellen)
---------------------------------------------------------------------------
local function spellName(id)
  local n = (C_Spell and C_Spell.GetSpellName and safe(C_Spell.GetSpellName, id)) or (GetSpellInfo and safe(GetSpellInfo, id))
  if n and not isSecret(n) then return n end
end
local function fmtTime(sec)
  sec = math.max(0, math.floor(sec))
  return string.format("%d:%02d", math.floor(sec / 60), sec % 60)
end
local STONE_CD = 30 * 60 -- Seelenstein: 30 Minuten Abklingzeit
local function soulstoneBuffLeft()
  if not (C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID) then return nil end
  for _, id in ipairs(SOULSTONE_BUFFS) do
    local a = safe(C_UnitAuras.GetPlayerAuraBySpellID, id)
    if a then
      if a.expirationTime and not isSecret(a.expirationTime) and a.expirationTime > 0 then return a.expirationTime - GetTime() end
      return -1 -- aktiv, Restzeit unbekannt
    end
  end
  if UnitBuff then
    for i = 1, 40 do
      local name, _, _, _, _, exp, _, _, _, sid = safe(UnitBuff, "player", i)
      if not name then break end
      for _, id in ipairs(SOULSTONE_BUFFS) do if sid == id then return (exp and exp > 0) and (exp - GetTime()) or -1 end end
    end
  end
  return nil
end
local function stoneCooldownLeft()
  local left = 0
  local fn = (C_Container and C_Container.GetItemCooldown) or GetItemCooldown
  if fn then
    for _, id in ipairs(SOULSTONES) do
      local start, dur = safe(fn, id)
      if start and dur and not isSecret(start) and start > 0 and dur > 1.5 then left = math.max(left, start + dur - GetTime()) end
    end
  end
  if DB and DB.stein and DB.stein.zeit then
    local own = DB.stein.zeit + STONE_CD - time()
    if own > left then left = own end
  end
  return left
end
local function stoneInBags() for _, id in ipairs(SOULSTONES) do if count(id) > 0 then return id end end end
local function bestCreateSoulstone()
  for _, id in ipairs(CREATE_SOULSTONE) do
    local k = safe(IsPlayerSpell, id) or safe(IsSpellKnown, id) or (C_SpellBook and safe(C_SpellBook.IsSpellKnown, id))
    if k then return spellName(id) end
  end
end

local stone = CreateFrame("Button", "TobsiikkHelferSeelenstein", UIParent, "SecureActionButtonTemplate")
stone:SetSize(44, 44)
stone:SetMovable(true); stone:EnableMouse(true); stone:RegisterForDrag("LeftButton")
stone:SetClampedToScreen(true)
pcall(stone.RegisterForClicks, stone, "RightButtonUp", "RightButtonDown")
stone.icon = stone:CreateTexture(nil, "ARTWORK"); stone.icon:SetAllPoints()
stone.icon:SetTexture((C_Item and C_Item.GetItemIconByID and safe(C_Item.GetItemIconByID, 5232)) or 134336)
stone.num = stone:CreateFontString(nil, "OVERLAY", "NumberFontNormalLarge")
stone.num:SetPoint("BOTTOMRIGHT", -2, 2)
stone.cd = CreateFrame("Cooldown", nil, stone, "CooldownFrameTemplate")
stone.cd:SetAllPoints()
if stone.cd.SetHideCountdownNumbers then stone.cd:SetHideCountdownNumbers(true) end
stone.timer = stone:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
stone.timer:SetPoint("CENTER", 0, 0)
stone.label = stone:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
stone.label:SetPoint("TOP", stone, "BOTTOM", 0, -3); stone.label:SetJustifyH("CENTER"); regLabel(stone.label)
-- Ausnahme: an wen der Seelenstein vergeben ist, steht immer darunter
stone.wer = stone:CreateFontString(nil, "OVERLAY", "GameFontNormal"); stone.wer:SetPoint("TOP", stone, "BOTTOM", 0, -3); stone.wer:SetJustifyH("CENTER")
pcall(stone.wer.SetFont, stone.wer, STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", 12, "OUTLINE"); stone.wer:Hide()
stone:SetScript("OnDragStart", function(s) if not DB.gesperrt and not InCombatLockdown() then s:StartMoving() end end)
stone:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); local p, _, rp, x, y = s:GetPoint(); DB.pos.stein = { p, rp, x, y } end)
stone.scaleKey = "stein"
stone.mode = nil; stone.macro = nil; stone.wasCd = false; stone.cdShown = false
stone:SetScript("OnEnter", function(s)
  GameTooltip:SetOwner(s, "ANCHOR_RIGHT")
  GameTooltip:AddLine("Seelenstein")
  if s.mode == "use" then GameTooltip:AddLine("Rechtsklick: Seelenstein auf dein freundliches Ziel legen (ohne Ziel auf dich).", 1, 1, 1, true)
  elseif s.mode == "create" then GameTooltip:AddLine("Rechtsklick: neuen Seelenstein herstellen (kostet 1 Seelensplitter).", 1, 1, 1, true)
  else GameTooltip:AddLine("Zeigt, ob dein Seelenstein aktiv oder vergeben ist.", 1, 1, 1, true) end
  GameTooltip:AddLine(DB.gesperrt and "Gesperrt (/th entsperren zum Verschieben)" or "Ziehen zum Verschieben (nicht im Kampf)", .7, .7, .7)
  GameTooltip:Show()
end)
stone:SetScript("OnLeave", function() GameTooltip:Hide() end)

local pendingAttr = false
local function setStoneAction(mode, macro)
  if stone.mode == mode and stone.macro == macro then return end
  if InCombatLockdown() then pendingAttr = true return end
  stone.mode, stone.macro = mode, macro
  if macro then stone:SetAttribute("type", "macro"); stone:SetAttribute("macrotext", macro)
  else stone:SetAttribute("type", nil); stone:SetAttribute("macrotext", nil) end
end

local function updateStone()
  if not DB or not DB.seelenstein then
    if not InCombatLockdown() then stone:Hide() end
    return
  end
  if not InCombatLockdown() then stone:Show() end
  if not knowsAny(CREATE_SOULSTONE) and not stoneInBags() then
    stone.num:SetText("")
    stone.icon:SetDesaturated(true); stone.icon:SetVertexColor(.6, .6, .6)
    local lv = UnitLevel("player") or 0
    stone.label:SetText(lv < 18 and "|cffaaaaaaSeelenstein ab Stufe 18|r" or "|cffaaaaaaSeelenstein beim Lehrer lernen|r")
    setStoneAction(nil, nil)
    return
  end
  local inBag = stoneInBags()
  local buff = soulstoneBuffLeft()
  local cd = stoneCooldownLeft()
  stone.num:SetText(inBag and count(inBag) or "")
  stone.icon:SetDesaturated(false); stone.icon:SetVertexColor(1, 1, 1)
  -- Countdown auf dem Symbol
  if cd > 0 then
    stone.timer:SetText(fmtTime(cd))
    if not stone.cdShown then stone.cd:SetCooldown(GetTime() - (STONE_CD - cd), STONE_CD); stone.cdShown = true end
    stone.wasCd = true
  else
    stone.timer:SetText("")
    if stone.cdShown then if stone.cd.Clear then stone.cd:Clear() else stone.cd:SetCooldown(0, 0) end; stone.cdShown = false end
    if stone.wasCd then
      stone.wasCd = false
      if DB.stein then DB.stein = nil end
      msg("|cff55dd55Seelenstein ist wieder bereit!|r")
      if PlaySound then pcall(PlaySound, (SOUNDKIT and SOUNDKIT.READY_CHECK) or 8960) end
    end
  end
  local wer = DB.stein and DB.stein.ziel
  -- Name unter dem Symbol, solange der Stein vergeben ist (Timer läuft im Bild)
  local zeig
  if buff then zeig = "Auf dir"
  elseif cd > 0 and wer then zeig = wer end
  if zeig and not stone.label:IsShown() then
    local r, g, b = 1, .82, 0
    if zeig ~= "Auf dir" then
      local ok, _, cls = pcall(UnitClass, zeig)
      local c = ok and cls and RAID_CLASS_COLORS and RAID_CLASS_COLORS[cls]
      if c then r, g, b = c.r, c.g, c.b end
    else r, g, b = .35, .87, .35 end
    stone.wer:SetText(zeig); stone.wer:SetTextColor(r, g, b); stone.wer:Show()
  else stone.wer:Hide() end
  if buff and buff > 0 and cd <= 0 then stone.timer:SetText(fmtTime(buff)) end
  if buff then
    stone.label:SetText("|cff55dd55Auf dir" .. (buff > 0 and (" · " .. fmtTime(buff) .. " übrig") or " aktiv") .. "|r" .. (cd > 0 and ("\n|cffffd100Neuer Stein in " .. fmtTime(cd) .. "|r") or ""))
  elseif cd > 0 then
    stone.label:SetText("|cffffd100" .. (wer and ("Auf " .. wer) or "Vergeben") .. " · bereit in " .. fmtTime(cd) .. "|r")
    stone.icon:SetVertexColor(1, .85, .4)
  elseif inBag then
    stone.label:SetText("|cffffffffBereit – Rechtsklick zum Benutzen|r")
  else
    stone.label:SetText("|cffff6644Kein Seelenstein!|r\n|cffaaaaaaRechtsklick zum Herstellen|r")
    stone.icon:SetDesaturated(true)
  end
  if inBag then
    setStoneAction("use", "/use [@target,help,nodead] item:" .. inBag .. "; [@player] item:" .. inBag)
  elseif cd <= 0 and not buff then
    local cs = bestCreateSoulstone()
    setStoneAction(cs and "create" or nil, cs and ("/cast " .. cs) or nil)
  else
    setStoneAction(nil, nil)
  end
end
local stoneAcc = 0
stone:SetScript("OnUpdate", function(_, el) stoneAcc = stoneAcc + el; if stoneAcc >= 1 then stoneAcc = 0; updateStone() end end)

---------------------------------------------------------------------------
-- 2) DoT-Symbole (je DoT ein Symbol, einzeln verschieb- und skalierbar)
---------------------------------------------------------------------------
local DOTS = {
  { key = "verderbnis", name = "Verderbnis", color = { .55, .3, .8 },
    ids = { [172]=12, [6222]=15, [6223]=18, [7648]=18, [11671]=18, [11672]=18, [25311]=18, [27216]=18 } },
  { key = "pein", name = "Omen der Pein", color = { .85, .25, .25 },
    ids = { [980]=24, [1014]=24, [6217]=24, [11711]=24, [11712]=24, [11713]=24, [27218]=24 } },
  { key = "lebensentzug", name = "Lebensentzug", color = { .3, .75, .35 },
    ids = { [18265]=30, [18879]=30, [18880]=30, [18881]=30, [27264]=30, [30911]=30 } },
  { key = "feuerbrand", name = "Feuerbrand", color = { .95, .55, .15 },
    ids = { [348]=15, [707]=15, [1094]=15, [2941]=15, [11665]=15, [11667]=15, [11668]=15, [25309]=15, [27215]=15 } },
  { key = "instabil", name = "Instabiles Gebrechen", color = { .2, .6, .9 },
    ids = { [30108]=18, [30404]=18, [30405]=18 } },
}
for _, d in ipairs(DOTS) do
  local n = (C_Spell and C_Spell.GetSpellName and safe(C_Spell.GetSpellName, next(d.ids))) or (GetSpellInfo and safe(GetSpellInfo, next(d.ids)))
  if n and not isSecret(n) then d.name = n end
end

local timers = {} -- [guid][key] = {ende, dauer}

-- Gemeinsame Helfer: Größe per Mausrad, Position merken
-- Einrasten: Shift beim Loslassen -> an Kanten/Mitten anderer Elemente (oder direkt daneben), sonst am Raster
local RASTER, FANG = 16, 14
local function box(fr)
  local ok, l, r, t, b = pcall(function() return fr:GetLeft(), fr:GetRight(), fr:GetTop(), fr:GetBottom() end)
  if not ok or type(l) ~= "number" or type(t) ~= "number" or type(r) ~= "number" or type(b) ~= "number" then return end
  local s = (fr:GetEffectiveScale() or 1) / (UIParent:GetEffectiveScale() or 1)
  return l * s, r * s, t * s, b * s, s
end
local function snapFrame(frame)
  if not (IsShiftKeyDown and IsShiftKeyDown()) then return end
  if InCombatLockdown() and frame.IsProtected and frame:IsProtected() then return end
  local l, r, t, b, s = box(frame); if not l then return end
  local dx, dy
  local function tryX(c, m) local d = c - m; if math.abs(d) <= FANG and (not dx or math.abs(d) < math.abs(dx)) then dx = d end end
  local function tryY(c, m) local d = c - m; if math.abs(d) <= FANG and (not dy or math.abs(d) < math.abs(dy)) then dy = d end end
  local function against(ol, or_, ot, ob)
    for _, c in ipairs({ ol, or_, (ol + or_) / 2 }) do tryX(c, l); tryX(c, r); tryX(c, (l + r) / 2) end
    for _, c in ipairs({ ot, ob, (ot + ob) / 2 }) do tryY(c, t); tryY(c, b); tryY(c, (t + b) / 2) end
  end
  -- Bildschirmmitte
  local W, H = UIParent:GetWidth() or 0, UIParent:GetHeight() or 0
  tryX(W / 2, (l + r) / 2); tryY(H / 2, (t + b) / 2)
  local seen = {}
  local function check(o)
    if type(o) ~= "table" or o == frame or seen[o] or not o.IsVisible or not o:IsVisible() then return end
    seen[o] = true
    local ol, or_, ot, ob = box(o); if ol then against(ol, or_, ot, ob) end
  end
  for _, e in ipairs(extraFrames) do check(e.frame) end
  if NS.snapMore then for _, o in ipairs(NS.snapMore()) do check(o) end end
  dx = dx or (math.floor(l / RASTER + .5) * RASTER - l)
  dy = dy or (math.floor(t / RASTER + .5) * RASTER - t)
  frame:ClearAllPoints(); frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", (l + dx) / s, (t + dy) / s)
end
NS.snapFrame = snapFrame
local function savePos(frame, key)
  pcall(snapFrame, frame)
  local p, _, rp, x, y = frame:GetPoint()
  DB.pos[key] = { p, rp, x, y }
end
-- Hilfsraster für den Platzier-Modus
local raster
local function showRaster(on)
  if not on then if raster then raster:Hide() end return end
  if not raster then
    raster = CreateFrame("Frame", "TobsiikkHelferRaster", UIParent); raster:SetAllPoints(UIParent); raster:SetFrameStrata("BACKGROUND"); raster:EnableMouse(false)
    local W, H = UIParent:GetWidth() or 1920, UIParent:GetHeight() or 1080
    local function line(vert, pos, gold)
      local tx = raster:CreateTexture(nil, "ARTWORK")
      if gold then tx:SetColorTexture(NS.GOLD[1], NS.GOLD[2], NS.GOLD[3], .55) else tx:SetColorTexture(1, 1, 1, (pos % (RASTER * 4) == 0) and .12 or .05) end
      if vert then tx:SetPoint("TOPLEFT", raster, "TOPLEFT", pos, 0); tx:SetPoint("BOTTOMLEFT", raster, "BOTTOMLEFT", pos, 0); tx:SetWidth(gold and 2 or 1)
      else tx:SetPoint("BOTTOMLEFT", raster, "BOTTOMLEFT", 0, pos); tx:SetPoint("BOTTOMRIGHT", raster, "BOTTOMRIGHT", 0, pos); tx:SetHeight(gold and 2 or 1) end
    end
    for x = RASTER, W, RASTER do line(true, x) end
    for y = RASTER, H, RASTER do line(false, y) end
    line(true, math.floor(W / 2), true); line(false, math.floor(H / 2), true)
    raster.t = raster:CreateFontString(nil, "OVERLAY", "GameFontNormal"); raster.t:SetPoint("TOP", 0, -60)
    raster.t:SetText("Platzier-Modus · ziehen = verschieben · |cffffffffShift beim Loslassen = einrasten|r · Mausrad = Größe")
  end
  raster:Show()
end
-- Prozent-Anzeige beim Vergrößern/Verkleinern (1.0 = 100 %)
local function pct(sc) return math.floor((sc or 1) * 100 + .5) .. " %" end
local scaleTip = CreateFrame("Frame", nil, UIParent)
scaleTip:SetFrameStrata("TOOLTIP"); scaleTip:SetSize(76, 26); scaleTip:Hide()
scaleTip.bg = scaleTip:CreateTexture(nil, "BACKGROUND"); scaleTip.bg:SetAllPoints(); scaleTip.bg:SetColorTexture(0, 0, 0, .8)
scaleTip.txt = scaleTip:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); scaleTip.txt:SetPoint("CENTER")
scaleTip.left = 0
scaleTip:SetScript("OnUpdate", function(s, el) s.left = s.left - el; if s.left <= 0 then s:Hide() end end)
local function showScale(frame, sc)
  scaleTip.txt:SetText(pct(sc))
  scaleTip:ClearAllPoints()
  scaleTip:SetPoint("BOTTOM", frame, "TOP", 0, 4)
  scaleTip.left = 1.5
  scaleTip:Show()
end
local function makeScalable(frame, key)
  frame:EnableMouseWheel(true)
  frame:SetScript("OnMouseWheel", function(s, delta)
    if DB.gesperrt then return end
    if s:IsProtected() and InCombatLockdown() then return end
    local old = s:GetScale()
    local sc = math.max(.5, math.min(3, math.floor(((DB.scale[key] or 1) + delta * .1) * 10 + .5) / 10))
    local x, y = s:GetCenter()
    DB.scale[key] = sc
    s:SetScale(sc)
    if x and y then
      s:ClearAllPoints()
      s:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x * old / sc, y * old / sc)
      DB.pos[key] = { "CENTER", "BOTTOMLEFT", x * old / sc, y * old / sc }
    end
    showScale(s, sc)
  end)
end

local function spellIcon(d)
  for id in pairs(d.ids) do
    local t = (C_Spell and C_Spell.GetSpellTexture and safe(C_Spell.GetSpellTexture, id)) or (GetSpellTexture and safe(GetSpellTexture, id))
    if t and not isSecret(t) then return t end
  end
  return 136118
end
local function updateKnownDots()
  for _, d in ipairs(DOTS) do
    d.known = false
    for id in pairs(d.ids) do
      if safe(IsPlayerSpell, id) or safe(IsSpellKnown, id) or (C_SpellBook and safe(C_SpellBook.IsSpellKnown, id)) then d.known = true break end
    end
  end
end

local placing = false -- /th verschieben zeigt alle DoT-Symbole zum Platzieren
local dotIcons = {}
NS.snapMore = function() local t = { shard, stone }; for _, b in ipairs(dotIcons) do t[#t + 1] = b end; return t end
for i, d in ipairs(DOTS) do
  local b = CreateFrame("Frame", "TobsiikkHelferDoT_" .. d.key, UIParent)
  b:SetSize(44, 44)
  b:SetMovable(true); b:EnableMouse(true); b:RegisterForDrag("LeftButton"); b:SetClampedToScreen(true)
  b.icon = b:CreateTexture(nil, "ARTWORK"); b.icon:SetAllPoints(); b.icon:SetTexture(spellIcon(d))
  b.cd = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate"); b.cd:SetAllPoints()
  if b.cd.SetHideCountdownNumbers then b.cd:SetHideCountdownNumbers(true) end
  if b.cd.SetReverse then b.cd:SetReverse(true) end
  b.timer = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge"); b.timer:SetPoint("CENTER", 0, 0)
  b.label = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); b.label:SetPoint("TOP", b, "BOTTOM", 0, -3); regLabel(b.label)
  b:SetScript("OnDragStart", function(s) if not DB.gesperrt then s:StartMoving() end end)
  b:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); savePos(s, "dot_" .. d.key) end)
  b:SetScript("OnEnter", function(s)
    GameTooltip:SetOwner(s, "ANCHOR_RIGHT"); GameTooltip:AddLine(d.name)
    GameTooltip:AddLine(DB.gesperrt and "Gesperrt (/th entsperren zum Verschieben)" or "Ziehen verschiebt, Mausrad ändert die Größe.", 1, 1, 1, true)
    GameTooltip:AddLine("Ausblenden: /th dot " .. d.key, .7, .7, .7); GameTooltip:Show()
  end)
  b:SetScript("OnLeave", function() GameTooltip:Hide() end)
  makeScalable(b, "dot_" .. d.key)
  b.d = d
  b:Hide()
  dotIcons[i] = b
end

-- Versucht die echte Restzeit vom Spiel zu lesen; nil wenn das Spiel sie nicht verrät.
local realWorks = false -- wird true, sobald das Spiel uns einmal echte DoT-Zeiten verraten hat
local function realRemaining(d)
  if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
    for i = 1, 40 do
      local a = safe(C_UnitAuras.GetAuraDataByIndex, "target", i, "HARMFUL|PLAYER")
      if not a then return 0 end
      if isSecret(a.spellId) or isSecret(a.expirationTime) or isSecret(a.duration) then return nil end
      if d.ids[a.spellId] and a.expirationTime and a.expirationTime > 0 then realWorks = true; return a.expirationTime - GetTime(), a.duration end
    end
    return 0
  elseif UnitDebuff then
    for i = 1, 40 do
      local name, _, _, _, dur, exp, src, _, _, sid = safe(UnitDebuff, "target", i)
      if not name then return 0 end
      if src == "player" and d.ids[sid] and exp and exp > 0 then realWorks = true; return exp - GetTime(), dur end
    end
    return 0
  end
  return nil
end

local function clearCd(b)
  if b.exp then if b.cd.Clear then b.cd:Clear() else b.cd:SetCooldown(0, 0) end; b.exp = nil end
end

makeScalable(shard, "splitter")
makeScalable(stone, "stein")

local ticker = CreateFrame("Frame")
local acc = 0
ticker:SetScript("OnUpdate", function(_, el)
  acc = acc + el; if acc < .1 then return end; acc = 0
  if not DB then return end
  local fight = UnitExists("target") and UnitCanAttack("player", "target") and not UnitIsDead("target")
  local guid = UnitGUID("target")
  for _, b in ipairs(dotIcons) do
    local d = b.d
    local wanted = DB.dots and not DB.dotAus[d.key] and (placing or d.known)
    if not wanted then b:Hide()
    elseif placing then
      b:Show(); b:SetAlpha(1); b.icon:SetDesaturated(false); clearCd(b)
      b.timer:SetText(""); b.label:SetText("|cffffd100" .. d.name .. "|r")
    elseif not fight then b:Hide()
    else
      local rem, dur = realRemaining(d)
      local est = false
      if rem == nil or (rem == 0 and not realWorks) then
        local t = guid and not isSecret(guid) and timers[guid] and timers[guid][d.key]
        rem, dur, est = 0, nil, false
        if t then rem, dur, est = t[1] - GetTime(), t[2], true end
      end
      b:Show()
      if rem and rem > 0 and dur and dur > 0 then
        b:SetAlpha(1); b.icon:SetDesaturated(false)
        b.timer:SetText((est and "~" or "") .. (rem >= 10 and tostring(math.floor(rem)) or string.format("%.1f", rem)))
        blinkTimer(b.timer, rem)
        local exp = GetTime() + rem
        if not b.exp or math.abs(b.exp - exp) > .5 then b.cd:SetCooldown(exp - dur, dur); b.exp = exp end
        b.label:SetText(rem < 3 and "|cffff8800nachlegen!|r" or d.name)
      else
        b:SetAlpha(.55); b.icon:SetDesaturated(true); clearCd(b)
        b.timer:SetText(""); b.label:SetText("|cffff5555fehlt|r")
      end
    end
  end
end)

---------------------------------------------------------------------------
-- 5) Weitere Helfer: Gesundheitsstein, Beschwörung, Einbruch der Nacht,
--    Furcht/Verbannen-Timer, Seelendieb-Hinweis, Erinnerungen
---------------------------------------------------------------------------
local function makeIcon(key, tex, secure, defX, defY)
  local b = CreateFrame("Button", "TobsiikkHelfer_" .. key, UIParent, secure and "SecureActionButtonTemplate" or nil)
  b:SetSize(44, 44)
  b:SetMovable(true); b:EnableMouse(true); b:RegisterForDrag("LeftButton"); b:SetClampedToScreen(true)
  b.icon = b:CreateTexture(nil, "ARTWORK"); b.icon:SetAllPoints(); b.icon:SetTexture(tex)
  b.num = b:CreateFontString(nil, "OVERLAY", "NumberFontNormalLarge"); b.num:SetPoint("BOTTOMRIGHT", -2, 2)
  b.cd = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate"); b.cd:SetAllPoints()
  if b.cd.SetHideCountdownNumbers then b.cd:SetHideCountdownNumbers(true) end
  b.timer = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge"); b.timer:SetPoint("CENTER", 0, 0)
  b.label = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); b.label:SetPoint("TOP", b, "BOTTOM", 0, -3); b.label:SetJustifyH("CENTER"); regLabel(b.label)
  b:SetScript("OnDragStart", function(s) if not DB.gesperrt and not (s:IsProtected() and InCombatLockdown()) then s:StartMoving() end end)
  b:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); savePos(s, key) end)
  makeScalable(b, key)
  b.key, b.cdUntil = key, nil
  table.insert(extraFrames, { frame = b, key = key, x = defX, y = defY })
  b:Hide()
  return b
end
local function setCd(b, startT, dur)
  if startT and dur and dur > 0 then
    if b.cdUntil ~= startT + dur then b.cd:SetCooldown(startT, dur); b.cdUntil = startT + dur end
  elseif b.cdUntil then
    if b.cd.Clear then b.cd:Clear() else b.cd:SetCooldown(0, 0) end
    b.cdUntil = nil
  end
end
local function setShown(b, on)
  if b:IsProtected() and InCombatLockdown() then return end
  if on then b:Show() else b:Hide() end
end
local function groupChannel()
  if IsInGroup and LE_PARTY_CATEGORY_INSTANCE and safe(IsInGroup, LE_PARTY_CATEGORY_INSTANCE) then return "INSTANCE_CHAT" end
  if IsInRaid and safe(IsInRaid) then return "RAID" end
  if (IsInGroup and safe(IsInGroup)) or (GetNumPartyMembers and (safe(GetNumPartyMembers) or 0) > 0) then return "PARTY" end
end
local function say(text)
  local ch = groupChannel()
  if not ch then msg("Du bist in keiner Gruppe. (" .. text .. ")") return end
  if not pcall(SendChatMessage, text, ch) then msg("Ansage war nicht möglich: " .. text) end
end
local function playerAura(ids)
  -- Restzeit eines eigenen Buffs: Zahl, -1 (aktiv, Zeit unbekannt) oder nil (nicht aktiv)
  if C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID then
    for _, id in ipairs(ids) do
      local a = safe(C_UnitAuras.GetPlayerAuraBySpellID, id)
      if a then
        if a.expirationTime and not isSecret(a.expirationTime) and a.expirationTime > 0 then return a.expirationTime - GetTime(), a.duration end
        return -1
      end
    end
  end
  if UnitBuff then
    for i = 1, 40 do
      local name, _, _, _, dur, exp, _, _, _, sid = safe(UnitBuff, "player", i)
      if not name then break end
      for _, id in ipairs(ids) do if sid == id then return (exp and exp > 0) and (exp - GetTime()) or -1, dur end end
    end
  end
  return nil
end
local function targetDebuff(ids)
  -- eigener Debuff auf dem Ziel: Restzeit, 0 (nicht drauf) oder nil (Spiel verrät es nicht)
  if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
    for i = 1, 40 do
      local a = safe(C_UnitAuras.GetAuraDataByIndex, "target", i, "HARMFUL|PLAYER")
      if not a then return 0 end
      if isSecret(a.spellId) or isSecret(a.expirationTime) then return nil end
      if ids[a.spellId] then return (a.expirationTime or 0) - GetTime() end
    end
    return 0
  elseif UnitDebuff then
    for i = 1, 40 do
      local name, _, _, _, _, exp, src, _, _, sid = safe(UnitDebuff, "target", i)
      if not name then return 0 end
      if src == "player" and ids[sid] then return (exp or 0) - GetTime() end
    end
    return 0
  end
  return nil
end
local function bestKnown(list) for _, id in ipairs(list) do if safe(IsPlayerSpell, id) or safe(IsSpellKnown, id) or (C_SpellBook and safe(C_SpellBook.IsSpellKnown, id)) then return id end end end
local function itemCdLeft(list)
  local fn = (C_Container and C_Container.GetItemCooldown) or GetItemCooldown
  if not fn then return 0 end
  for _, id in ipairs(list) do
    local st, du = safe(fn, id)
    if st and du and not isSecret(st) and st > 0 and du > 1.5 then return st + du - GetTime(), st, du end
  end
  return 0
end
local function spellTex(id, fallback)
  local t = (C_Spell and C_Spell.GetSpellTexture and safe(C_Spell.GetSpellTexture, id)) or (GetSpellTexture and safe(GetSpellTexture, id))
  if t and not isSecret(t) then return t end
  return fallback
end

-- 5a) Gesundheitsstein-Symbol -------------------------------------------------
local HS_DESC = { 22105, 22104, 22103, 19013, 19012, 9421, 19011, 19010, 5510, 19009, 19008, 5509, 19007, 19006, 5511, 19005, 19004, 5512 }
local HS_CREATE_DESC = { 27230, 11730, 11729, 5699, 6202, 6201 }
local hs = makeIcon("gesundheitsstein", (C_Item and C_Item.GetItemIconByID and safe(C_Item.GetItemIconByID, 5512)) or 135230, true, -280, -160)
pcall(hs.RegisterForClicks, hs, "LeftButtonUp", "RightButtonUp", "RightButtonDown")
hs.mode, hs.macro, hs.pending = nil, nil, false
local function hsAction(mode, macro)
  if hs.mode == mode and hs.macro == macro then return end
  if InCombatLockdown() then hs.pending = true return end
  hs.mode, hs.macro = mode, macro
  hs:SetAttribute("type2", macro and "macro" or nil); hs:SetAttribute("macrotext2", macro)
end
hs:HookScript("OnClick", function(_, btn)
  if btn == "LeftButton" and IsShiftKeyDown() then
    if anyItem(HS_DESC) then say("Gesundheitssteine liegen bereit! Wer einen braucht, kurz Bescheid sagen.")
    else msg("Du hast gerade keinen Gesundheitsstein.") end
  end
end)
hs:SetScript("OnEnter", function(s)
  GameTooltip:SetOwner(s, "ANCHOR_RIGHT"); GameTooltip:AddLine("Gesundheitsstein")
  if s.mode == "use" then GameTooltip:AddLine("Rechtsklick: Gesundheitsstein benutzen", 1, 1, 1)
  elseif s.mode == "create" then GameTooltip:AddLine("Rechtsklick: Gesundheitsstein herstellen (1 Seelensplitter)", 1, 1, 1) end
  GameTooltip:AddLine("Umschalt + Linksklick: in der Gruppe ansagen, dass Steine bereitliegen", 1, 1, 1, true)
  GameTooltip:AddLine(DB.gesperrt and "Gesperrt (/th entsperren zum Verschieben)" or "Ziehen verschiebt, Mausrad ändert die Größe", .7, .7, .7)
  GameTooltip:Show()
end)
hs:SetScript("OnLeave", function() GameTooltip:Hide() end)
local function updateHS()
  if not DB.gesundheitsstein then setShown(hs, false) return end
  setShown(hs, true)
  local inBag
  for _, id in ipairs(HS_DESC) do if count(id) > 0 then inBag = id break end end
  local createId = bestKnown(HS_CREATE_DESC)
  local left, st, du = itemCdLeft(HS_DESC)
  hs.icon:SetDesaturated(not inBag); hs.icon:SetVertexColor(1, 1, 1)
  hs.num:SetText(inBag and count(inBag) or "")
  setCd(hs, left > 0 and st or nil, du)
  hs.timer:SetText(left > 0 and fmtTime(left) or "")
  if not createId and not inBag then
    hs.label:SetText("|cffaaaaaaGesundheitsstein ab Stufe 10|r"); hsAction(nil, nil); return
  end
  if inBag then
    hs.label:SetText(left > 0 and ("|cffffd100Bereit in " .. fmtTime(left) .. "|r") or "|cffffffffRechtsklick: benutzen|r")
    hsAction("use", "/use item:" .. inBag)
  else
    hs.label:SetText("|cffff6644Kein Gesundheitsstein!|r\n|cffaaaaaaRechtsklick zum Herstellen|r")
    local n = spellName(createId)
    hsAction(n and "create" or nil, n and ("/cast " .. n) or nil)
  end
end

-- 5b) Beschwörungs-Helfer ------------------------------------------------------
local SUMMON = { [698] = true }
local function onSummon()
  if not DB.beschwoeren then return end
  local name
  if UnitExists("target") and UnitIsPlayer("target") and UnitIsFriend("player", "target") and not UnitIsUnit("target", "player") then name = UnitName("target") end
  if isSecret(name) then name = nil end
  say(name and ("Beschwöre " .. name .. " – bitte aufs Portal klicken!") or "Beschwörungsportal steht – bitte aufs Portal klicken!")
  if name then pcall(SendChatMessage, "Ich beschwöre dich gleich, bitte die Beschwörung annehmen.", "WHISPER", nil, name) end
end

-- 5c) Einbruch der Nacht (Schattentrance) -------------------------------------
local TRANCE = { 17941 }
local nacht = makeIcon("nacht", spellTex(686, 136197), false, 0, 120)
nacht:SetSize(56, 56)
nacht.label:SetText("|cffff66ffSofort-Schattenblitz!|r")
nacht.seen = false
local function updateNacht(el)
  if not DB.nacht then nacht:Hide() return end
  if placing then nacht:Show(); nacht:SetAlpha(1); nacht.timer:SetText(""); return end
  local left = playerAura(TRANCE)
  if left then
    nacht:Show()
    nacht.t = (nacht.t or 0) + el
    nacht:SetAlpha(.65 + .35 * math.abs(math.sin(nacht.t * 5)))
    nacht.timer:SetText(left > 0 and string.format("%.0f", left) or ""); blinkTimer(nacht.timer, left)
    if not nacht.seen then nacht.seen = true; if DB.nachtTon ~= false then klang(DB.nachtKlang or 5, 2, .35) end end -- lauter Doppel-Ton über "Master"
  else
    nacht:Hide(); nacht.seen = false
  end
end

-- 5d) Furcht- und Verbannen-Timer ---------------------------------------------
local CC = {
  furcht = { ids = { [5782] = 10, [6213] = 15, [6215] = 20 }, tex = spellTex(5782, 136183), x = 160, name = "Furcht" },
  verbannen = { ids = { [710] = 20, [18647] = 30 }, tex = spellTex(710, 136135), x = 220, name = "Verbannen" },
}
for key, c in pairs(CC) do
  c.frame = makeIcon(key, c.tex, false, c.x, -160)
  c.frame:SetScript("OnEnter", function(s) GameTooltip:SetOwner(s, "ANCHOR_RIGHT"); GameTooltip:AddLine(c.name .. "-Timer"); GameTooltip:AddLine("Zeigt, wie lange dein " .. c.name .. " noch hält.", 1, 1, 1, true); GameTooltip:Show() end)
  c.frame:SetScript("OnLeave", function() GameTooltip:Hide() end)
end
local function onCC(spellID)
  for _, c in pairs(CC) do
    local dur = c.ids[spellID]
    if dur then
      local n = UnitName("target"); if isSecret(n) then n = nil end
      local g = UnitGUID("target"); if isSecret(g) then g = nil end
      c.active = { ende = GetTime() + dur, dur = dur, start = GetTime(), name = n, guid = g, warned = false }
    end
  end
end
local function updateCC()
  for _, c in pairs(CC) do
    local b = c.frame
    if not DB.cc then b:Hide()
    elseif placing then b:Show(); b.timer:SetText(""); b.label:SetText("|cffffd100" .. c.name .. "|r")
    elseif c.active then
      local a = c.active
      local left = a.ende - GetTime()
      -- vorzeitig gebrochen? Nur prüfbar, wenn das Ziel noch ausgewählt ist und das Spiel es verrät
      if a.guid and GetTime() - a.start > .7 and UnitGUID("target") == a.guid then
        local real = targetDebuff(c.ids)
        if real == 0 then left = 0 elseif real and real > 0 then left = real; a.ende = GetTime() + real end
      end
      if left <= 0 then
        c.active = nil; b:Hide(); setCd(b, nil)
      else
        b:Show(); setCd(b, a.start, a.dur)
        b.timer:SetText(string.format(left < 10 and "%.1f" or "%.0f", left))
        if left < 3 then
          blinkTimer(b.timer, left); b.label:SetText("|cffff8800läuft aus!|r")
          if not a.warned then a.warned = true; if PlaySound then pcall(PlaySound, (SOUNDKIT and SOUNDKIT.RAID_WARNING) or 8959) end end
        else
          blinkTimer(b.timer, left); b.label:SetText(a.name or c.name)
        end
      end
    else b:Hide() end
  end
end

-- 5e) Seelendieb-Hinweis --------------------------------------------------------
local DRAIN_SOUL = { 27217, 11675, 8289, 8288, 1120 }
local sd = makeIcon("seelendieb", spellTex(1120, 136163), false, 0, 60)
sd:SetSize(50, 50)
sd.label:SetText("|cffbb88ffJetzt Seelendieb!|r")
local function trivial()
  if UnitIsTrivial then return safe(UnitIsTrivial, "target") end
  if GetQuestGreenRange then
    local tl, pl = UnitLevel("target") or 0, UnitLevel("player") or 0
    return tl > 0 and tl < pl - (safe(GetQuestGreenRange) or 5)
  end
  return false
end
local function updateSD()
  if not DB.seelendieb then sd:Hide() return end
  if placing then sd:Show(); return end
  if not bestKnown(DRAIN_SOUL) or count(SOUL_SHARD) >= (DB.splitterMax or 25)
    or not UnitExists("target") or not UnitCanAttack("player", "target") or UnitIsDead("target") or UnitIsPlayer("target") then sd:Hide() return end
  local h, m = UnitHealth("target"), UnitHealthMax("target")
  if isSecret(h) or isSecret(m) or not h or not m or m <= 0 then sd:Hide() return end
  if h / m <= .25 and not trivial() then sd:Show(); sd.timer:SetText(math.floor(h / m * 100) .. "%") else sd:Hide() end
end

-- 5f) Erinnerungen außerhalb des Kampfes -----------------------------------------
local ARMOR = { 28189, 28176, 27260, 11735, 11734, 11733, 1086, 706, 696, 687 }
local SACRIFICE = { 18789, 18790, 18791, 18792, 35701 }
local SUMMON_IMP = { 688 }
local er = CreateFrame("Frame", "TobsiikkHelfer_erinnerung", UIParent, "BackdropTemplate")
er:SetSize(260, 52); er:SetMovable(true); er:EnableMouse(true); er:RegisterForDrag("LeftButton"); er:SetClampedToScreen(true)
if er.SetBackdrop then
  er:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
  er:SetBackdropColor(.12, .02, .18, .9); er:SetBackdropBorderColor(.75, .35, 1, 1)
end
er.icon = er:CreateTexture(nil, "ARTWORK"); er.icon:SetSize(32, 32); er.icon:SetPoint("LEFT", 10, 0)
er.icon:SetTexture(spellTex(688, 136218))
er.text = er:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); er.text:SetPoint("LEFT", er.icon, "RIGHT", 10, 0); er.text:SetJustifyH("LEFT")
er.last = ""
er:SetScript("OnUpdate", function(s, el)
  -- leichtes Blinken
  s.t = (s.t or 0) + el
  local a = .55 + .45 * (0.5 + 0.5 * math.cos(s.t * 4))
  s.text:SetAlpha(a); s.icon:SetAlpha(a)
end)
local function erFit()
  local w = (er.text:GetStringWidth() or 180) + 64
  local h = math.max(52, (er.text:GetStringHeight() or 20) + 24)
  er:SetSize(math.max(200, w), h)
end
er:SetScript("OnDragStart", function(s) if not DB.gesperrt then s:StartMoving() end end)
er:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); savePos(s, "erinnerung") end)
makeScalable(er, "erinnerung")
table.insert(extraFrames, { frame = er, key = "erinnerung", x = 0, y = 180 })
er:Hide()
local function updateER()
  if not DB.erinnerung then er:Hide() return end
  if placing then er:Show(); er.text:SetText("|cffffd100Erinnerungen erscheinen hier|r"); erFit(); return end
  if InCombatLockdown() or UnitIsDeadOrGhost("player") or (UnitOnTaxi and UnitOnTaxi("player")) then er:Hide(); er.last = "" return end
  local lines = {}
  local armor = bestKnown(ARMOR)
  if armor and not playerAura(ARMOR) then table.insert(lines, "|cffff6644" .. (spellName(armor) or "Dämonenrüstung") .. " fehlt!|r") end
  local sac = playerAura(SACRIFICE)
  local sacLine = (sac and sac > 0 and sac < 300) and ("|cffffd100Dämonische Opferung endet in " .. fmtTime(sac) .. "|r") or nil
  if bestKnown(SUMMON_IMP) and not UnitExists("pet") and not sac and not (IsMounted and IsMounted()) then table.insert(lines, "|cffff6644Kein Dämon beschworen!|r") end
  if sacLine then
    if not er.sacWarned then er.sacWarned = true; if DB.erinnerungTon then klang(DB.erinnerungKlang, 3) end end
  else er.sacWarned = false end
  if #lines > 0 or sacLine then
    local txt = table.concat(lines, "\n")
    local shown = txt
    if sacLine then shown = (txt ~= "" and (txt .. "\n") or "") .. sacLine end
    er.text:SetText(shown); erFit(); er:Show()
    -- leiser Ton, sobald eine neue Erinnerung auftaucht
    local neu = false
    for _, l in ipairs(lines) do if not er.last:find(l, 1, true) then neu = true end end
    if neu and DB.erinnerungTon then klang(DB.erinnerungKlang, 3) end
    er.last = txt
  else er:Hide(); er.last = "" end
end

-- Splitter-Obergrenze / volle Taschen (wird in updateShard angezeigt)
shardSpace = function()
  local soulFull, total = false, 0
  local fn = (C_Container and C_Container.GetContainerNumFreeSlots) or GetContainerNumFreeSlots
  if not fn then return false, 99 end
  for b = 0, (NUM_TOTAL_EQUIPPED_BAG_SLOTS or NUM_BAG_SLOTS or 4) do
    local free, fam = safe(fn, b)
    free = free or 0; total = total + free
    if fam and fam ~= 0 and bit and bit.band and bit.band(fam, 4) ~= 0 and free == 0 then soulFull = true end
  end
  return soulFull, total
end

-- 5h) Aggro-Warnung (nur in der Gruppe) ------------------------------------------
local ag = makeIcon("aggro", "Interface\\Icons\\Ability_Warrior_Challange", false, -130, 120)
ag:SetSize(52, 52)
ag.warned = false
ag:SetScript("OnEnter", function(s) GameTooltip:SetOwner(s, "ANCHOR_RIGHT"); GameTooltip:AddLine("Aggro-Warnung"); GameTooltip:AddLine("Zeigt deine Bedrohung im Vergleich zum Tank. Bei 100 % greift der Gegner dich an.", 1, 1, 1, true); GameTooltip:Show() end)
ag:SetScript("OnLeave", function() GameTooltip:Hide() end)
local function updateAggro(el)
  if not DB.aggro then ag:Hide() return end
  if placing then ag:Show(); ag:SetAlpha(1); ag.timer:SetText("90%"); ag.label:SetText("|cffffd100Aggro-Warnung|r"); return end
  local inGroup = (IsInGroup and safe(IsInGroup)) or (GetNumPartyMembers and (safe(GetNumPartyMembers) or 0) > 0)
  if not inGroup or not InCombatLockdown() or not UnitExists("target") or not UnitCanAttack("player", "target") or UnitIsDead("target") or not UnitDetailedThreatSituation then
    ag:Hide(); ag.warned = false; return
  end
  local tanking, _, pct = safe(UnitDetailedThreatSituation, "player", "target")
  if isSecret(tanking) or isSecret(pct) or not pct then ag:Hide(); return end
  local schwelle = DB.aggroSchwelle or 85
  if tanking or pct >= schwelle then
    ag:Show()
    ag.t = (ag.t or 0) + el
    ag:SetAlpha(.6 + .4 * math.abs(math.sin(ag.t * 6)))
    if tanking then
      ag.timer:SetText("!"); ag.timer:SetTextColor(1, .2, .2)
      ag.label:SetText("|cffff3333Du hast Aggro!|r")
    else
      ag.timer:SetText(math.floor(pct) .. "%"); ag.timer:SetTextColor(1, .6, .1)
      ag.label:SetText("|cffff8800Fast Aggro – kurz aufhören!|r")
    end
    if not ag.warned then
      ag.warned = true
      if DB.aggroTon and PlaySound then pcall(PlaySound, (SOUNDKIT and SOUNDKIT.RAID_WARNING) or 8959, "Master") end
    end
  else
    ag:Hide()
    if pct < schwelle - 15 then ag.warned = false end -- erst wieder warnen, wenn die Bedrohung deutlich gesunken war
  end
end

-- Ereignisse und Takt für 5a–5i
local ef = CreateFrame("Frame")
ef:RegisterEvent("PLAYER_REGEN_ENABLED")
if not pcall(ef.RegisterUnitEvent, ef, "UNIT_SPELLCAST_SUCCEEDED", "player") then ef:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED") end
ef:SetScript("OnEvent", function(_, ev, unit, _, spellID)
  if not DB then return end
  if ev == "UNIT_SPELLCAST_SUCCEEDED" and unit == "player" and not isSecret(spellID) then
    if SUMMON[spellID] then onSummon() end
    onCC(spellID)
  elseif ev == "PLAYER_REGEN_ENABLED" and hs.pending then hs.pending = false; hs.mode = "?"; updateHS()
  end
end)
local fast, slow = 0, 0
ef:SetScript("OnUpdate", function(_, el)
  if not DB then return end
  fast = fast + el; slow = slow + el
  if fast >= .1 then updateNacht(fast); updateCC(); pcall(updateAggro, fast); fast = 0 end
  if slow >= .5 then pcall(updateHS); pcall(updateSD); pcall(updateER); slow = 0 end
end)

-- 5g) Berufs-Infos im Tooltip ----------------------------------------------------
local TT = {
  [2589] = { "Schneiderei: Leinenstoffballen (1–30)", "Erste Hilfe: Leinenverband (1–50)" },
  [2592] = { "Schneiderei: Wollstoffballen (55–80)", "Erste Hilfe: Wollverband (80–135)" },
  [4306] = { "Schneiderei: Seidenstoffballen (100–120)", "Erste Hilfe: Seidenverband (150–193)" },
  [4338] = { "Schneiderei: Magiestoffballen (140–150)", "Erste Hilfe: Magiestoffverband (210–260)" },
  [14047] = { "Schneiderei: Runenstoffballen", "Erste Hilfe: Runenstoffverband (260–300)" },
  [14256] = { "Schneiderei: Teufelsstoff-Rezepte (Hexer-Ausrüstung)" },
  [21877] = { "Schneiderei: Netherstoffballen (TBC)", "Erste Hilfe: Netherstoffverband (TBC)" },
  [2996] = { "Schneiderei: Leinengürtel (30–55)" },
  [2997] = { "Schneiderei: Wollumhang (80–95), Doppelt genähte Wollschultern (95–100)" },
  [4305] = { "Schneiderei: Purpurrote Seidenweste (150–170) und -pantalons (170–190)" },
  [4339] = { "Schneiderei: Schwarze Magiestoffhandschuhe (190–215), Magiestofftasche (215–225)" },
  [10940] = { "Verzauberkunst: Brust – Unterlegene Ausdauer (20–70), Umhang – Schwacher Schutz (100–130)" },
  [10938] = { "Verzauberkunst: Armschiene – Schwache Abwehr (20–70), Brust – Schwache Absorption (70–109)", "Verzauberkunst: Geringer Zauberstab" },
  [10939] = { "Verzauberkunst: Großer Zauberstab, rechtsklicken = 3 Geringe Magieessenzen" },
  [11083] = { "Verzauberkunst: Schwaches Manaöl (151–165), Stiefel – Geringe Beweglichkeit (165–185)" },
  [11137] = { "Verzauberkunst: Armschiene – Stärke (185–200), Geringes Zauberöl (201–220)" },
  [11176] = { "Verzauberkunst: Geringes Manaöl (250–265), Schild – Große Ausdauer (265–294)" },
  [16204] = { "Verzauberkunst: Umhang – Überragende Verteidigung (295–300)" },
  [22445] = { "Verzauberkunst: TBC-Verzauberungen (Arkaner Staub)" },
  [1210] = { "Verzauberkunst: Runenverzierte Silberrute (109–110)" },
  [2447] = { "Erste Hilfe: Schwacher Heiltrank (55–80)" },
  [2450] = { "Erste Hilfe: Geringer Heiltrank" },
  [2453] = { "Erste Hilfe: Heiltrank (135–150)" },
  [3357] = { "Erste Hilfe: Großer Heiltrank (193–200)" },
  [3821] = { "Kochen: Golddorntee (215–231)" },
  [4304] = { "Erste Hilfe: Lederaderpresse (200–210)" },
  [769] = { "Kochen: Geröstetes Eberfleisch (1–66)" },
  [2673] = { "Kochen: Kojotensteak (90–115)" },
  [2674] = { "Kochen: Krabbenküchlein (115–136)" },
  [1015] = { "Kochen: Mageres Wolfssteak (136–175)" },
  [6289] = { "Kochen: Langkiefer-Schlammschnapper (66–90)" },
  [8365] = { "Kochen: Mithrilkopfforelle (175–215)" },
  [4603] = { "Kochen: Gefleckter Gelbschwanz (231–269)" },
  [13759] = { "Kochen: Nachtflossensuppe (269–300)" },
}
local function addProfLines(tip, id)
  if not DB or not DB.tooltip or not id or isSecret(id) then return end
  local l = TT[id]
  if not l then return end
  tip:AddLine(" ")
  tip:AddLine("|cff9b59d6siikkUI – brauchst du für:|r")
  for _, t in ipairs(l) do tip:AddLine(t, 1, 1, 1, true) end
  tip:Show()
end
if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
  pcall(TooltipDataProcessor.AddTooltipPostCall, Enum.TooltipDataType.Item, function(tip, data)
    if tip == GameTooltip or tip == ItemRefTooltip then addProfLines(tip, data and data.id) end
  end)
else
  for _, tip in ipairs({ GameTooltip, ItemRefTooltip }) do
    if tip and tip.HookScript then
      pcall(tip.HookScript, tip, "OnTooltipSetItem", function(t)
        local _, link = t:GetItem()
        local id = link and tonumber(link:match("item:(%d+)"))
        addProfLines(t, id)
      end)
    end
  end
end

local function onCast(spellID)
  if isSecret(spellID) then return end
  for _, id in ipairs(SOULSTONE_BUFFS) do
    if spellID == id then
      local ziel = UnitName("player")
      if UnitExists("target") and UnitIsFriend("player", "target") and not UnitIsDead("target") then ziel = UnitName("target") end
      if isSecret(ziel) then ziel = nil end
      DB.stein = { zeit = time(), ziel = ziel }
      stone.cdShown = false
    end
  end
  local guid = UnitGUID("target")
  if not guid or isSecret(guid) then return end
  for _, d in ipairs(DOTS) do
    local dur = d.ids[spellID]
    if dur then
      timers[guid] = timers[guid] or {}
      timers[guid][d.key] = { GetTime() + dur, dur }
    end
  end
end

---------------------------------------------------------------------------
-- 3) Inventar-Export
---------------------------------------------------------------------------
local SLOTS = { {1,"kopf"},{2,"hals"},{3,"schultern"},{15,"ruecken"},{5,"brust"},{9,"handgelenke"},{10,"haende"},{6,"taille"},{7,"beine"},{8,"fuesse"},{11,"finger1"},{12,"finger2"},{13,"schmuck1"},{14,"schmuck2"},{16,"waffe"},{17,"nebenhand"},{18,"zauberstab"} }
local INVTYPE = { INVTYPE_HEAD="kopf", INVTYPE_NECK="hals", INVTYPE_SHOULDER="schultern", INVTYPE_CLOAK="ruecken", INVTYPE_CHEST="brust", INVTYPE_ROBE="brust", INVTYPE_WRIST="handgelenke", INVTYPE_HAND="haende", INVTYPE_WAIST="taille", INVTYPE_LEGS="beine", INVTYPE_FEET="fuesse", INVTYPE_FINGER="finger1", INVTYPE_TRINKET="schmuck1", INVTYPE_WEAPON="waffe", INVTYPE_WEAPONMAINHAND="waffe", INVTYPE_2HWEAPON="waffe", INVTYPE_WEAPONOFFHAND="nebenhand", INVTYPE_HOLDABLE="nebenhand", INVTYPE_SHIELD="nebenhand", INVTYPE_RANGED="zauberstab", INVTYPE_RANGEDRIGHT="zauberstab", INVTYPE_THROWN="zauberstab" }

local function clean(s) return (tostring(s or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", "")) end
local function js(s)
  s = clean(s):gsub("\\", "\\\\"):gsub('"', '\\"'):gsub("\n", "\\n"):gsub("[%c]", " ")
  return '"' .. s .. '"'
end
local function tooltipLines(link)
  local out = {}
  if C_TooltipInfo and C_TooltipInfo.GetHyperlink then
    local data = safe(C_TooltipInfo.GetHyperlink, link)
    if data and data.lines then
      for i, l in ipairs(data.lines) do
        if i > 1 and l.leftText and not isSecret(l.leftText) and l.leftText ~= "" then table.insert(out, l.leftText) end
        if #out >= 25 then break end
      end
    end
  end
  return out
end
local function itemJson(link, menge, ort, forceSlot)
  local name, _, q, _, _, _, _, _, equip, _, _, classID = safe(GetItemInfo, link)
  if not name and C_Item and C_Item.GetItemInfo then name, _, q, _, _, _, _, _, equip, _, _, classID = safe(C_Item.GetItemInfo, link) end
  if C_Item and C_Item.GetItemInfoInstant then
    local _, _, _, eq, _, cid = safe(C_Item.GetItemInfoInstant, link)
    equip = equip or eq; classID = classID or cid
  elseif GetItemInfoInstant then
    local _, _, _, eq, _, cid = safe(GetItemInfoInstant, link)
    equip = equip or eq; classID = classID or cid
  end
  name = name or clean(link):match("%[(.-)%]") or "?"
  local parts = { '"name":' .. js(name), '"menge":' .. (menge or 1), '"q":' .. (q or 1), '"typ":' .. (classID or -1) }
  if ort then table.insert(parts, '"ort":' .. js(ort)) end
  local slot = forceSlot or (equip and INVTYPE[equip])
  if slot then
    table.insert(parts, '"slot":' .. js(slot))
    local tt = {}
    for _, l in ipairs(tooltipLines(link)) do table.insert(tt, js(l)) end
    table.insert(parts, '"tt":[' .. table.concat(tt, ",") .. ']')
  end
  return "{" .. table.concat(parts, ",") .. "}"
end

local function bagIds()
  local ids = {}
  local last = NUM_TOTAL_EQUIPPED_BAG_SLOTS or NUM_BAG_SLOTS or 4
  for b = 0, last do table.insert(ids, b) end
  return ids
end
local function bankIds()
  local ids = {}
  if Enum and Enum.BagIndex and Enum.BagIndex.CharacterBankTab_1 then
    for i = 1, 6 do local v = Enum.BagIndex["CharacterBankTab_" .. i]; if v then table.insert(ids, v) end end
    return ids
  end
  table.insert(ids, BANK_CONTAINER or -1)
  local first = (NUM_TOTAL_EQUIPPED_BAG_SLOTS or NUM_BAG_SLOTS or 4) + 1
  for b = first, first + (NUM_BANKBAGSLOTS or 6) - 1 do table.insert(ids, b) end
  return ids
end
local function readBags(ids, ort)
  local agg, order = {}, {}
  local numSlots = (C_Container and C_Container.GetContainerNumSlots) or GetContainerNumSlots
  for _, bag in ipairs(ids) do
    local n = safe(numSlots, bag) or 0
    for s = 1, n do
      local link, cnt
      if C_Container and C_Container.GetContainerItemInfo then
        local info = safe(C_Container.GetContainerItemInfo, bag, s)
        if info then link, cnt = info.hyperlink, info.stackCount end
      else
        local _, c, _, _, _, _, l = safe(GetContainerItemInfo, bag, s)
        link, cnt = l, c
      end
      if link and not isSecret(link) then
        local key = clean(link):match("%[(.-)%]") or link
        if not agg[key] then agg[key] = { link = link, n = 0 }; table.insert(order, key) end
        agg[key].n = agg[key].n + (cnt or 1)
      end
    end
  end
  local out = {}
  for _, k in ipairs(order) do table.insert(out, itemJson(agg[k].link, agg[k].n, ort)) end
  return out
end

local function professions()
  local out = {}
  if GetNumSkillLines and GetSkillLineInfo then
    for i = 1, (safe(GetNumSkillLines) or 0) do
      local name, header, _, rank, _, _, max = safe(GetSkillLineInfo, i)
      if name and not header and rank and max and max > 1 then table.insert(out, js(name) .. ":" .. rank) end
    end
  elseif GetProfessions and GetProfessionInfo then
    local list = { GetProfessions() }
    for i = 1, 6 do
      local idx = list[i]
      if idx then local name, _, rank = safe(GetProfessionInfo, idx); if name and rank then table.insert(out, js(name) .. ":" .. rank) end end
    end
  end
  return out
end

local function gold()
  local m = GetMoney() or 0
  return string.format("%dg %ds %dk", math.floor(m / 10000), math.floor(m / 100) % 100, m % 100)
end

local function buildExport()
  local gear = {}
  for _, s in ipairs(SLOTS) do
    local link = safe(GetInventoryItemLink, "player", s[1])
    if link then
      local obj = itemJson(link, 1, nil, s[2])
      table.insert(gear, js(s[2]) .. ":" .. obj)
    end
  end
  local bags = readBags(bagIds())
  local parts = {
    '"quelle":"TobsiikkHelfer"', '"version":1',
    '"zeit":' .. js(date("%d.%m.%Y %H:%M")),
    '"name":' .. js(UnitName("player")),
    '"stufe":' .. (UnitLevel("player") or 0),
    '"gold":' .. js(gold()),
    '"berufe":{' .. table.concat(professions(), ",") .. '}',
    '"gear":{' .. table.concat(gear, ",") .. '}',
    '"taschen":[' .. table.concat(bags, ",") .. ']',
  }
  if DB.bank then
    table.insert(parts, '"bank":[' .. table.concat(DB.bank, ",") .. ']')
    table.insert(parts, '"bankStand":' .. js(DB.bankZeit or ""))
  end
  return "{" .. table.concat(parts, ",") .. "}"
end

local exp
local function showExport()
  if not exp then
    exp = CreateFrame("Frame", "TobsiikkHelferExport", UIParent, "BasicFrameTemplateWithInset")
    exp:SetSize(520, 380); exp:SetPoint("CENTER"); exp:SetFrameStrata("DIALOG")
    exp:SetMovable(true); exp:EnableMouse(true); exp:RegisterForDrag("LeftButton")
    exp:SetScript("OnDragStart", exp.StartMoving); exp:SetScript("OnDragStop", exp.StopMovingOrSizing)
    exp.title = exp:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    exp.title:SetPoint("TOP", 0, -5); exp.title:SetText("Inventar-Export für deinen Guide")
    exp.hint = exp:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    exp.hint:SetPoint("TOPLEFT", 14, -32); exp.hint:SetPoint("TOPRIGHT", -14, -32); exp.hint:SetJustifyH("LEFT")
    exp.hint:SetText("Strg+A, dann Strg+C. Im Guide unter Inventar → „Addon-Export einfügen“ mit Strg+V einfügen.")
    local sf = CreateFrame("ScrollFrame", nil, exp, "UIPanelScrollFrameTemplate")
    sf:SetPoint("TOPLEFT", 14, -56); sf:SetPoint("BOTTOMRIGHT", -32, 14)
    local eb = CreateFrame("EditBox", nil, sf)
    eb:SetMultiLine(true); eb:SetFontObject(ChatFontNormal); eb:SetWidth(460); eb:SetHeight(300); eb:SetAutoFocus(false)
    eb:SetScript("OnEscapePressed", function() exp:Hide() end)
    sf:SetScrollChild(eb)
    exp.eb = eb
    tinsert(UISpecialFrames, "TobsiikkHelferExport")
  end
  local ok, text = pcall(buildExport)
  if not ok then msg("Export fehlgeschlagen: " .. tostring(text)) return end
  exp.eb:SetText(text); exp:Show(); exp.eb:SetFocus(); exp.eb:HighlightText()
  if not DB.bank then msg("Tipp: Öffne einmal deine Bank, dann ist sie beim nächsten Export dabei.") end
end

---------------------------------------------------------------------------
-- Ereignisse und Befehle
---------------------------------------------------------------------------
local function place(frame, pos, dp, dx, dy)
  frame:ClearAllPoints()
  if pos then frame:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4]) else frame:SetPoint(dp, UIParent, dp, dx, dy) end
end

-- 5g) Eigene Zauberleiste (rot, „Tobsiikk“ in Lila) ----------------------------
local CB_ROT, CB_HELL, CB_GRAU = { .85, .08, .08 }, { 1, .35, .3 }, { .45, .45, .45 }
local CB_LILA = "|cffb266ff"
local CHANNEL_TICKS = { [689] = 5, [1120] = 5, [755] = 10, [5740] = 4, [1949] = 15, [5138] = 5 } -- Blutsauger, Seelendieb, Lebenslinie, Feuerregen, Höllenfeuer, Mana entziehen
local cbWorks, cbWarned, cbHooked, tickNames = true, false, false, nil
local cb = CreateFrame("Frame", "TobsiikkHelfer_zauberleiste", UIParent, "BackdropTemplate")
cb:SetSize(260, 24); cb:SetMovable(true); cb:EnableMouse(true); cb:RegisterForDrag("LeftButton"); cb:SetClampedToScreen(true)
if cb.SetBackdrop then
  cb:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
  cb:SetBackdropColor(0, 0, 0, .85); cb:SetBackdropBorderColor(.7, .4, 1, 1)
end
cb.icon = cb:CreateTexture(nil, "ARTWORK"); cb.icon:SetSize(24, 24); cb.icon:SetPoint("RIGHT", cb, "LEFT", -3, 0); cb.icon:SetTexCoord(.08, .92, .08, .92)
cb.bar = CreateFrame("StatusBar", nil, cb); cb.bar:SetPoint("TOPLEFT", 4, -4); cb.bar:SetPoint("BOTTOMRIGHT", -4, 4)
cb.bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); cb.bar:SetMinMaxValues(0, 1); cb.bar:SetValue(0)
cb.bar:SetStatusBarColor(CB_ROT[1], CB_ROT[2], CB_ROT[3])
cb.lag = cb.bar:CreateTexture(nil, "OVERLAY"); cb.lag:SetColorTexture(1, 1, 1, .25); cb.lag:Hide()
cb.spark = cb.bar:CreateTexture(nil, "OVERLAY", nil, 2); cb.spark:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
cb.spark:SetBlendMode("ADD"); cb.spark:SetSize(20, 34)
cb.label = cb.bar:CreateFontString(nil, "OVERLAY", "GameFontNormal"); cb.label:SetPoint("LEFT", 6, 0); cb.label:Hide() -- kein Name mehr
-- Fraktions-Zeichen links in der Leiste und wählbare Leuchtfarbe (Einstellungen: Reiter „Bedienung“)
cb.emblem = cb.bar:CreateTexture(nil, "OVERLAY", nil, 3); cb.emblem:SetSize(20, 20); cb.emblem:SetPoint("LEFT", cb.bar, "LEFT", 2, 0)
NS.addLogo(cb.emblem, "Interface\\AddOns\\siikkUI\\Media\\horde3d_hd")
cb.FARBEN = { rot = { "Rot", 1, .12, .08 }, gruen = { "Grün", .1, 1, .25 }, blau = { "Blau", .15, .6, 1 }, orange = { "Orange", 1, .55, .05 } }
cb.FARBFOLGE = { "rot", "gruen", "blau", "orange" }
cb.ZEICHEN = { horde = { "Horde", { "Interface\\AddOns\\siikkUI\\Media\\horde3d_hd" } },
  allianz = { "Allianz", { "Interface\\BattlefieldFrame\\Battleground-Alliance", "Interface\\TargetingFrame\\UI-PVP-Alliance" } } }
cb.applyStyle = function()
  local f = cb.FARBEN[(DB and DB.cbFarbe) or "rot"] or cb.FARBEN.rot
  CB_ROT[1], CB_ROT[2], CB_ROT[3] = f[2], f[3], f[4]                                   -- Leistenfarbe
  CB_HELL[1], CB_HELL[2], CB_HELL[3] = math.min(1, f[2] + .3), math.min(1, f[3] + .3), math.min(1, f[4] + .3) -- Aufblitzen bei Erfolg
  local t = cb.bar.GetStatusBarTexture and cb.bar:GetStatusBarTexture()
  if type(t) == "table" and t.SetBlendMode then t:SetBlendMode("ADD") end                -- leuchtend
  if cb.SetBackdropBorderColor then cb:SetBackdropBorderColor(f[2], f[3], f[4], 1) end
  if cb.mode or not cb:IsShown() then cb.bar:SetStatusBarColor(f[2], f[3], f[4]) end
end
cb.time = cb.bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); cb.time:SetPoint("RIGHT", -5, 0)
cb.spell = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); cb.spell:SetPoint("BOTTOM", cb, "TOP", 0, 2)
cb.ticks = {}
cb:SetScript("OnDragStart", function(s) if not DB.gesperrt then s:StartMoving() end end)
cb:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); savePos(s, "zauberleiste") end)
makeScalable(cb, "zauberleiste")
table.insert(extraFrames, { frame = cb, key = "zauberleiste", x = 0, y = -290 })
cb:Hide()

local function dec(v) return (string.format("%.1f", v or 0):gsub("%.", ",")) end
local function cbColor(c) cb.bar:SetStatusBarColor(c[1], c[2], c[3]) end
local function blizzBar() return PlayerCastingBarFrame or CastingBarFrame end
local function cbBlizz()
  local bf = blizzBar()
  if not bf or not DB then return end
  if not cbHooked and bf.HookScript then
    cbHooked = true
    bf:HookScript("OnShow", function(s) if DB and DB.castbar and DB.castbarBlizzAus and cbWorks then pcall(s.Hide, s) end end)
  end
  if DB.castbar and DB.castbarBlizzAus and cbWorks and bf:IsShown() then pcall(bf.Hide, bf) end
end
local function cbRead()
  local r, mode = { safe(UnitCastingInfo, "player") }, "cast"
  if not r[1] then r, mode = { safe(UnitChannelInfo, "player") }, "channel" end
  if not r[1] then return nil end
  local name, tex, st, en = r[1], r[3], r[4], r[5]
  if isSecret(name) or isSecret(st) or isSecret(en) or type(st) ~= "number" or type(en) ~= "number" then cbWorks = false; return nil end
  local id = (mode == "cast") and r[9] or r[8]
  if isSecret(id) then id = nil end
  if isSecret(tex) then tex = nil end
  return mode, name, tex, st / 1000, en / 1000, id
end
local function ticksFor(id, name)
  if id and CHANNEL_TICKS[id] then return CHANNEL_TICKS[id] end
  if not tickNames then
    tickNames = {}
    for sid, n in pairs(CHANNEL_TICKS) do local nm = spellName(sid); if nm then tickNames[nm] = n end end
  end
  return tickNames[name]
end
local function cbTicks(n)
  for _, t in ipairs(cb.ticks) do t:Hide() end
  if not n or n < 2 then return end
  local w = cb.bar:GetWidth() or 0
  for i = 1, n - 1 do
    local t = cb.ticks[i]
    if not t then t = cb.bar:CreateTexture(nil, "OVERLAY", nil, 1); t:SetColorTexture(1, 1, 1, .6); t:SetWidth(1); cb.ticks[i] = t end
    t:ClearAllPoints(); t:SetPoint("TOPLEFT", cb.bar, "TOPLEFT", w * i / n, 0); t:SetPoint("BOTTOMLEFT", cb.bar, "BOTTOMLEFT", w * i / n, 0); t:Show()
  end
end
local function cbBegin(mode, name, tex, st, en)
  cb.mode, cb.st, cb.en = mode, st, en
  cb.spell:SetText(name or ""); cb.icon:SetTexture(tex or 136197); cb.icon:Show()
  cbColor(CB_ROT); cb:SetAlpha(1); cb:Show()
end
local function cbStart()
  if not DB or not DB.castbar then return end
  local mode, name, tex, st, en, id = cbRead()
  if not mode then
    if not cbWorks then
      cb:Hide()
      local bf = blizzBar(); if bf then pcall(bf.Show, bf) end
      if not cbWarned then cbWarned = true; msg("Die eigene Zauberleiste bekommt in dieser Spielversion keine Zauberdaten – die normale Blizzard-Leiste bleibt an.") end
    end
    return
  end
  cb.fake = nil
  cbBegin(mode, name, tex, st, en)
  cbTicks(mode == "channel" and ticksFor(id, name) or nil)
  -- Verzögerung (Latenz) als hellen Bereich anzeigen
  local lagS = 0
  if GetNetStats then local _, _, home, world = GetNetStats(); local l = world or home; if l and not isSecret(l) then lagS = l / 1000 end end
  local dur, w = en - st, cb.bar:GetWidth() or 0
  if lagS > 0 and dur > 0 and w > 0 then
    cb.lag:ClearAllPoints(); cb.lag:SetWidth(math.max(1, math.min(1, lagS / dur) * w))
    if mode == "cast" then cb.lag:SetPoint("TOPRIGHT"); cb.lag:SetPoint("BOTTOMRIGHT") else cb.lag:SetPoint("TOPLEFT"); cb.lag:SetPoint("BOTTOMLEFT") end
    cb.lag:Show()
  else cb.lag:Hide() end
end
local function cbEnd(kind) -- "ok" = fertig, "fail" = unterbrochen, "stop" = abgebrochen
  if not cb.mode or cb.mode == "fade" then return end
  if kind == "fail" then cbColor(CB_GRAU); cb.spell:SetText(cb.failText or "Unterbrochen"); cb.bar:SetValue(1)
  elseif kind == "ok" then cbColor(CB_HELL); cb.bar:SetValue(cb.mode == "cast" and 1 or 0) end
  cb.time:SetText(""); cb.spark:Hide(); cb.lag:Hide(); cbTicks(nil)
  cb.mode, cb.fadeT, cb.fake = "fade", .5, nil
end
local function cbPreview()
  if placing and DB and DB.castbar then
    cb.mode = nil; cbColor(CB_ROT); cb:SetAlpha(1)
    cb.spell:SetText("Schattenblitz (Beispiel)")
    cb.icon:SetTexture(spellTex(686, 136197)); cb.bar:SetValue(.6); cb.time:SetText("1,0 / 2,5")
    cb.spark:ClearAllPoints(); cb.spark:SetPoint("CENTER", cb.bar, "LEFT", .6 * (cb.bar:GetWidth() or 0), 0); cb.spark:Show()
    cb:Show()
  elseif not cb.mode then cb:Hide() end
end
local function cbTest()
  local now = GetTime()
  cbBegin("cast", "Schattenblitz (Probe)", spellTex(686, 136197), now, now + 2.5)
  cbTicks(nil); cb.lag:Hide(); cb.fake = true
end
cb:SetScript("OnUpdate", function(s, el)
  if placing and not s.mode then return end
  if s.mode == "fade" then
    s.fadeT = s.fadeT - el; s:SetAlpha(math.max(0, s.fadeT / .5))
    if s.fadeT <= 0 then s.mode = nil; s:Hide() end
    return
  end
  if not s.mode then s:Hide() return end
  if not s.fake then -- Zurückwerfen durch Treffer: neue Zeiten übernehmen
    local mode, _, _, st, en = cbRead()
    if mode == s.mode then s.st, s.en = st, en end
  end
  local now, dur = GetTime(), s.en - s.st
  if dur <= 0 then return end
  if now > s.en + (s.fake and 0 or .5) then cbEnd(s.fake and "ok" or "stop") return end -- Sicherheitsnetz
  local p = math.max(0, math.min(1, (now - s.st) / dur))
  local shown = (s.mode == "cast") and p or (1 - p)
  s.bar:SetValue(shown)
  s.spark:ClearAllPoints(); s.spark:SetPoint("CENTER", s.bar, "LEFT", shown * (s.bar:GetWidth() or 0), 0); s.spark:Show()
  s.time:SetText(dec(math.max(0, s.en - now)) .. " / " .. dec(dur))
end)
local cbEv = CreateFrame("Frame")
for _, e in ipairs({ "UNIT_SPELLCAST_START", "UNIT_SPELLCAST_STOP", "UNIT_SPELLCAST_FAILED", "UNIT_SPELLCAST_INTERRUPTED", "UNIT_SPELLCAST_DELAYED",
  "UNIT_SPELLCAST_CHANNEL_START", "UNIT_SPELLCAST_CHANNEL_UPDATE", "UNIT_SPELLCAST_CHANNEL_STOP", "UNIT_SPELLCAST_SUCCEEDED" }) do
  if not pcall(cbEv.RegisterUnitEvent, cbEv, e, "player") then pcall(cbEv.RegisterEvent, cbEv, e) end
end
cbEv:SetScript("OnEvent", function(_, ev, unit)
  if not DB or unit ~= "player" then return end
  if not DB.castbar then cb.mode = nil; cb:Hide() return end
  if ev == "UNIT_SPELLCAST_START" or ev == "UNIT_SPELLCAST_CHANNEL_START" then cbStart(); cbBlizz()
  elseif ev == "UNIT_SPELLCAST_SUCCEEDED" then if cb.mode == "cast" and not cb.fake then cbEnd("ok") end
  elseif ev == "UNIT_SPELLCAST_INTERRUPTED" or ev == "UNIT_SPELLCAST_FAILED" then
    -- Ein fehlgeschlagener zweiter Zauber darf den laufenden nicht beenden
    if cb.fake or not cb.mode or cb.mode == "fade" or cbRead() then return end
    cb.failText = (ev == "UNIT_SPELLCAST_INTERRUPTED") and "Unterbrochen" or "Fehlgeschlagen"; cbEnd("fail")
  elseif ev == "UNIT_SPELLCAST_CHANNEL_STOP" then if cb.mode == "channel" then cbEnd("ok") end
  elseif ev == "UNIT_SPELLCAST_STOP" then if cb.mode == "cast" and not cb.fake and not cbRead() then cbEnd("stop") end
  end -- DELAYED / CHANNEL_UPDATE: die neuen Zeiten liest OnUpdate selbst
end)

local function edges(frame)
  if frame.edges then return frame.edges end
  local t = {}
  local function e(p1, p2, w, h)
    local x = frame:CreateTexture(nil, "OVERLAY", nil, 7)
    x:SetColorTexture(1, .82, 0, .9); x:SetPoint(p1); x:SetPoint(p2)
    if w then x:SetWidth(w) else x:SetHeight(h) end
    table.insert(t, x)
  end
  e("TOPLEFT", "TOPRIGHT", nil, 2); e("BOTTOMLEFT", "BOTTOMRIGHT", nil, 2)
  e("TOPLEFT", "BOTTOMLEFT", 2); e("TOPRIGHT", "BOTTOMRIGHT", 2)
  frame.edges = t
  return t
end
local function showEdges(frame, on) for _, x in ipairs(edges(frame)) do if on then x:Show() else x:Hide() end end end

local function applyLayout()
  shard:SetScale(DB.scale.splitter or 1); place(shard, DB.pos.splitter, "CENTER", -220, -160)
  if not InCombatLockdown() then stone:SetScale(DB.scale.stein or 1); place(stone, DB.pos.stein, "CENTER", -160, -160) end
  for i, b in ipairs(dotIcons) do
    local k = "dot_" .. b.d.key
    b:SetScale(DB.scale[k] or 1)
    place(b, DB.pos[k], "CENTER", (i - (#dotIcons + 1) / 2) * 56, -230)
  end
  local wheel = not DB.gesperrt
  for _, e in ipairs(extraFrames) do
    local fr = e.frame
    if not (fr:IsProtected() and InCombatLockdown()) then
      fr:SetScale(DB.scale[e.key] or 1); place(fr, DB.pos[e.key], e.point or "CENTER", e.x, e.y)
      fr:EnableMouseWheel(wheel)
    end
    showEdges(fr, wheel)
  end
  showEdges(shard, wheel); showEdges(stone, wheel)
  for _, b in ipairs(dotIcons) do showEdges(b, wheel) end
  shard:EnableMouseWheel(wheel)
  for _, b in ipairs(dotIcons) do b:EnableMouseWheel(wheel) end
  cb:EnableMouse(wheel) -- gesperrt: Zauberleiste lässt Klicks durch
  cbPreview(); cbBlizz()
  if NS.onLayout then pcall(NS.onLayout, placing) end
  if not InCombatLockdown() then stone:EnableMouseWheel(wheel) end
  showRaster(placing)
  for _, fs in ipairs(labels) do if placing then fs:Show() else fs:Hide() end end
end
updateKnownDots()

---------------------------------------------------------------------------
-- Profile: Einstellungen (und auf Wunsch Tastenbelegung) unter einem Namen speichern, für Twinks laden
-- Gespeichert accountweit in HexenmeisterProfile – jeder Charakter dieses Spiels kann sie nutzen.
---------------------------------------------------------------------------
local function deepcopy(v, seen)
  if type(v) ~= "table" then return v end
  seen = seen or {}; if seen[v] then return seen[v] end
  local t = {}; seen[v] = t
  for k, x in pairs(v) do t[deepcopy(k, seen)] = deepcopy(x, seen) end
  return t
end
local BIND_GROUPS = { { "ACTIONBUTTON", 12 }, { "MULTIACTIONBAR1BUTTON", 12 }, { "MULTIACTIONBAR2BUTTON", 12 }, { "MULTIACTIONBAR3BUTTON", 12 },
  { "MULTIACTIONBAR4BUTTON", 12 }, { "BONUSACTIONBUTTON", 10 }, { "SHAPESHIFTBUTTON", 10 } }
local function grabBindings()
  local t = {}
  for _, g in ipairs(BIND_GROUPS) do
    for i = 1, g[2] do
      local cmd = g[1] .. i
      local keys = { pcall(GetBindingKey, cmd) }
      if keys[1] then table.remove(keys, 1); if #keys > 0 then t[cmd] = keys end end
    end
  end
  return t
end
local function applyBindings(t)
  if type(t) ~= "table" or InCombatLockdown() or not SetBinding then return false end
  for _, g in ipairs(BIND_GROUPS) do
    for i = 1, g[2] do
      local cmd = g[1] .. i
      for _, k in ipairs({ pcall(GetBindingKey, cmd) }) do if type(k) == "string" then pcall(SetBinding, k) end end
    end
  end
  for cmd, keys in pairs(t) do
    if type(cmd) == "string" and type(keys) == "table" then for i = 1, #keys do if type(keys[i]) == "string" then pcall(SetBinding, keys[i], cmd) end end end
  end
  if SaveBindings then pcall(SaveBindings, (GetCurrentBindingSet and GetCurrentBindingSet()) or 1) end
  return true
end
local function profStore()
  local root = rawget(_G, "HexenmeisterProfile")
  if type(root) ~= "table" then root = {}; HexenmeisterProfile = root end
  if type(rawget(root, "profile")) ~= "table" then root.profile = {} end
  return root.profile
end
local function className() local loc, tok = UnitClass("player"); return loc or tok or "Profil", tok end
local function profSave(name, withBinds)
  name = (name or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if name == "" then msg("Bitte einen Namen für das Profil eingeben."); return end
  local data = deepcopy(TobsiikkHelferDB or {})
  data.profilName = nil
  profStore()[name] = { daten = data, tasten = withBinds and grabBindings() or nil, klasse = select(2, className()),
    von = (UnitName("player") or "?"), zeit = date and date("%d.%m.%Y %H:%M") or "" }
  if DB then DB.profilName = name end
  msg("Profil |cffffd100" .. name .. "|r gespeichert" .. (withBinds and " (mit Tastenbelegung)." or "."))
  if NS.profRefresh then NS.profRefresh() end
end
local function profLoad(name)
  local p = profStore()[name or ""]
  if not p then msg("Profil „" .. tostring(name) .. "“ gibt es nicht."); return end
  if InCombatLockdown() then msg("Bitte nach dem Kampf laden."); return end
  local db = TobsiikkHelferDB
  for k in pairs(db) do db[k] = nil end
  for k, v in pairs(deepcopy(p.daten or {})) do db[k] = v end
  db.profilName = name
  if p.tasten then applyBindings(p.tasten) end
  msg("Profil |cffffd100" .. name .. "|r geladen – die Oberfläche wird neu geladen ...")
  if ReloadUI then ReloadUI() end
end
local function profDelete(name)
  local st = profStore()
  if not st[name or ""] then msg("Profil „" .. tostring(name) .. "“ gibt es nicht."); return end
  st[name] = nil; msg("Profil |cffffd100" .. name .. "|r gelöscht.")
  if DB and DB.profilName == name then DB.profilName = nil end
  if NS.profRefresh then NS.profRefresh() end
end
local function profNames() local t = {}; for n in pairs(profStore()) do t[#t + 1] = n end; table.sort(t); return t end
NS.profSave, NS.profLoad, NS.profDelete, NS.profNames = profSave, profLoad, profDelete, profNames

f:RegisterEvent("ADDON_LOADED")
f:SetScript("OnEvent", function(_, ev, a1, a2, a3)
  if ev == "ADDON_LOADED" and a1 == ADDON then
    if TobsiikkHelferDB == nil then
      -- neuer Charakter (Twink): gibt es ein Profil mit dem Namen seiner Klasse, startet er gleich damit
      local loc = UnitClass("player")
      local p = type(loc) == "string" and rawget(profStore(), loc)
      if type(p) == "table" and type(p.daten) == "table" then TobsiikkHelferDB = deepcopy(p.daten or {}); TobsiikkHelferDB.profilName = loc; NS.autoProfil = { name = loc, tasten = p.tasten } end
    end
    TobsiikkHelferDB = TobsiikkHelferDB or {}
    for k, v in pairs(DEFAULTS) do if TobsiikkHelferDB[k] == nil then TobsiikkHelferDB[k] = v end end
    DB = TobsiikkHelferDB
    if type(DB.scale) ~= "table" then DB.scale = {} end
    standardLayout(false) -- fehlende Plätze mit der Standard-Anordnung füllen
    if type(DB.dotAus) ~= "table" then DB.dotAus = {} end
    if not DB.klangGewaehlt then DB.erinnerungKlang = 2; DB.klangGewaehlt = true end -- Wecker als gewählter Standard
    pcall(cb.applyStyle)
    applyLayout()
    for _, e in ipairs({ "PLAYER_ENTERING_WORLD", "BAG_UPDATE_DELAYED", "BAG_UPDATE_COOLDOWN", "PLAYER_REGEN_ENABLED", "SPELLS_CHANGED", "BANKFRAME_OPENED", "PLAYERBANKSLOTS_CHANGED", "PLAYER_TARGET_CHANGED" }) do
      pcall(f.RegisterEvent, f, e)
    end
    for _, e in ipairs({ "UNIT_AURA", "UNIT_SPELLCAST_SUCCEEDED" }) do
      if not pcall(f.RegisterUnitEvent, f, e, "player") then pcall(f.RegisterEvent, f, e) end
    end
    updateKnownDots(); updateShard(); updateStone()
  elseif not DB then return
  elseif ev == "UNIT_SPELLCAST_SUCCEEDED" then
    if a1 == "player" then onCast(a3) end
  elseif ev == "UNIT_AURA" then
    if a1 == "player" then updateShard(); updateStone() end
  elseif ev == "BANKFRAME_OPENED" or ev == "PLAYERBANKSLOTS_CHANGED" then
    C_Timer.After(.3, function() local ok, b = pcall(readBags, bankIds(), "Bank"); if ok then DB.bank = b; DB.bankZeit = date("%d.%m.%Y %H:%M") end end)
  elseif ev == "PLAYER_TARGET_CHANGED" then
    for g, t in pairs(timers) do local alive = false; for _, v in pairs(t) do if v[1] > GetTime() then alive = true end end; if not alive then timers[g] = nil end end
  else
    if ev == "PLAYER_REGEN_ENABLED" and pendingAttr then pendingAttr = false; stone.mode = "?" end
    if ev == "SPELLS_CHANGED" or ev == "PLAYER_ENTERING_WORLD" then updateKnownDots() end
    updateShard(); updateStone()
  end
end)

SLASH_TOBSIIKKHELFER1 = "/th"
SLASH_TOBSIIKKHELFER2 = "/tobsiikk"
SlashCmdList.TOBSIIKKHELFER = function(input)
  local cmd, arg = (input or ""):lower():match("^(%S*)%s*(.-)$")
  if cmd == "export" then showExport()
  elseif cmd == "schwelle" and tonumber(arg) then DB.schwelle = tonumber(arg); updateShard(); msg("Splitter werden rot unter " .. DB.schwelle .. ".")
  elseif cmd == "splitter" then DB.splitter = not DB.splitter; updateShard(); msg("Seelensplitter-Anzeige " .. (DB.splitter and "an" or "aus") .. ".")
  elseif cmd == "seelenstein" or cmd == "stein" then DB.seelenstein = not DB.seelenstein; updateStone(); msg("Seelenstein-Anzeige " .. (DB.seelenstein and "an" or "aus") .. ".")
  elseif cmd == "diag" then
    local function yn(v) return v and "ja" or "nein" end
    msg("Version 14.9 · " .. (DB.gesperrt and "gesperrt" or "entsperrt") .. " · Stufe " .. (UnitLevel("player") or "?"))
    msg("Seelenstein-Anzeige an: " .. yn(DB.seelenstein) .. " · sichtbar: " .. yn(stone:IsShown()))
    msg("Zauberleiste an: " .. yn(DB.castbar) .. " · bekommt Zauberdaten: " .. yn(cbWorks) .. " · Blizzard-Leiste ausgeblendet: " .. yn(DB.castbarBlizzAus))
    msg("Kennt Gesundheitsstein herstellen: " .. yn(knowsAny(CREATE_HEALTHSTONE)) .. " · Seelenstein herstellen: " .. yn(knowsAny(CREATE_SOULSTONE)))
    msg("Seelenstein in Taschen: " .. tostring(stoneInBags() or "nein") .. " · Buff: " .. tostring(soulstoneBuffLeft()) .. " · Abklingzeit: " .. math.floor(stoneCooldownLeft()))
    msg("Funktionen: IsPlayerSpell " .. yn(IsPlayerSpell) .. ", IsSpellKnown " .. yn(IsSpellKnown) .. ", C_UnitAuras " .. yn(C_UnitAuras) .. ", UnitBuff " .. yn(UnitBuff))
    local p = { stone:GetPoint() }
    msg("Position: " .. tostring(p[1]) .. " " .. tostring(p[4]) .. " " .. tostring(p[5]))
  elseif cmd == "klang" then
    DB.erinnerungKlang = (DB.erinnerungKlang or 1) % #KLAENGE + 1
    msg("Hinweiston: " .. klang(DB.erinnerungKlang) .. " (nochmal /th klang zum Wechseln)")
  elseif cmd == "aggro" then
    local n = tonumber(arg)
    if n and n >= 50 and n <= 100 then DB.aggroSchwelle = n; msg("Aggro-Warnung ab " .. n .. " % Bedrohung.")
    else DB.aggro = not DB.aggro; msg("Aggro-Warnung " .. (DB.aggro and "an" or "aus") .. ".") end
  elseif cmd == "ton" then DB.erinnerungTon = not DB.erinnerungTon; msg("Ton bei Erinnerungen " .. (DB.erinnerungTon and "an" or "aus") .. ".")
  elseif cmd == "dots" then DB.dots = not DB.dots; msg("DoT-Symbole " .. (DB.dots and "an" or "aus") .. ".")
  elseif cmd == "dot" and arg ~= "" then
    local hit
    for _, d in ipairs(DOTS) do if d.key:find(arg, 1, true) or d.name:lower():find(arg, 1, true) then hit = d break end end
    if hit then DB.dotAus[hit.key] = not DB.dotAus[hit.key] or nil; msg(hit.name .. ": " .. (DB.dotAus[hit.key] and "ausgeblendet" or "wird angezeigt") .. ".")
    else msg("Unbekannter DoT. Möglich: verderbnis, pein, lebensentzug, feuerbrand, instabil") end
  elseif cmd == "verschieben" then placing = not placing
    if placing then DB.gesperrt = false; applyLayout(); msg("Platzier-Modus an: Alle Symbole sind sichtbar. Ziehen verschiebt, Shift beim Loslassen rastet ein, Mausrad ändert die Größe. Fertig mit /th verschieben.")
    else DB.gesperrt = true; applyLayout(); msg("Platzier-Modus aus, Symbole sind jetzt gesperrt.") end
  elseif cmd == "groesse" or cmd == "größe" then
    local raw = ((arg or ""):gsub("%%", ""):gsub(",", "."):gsub("%s", ""))
    local sc = tonumber(raw)
    if sc and sc >= 50 and sc <= 300 then sc = sc / 100 end -- auch Prozent: /th groesse 150
    if sc and sc >= .5 and sc <= 3 then
      sc = math.floor(sc * 100 + .5) / 100
      DB.scale.splitter = sc; DB.scale.stein = sc
      for _, b in ipairs(dotIcons) do DB.scale["dot_" .. b.d.key] = sc end
      for _, e in ipairs(extraFrames) do DB.scale[e.key] = sc end
      DB.pos = {}; standardLayout(false); applyLayout(); msg("Alle Symbole auf " .. pct(sc) .. " gesetzt (Startplätze).")
    else msg("Bitte eine Größe zwischen 50 und 300 %, z. B. /th groesse 150") end
  elseif cmd == "profil" or cmd == "profile" then
    local sub = (arg or ""):match("^(%S*)")
    local nm = (input or ""):match("^%S+%s+%S+%s+(.-)%s*$") or "" -- Groß-/Kleinschreibung des Namens behalten
    if sub == "speichern" then profSave(nm ~= "" and nm or (UnitClass("player")), DB.profilMitTasten ~= false)
    elseif sub == "laden" then profLoad(nm)
    elseif sub == "loeschen" or sub == "löschen" then profDelete(nm)
    else local n = profNames(); msg("Profile: " .. (#n > 0 and table.concat(n, ", ") or "noch keine") .. " · /th profil speichern|laden|löschen Name") end
  elseif cmd == "procton" or cmd == "proc" then
    if arg == "aus" or arg == "an" or cmd == "proc" then
      if arg == "aus" then DB.nachtTon = false elseif arg == "an" then DB.nachtTon = true else DB.nachtTon = not (DB.nachtTon ~= false) end
      msg("Ton beim Sofort-Schattenblitz " .. ((DB.nachtTon ~= false) and "an" or "aus") .. ".")
    else
      DB.nachtKlang = (DB.nachtKlang or 5) % #KLAENGE + 1
      msg("Proc-Ton: " .. klang(DB.nachtKlang, 2, .35) .. " (zur Probe abgespielt)")
    end
  elseif cmd == "zauberleiste" or cmd == "castbar" then
    if arg == "test" or arg == "probe" then
      if not DB.castbar then DB.castbar = true end
      cbTest(); msg("Probe-Zauber läuft (2,5 Sekunden).")
    else
      DB.castbar = not DB.castbar
      if not DB.castbar then cb.mode = nil; cb:Hide(); local bf = blizzBar(); if bf and UnitCastingInfo and safe(UnitCastingInfo, "player") then pcall(bf.Show, bf) end end
      cbBlizz(); msg("Eigene Zauberleiste " .. (DB.castbar and "an" or "aus") .. ".")
    end
  elseif cmd == "sperren" or cmd == "lock" or cmd == "entsperren" or cmd == "unlock" or cmd == "los" then
    if cmd == "sperren" or cmd == "lock" then DB.gesperrt = true elseif cmd == "entsperren" or cmd == "unlock" then DB.gesperrt = false else DB.gesperrt = not DB.gesperrt end
    if DB.gesperrt then placing = false end
    applyLayout()
    msg(DB.gesperrt and "|cff55dd55Gesperrt:|r Symbole bleiben, wo sie sind. Zum Verschieben: /th entsperren" or "|cffffd100Entsperrt:|r Gelber Rahmen = verschiebbar, Mausrad ändert die Größe. Fertig: /th sperren")
  elseif cmd == "neu" or cmd == "neuigkeiten" or cmd == "changelog" then local a = rawget(_G, "SiikkNeuAPI"); if a and a["siikk-Oberfläche"] then a["siikk-Oberfläche"]() end
  elseif cmd == "addons" or cmd == "module" then if NS.addonZentrale then NS.addonZentrale() end
  elseif cmd == "verkaufen" or cmd == "muell" or cmd == "müll" then if NS.muellVerkaufen then NS.muellVerkaufen() end
  elseif cmd == "reset" then DB.pos = {}; DB.scale = {}; standardLayout(true); if NS.questStandard then pcall(NS.questStandard) end; if NS.meterStandard then pcall(NS.meterStandard) end; applyLayout(); msg("Positionen und Größen auf die Standard-Anordnung zurückgesetzt.")
  else
    msg("/th – Einstellungsfenster öffnen (auch über den Minimap-Knopf)")
    msg("/th minimap – Minimap-Knopf ein-/ausblenden")
    msg("Weitere Befehle:")
    msg("/th export – Inventar-Export für den Guide")
    msg("/th schwelle 5 – ab wann die Splitter rot werden")
    msg("/th splitter – Splitter-Anzeige an/aus")
    msg("/th stein – Seelenstein-Anzeige an/aus (Rechtsklick benutzt oder stellt her)")
    msg("/th dots – alle DoT-Symbole an/aus")
    msg("/th dot feuerbrand – einzelnes DoT-Symbol an/aus")
    msg("/th verschieben – alle Symbole zum Platzieren zeigen")
    msg("/th groesse 150 – alle Symbole auf 150 % setzen (Mausrad: einzeln, zeigt die % an)")
    msg("/th sperren – alle Symbole festmachen")
    msg("/th entsperren – Symbole wieder verschiebbar machen (gelber Rahmen)")
    msg("/th reset – Fenster zurück an den Startplatz")
    msg("/th verkaufen – beim Händler alles mit Münzsymbol verkaufen (oder Knopf „Schnellverkaufen“)")
    msg("/ah – siikk-Auktionshaus (eigenes Addon im Komplettpaket siikk-UI): Preise, Verkaufen, Kaufen, Übersicht")
    msg("/sz – siikk-Schadenszahlen (eigenes Addon im Komplettpaket siikk-UI): Schrift, Farben und Krits der Schadenszahlen")
    msg("/il – siikk-Infoleiste (eigenes Addon im Komplettpaket siikk-UI): Leiste mit Ort, Gold, Haltbarkeit, Erfahrung, FPS und Uhr")
    msg("/sammler – siikk-Minimapsammler (eigenes Addon im Komplettpaket siikk-UI): alle Minimap-Knöpfe in einem Klappmenü")
    msg("/layer – siikk-Layer (eigenes Addon, Anniversary und Forever): zeigt, auf welchem Layer du bist")
    msg("/th addons – alle siikk-Addons verwalten: Info, Neu, an/aus und Minimap-Knöpfe")
    msg("/th neu – was sich im letzten Update geändert hat")
    msg("/th zauberleiste – eigene Zauberleiste an/aus · /th zauberleiste test – Probe-Zauber")
    msg("/th proc – Ton beim Sofort-Schattenblitz an/aus · /th procton – anderen Proc-Ton wählen (Probe)")
    msg("/th aggro – Aggro-Warnung an/aus · /th aggro 80 – ab wie viel % warnen")
    msg("/th ton – Ton bei Erinnerungen an/aus")
    msg("/th klang – anderen Hinweiston wählen (spielt ihn zur Probe)")
    msg("/th diag – Prüfbericht, falls etwas nicht angezeigt wird")
  end
end

---------------------------------------------------------------------------
-- 4) Minimap-Knopf und Einstellungsfenster
---------------------------------------------------------------------------
local function rescale(frame, key, sc)
  if frame:IsProtected() and InCombatLockdown() then return end
  local old = frame:GetScale()
  local x, y = frame:GetCenter()
  DB.scale[key] = sc
  frame:SetScale(sc)
  if x and y then
    frame:ClearAllPoints()
    frame:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x * old / sc, y * old / sc)
    DB.pos[key] = { "CENTER", "BOTTOMLEFT", x * old / sc, y * old / sc }
  end
end
local function scaleAll(sc)
  rescale(shard, "splitter", sc); rescale(stone, "stein", sc)
  for _, b in ipairs(dotIcons) do rescale(b, "dot_" .. b.d.key, sc) end
  for _, e in ipairs(extraFrames) do rescale(e.frame, e.key, sc) end
end

-- Ziehgriff unten rechts: Fenster größer/kleiner (Strg + Mausrad geht auch)
local function addScaleGrip(win, key, baseW)
  local function setSc(sc)
    sc = math.max(.6, math.min(1.6, math.floor(sc * 20 + .5) / 20))
    local l, t, old = win:GetLeft(), win:GetTop(), win:GetScale()
    win:SetScale(sc)
    if l and t then win:ClearAllPoints(); win:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", l * old / sc, t * old / sc) end
    if DB then DB.fenster = DB.fenster or {}; DB.fenster[key] = sc end
    showScale(win, sc)
  end
  local g = CreateFrame("Button", nil, win)
  g:SetSize(18, 18); g:SetPoint("BOTTOMRIGHT", -5, 5); g:SetFrameLevel(win:GetFrameLevel() + 10)
  g:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
  g:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
  g:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
  g:SetScript("OnMouseDown", function(s)
    s.x0, s.sc0 = GetCursorPosition(), win:GetScale()
    s:SetScript("OnUpdate", function()
      local x = GetCursorPosition()
      setSc(s.sc0 + (x - s.x0) / ((UIParent:GetEffectiveScale() or 1) * (baseW or 700)))
    end)
  end)
  g:SetScript("OnMouseUp", function(s) s:SetScript("OnUpdate", nil) end)
  g:SetScript("OnEnter", function(s) GameTooltip:SetOwner(s, "ANCHOR_RIGHT"); GameTooltip:AddLine("Ziehen: Fenster größer/kleiner"); GameTooltip:AddLine("oder Strg + Mausrad", .8, .8, .8); GameTooltip:Show() end)
  g:SetScript("OnLeave", function() GameTooltip:Hide() end)
  win:EnableMouseWheel(true)
  win:SetScript("OnMouseWheel", function(_, d) if IsControlKeyDown and IsControlKeyDown() then setSc(win:GetScale() + d * .05) end end)
  win.applySavedScale = function() if DB and DB.fenster and DB.fenster[key] then win:SetScale(DB.fenster[key]) end end
  win:HookScript("OnShow", win.applySavedScale)
end

local panel = CreateFrame("Frame", "TobsiikkHelferMenue", UIParent, "BasicFrameTemplateWithInset")
panel:SetSize(560, 650); panel:SetPoint("CENTER"); panel:SetFrameStrata("DIALOG"); panel:Hide()
panel:SetMovable(true); panel:EnableMouse(true); panel:RegisterForDrag("LeftButton"); panel:SetClampedToScreen(true)
panel:SetScript("OnDragStart", panel.StartMoving); panel:SetScript("OnDragStop", panel.StopMovingOrSizing)
tinsert(UISpecialFrames, "TobsiikkHelferMenue")
panel.title = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
panel.title:SetPoint("TOP", 0, -5); panel.title:SetText("siikk-Oberfläche · Einstellungen")

addScaleGrip(panel, "menue", 560)
local checks, sliders, refresh, head2, klangBtn, procBtn = {}, {}, nil, nil, nil, nil
-- Reiter-Seiten im Hauptfenster (1 Hexer, 2 Helfer, 3 Bedienung); alle Bausteine landen auf der gerade gewählten Seite
local pages = {}
for i = 1, 3 do local pg = CreateFrame("Frame", nil, panel); pg:SetAllPoints(); pg:Hide(); pages[i] = pg end
local cur = pages[1]
local function head(text, y, x)
  local h = cur:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  h:SetPoint("TOPLEFT", panel, "TOPLEFT", x or 18, y); h:SetText(text)
  return h
end
local function mkCheck(x, y, text, get, set)
  local cb = CreateFrame("CheckButton", nil, cur, "UICheckButtonTemplate")
  cb:SetSize(26, 26); cb:SetPoint("TOPLEFT", panel, "TOPLEFT", x, y)
  for _, k in ipairs({ "text", "Text" }) do local t = rawget(cb, k); if type(t) == "table" and t.SetText then t:SetText("") end end
  local fs = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  fs:SetPoint("LEFT", cb, "RIGHT", 2, 1); fs:SetText(text)
  cb:SetScript("OnClick", function(s) set(s:GetChecked() and true or false); refresh() end)
  cb.get = get
  table.insert(checks, cb)
  return cb
end
local function mkSlider(x, y, w, minv, maxv, step, label, get, set, fmt)
  local t = cur:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  t:SetPoint("TOPLEFT", panel, "TOPLEFT", x, y)
  local s = CreateFrame("Slider", nil, cur)
  s:SetOrientation("HORIZONTAL"); s:SetSize(w, 18); s:SetPoint("TOPLEFT", panel, "TOPLEFT", x, y - 18)
  local bg = s:CreateTexture(nil, "BACKGROUND"); bg:SetColorTexture(0, 0, 0, .7)
  bg:SetPoint("LEFT"); bg:SetPoint("RIGHT"); bg:SetHeight(6)
  s:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
  s:SetMinMaxValues(minv, maxv); s:SetValueStep(step)
  if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
  s:EnableMouse(true)
  local lo = s:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); lo:SetPoint("TOPLEFT", s, "BOTTOMLEFT", 0, -1); lo:SetText(fmt(minv))
  local hi = s:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); hi:SetPoint("TOPRIGHT", s, "BOTTOMRIGHT", 0, -1); hi:SetText(fmt(maxv))
  s:SetScript("OnValueChanged", function(self, v)
    v = math.floor(v / step + .5) * step
    t:SetText(label .. ": |cffffd100" .. fmt(v) .. "|r")
    if not self.quiet then set(v) end
  end)
  s.get, s.title, s.label, s.fmt = get, t, label, fmt
  table.insert(sliders, s)
  return s
end
local function mkButton(x, y, w, text, fn)
  local b = CreateFrame("Button", nil, cur, "UIPanelButtonTemplate")
  b:SetSize(w, 24); b:SetPoint("TOPLEFT", panel, "TOPLEFT", x, y); b:SetText(text)
  b:SetScript("OnClick", function() fn(); if refresh then refresh() end end)
  return b
end

-- Inhalt · Reiter 1: Hexer
cur = pages[1]
head("Anzeigen", -40)
mkCheck(16, -62, "Seelensplitter-Anzeige", function() return DB.splitter end, function(v) DB.splitter = v; updateShard() end)
mkCheck(16, -86, "Seelenstein-Anzeige", function() return DB.seelenstein end, function(v) DB.seelenstein = v; updateStone() end)
mkCheck(16, -110, "DoT-Symbole", function() return DB.dots end, function(v) DB.dots = v end)
mkCheck(280, -62, "Gesundheitsstein-Symbol", function() return DB.gesundheitsstein end, function(v) DB.gesundheitsstein = v; updateShard() end)
head("Einzelne DoTs", -146)
for i, d in ipairs(DOTS) do
  local col, row = (i - 1) % 2, math.floor((i - 1) / 2)
  mkCheck(16 + col * 264, -168 - row * 24, d.name, function() return not DB.dotAus[d.key] end, function(v) DB.dotAus[d.key] = (not v) or nil end)
end
head("Größe und Warnung", -248)
mkSlider(22, -272, 510, 1, 20, 1, "Splitter werden rot unter", function() return DB.schwelle end,
  function(v) DB.schwelle = v; updateShard() end, function(v) return tostring(math.floor(v)) end)
mkSlider(22, -326, 510, 10, 40, 1, "Splitter: genug ab", function() return DB.splitterMax or 25 end,
  function(v) DB.splitterMax = v; updateShard() end, function(v) return tostring(math.floor(v)) end)
local sizeSlider = mkSlider(22, -380, 510, .5, 3, .1, "Größe aller Symbole", function() return DB.scale.splitter or 1 end,
  function(v) scaleAll(v) end, function(v) return pct(v) end)
do
local tipTxt = pages[1]:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
tipTxt:SetPoint("TOPLEFT", panel, "TOPLEFT", 22, -436); tipTxt:SetWidth(510); tipTxt:SetJustifyH("LEFT")
tipTxt:SetText("Gesundheitsstein: Rechtsklick benutzt, Umschalt + Linksklick sagt in der Gruppe an. Verschieben: lila Knopf „Platzieren starten“ oben rechts.")
end

-- Reiter 2: Helfer
cur = pages[2]
head("Hinweise & Töne", -40)
NS.hexerOnly = {} -- nur beim Hexenmeister sichtbar
NS.helferMove = {} -- rückt bei anderen Klassen nach oben (keine Lücken)
NS.hm = function(o) table.insert(NS.helferMove, o); return o end
table.insert(NS.hexerOnly, mkCheck(16, -62, "Beschwörung in der Gruppe ansagen", function() return DB.beschwoeren end, function(v) DB.beschwoeren = v end))
table.insert(NS.hexerOnly, mkCheck(16, -86, "Einbruch-der-Nacht-Alarm", function() return DB.nacht end, function(v) DB.nacht = v end))
table.insert(NS.hexerOnly, mkCheck(16, -110, "Furcht- und Verbannen-Timer", function() return DB.cc end, function(v) DB.cc = v end))
table.insert(NS.hexerOnly, mkCheck(16, -134, "Seelendieb-Hinweis (Ziel unter 25 %)", function() return DB.seelendieb end, function(v) DB.seelendieb = v end))
table.insert(NS.hexerOnly, mkCheck(16, -158, "Erinnerung: Rüstung und Dämon", function() return DB.erinnerung end, function(v) DB.erinnerung = v end))
NS.hm(mkCheck(16, -182, "Berufs-Infos im Gegenstands-Tooltip", function() return DB.tooltip end, function(v) DB.tooltip = v end))
NS.hm(mkCheck(16, -206, "Ton bei neuen Erinnerungen", function() return DB.erinnerungTon end, function(v) DB.erinnerungTon = v end))
klangBtn = NS.hm(mkButton(18, -236, 340, "", function()
  DB.erinnerungKlang = (DB.erinnerungKlang or 1) % #KLAENGE + 1
  klang(DB.erinnerungKlang)
end))
NS.hm(head("Aggro", -276))
NS.hm(mkCheck(16, -298, "Aggro-Warnung (nur in der Gruppe)", function() return DB.aggro end, function(v) DB.aggro = v end))
NS.hm(mkCheck(280, -298, "Ton bei Aggro-Warnung", function() return DB.aggroTon end, function(v) DB.aggroTon = v end))
NS.hm(NS.hm(mkSlider(22, -330, 510, 60, 100, 5, "Warnen ab Bedrohung", function() return DB.aggroSchwelle or 85 end,
  function(v) DB.aggroSchwelle = v end, function(v) return math.floor(v) .. " %" end)).title)
table.insert(NS.hexerOnly, head("Sofort-Schattenblitz", -386))
table.insert(NS.hexerOnly, mkCheck(16, -408, "Ton beim Sofort-Schattenblitz", function() return DB.nachtTon ~= false end, function(v) DB.nachtTon = v end))
procBtn = mkButton(18, -438, 340, "", function()
  DB.nachtKlang = (DB.nachtKlang or 5) % #KLAENGE + 1
  klang(DB.nachtKlang, 2, .35)
end)
table.insert(NS.hexerOnly, procBtn)

-- Reiter 3: Bedienung & Zauberleiste
cur = pages[3]
head("Bedienung & Platzieren", -40)
mkCheck(16, -62, "Symbole sperren (nicht verschiebbar)", function() return DB.gesperrt end,
  function(v) SlashCmdList.TOBSIIKKHELFER(v and "sperren" or "entsperren") end)
mkCheck(16, -86, "Minimap-Knopf anzeigen", function() return not DB.minimapAus end,
  function(v) DB.minimapAus = not v; if TobsiikkHelferMinimap then if v then TobsiikkHelferMinimap:Show() else TobsiikkHelferMinimap:Hide() end end end)
mkCheck(280, -62, "Questpfeil (führt dich zur Quest)", function() local c = DB.questPfeil; return not (type(c) == "table" and c.an == false) end,
  function(v) SlashCmdList.TOBSIIKKHELFER(v and "pfeil an" or "pfeil aus") end)
mkCheck(280, -86, "siikk-Questhilfe statt siikkUI-Questanzeige", function() return SiikkUIQuestFensterModus and SiikkUIQuestFensterModus() == "hilfe" end,
  function(v) if SiikkUIQuestFenster then SiikkUIQuestFenster(v and "hilfe" or "standard") end end)
local placeBtn = mkButton(18, -120, 250, "Platzier-Modus", function() SlashCmdList.TOBSIIKKHELFER("verschieben") end)
mkButton(282, -120, 250, "Plätze zurücksetzen", function() SlashCmdList.TOBSIIKKHELFER("reset") end)
mkButton(18, -150, 250, "Inventar-Export", function() panel:Hide(); showExport() end)
mkButton(282, -150, 250, "Prüfbericht (Chat)", function() SlashCmdList.TOBSIIKKHELFER("diag") end)
head("Zauberleiste & Logo", -196)
mkCheck(16, -218, "Eigene Zauberleiste (leuchtend, mit Fraktions-Zeichen)", function() return DB.castbar end,
  function(v) if (v and true or false) ~= (DB.castbar and true or false) then SlashCmdList.TOBSIIKKHELFER("zauberleiste") end end)
mkCheck(16, -242, "Normale Blizzard-Zauberleiste ausblenden", function() return DB.castbarBlizzAus end,
  function(v) DB.castbarBlizzAus = v; cbBlizz(); if not v then msg("Die Blizzard-Leiste erscheint ab dem nächsten Zauber wieder.") end end)
mkButton(18, -274, 250, "Probe-Zauber", function() SlashCmdList.TOBSIIKKHELFER("zauberleiste test") end)
cb.farbBtn = mkButton(18, -304, 250, "", function()
  local cur2, nxt = DB.cbFarbe or "rot", "rot"
  for i, k in ipairs(cb.FARBFOLGE) do if k == cur2 then nxt = cb.FARBFOLGE[i % #cb.FARBFOLGE + 1] end end
  DB.cbFarbe = nxt; cb.applyStyle(); SlashCmdList.TOBSIIKKHELFER("zauberleiste test")
end)
cb.lebenBtn = mkButton(18, -334, 514, "", function()
  DB.lebenZeichen = (DB.lebenZeichen == "aus") and "an" or "aus"; if NS.applyLebenZeichen then NS.applyLebenZeichen() end
end)
cb.zeichenBtn = mkButton(282, -304, 250, "", function()
  DB.zeichen = (NS.zeichenArt() == "allianz") and "horde" or "allianz"; NS.applyZeichen(); SlashCmdList.TOBSIIKKHELFER("zauberleiste test")
end)
head("Befehle", -386)
do
local cmdTxt = pages[3]:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
cmdTxt:SetPoint("TOPLEFT", panel, "TOPLEFT", 22, -410); cmdTxt:SetWidth(510); cmdTxt:SetJustifyH("LEFT")
cmdTxt:SetText("|cffffd100/th|r Einstellungen · |cffffd100/kb|r Tastenbelegung per Maus · |cffffd100/meter|r Schadensmesser · |cffffd100/th hilfe|r alle Befehle")
end

do -- Profile-Bereich (eigener Block, damit die Datei unter Luas 200-Variablen-Grenze bleibt)
head("Profile (für Twinks)", -444)
local profBox = CreateFrame("EditBox", "TobsiikkHelferProfilName", pages[3], "InputBoxTemplate")
profBox:SetSize(162, 20); profBox:SetPoint("TOPLEFT", panel, "TOPLEFT", 26, -474); profBox:SetAutoFocus(false)
profBox:SetScript("OnEscapePressed", function(s) s:ClearFocus() end); profBox:SetScript("OnEnterPressed", function(s) s:ClearFocus() end)
-- Auswahl-Liste (Drop-down) mit allen gespeicherten Profilen
local GOLDC = NS.GOLD
local dropBtn = CreateFrame("Button", nil, pages[3], "BackdropTemplate"); dropBtn:SetSize(24, 22); dropBtn:SetPoint("LEFT", profBox, "RIGHT", 2, 0)
if dropBtn.SetBackdrop then dropBtn:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 }); dropBtn:SetBackdropColor(0, 0, 0, .8); dropBtn:SetBackdropBorderColor(GOLDC[1], GOLDC[2], GOLDC[3], 1) end
dropBtn.t = dropBtn:CreateTexture(nil, "ARTWORK"); dropBtn.t:SetSize(16, 16); dropBtn.t:SetPoint("CENTER"); dropBtn.t:SetTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Up")
local dropList = CreateFrame("Frame", "TobsiikkHelferProfilListe", pages[3], "BackdropTemplate")
dropList:SetPoint("TOPLEFT", profBox, "BOTTOMLEFT", -6, -2); dropList:SetWidth(330); dropList:SetFrameStrata("FULLSCREEN_DIALOG"); dropList:Hide()
if dropList.SetBackdrop then dropList:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } }); dropList:SetBackdropColor(0, 0, 0, .95); dropList:SetBackdropBorderColor(GOLDC[1], GOLDC[2], GOLDC[3], 1) end
local dropRows, dropOff, DROP_MAX = {}, 0, 10
local function fillDrop()
  local names = profNames()
  dropOff = math.max(0, math.min(dropOff, #names - DROP_MAX))
  local shown = math.min(DROP_MAX, math.max(1, #names))
  for i = 1, math.max(#dropRows, shown) do
    local r = dropRows[i]
    if not r and i <= shown then
      r = CreateFrame("Button", nil, dropList); r:SetHeight(20)
      r:SetPoint("TOPLEFT", 6, -6 - (i - 1) * 20); r:SetPoint("RIGHT", -6, 0)
      r.hl = r:CreateTexture(nil, "HIGHLIGHT"); r.hl:SetAllPoints(); r.hl:SetColorTexture(.62, .22, .95, .35)
      r.n = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); r.n:SetPoint("LEFT", 4, 0)
      r.d = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); r.d:SetPoint("RIGHT", -4, 0)
      r:SetScript("OnClick", function(x) if x.name then profBox:SetText(x.name); dropList:Hide() end end)
      dropRows[i] = r
    end
    if r then
      local nm = names[i + dropOff]
      if i <= shown and nm then
        local p = profStore()[nm] or {}
        local cls = p.klasse and LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[p.klasse]
        local c = p.klasse and RAID_CLASS_COLORS and RAID_CLASS_COLORS[p.klasse]
        r.name = nm; r.n:SetText(nm .. ((DB and DB.profilName == nm) and "  |cff55ff55(aktiv)|r" or ""))
        if c then r.n:SetTextColor(c.r, c.g, c.b) else r.n:SetTextColor(1, 1, 1) end
        r.d:SetText((cls or p.klasse or "") .. (p.tasten and " · Tasten" or "") .. (p.zeit and p.zeit ~= "" and (" · " .. p.zeit) or ""))
        r:Show()
      elseif i <= shown then
        r.name = nil; r.n:SetText("|cff999999Noch keine Profile gespeichert|r"); r.n:SetTextColor(1, 1, 1); r.d:SetText(""); r:Show()
      else r:Hide() end
    end
  end
  dropList:SetHeight(12 + shown * 20)
end
dropList:EnableMouseWheel(true)
dropList:SetScript("OnMouseWheel", function(_, d) dropOff = dropOff - d; fillDrop() end)
dropBtn:SetScript("OnClick", function() if dropList:IsShown() then dropList:Hide() else dropOff = 0; fillDrop(); dropList:Show() end end)
dropBtn:SetScript("OnEnter", function(x) GameTooltip:SetOwner(x, "ANCHOR_RIGHT"); GameTooltip:AddLine("Gespeicherte Profile anzeigen"); GameTooltip:Show() end)
dropBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
pages[3]:HookScript("OnHide", function() dropList:Hide() end)
NS.profDropBtn = dropBtn
local profBinds = mkCheck(230, -471, "mit Tastenbelegung", function() return DB.profilMitTasten ~= false end, function(v) DB.profilMitTasten = v end)
mkButton(18, -502, 168, "Speichern", function() profSave(profBox:GetText(), DB.profilMitTasten ~= false) end)
mkButton(192, -502, 168, "Laden", function() profLoad(profBox:GetText()) end)
mkButton(366, -502, 168, "Löschen", function() profDelete(profBox:GetText()) end)
mkButton(18, -590, 514, "siikk-Addons verwalten (an/aus · Minimap-Knöpfe)", function() if NS.addonZentrale then panel:Hide(); NS.addonZentrale() end end)
local profList = pages[3]:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
profList:SetPoint("TOPLEFT", panel, "TOPLEFT", 22, -534); profList:SetWidth(510); profList:SetJustifyH("LEFT")
NS.profRefresh = function()
  local n = profNames()
  profList:SetText("Vorhanden: " .. (#n > 0 and ("|cffffd100" .. table.concat(n, "|r, |cffffd100") .. "|r") or "|cff999999noch keine|r") ..
    "\nAktiv bei diesem Charakter: |cffffffff" .. ((DB and DB.profilName) or "eigene Einstellungen") .. "|r  ·  Tipp: Heißt ein Profil wie eine Klasse (z. B. „Magier“), bekommt ein neuer Charakter dieser Klasse es automatisch.")
  if profBox:GetText() == "" then profBox:SetText((DB and DB.profilName) or (UnitClass("player")) or "") end
end
end
cur = pages[1]

---------------------------------------------------------------------------
-- Reiterleiste unter dem Fenster – wandert mit zu „Rahmen & Chat“ und „Leisten & Taschen“
---------------------------------------------------------------------------
local TABS = { "Hexer", "Hinweise", "Allgemein", "Rahmen & Chat", "Leisten", "Cooldowns", "Positionen" }
local strip = CreateFrame("Frame", "TobsiikkHelferReiter", panel); strip:SetSize(560, 28)
local tabBtns = {}
local activeWin, activeTab = panel, 1
local function tabWin(i)
  if i == 1 and NS.tab1Win then local w = NS.tab1Win(); if w then return w end end
  if i <= 3 then return panel end
  return rawget(_G, ({ "", "", "", "TobsiikkHelferRahmenMenue", "TobsiikkHelferOberflaecheMenue", "TobsiikkHelferCooldownMenue", "TobsiikkHelferElementeMenue" })[i])
end
local function paintTabs()
  for i, b in ipairs(tabBtns) do
    local on = i == activeTab
    if b.SetBackdropColor then b:SetBackdropColor(on and .32 or .05, on and .12 or .04, on and .45 or .07, .95); b:SetBackdropBorderColor(NS.GOLD[1], NS.GOLD[2], NS.GOLD[3], on and 1 or .6) end
    b.t:SetTextColor(on and 1 or .85, on and .85 or .75, on and .3 or .55)
  end
end
local function attachStrip(win, i)
  activeWin, activeTab = win, i
  strip:SetParent(win); strip:ClearAllPoints(); strip:SetPoint("TOPLEFT", win, "BOTTOMLEFT", 6, 2)
  strip:SetFrameLevel((win:GetFrameLevel() or 1) + 5); strip:Show(); paintTabs()
  if NS.onTabWin then pcall(NS.onTabWin, win, i) end
end
local function showPage(i) for k, pg in ipairs(pages) do if k == i then pg:Show() else pg:Hide() end end end
NS.showTab = function(i)
  local target = tabWin(i); if type(target) ~= "table" then return end
  local from = activeWin
  if from and from ~= target and from:IsShown() then
    local l, t = from:GetLeft(), from:GetTop()
    local fs, ts = from:GetEffectiveScale() or 1, target:GetEffectiveScale() or 1
    if l and t and ts > 0 then
      local x, y = l * fs / ts, t * fs / ts
      local nm = target:GetName()
      if DB and nm then DB.fensterPos = DB.fensterPos or {}; DB.fensterPos[nm] = { "TOPLEFT", "BOTTOMLEFT", x, y } end
      target:ClearAllPoints(); target:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", x, y)
    end
    from:Hide()
  end
  if target == panel then showPage(i) end
  if i <= 3 and DB then DB.reiter = i end
  target:Show()
  attachStrip(target, i)
end
for i, name in ipairs(TABS) do
  local b = CreateFrame("Button", nil, strip, "BackdropTemplate"); b:SetSize(({ 76, 76, 80, 110, 66, 86, 86 })[i] or 84, 26)
  if i == 1 then b:SetPoint("LEFT", 0, 0) else b:SetPoint("LEFT", tabBtns[i - 1], "RIGHT", 3, 0) end
  if b.SetBackdrop then b:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 }) end
  b.t = b:CreateFontString(nil, "OVERLAY", "GameFontNormal"); b.t:SetPoint("CENTER"); b.t:SetText(name)
  b:SetScript("OnClick", function() NS.showTab(i) end)
  tabBtns[i] = b
end
-- andere Fenster melden sich an, damit die Reiter auch dort unten hängen
NS.attachTabs = function(win, i) if win and win.HookScript then win:HookScript("OnShow", function(w) attachStrip(w, type(i) == "function" and i() or i) end) end end
NS.tabBtns = tabBtns
showPage(1)

local foot = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
foot:SetPoint("BOTTOM", 0, 10); foot:SetText("Version 14.9 · Mausrad über einem Symbol ändert nur dieses")

refresh = function()
  if not DB then return end
  for _, cb in ipairs(checks) do cb:SetChecked(cb.get() and true or false) end
  for _, s in ipairs(sliders) do s.quiet = true; s:SetValue(s.get()); s.quiet = false end
  placeBtn:SetText(placing and "Platzieren beenden" or "Platzier-Modus")
  if procBtn then procBtn:SetText("Proc-Ton: " .. ((KLAENGE[DB.nachtKlang or 5] or KLAENGE[5]).name) .. "  (klicken = wechseln)") end
  if cb.farbBtn then local fb = cb.FARBEN[DB.cbFarbe or "rot"] or cb.FARBEN.rot; cb.farbBtn:SetText(("Leistenfarbe: |cff%02x%02x%02x%s|r  (klicken)"):format(math.floor(fb[2] * 255), math.floor(fb[3] * 255), math.floor(fb[4] * 255), fb[1])) end
  if cb.lebenBtn then cb.lebenBtn:SetText("Logo auch in den Lebensleisten (du + Ziel): " .. ((DB.lebenZeichen == "aus") and "|cffff5555aus|r" or "|cff55ff55an|r") .. "  (klicken)") end
  if cb.zeichenBtn then cb.zeichenBtn:SetText("Logo überall: " .. (NS.zeichenArt() == "allianz" and "|cff4f9bffAllianz|r" or "|cffff3333Horde|r") .. "  (klicken)") end
  if klangBtn then klangBtn:SetText("Hinweiston: " .. ((KLAENGE[DB.erinnerungKlang or 1] or KLAENGE[1]).name) .. "  (klicken = wechseln)") end
end
panel:SetScript("OnShow", function() panel.applySavedScale(); refresh(); if NS.profRefresh then NS.profRefresh() end end)
panel:HookScript("OnShow", function() local i = (DB and DB.reiter) or 1; if i > 3 then i = 1 end
  if i == 1 and NS.tab1Win and NS.tab1Win() then activeWin = panel; NS.showTab(1) return end -- andere Klassen: Reiter 1 ist das Klassen-Fenster
  showPage(i); attachStrip(panel, i) end)
local function togglePanel() if panel:IsShown() then panel:Hide() else panel:Show() end end

-- Minimap-Knopf
local mm = CreateFrame("Button", "TobsiikkHelferMinimap", Minimap)
mm:SetSize(31, 31); mm:SetFrameStrata("MEDIUM"); mm:SetFrameLevel(8)
mm:RegisterForClicks("LeftButtonUp", "RightButtonUp"); mm:RegisterForDrag("LeftButton")
mm:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
local mmBg = mm:CreateTexture(nil, "BACKGROUND"); mmBg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
mmBg:SetSize(20, 20); mmBg:SetPoint("TOPLEFT", 7, -5)
local mmIcon = mm:CreateTexture(nil, "ARTWORK")
-- eigenes Symbol: Fraktions-Wappen (Horde/Allianz)
mmIcon:SetTexture("Interface\\AddOns\\siikkUI\\Media\\" .. ((UnitFactionGroup("player") == "Alliance") and "allianz_hd" or "horde_rot_hd"))
mmIcon:SetSize(21, 21); mmIcon:SetPoint("TOPLEFT", 5, -5)
local mmBorder = mm:CreateTexture(nil, "OVERLAY"); mmBorder:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
mmBorder:SetSize(53, 53); mmBorder:SetPoint("TOPLEFT")
local function mmPlace()
  local a = math.rad(DB and DB.minimapWinkel or 220)
  local r = ((Minimap:GetWidth() or 140) / 2) + 5
  local c, s = math.cos(a), math.sin(a)
  if NS.minimapSquare and NS.minimapSquare() then -- eckige Minimap: am Rand des Quadrats entlang
    local m = math.max(math.abs(c), math.abs(s)); if m > 0 then c, s = c / m, s / m end
    r = ((Minimap:GetWidth() or 140) / 2) + 2
  end
  mm:ClearAllPoints(); mm:SetPoint("CENTER", Minimap, "CENTER", c * r, s * r)
end
mm:SetScript("OnDragStart", function(s)
  s:SetScript("OnUpdate", function()
    local mx, my = Minimap:GetCenter()
    local cx, cy = GetCursorPosition()
    local sc = Minimap:GetEffectiveScale()
    DB.minimapWinkel = math.deg(math.atan2(cy / sc - my, cx / sc - mx))
    mmPlace()
  end)
end)
mm:SetScript("OnDragStop", function(s) s:SetScript("OnUpdate", nil) end)
mm:SetScript("OnClick", function(_, btn)
  if btn == "RightButton" then SlashCmdList.TOBSIIKKHELFER(DB.gesperrt and "entsperren" or "sperren"); if panel:IsShown() then refresh() end
  elseif IsShiftKeyDown() and NS.addonZentrale then NS.addonZentrale()
  else togglePanel() end
end)
mm:SetScript("OnEnter", function(s)
  GameTooltip:SetOwner(s, "ANCHOR_LEFT")
  GameTooltip:AddLine("|cffe03030siikk|r-|cffffd100Oberfläche|r")
  GameTooltip:AddLine("Linksklick: Einstellungen", 1, 1, 1)
  GameTooltip:AddLine("Rechtsklick: " .. (DB.gesperrt and "Symbole entsperren" or "Symbole sperren"), 1, 1, 1)
  GameTooltip:AddLine("Shift+Linksklick: alle siikk-Addons verwalten", 1, 1, 1)
  GameTooltip:AddLine("Ziehen: Knopf um die Minimap verschieben", .7, .7, .7)
  GameTooltip:Show()
end)
mm:SetScript("OnLeave", function() GameTooltip:Hide() end)

local login = CreateFrame("Frame")
login:RegisterEvent("PLAYER_LOGIN")
login:SetScript("OnEvent", function()
  if not DB then return end
  mmPlace()
  if DB.minimapAus then mm:Hide() else mm:Show() end
  local ap = NS.autoProfil
  if ap then
    if ap.tasten then applyBindings(ap.tasten) end
    msg("Neuer Charakter: Profil |cffffd100" .. ap.name .. "|r automatisch übernommen" .. (ap.tasten and " (mit Tastenbelegung)." or "."))
    NS.autoProfil = nil
  end
end)

-- Befehle ergänzen
local baseSlash = SlashCmdList.TOBSIIKKHELFER
SlashCmdList.TOBSIIKKHELFER = function(input)
  local c = (input or ""):lower():match("^(%S*)")
  if c == "" or c == "menu" or c == "menü" or c == "optionen" or c == "einstellungen" then togglePanel()
  elseif c == "minimap" then DB.minimapAus = not DB.minimapAus; if DB.minimapAus then mm:Hide() else mm:Show(); mmPlace() end
    msg("Minimap-Knopf " .. (DB.minimapAus and "ausgeblendet." or "angezeigt."))
  else baseSlash(input) end
  if panel:IsShown() then refresh() end
end

-- Für TobsiikkHelfer_Rahmen.lua (Spieler-, Ziel-, Gruppen-, Raidrahmen und Chat)
NS.msg, NS.pct, NS.showScale, NS.safe, NS.isSecret = msg, pct, showScale, safe, isSecret
NS.makeScalable, NS.savePos, NS.extraFrames, NS.addScaleGrip = makeScalable, savePos, extraFrames, addScaleGrip
NS.applyLayout = function() applyLayout() end
NS.isPlacing = function() return placing end
NS.mainPanel = panel
NS.mmPlace = function() if DB then mmPlace() end end
