-- siikk-Oberfläche · Zentrale für alle siikk-Addons
-- Zeigt, welche siikk-Addons installiert sind, schaltet sie an/aus (nach Neuladen) und blendet ihre Minimap-Knöpfe ein/aus.
local ADDON, NS = ...
local GOLD = NS.GOLD or { .85, .65, .15 }
local function msg(t) if NS.msg then NS.msg(t) else print(t) end end

local LISTE = {
  { ordner = "siikkUI", name = "siikk-Oberfläche", text = "Rahmen, Leisten, Taschen, Fenster-Design, Klassen-Helfer", mm = "siikk-Oberfläche",
    icon = function() return "Interface\\AddOns\\siikkUI\\Media\\" .. ((UnitFactionGroup("player") == "Alliance") and "allianz_hd" or "horde_rot_hd") end },
  { ordner = "siikkUI-Damagemeter", name = "siikk-Damagemeter", text = "Schaden, Heilung und Aggro – bis zu 4 Fenster", mm = "siikk-Damagemeter",
    icon = function() return "Interface\\AddOns\\siikkUI-Damagemeter\\Media\\siikk_dm_icon" end },
  { ordner = "siikk-Questhilfe", name = "siikk-Questhilfe", text = "Quests auf Karte und Minimap, Questpfeil mit Meterzahl", mm = "siikk-Questhilfe", nurClassic = true,
    icon = function() return "Interface\\AddOns\\siikk-Questhilfe\\Icons\\questie" end },
  { ordner = "siikkAH", name = "siikk-Auktionshaus", text = "Preise scannen, schnell verkaufen und kaufen, Gewinn", mm = "siikk-Auktionshaus", nurClassic = true,
    icon = function() return "Interface\\AddOns\\siikkAH\\Media\\siikk_ah_icon" end },
  { ordner = "siikkSZ", name = "siikk-Schadenszahlen", text = "Schönere Schadenszahlen über dem Gegner, goldene Krits", mm = "siikk-Schadenszahlen",
    icon = function() return "Interface\\AddOns\\siikkSZ\\Media\\siikk_sz_icon" end },
  { ordner = "siikkInfo", name = "siikk-Infoleiste", text = "Leiste mit Ort, Gold, Haltbarkeit, Erfahrung, FPS, Uhr", mm = "siikk-Infoleiste",
    icon = function() return "Interface\\AddOns\\siikkInfo\\Media\\siikk_info_icon" end },
  { ordner = "siikkMMS", name = "siikk-Minimapsammler", text = "Alle Minimap-Knöpfe in einem Knopf mit Klappmenü", mm = "siikk-Minimapsammler",
    icon = function() return "Interface\\AddOns\\siikkMMS\\Media\\siikk_mms_icon" end },
  { ordner = "siikkLayer", name = "siikk-Layer", text = "Zeigt, auf welchem Layer du bist – mit Gilden-Abgleich", mm = "siikk-Layer", nurClassic = true,
    icon = function() return "Interface\\AddOns\\siikkLayer\\Media\\siikk_layer_icon" end },
}

-- Addon-Schnittstelle (alt und neu)
local A = C_AddOns or {}
local function vorhanden(o)
  local fn = A.DoesAddOnExist or DoesAddOnExist
  if fn then local ok, r = pcall(fn, o); if ok then return r end end
  local gi = A.GetAddOnInfo or GetAddOnInfo
  local ok, n = pcall(gi, o); return ok and n ~= nil
end
local function aktiv(o)
  local fn = A.GetAddOnEnableState or GetAddOnEnableState
  if not fn then return true end
  local ich = UnitName("player")
  local ok, st = pcall(fn, o, ich)
  if not ok or type(st) ~= "number" then ok, st = pcall(fn, ich, o) end
  return ok and type(st) == "number" and st > 0
end
local function geladen(o) local fn = A.IsAddOnLoaded or IsAddOnLoaded; local ok, r = pcall(fn, o); return ok and r and true or false end
local function setzen(o, an)
  local fn = an and (A.EnableAddOn or EnableAddOn) or (A.DisableAddOn or DisableAddOn)
  if fn then pcall(fn, o) end
  if o == "siikk-Questhilfe" and an then local e = A.EnableAddOn or EnableAddOn; if e then pcall(e, "QuestieDB") end end
end

-- Minimap-Knopf der Oberfläche selbst ebenfalls zentral schaltbar
SiikkMinimapAPI = rawget(_G, "SiikkMinimapAPI") or {}
SiikkMinimapAPI["siikk-Oberfläche"] = {
  get = function() local db = rawget(_G, "TobsiikkHelferDB"); return not (db and db.minimapAus) end,
  set = function(an) local db = rawget(_G, "TobsiikkHelferDB"); if db then db.minimapAus = not an end
    local b = rawget(_G, "TobsiikkHelferMinimap"); if b then b:SetShown(an and true or false) end end,
}

local W = CreateFrame("Frame", "siikkUIAddonZentrale", UIParent, "BackdropTemplate")
W:SetSize(540, 610); W:SetPoint("CENTER", 0, 60); W:SetFrameStrata("DIALOG"); W:Hide()
W:SetMovable(true); W:EnableMouse(true); W:RegisterForDrag("LeftButton"); W:SetClampedToScreen(true)
W:SetScript("OnDragStart", W.StartMoving); W:SetScript("OnDragStop", W.StopMovingOrSizing)
W:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
W:SetBackdropColor(.03, .02, .05, .95); W:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
tinsert(UISpecialFrames, "siikkUIAddonZentrale")
local kopf = W:CreateTexture(nil, "BORDER"); kopf:SetPoint("TOPLEFT", 4, -4); kopf:SetPoint("TOPRIGHT", -4, -4); kopf:SetHeight(26); kopf:SetColorTexture(.315, .19, .45, .8)
local titel = W:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); titel:SetPoint("LEFT", kopf, "LEFT", 10, 0)
titel:SetText("|cffe03030siikk|r-|cffffd100UI|r  |cffccccccalle siikk-Addons|r")
local zu = CreateFrame("Button", nil, W, "UIPanelCloseButton"); zu:SetPoint("TOPRIGHT", 0, 0)
local kA = W:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); kA:SetPoint("TOPRIGHT", -112, -38); kA:SetText("Aktiv")
local kM = W:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); kM:SetPoint("TOPRIGHT", -26, -38); kM:SetText("Minimap")
local hinweis = W:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); hinweis:SetPoint("BOTTOMLEFT", 14, 44); hinweis:SetPoint("BOTTOMRIGHT", -14, 44); hinweis:SetJustifyH("LEFT")
local neu = CreateFrame("Button", nil, W, "UIPanelButtonTemplate"); neu:SetSize(220, 24); neu:SetPoint("BOTTOM", 0, 14); neu:SetText("Jetzt neu laden (/reload)")
-- Sprache für alle siikk-Addons (Fenster aus siikkSprache)
local spr = CreateFrame("Button", nil, W, "UIPanelButtonTemplate"); spr:SetSize(140, 24); spr:SetPoint("BOTTOMLEFT", 14, 14)
do local fs = spr:GetFontString(); if type(fs) == "table" and fs.SetFont then pcall(fs.SetFont, fs, "Fonts\\FRIZQT___CYR.TTF", 12, "") end end
spr:SetText(((siikkSprache and siikkSprache() ~= "de") and "Language: " or "Sprache: ") .. ((siikkSpracheName and siikkSpracheName()) or "Deutsch"))
spr:SetScript("OnClick", function() if SiikkSpracheOeffnen then SiikkSpracheOeffnen() end end)
neu:SetScript("OnClick", function() ReloadUI() end); neu:Hide()

local zeilen, geaendert = {}, false
for i, e in ipairs(LISTE) do
  local z = CreateFrame("Frame", nil, W, "BackdropTemplate"); z:SetPoint("TOPLEFT", 12, -52 - (i - 1) * 62); z:SetPoint("TOPRIGHT", -12, -52 - (i - 1) * 62); z:SetHeight(56)
  z:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
  z:SetBackdropColor(0, 0, 0, .45); z:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .7)
  z.icon = z:CreateTexture(nil, "ARTWORK"); z.icon:SetSize(40, 40); z.icon:SetPoint("LEFT", 8, 0)
  z.name = z:CreateFontString(nil, "OVERLAY", "GameFontNormal"); z.name:SetPoint("TOPLEFT", 56, -8)
  z.status = z:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); z.status:SetPoint("LEFT", z.name, "RIGHT", 8, 0)
  z.text = z:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); z.text:SetPoint("TOPLEFT", 56, -28); z.text:SetWidth(210); z.text:SetJustifyH("LEFT")
  z.an = CreateFrame("CheckButton", nil, z, "UICheckButtonTemplate"); z.an:SetSize(26, 26); z.an:SetPoint("RIGHT", -100, 0)
  z.mm = CreateFrame("CheckButton", nil, z, "UICheckButtonTemplate"); z.mm:SetSize(26, 26); z.mm:SetPoint("RIGHT", -18, 0)
  z.info = CreateFrame("Button", nil, z, "UIPanelButtonTemplate"); z.info:SetSize(46, 22); z.info:SetPoint("RIGHT", -196, 0); z.info:SetText("Info")
  z.neu = CreateFrame("Button", nil, z, "UIPanelButtonTemplate"); z.neu:SetSize(46, 22); z.neu:SetPoint("RIGHT", -146, 0); z.neu:SetText("Neu")
  z.neu:SetScript("OnClick", function()
    local api = rawget(_G, "SiikkNeuAPI"); local fn = api and api[e.mm]
    if fn then W:Hide(); fn() else msg(e.name .. " ist nicht geladen – erst aktivieren und neu laden.") end
  end)
  z.info:SetScript("OnClick", function()
    if e.ordner == "siikkUI" then W:Hide(); SlashCmdList.TOBSIIKKHELFER("intro") return end
    local api = rawget(_G, "SiikkIntroAPI"); local fn = api and api[e.mm]
    if fn then W:Hide(); fn() else msg(e.name .. " ist nicht geladen – erst aktivieren und neu laden.") end
  end)
  for _, cb in ipairs({ z.an, z.mm }) do for _, k in ipairs({ "text", "Text" }) do local t = rawget(cb, k); if type(t) == "table" and t.SetText then t:SetText("") end end end
  z.an:SetScript("OnClick", function(s)
    local v = s:GetChecked() and true or false
    if e.ordner == "siikkUI" and not v then msg("Achtung: Du schaltest die siikk-Oberfläche selbst aus. Wieder an geht es nur im AddOn-Menü der Charakterauswahl.") end
    setzen(e.ordner, v); geaendert = true; W.Auffrischen()
  end)
  z.mm:SetScript("OnClick", function(s) local api = SiikkMinimapAPI[e.mm]; if api then api.set(s:GetChecked() and true or false) end; W.Auffrischen() end)
  z.e = e; zeilen[i] = z
end

function W.Auffrischen()
  local classic = (WOW_PROJECT_ID and WOW_PROJECT_MAINLINE and WOW_PROJECT_ID ~= WOW_PROJECT_MAINLINE) and true or false
  for _, z in ipairs(zeilen) do
    local e = z.e
    z.icon:SetTexture(e.icon()); z.name:SetText(e.name); z.text:SetText(e.text)
    local da = vorhanden(e.ordner)
    if not da then
      z.status:SetText((e.nurClassic and not classic) and "|cff888888gibt es nicht in dieser Spielversion|r" or "|cffff6060nicht installiert|r")
      z.an:Disable(); z.an:SetChecked(false); z.mm:Disable(); z.mm:SetChecked(false); z.icon:SetDesaturated(true); z.info:Disable(); z.neu:Disable()
    else
      local ak, gl = aktiv(e.ordner), geladen(e.ordner)
      z.status:SetText(gl and (ak and "|cff33ff33läuft|r" or "|cffffd100wird nach Neuladen ausgeschaltet|r") or (ak and "|cffffd100wird nach Neuladen gestartet|r" or "|cff999999aus|r"))
      z.an:Enable(); z.an:SetChecked(ak); z.icon:SetDesaturated(not gl); z.info:SetEnabled(gl); z.neu:SetEnabled(gl)
      local api = SiikkMinimapAPI[e.mm]
      if api and gl then z.mm:Enable(); z.mm:SetChecked(api.get() and true or false) else z.mm:Disable(); z.mm:SetChecked(false) end
    end
  end
  hinweis:SetText(geaendert and "|cffffd100An/Aus wirkt erst nach dem Neuladen der Oberfläche.|r" or "|cffffd100Info|r = Einführung, |cffffd100Neu|r = Änderungen im letzten Update. |cffffd100Aktiv|r schaltet es an oder aus (wirkt nach /reload). |cffffd100Minimap|r blendet seinen Knopf sofort ein oder aus.")
  neu:SetShown(geaendert)
end
W:SetScript("OnShow", W.Auffrischen)
NS.addonZentrale = function() if W:IsShown() then W:Hide() else W:Show() end end
