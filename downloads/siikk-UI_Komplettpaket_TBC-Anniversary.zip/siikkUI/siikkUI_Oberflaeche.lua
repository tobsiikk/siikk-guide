-- siikkUI · Oberfläche
-- Eckige Minimap mit Goldrand und Uhr, 4×8-Aktionsleiste mit Horde-Emblem, verschiebbare Menü- und Taschenleiste
-- und ein gemeinsames Taschenfenster (alle Taschen, Sortieren, Hexer-Hintergrund).
-- Es werden die ORIGINALEN Blizzard-Knöpfe benutzt (Tastenbelegung, Abklingzeiten, Ziehen & Ablegen bleiben erhalten).

local ADDON, NS = ...
NS = NS or {}
local DB
local function msg(t) if NS.msg then NS.msg(t) else print(t) end end
local function pass(ok, ...) if ok then return ... end end
local function safe(fn, ...) if not fn then return nil end return pass(pcall(fn, ...)) end

local UDEF = { seitenLeiste = true, xpLeiste = true, xpBlizzAus = true, minimapEckig = true, leiste = true, menueLeiste = true, taschenLeiste = true, taschenFenster = true,
  taschenSpalten = 10, leisteLogo = .5, minimapIcons = {}, tooltipEigen = true, tooltipLogo = .15, fensterStil = true,
  leisteSpalten = 8, leisteAnzahl = 32, seiteSpalten = 2, seiteAnzahl = 24, hintergrund = .6, ruheTransparent = true }
local LOGO = "Interface\\AddOns\\siikkUI\\Media\\horde3d_hd"
local GOLD = NS.GOLD or { .85, .65, .15 }
local LILA = { .62, .22, .95 }
local hidden = CreateFrame("Frame"); hidden:Hide()
local pendingUI = false
local done = {}

local function addExtra(frame, key, point, x, y)
  if NS.extraFrames then table.insert(NS.extraFrames, { frame = frame, key = key, point = point, x = x, y = y }) end
end
local function goldEdge(fr, size, a)
  local e = CreateFrame("Frame", nil, fr, "BackdropTemplate")
  e:SetPoint("TOPLEFT", -(size or 1), size or 1); e:SetPoint("BOTTOMRIGHT", size or 1, -(size or 1))
  if e.SetBackdrop then
    e:SetBackdrop({ edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = size or 1 })
    e:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], a or .85)
  end
  e:SetFrameLevel((fr:GetFrameLevel() or 1) + 3)
  if e.EnableMouse then e:EnableMouse(false) end
  return e
end
local function kill(region)
  if type(region) ~= "table" then return end
  pcall(region.SetAlpha, region, 0)
  if region.EnableMouse then pcall(region.EnableMouse, region, false) end
end
local function bindText(cmd)
  if not cmd or not GetBindingKey then return "" end
  local key = safe(GetBindingKey, cmd)
  if not key then return "" end
  local t = (GetBindingText and safe(GetBindingText, key, "KEY_", true)) or key
  if type(t) ~= "string" then t = key end
  t = t:gsub("SHIFT%-", "S-"):gsub("CTRL%-", "C-"):gsub("ALT%-", "A-"):gsub("STRG%-", "C-"):gsub("UMSCHALT%-", "S-")
  return t
end
-- Neuere Clients haben Blizzards Bearbeitungsmodus (Esc > Bearbeitungsmodus). Dessen Systeme fassen wir nicht an.
local function editMode() return EditModeManagerFrame ~= nil end
local function onButtonLabel(b)
  if b.thBind then return b.thBind end
  local l = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  l:SetPoint("BOTTOM", b, "BOTTOM", 0, 2)
  local path = l.GetFont and l:GetFont(); if type(path) ~= "string" then path = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF" end
  pcall(l.SetFont, l, path, 10, "OUTLINE")
  l:SetTextColor(1, .85, .3)
  b.thBind = l
  return l
end
-- Goldener Rahmen um eine Gruppe von Blizzard-Knöpfen, der den Knöpfen folgt (auch nach dem Bearbeitungsmodus)
local function decorate(name, getButtons)
  local d = CreateFrame("Frame", name, UIParent, "BackdropTemplate")
  if d.SetBackdrop then
    d:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    d:SetBackdropColor(0, 0, 0, .55); d:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .95)
  end
  d:EnableMouse(false); d:Hide()
  d.acc = 1
  local function fit()
    local ui = UIParent:GetEffectiveScale() or 1
    local l, r, t, b, ref
    for _, btn in ipairs(getButtons()) do
      if btn:IsVisible() and btn:GetLeft() then
        local sc = (btn:GetEffectiveScale() or 1) / ui
        local bl, br, bt, bb = btn:GetLeft() * sc, btn:GetRight() * sc, btn:GetTop() * sc, btn:GetBottom() * sc
        l = l and math.min(l, bl) or bl; r = r and math.max(r, br) or br
        t = t and math.max(t, bt) or bt; b = b and math.min(b, bb) or bb
        ref = ref or btn
        if not btn.thGold then btn.thGold = goldEdge(btn, 1, .8) end
      end
    end
    if not l then d:Hide() return end
    d:ClearAllPoints()
    d:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", l - 6, t + 6)
    d:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMLEFT", r + 6, b - 6)
    if ref and ref.GetFrameStrata then pcall(d.SetFrameStrata, d, ref:GetFrameStrata()); pcall(d.SetFrameLevel, d, math.max(0, (ref:GetFrameLevel() or 1) - 1)) end
    d:Show()
  end
  local u = CreateFrame("Frame")
  u:SetScript("OnUpdate", function(s, el) s.acc = (s.acc or 1) + el; if s.acc >= .3 then s.acc = 0; pcall(fit) end end)
  d.fit = fit
  return d
end
local function movable(fr, key)
  fr:SetMovable(true); fr:SetClampedToScreen(true); fr:EnableMouse(true); fr:RegisterForDrag("LeftButton")
  fr:SetScript("OnDragStart", function(s) if DB and not DB.gesperrt and not InCombatLockdown() then s:StartMoving() end end)
  fr:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); if NS.savePos then NS.savePos(s, key) end end)
  if NS.makeScalable then NS.makeScalable(fr, key) end
end
-- Griff über einer Leiste, deren Fläche voller Knöpfe ist (nur im entsperrten Zustand sichtbar)
local handles = {}
local function addHandle(fr, key, text)
  local h = CreateFrame("Frame", nil, fr, "BackdropTemplate")
  h:SetPoint("BOTTOMLEFT", fr, "TOPLEFT", 0, 2); h:SetPoint("BOTTOMRIGHT", fr, "TOPRIGHT", 0, 2); h:SetHeight(18)
  if h.SetBackdrop then
    h:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    h:SetBackdropColor(.25, .18, .02, .9); h:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
  end
  h.t = h:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); h.t:SetPoint("CENTER")
  h.t:SetText(text .. "  ·  ziehen = verschieben, Mausrad = Größe")
  h:EnableMouse(true); h:RegisterForDrag("LeftButton"); h:EnableMouseWheel(true)
  h:SetScript("OnDragStart", function() if DB and not DB.gesperrt and not InCombatLockdown() then fr:StartMoving() end end)
  h:SetScript("OnDragStop", function() fr:StopMovingOrSizing(); if NS.savePos then NS.savePos(fr, key) end end)
  h:SetScript("OnMouseWheel", function(_, d) local f = fr:GetScript("OnMouseWheel"); if f and not InCombatLockdown() then f(fr, d) end end)
  h:SetFrameLevel((fr:GetFrameLevel() or 1) + 20)
  h:Hide(); h.owner = fr
  handles[#handles + 1] = h
  return h
end
local function updateHandles()
  local show = DB and not DB.gesperrt
  for _, h in ipairs(handles) do if show and h.owner and h.owner:IsShown() then h:Show() else h:Hide() end end
end
local function holder(name, w, h)
  local f = CreateFrame("Frame", name, UIParent, "BackdropTemplate")
  f:SetSize(w, h)
  if f.SetBackdrop then
    f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    f:SetBackdropColor(0, 0, 0, .55); f:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .9)
  end
  return f
end

---------------------------------------------------------------------------
-- 1) Eckige Minimap mit Goldrand, verschiebbaren Randsymbolen und Uhr
---------------------------------------------------------------------------
NS.minimapSquare = function() return DB and DB.minimapEckig and done.minimap end
local function edgePlace(b, ang)
  if not b or not Minimap then return end
  local half = ((Minimap:GetWidth() or 140) / 2) + 2
  local c, s = math.cos(math.rad(ang)), math.sin(math.rad(ang))
  local m = math.max(math.abs(c), math.abs(s)); if m > 0 then c, s = c / m, s / m end
  b:ClearAllPoints(); b:SetPoint("CENTER", Minimap, "CENTER", c * half, s * half)
end
local dragger = CreateFrame("Frame"); dragger:Hide()
dragger:SetScript("OnUpdate", function(d)
  local b = d.btn
  if not b or not Minimap then d:Hide() return end
  local mx, my = Minimap:GetCenter()
  local cx, cy = GetCursorPosition()
  local sc = Minimap:GetEffectiveScale() or 1
  if not mx or not cx then return end
  local ang = math.deg(math.atan2(cy / sc - my, cx / sc - mx))
  DB.minimapIcons[b.thKey] = ang
  edgePlace(b, ang)
end)
-- Blizzard-Symbole, die sich um die Minimap ziehen lassen (Name, Schlüssel, Startwinkel)
local EDGE = {
  { "MinimapZoomIn", "plus", -20 }, { "MinimapZoomOut", "minus", -45 },
  { "MiniMapMailFrame", "post", 160 }, { "MiniMapTrackingFrame", "suche", 135 }, { "MiniMapTracking", "suche", 135 },
  { "GameTimeFrame", "tageszeit", 45 }, { "MiniMapBattlefieldFrame", "pvp", 205 }, { "MiniMapLFGFrame", "lfg", 230 },
  { "QueueStatusMinimapButton", "warteschlange", 230 }, { "MiniMapWorldMapButton", "weltkarte", 100 },
}
local function edgeIcon(b, key, def)
  if not b or b.thKey then return end
  b.thKey = key
  pcall(b.SetParent, b, Minimap)
  pcall(b.SetFrameLevel, b, (Minimap:GetFrameLevel() or 1) + 6)
  if b.RegisterForDrag then pcall(b.RegisterForDrag, b, "LeftButton") end
  if b.HookScript then
    b:HookScript("OnDragStart", function(s) if DB and not DB.gesperrt then dragger.btn = s; dragger:Show() end end)
    b:HookScript("OnDragStop", function() dragger.btn = nil; dragger:Hide() end)
  end
  edgePlace(b, DB.minimapIcons[key] or def)
end
local function placeEdges()
  for _, e in ipairs(EDGE) do local b = _G[e[1]]; if b and b.thKey then edgePlace(b, DB.minimapIcons[b.thKey] or e[3]) end end
  if NS.mmPlace then NS.mmPlace() end
end

local clock
local function clockText()
  local h, m
  local useLocal = true
  if GetCVarBool then local v = safe(GetCVarBool, "timeMgrUseLocalTime"); if v == false then useLocal = false end end
  if not useLocal and GetGameTime then h, m = GetGameTime() end
  if not h then local t = date("*t"); h, m = t.hour, t.min end
  local d = date("*t")
  local TAG = { "So", "Mo", "Di", "Mi", "Do", "Fr", "Sa" }
  return string.format("%02d:%02d:%02d", h or 0, m or 0, d.sec or 0) .. "  |cffbbbbbb" .. (TAG[d.wday] or "") .. " " .. string.format("%02d.%02d.%04d", d.day, d.month, d.year) .. "|r"
end
local function hideBlizzClock()
  local c = TimeManagerClockButton
  if c and not c.thHooked then
    c.thHooked = true
    c:HookScript("OnShow", function(s) if DB and DB.minimapEckig and done.minimap then s:Hide() end end)
  end
  if c then c:Hide() end
end

local function setupMinimap()
  if done.minimap or not DB.minimapEckig or not Minimap then return end
  if InCombatLockdown() then pendingUI = true return end
  done.minimap = true
  pcall(Minimap.SetMaskTexture, Minimap, "Interface\\Buttons\\WHITE8X8")
  GetMinimapShape = function() return "SQUARE" end -- damit Addon-Symbole (LibDBIcon) eckig um die Karte laufen
  for _, n in ipairs({ "MinimapBorder", "MinimapBorderTop", "MinimapCompassTexture", "MinimapNorthTag", "MinimapToggleButton" }) do
    local r = _G[n]; if r then pcall(r.Hide, r); kill(r) end
  end
  if MinimapCluster and MinimapCluster.BorderTop then kill(MinimapCluster.BorderTop) end
  -- Goldrahmen
  Minimap.thGold = goldEdge(Minimap, 3, 1)
  if Minimap.thGold.SetBackdropBorderColor then Minimap.thGold:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1) end -- Goldrand wie Leisten, Taschen und Fenster
  Minimap.thBack = Minimap:CreateTexture(nil, "BACKGROUND", nil, -8)
  Minimap.thBack:SetPoint("TOPLEFT", -3, 3); Minimap.thBack:SetPoint("BOTTOMRIGHT", 3, -3); Minimap.thBack:SetColorTexture(0, 0, 0, 1)
  -- kleines Namensschild „siikkUI“ oben mittig auf dem Rand (Klicks gehen durch, Karte bleibt frei)
  do
    local tag = CreateFrame("Frame", "TobsiikkHelferMinimapSchild", Minimap, "BackdropTemplate")
    tag:SetPoint("CENTER", Minimap, "TOP", 0, 1); tag:SetHeight(13); tag:EnableMouse(false)
    tag:SetFrameLevel((Minimap.thGold and Minimap.thGold:GetFrameLevel() or Minimap:GetFrameLevel()) + 2)
    if tag.SetBackdrop then
      tag:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
      tag:SetBackdropColor(0, 0, 0, .9); tag:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
    end
    tag.t = tag:CreateFontString(nil, "OVERLAY"); tag.t:SetPoint("CENTER", 0, 0)
    pcall(tag.t.SetFont, tag.t, STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", 9, "OUTLINE")
    tag.t:SetText("|cffe03030siikk|r|cffffd100UI|r")
    local w = tag.t:GetStringWidth(); tag:SetWidth(((type(w) == "number" and w > 0) and w or 36) + 10)
  end
  -- Gebietsname über der Karte
  if MinimapZoneTextButton then
    pcall(MinimapZoneTextButton.SetParent, MinimapZoneTextButton, Minimap)
    MinimapZoneTextButton:ClearAllPoints(); MinimapZoneTextButton:SetPoint("BOTTOM", Minimap, "TOP", 0, 10)
  end
  -- Verschieben / Größe (Mausrad im Entsperrt-Modus), sonst Mausrad = Zoom
  Minimap:SetMovable(true); Minimap:SetClampedToScreen(true); Minimap:RegisterForDrag("LeftButton")
  Minimap:SetScript("OnDragStart", function(s) if DB and not DB.gesperrt then s:StartMoving() end end)
  Minimap:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); if NS.savePos then NS.savePos(s, "minimap") end end)
  Minimap:EnableMouseWheel(true)
  Minimap:SetScript("OnMouseWheel", function(s, d)
    if DB and not DB.gesperrt then
      local old = s:GetScale()
      local sc = math.max(.5, math.min(3, math.floor(((DB.scale.minimap or 1) + d * .1) * 10 + .5) / 10))
      local x, y = s:GetCenter()
      DB.scale.minimap = sc; s:SetScale(sc)
      if x and y then s:ClearAllPoints(); s:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x * old / sc, y * old / sc); DB.pos.minimap = { "CENTER", "BOTTOMLEFT", x * old / sc, y * old / sc } end
      if NS.showScale then NS.showScale(s, sc) end
    else
      local z, mz = s:GetZoom() or 0, (s.GetZoomLevels and s:GetZoomLevels()) or 5
      if d > 0 and z < mz then s:SetZoom(z + 1) elseif d < 0 and z > 0 then s:SetZoom(z - 1) end
    end
  end)
  addExtra(Minimap, "minimap", "TOPRIGHT", -24, -40)
  -- Randsymbole
  for _, e in ipairs(EDGE) do local b = _G[e[1]]; if b then edgeIcon(b, e[2], e[3]) end end
  -- Uhr (dicker, Goldrand) unter der Karte
  clock = CreateFrame("Button", "TobsiikkHelferUhr", Minimap, "BackdropTemplate")
  clock:SetSize(120, 15); clock:SetPoint("TOP", Minimap, "BOTTOM", 0, -6)
  if clock.SetBackdrop then
    clock:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    clock:SetBackdropColor(0, 0, 0, .85); clock:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
  end
  clock.t = clock:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge"); clock.t:SetPoint("CENTER", 0, 0)
  local path = clock.t.GetFont and clock.t:GetFont(); if type(path) ~= "string" then path = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF" end
  pcall(clock.t.SetFont, clock.t, path, 10, "OUTLINE")
  clock.acc = 1
  clock:SetScript("OnUpdate", function(s, el) s.acc = s.acc + el; if s.acc >= .2 then s.acc = 0; s.t:SetText(clockText()); local w = s.t:GetStringWidth(); if type(w) == "number" and w > 0 then s:SetWidth(w + 12) end end end)
  clock:RegisterForClicks("AnyUp")
  clock:SetScript("OnClick", function()
    if not TimeManager_Toggle and UIParentLoadAddOn then pcall(UIParentLoadAddOn, "Blizzard_TimeManager") end
    if TimeManager_Toggle then pcall(TimeManager_Toggle) end
  end)
  clock:SetScript("OnEnter", function(s) GameTooltip:SetOwner(s, "ANCHOR_BOTTOM"); GameTooltip:AddLine("Uhrzeit"); do local d = date("*t"); local T = { "Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag" }
    local M = { "Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember" }
    GameTooltip:AddLine(T[d.wday] .. ", " .. d.day .. ". " .. M[d.month] .. " " .. d.year, 1, 1, 1) end; GameTooltip:AddLine("Klick: Stoppuhr und Wecker", .8, .8, .8); GameTooltip:Show() end)
  clock:SetScript("OnLeave", function() GameTooltip:Hide() end)
  hideBlizzClock()
  placeEdges()
  if NS.applyLayout then NS.applyLayout() end
end

---------------------------------------------------------------------------
-- 2) Aktionsleiste 4×8 mit Horde-Emblem
---------------------------------------------------------------------------
local SLOT, GAP = 36, 5
local bar = holder("TobsiikkHelferAktionsleiste", 8 * SLOT + 7 * GAP + 18, 4 * SLOT + 3 * GAP + 18)
bar:Hide()
bar.logo = bar:CreateTexture(nil, "BACKGROUND", nil, 2)
bar.logo:SetTexture(LOGO); bar.logo:SetTexCoord(.06, .94, .2, .8); bar.logo:SetPoint("CENTER")
if NS.addLogo then NS.addLogo(bar.logo, LOGO, { tc = { .06, .94, .2, .8 }, a = 1.47 }) end
bar.logo:SetSize((8 * SLOT + 7 * GAP) * .95, (4 * SLOT + 3 * GAP) * 1.05)
local petBar = CreateFrame("Frame", "TobsiikkHelferBegleiterleiste", UIParent, "SecureHandlerStateTemplate,BackdropTemplate")
petBar:SetSize(10 * 32 + 9 * 4 + 14, 32 + 14); petBar:Hide()

local function gridButtons()
  local t = {}
  for i = 1, 12 do t[#t + 1] = _G["ActionButton" .. i] end
  for i = 1, 12 do t[#t + 1] = _G["MultiBarBottomLeftButton" .. i] end
  for i = 1, 12 do t[#t + 1] = _G["MultiBarBottomRightButton" .. i] end
  return t
end
local function styleButton(b)
  if b.thStyled then return end
  b.thStyled = true
  b.thGold = goldEdge(b, 1, .8)
  local n = b.GetNormalTexture and b:GetNormalTexture(); if type(n) == "table" and n.SetAlpha then pcall(n.SetAlpha, n, 0) end -- graues Feld weg, Logo bleibt sichtbar
  for _, k in ipairs({ "SlotBackground", "SlotArt" }) do kill(rawget(b, k)) end
  local nm = b.GetName and b:GetName(); if type(nm) == "string" then kill(_G[nm .. "FloatingBG"]) end
  if b.Update then pcall(hooksecurefunc, b, "Update", function(x) local nt = x.GetNormalTexture and x:GetNormalTexture(); if type(nt) == "table" and nt.SetAlpha then nt:SetAlpha(0) end end) end
end
local function hideArt()
  local names = { "MainMenuBarTexture0", "MainMenuBarTexture1", "MainMenuBarTexture2", "MainMenuBarTexture3", "MainMenuBarLeftEndCap",
    "MainMenuBarRightEndCap", "MainMenuBarPageNumber", "ActionBarUpButton", "ActionBarDownButton", "MainMenuBarTextureExtender",
    "SlidingActionBarTexture0", "SlidingActionBarTexture1", "MultiBarBottomLeftBackground" }
  for _, n in ipairs(names) do kill(_G[n]) end
  local art = MainMenuBarArtFrame
  if art then for _, k in ipairs({ "LeftEndCap", "RightEndCap", "PageNumber", "Background" }) do kill(rawget(art, k)) end end
  for _, br in ipairs({ MainMenuBar, MainActionBar }) do
    if type(br) == "table" then for _, k in ipairs({ "EndCaps", "BorderArt", "ActionBarPageNumber", "Background" }) do kill(rawget(br, k)) end end
  end
  if MainMenuBarArtFrameBackground then kill(MainMenuBarArtFrameBackground) end
  for _, f in ipairs({ MainMenuBar, MainMenuBarArtFrame }) do if f and f.EnableMouse then pcall(f.EnableMouse, f, false) end end
end
local function setupBars()
  if done.bars or not DB.leiste then return end
  if InCombatLockdown() then pendingUI = true return end
  local btns = gridButtons()
  if #btns < 36 then msg("Die 4×8-Leiste konnte nicht alle Aktionsknöpfe finden – sie bleibt aus."); return end
  done.bars = true
  -- untere Leisten aktivieren und leere Felder immer zeigen (zum Hineinziehen von Zaubern)
  if GetActionBarToggles and SetActionBarToggles then
    local _, _, r1, r2 = GetActionBarToggles()
    local side = DB.seitenLeiste
    pcall(SetActionBarToggles, 1, 1, (side or r1) and 1 or nil, (side or r2) and 1 or nil, 1)
  end
  if SetCVar then pcall(SetCVar, "alwaysShowActionBars", "1") end
  if MultiActionBar_Update then pcall(MultiActionBar_Update) end
  if MultiActionBar_UpdateGridVisibility then pcall(MultiActionBar_UpdateGridVisibility) end
  local function placeGrid()
    if InCombatLockdown() then pendingUI = true; done.gridDirty = true return end
    local n = math.max(1, math.min(#btns, math.floor(DB.leisteAnzahl or 32)))
    local cols = math.max(1, math.min(n, math.floor(DB.leisteSpalten or 8)))
    local rows = math.ceil(n / cols)
    bar:SetSize(cols * SLOT + (cols - 1) * GAP + 18, rows * SLOT + (rows - 1) * GAP + 18)
    for i, b in ipairs(btns) do
      if i <= n then
        local col, row = (i - 1) % cols, math.floor((i - 1) / cols)
        if b:GetParent() ~= bar then pcall(b.SetParent, b, bar) end
        b:ClearAllPoints(); b:SetPoint("TOPLEFT", bar, "TOPLEFT", 9 + col * (SLOT + GAP), -9 - row * (SLOT + GAP))
        pcall(b.SetSize, b, SLOT, SLOT)
        styleButton(b)
        pcall(b.Show, b)
      elseif b:GetParent() ~= hidden then pcall(b.SetParent, b, hidden) end
    end
  end
  NS.placeGrid = placeGrid
  for _, b in ipairs(btns) do
    if b.SetAttribute and b.GetAttribute then pcall(b.SetAttribute, b, "showgrid", bit and bit.bor and bit.bor(b:GetAttribute("showgrid") or 0, 1) or 1) end
  end
  placeGrid()
  -- Blizzards Leisten ordnen ihre Knöpfe im Bearbeitungsmodus neu an – danach sofort zurück ins 4×8-Raster
  for _, br in ipairs({ MainMenuBar, MultiBarBottomLeft, MultiBarBottomRight, MainActionBar }) do
    if type(br) == "table" then
      for _, m in ipairs({ "UpdateGridLayout", "Layout", "UpdateButtonArt" }) do
        if type(br[m]) == "function" then pcall(hooksecurefunc, br, m, function() if not br.thBusy then br.thBusy = true; pcall(placeGrid); br.thBusy = nil end end) end
      end
    end
  end
  if EditModeManagerFrame then
    for _, m in ipairs({ "ExitEditMode", "UpdateLayoutInfo" }) do
      if type(EditModeManagerFrame[m]) == "function" then pcall(hooksecurefunc, EditModeManagerFrame, m, function() pcall(placeGrid) end) end
    end
  end
  if ActionButton_Update then
    hooksecurefunc("ActionButton_Update", function(b) if b and b.thStyled then local n = b.GetNormalTexture and b:GetNormalTexture(); if type(n) == "table" and n.SetAlpha then n:SetAlpha(0) end end end)
  end
  bar.logo:Hide(); if NS.applyBG then NS.applyBG() end
  bar:Show()
  movable(bar, "aktionsleiste")
  addHandle(bar, "aktionsleiste", "4×8-Leiste")
  addExtra(bar, "aktionsleiste", "BOTTOM", 0, 70)
  -- Begleiterleiste (Dämonen-Fähigkeiten) behalten und mitverschiebbar machen
  local n = 0
  for i = 1, 10 do
    local b = _G["PetActionButton" .. i]
    if b then
      n = n + 1
      pcall(b.SetParent, b, petBar)
      b:ClearAllPoints(); b:SetPoint("LEFT", petBar, "LEFT", 7 + (i - 1) * 36, 0)
    end
  end
  if n > 0 then
    if petBar.SetBackdrop then petBar:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 10, insets = { left = 2, right = 2, top = 2, bottom = 2 } }); petBar:SetBackdropColor(0, 0, 0, .5); petBar:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .8) end
    movable(petBar, "begleiterleiste")
    addHandle(petBar, "begleiterleiste", "Dämonenleiste")
    addExtra(petBar, "begleiterleiste", "BOTTOM", 0, 70 + 4 * SLOT + 3 * GAP + 30)
    if RegisterStateDriver then RegisterStateDriver(petBar, "visibility", "[pet] show; hide") end
  end
  hideArt()
  if NS.applyLayout then NS.applyLayout() end
end

---------------------------------------------------------------------------
-- 2b) Seitenleisten als 2×12-Raster (gleicher Stil wie die 4×8-Leiste)
---------------------------------------------------------------------------
local side = holder("TobsiikkHelferSeitenleiste", 2 * SLOT + GAP + 18, 12 * SLOT + 11 * GAP + 18)
side:Hide()
side.logo = side:CreateTexture(nil, "BACKGROUND", nil, 2)
side.logo:SetTexture(LOGO)
-- Schriftzug um 90° gedreht, damit er die hohe, schmale Leiste füllt (von oben nach unten lesbar)
do local l, r, t, b = .06, .94, .2, .8; side.logo:SetTexCoord(l, b, r, b, l, t, r, t); if NS.addLogo then NS.addLogo(side.logo, LOGO, { tc8 = { l, b, r, b, l, t, r, t }, a = .68 }) end end
side.logo:SetPoint("CENTER"); side.logo:SetSize((2 * SLOT + GAP) * 1.05, (12 * SLOT + 11 * GAP) * .95)
local function sideButtons()
  local t = {}
  for i = 1, 12 do t[#t + 1] = _G["MultiBarLeftButton" .. i] end  -- linke Spalte
  for i = 1, 12 do t[#t + 1] = _G["MultiBarRightButton" .. i] end -- rechte Spalte
  return t
end
local function setupSide()
  if done.side or not DB.seitenLeiste then return end
  if InCombatLockdown() then pendingUI = true return end
  local btns = sideButtons()
  if #btns < 24 then msg("Die 2×12-Seitenleiste konnte nicht alle Knöpfe finden – sie bleibt aus."); return end
  done.side = true
  if not done.bars and GetActionBarToggles and SetActionBarToggles then
    local a, b = GetActionBarToggles()
    pcall(SetActionBarToggles, a and 1 or nil, b and 1 or nil, 1, 1, 1)
  end
  if SetCVar then pcall(SetCVar, "alwaysShowActionBars", "1") end
  if MultiActionBar_Update then pcall(MultiActionBar_Update) end
  local function placeSide()
    if InCombatLockdown() then pendingUI = true; done.sideDirty = true return end
    local n = math.max(1, math.min(#btns, math.floor(DB.seiteAnzahl or 24)))
    local cols = math.max(1, math.min(n, math.floor(DB.seiteSpalten or 2)))
    local rows = math.ceil(n / cols)
    side:SetSize(cols * SLOT + (cols - 1) * GAP + 18, rows * SLOT + (rows - 1) * GAP + 18)
    for i, b in ipairs(btns) do
      if i <= n then
        local col, row = math.floor((i - 1) / rows), (i - 1) % rows -- spaltenweise: links die linke Leiste
        if b:GetParent() ~= side then pcall(b.SetParent, b, side) end
        b:ClearAllPoints(); b:SetPoint("TOPLEFT", side, "TOPLEFT", 9 + col * (SLOT + GAP), -9 - row * (SLOT + GAP))
        pcall(b.SetSize, b, SLOT, SLOT)
        styleButton(b)
        pcall(b.Show, b)
      elseif b:GetParent() ~= hidden then pcall(b.SetParent, b, hidden) end
    end
  end
  NS.placeSide = placeSide
  for _, b in ipairs(btns) do
    if b.SetAttribute and b.GetAttribute then pcall(b.SetAttribute, b, "showgrid", bit and bit.bor and bit.bor(b:GetAttribute("showgrid") or 0, 1) or 1) end
  end
  placeSide()
  for _, br in ipairs({ MultiBarRight, MultiBarLeft }) do
    if type(br) == "table" then
      for _, m in ipairs({ "UpdateGridLayout", "Layout", "UpdateButtonArt" }) do
        if type(br[m]) == "function" then pcall(hooksecurefunc, br, m, function() if not br.thBusy then br.thBusy = true; pcall(placeSide); br.thBusy = nil end end) end
      end
    end
  end
  if EditModeManagerFrame then
    for _, m in ipairs({ "ExitEditMode", "UpdateLayoutInfo" }) do
      if type(EditModeManagerFrame[m]) == "function" then pcall(hooksecurefunc, EditModeManagerFrame, m, function() pcall(placeSide) end) end
    end
  end
  side.logo:Hide(); if NS.applyBG then NS.applyBG() end
  side:Show()
  movable(side, "seitenleiste")
  addHandle(side, "seitenleiste", "2×12")
  addExtra(side, "seitenleiste", "RIGHT", -8, 0)
  if NS.applyLayout then NS.applyLayout() end
end

---------------------------------------------------------------------------
-- 3) Menüleiste (Charakter, Zauberbuch, Berufe ...) und Taschenleiste – mit Tastenbelegung
---------------------------------------------------------------------------
local MICRO = { { "CharacterMicroButton", "TOGGLECHARACTER0" }, { "SpellbookMicroButton", "TOGGLESPELLBOOK" }, { "TalentMicroButton", "TOGGLETALENTS" },
  { "QuestLogMicroButton", "TOGGLEQUESTLOG" }, { "SocialsMicroButton", "TOGGLESOCIAL" }, { "GuildMicroButton", "TOGGLEGUILDTAB" },
  { "WorldMapMicroButton", "TOGGLEWORLDMAP" }, { "LFGMicroButton", "TOGGLEGROUPFINDER" }, { "PVPMicroButton", "TOGGLECHARACTER4" },
  { "MainMenuMicroButton", "TOGGLEGAMEMENU" }, { "HelpMicroButton", nil } }
local micro = holder("TobsiikkHelferMenueleiste", 100, 76); micro:Hide()
local microBtns = {}
local microCont -- neuere Clients: Blizzard ordnet die Knöpfe selbst in einem Behälter an (MicroMenuContainer)
local function anchorCont()
  if not microCont or microCont.thAnchoring then return end
  microCont.thAnchoring = true
  microCont:ClearAllPoints(); microCont:SetPoint("BOTTOMLEFT", micro, "BOTTOMLEFT", 6, 18)
  microCont.thAnchoring = nil
  local w, h = microCont:GetWidth() or 0, microCont:GetHeight() or 0
  if w < 20 then w = #microBtns * 26 end
  if h < 10 then h = 40 end
  micro:SetSize(w + 12, h + 24)
end
local function layoutMicro()
  if not done.micro then return end
  if labelOnlyMicro then for _, e in ipairs(microBtns) do e.l:SetText(bindText(e.cmd)) end return end
  if microCont then
    anchorCont()
  else
    local x = 6
    for _, e in ipairs(microBtns) do
      local b = e.b
      if b:IsShown() or b.thForce then
        b:ClearAllPoints(); b:SetPoint("BOTTOMLEFT", micro, "BOTTOMLEFT", x, 16)
        x = x + ((b:GetWidth() or 28) - 2)
      end
    end
    micro:SetWidth(x + 8)
  end
  for _, e in ipairs(microBtns) do e.l:SetText(bindText(e.cmd)) end
end
local labelOnlyMicro = false
-- Menü-/Taschenleiste in Clients mit Bearbeitungsmodus: NICHT umhängen (das führte zu Fehlern),
-- sondern nur an einen unsichtbaren Platzhalter mit goldenem Griff anheften
local function attachCont(cont, h, key, text, pt, x, y, anchorPt, w0, h0)
  if type(cont) ~= "table" or not cont.SetPoint then return false end
  local function anc()
    if cont.thAnchoring or InCombatLockdown() then return end
    cont.thAnchoring = true
    pcall(function()
      if not w0 then
        local s = (cont:GetEffectiveScale() or 1) / (h:GetEffectiveScale() or 1)
        h:SetSize(math.max(60, (cont:GetWidth() or 200) * s + 12), math.max(30, (cont:GetHeight() or 40) * s + 12))
      end
      cont:ClearAllPoints(); cont:SetPoint(anchorPt or "CENTER", h, anchorPt or "CENTER", anchorPt == "LEFT" and 6 or (anchorPt == "RIGHT" and -6 or 0), 0)
    end)
    cont.thAnchoring = nil
  end
  if w0 then h:SetSize(w0, h0) end
  pcall(hooksecurefunc, cont, "SetPoint", anc)
  for _, m in ipairs({ "Layout", "UpdateSystem", "ApplySystemAnchor" }) do if type(cont[m]) == "function" then pcall(hooksecurefunc, cont, m, anc) end end
  if EditModeManagerFrame then
    for _, m in ipairs({ "ExitEditMode", "UpdateLayoutInfo" }) do if type(EditModeManagerFrame[m]) == "function" then pcall(hooksecurefunc, EditModeManagerFrame, m, anc) end end
  end
  -- Platzhalter selbst unsichtbar und klick-durchlässig (die Goldoptik kommt von decorate); gezogen wird am Griff
  if h.SetBackdropColor then h:SetBackdropColor(0, 0, 0, 0); h:SetBackdropBorderColor(0, 0, 0, 0) end
  movable(h, key); h:EnableMouse(false)
  addHandle(h, key, text); addExtra(h, key, pt, x, y)
  h:Show(); h.anc = anc
  local ap = NS.applyLayout; if ap then ap() end
  anc()
  -- nach jedem Verschieben/Neuplatzieren sofort nachziehen
  if not h.thHooked then h.thHooked = true; h:HookScript("OnDragStop", anc); hooksecurefunc(h, "SetPoint", function() if not cont.thAnchoring then anc() end end) end
  return true
end
local function setupMicro()
  if done.micro or not DB.menueLeiste then return end
  done.micro = true
  if editMode() or MicroMenuContainer or MicroMenu then
    -- Blizzard verwaltet die Menüleiste selbst: nur die Tastenbelegung einblenden, verschieben über den Bearbeitungsmodus
    labelOnlyMicro = true
    for _, e in ipairs(MICRO) do
      local b = _G[e[1]]
      if b then microBtns[#microBtns + 1] = { b = b, cmd = e[2], l = onButtonLabel(b) } end
    end
    for _, e in ipairs(microBtns) do e.l:SetText(bindText(e.cmd)) end
    decorate("TobsiikkHelferMenueRahmen", function() local t = {}; for _, e in ipairs(microBtns) do t[#t + 1] = e.b end; return t end)
    -- verschiebbar über einen goldenen Griff (sichtbar, wenn entsperrt / im Platzier-Modus)
    local cont = MicroMenuContainer or MicroMenu
    if not attachCont(cont, micro, "menueleiste", "Menüleiste", "BOTTOMRIGHT", -320, 4) then
      attachCont(_G.CharacterMicroButton, micro, "menueleiste", "Menüleiste", "BOTTOMRIGHT", -320, 4, "LEFT", 300, 44)
    end
    return
  end
  microCont = nil
  for _, e in ipairs(MICRO) do
    local b = _G[e[1]]
    if b then
      if not microCont then pcall(b.SetParent, b, micro) end -- ältere Clients: Knöpfe einzeln übernehmen
      local l = micro:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
      l:SetPoint("TOP", b, "BOTTOM", 0, -1); l:SetTextColor(GOLD[1] + .1, GOLD[2] + .1, GOLD[3] + .1)
      microBtns[#microBtns + 1] = { b = b, cmd = e[2], l = l }
    end
  end
  if #microBtns == 0 and not microCont then return end
  if microCont then
    -- den ganzen Blizzard-Behälter verschieben, damit Blizzard die Knöpfe weiter selbst anordnen kann
    pcall(microCont.SetParent, microCont, micro)
    pcall(hooksecurefunc, microCont, "SetPoint", function() anchorCont() end)
    if microCont.Layout then pcall(hooksecurefunc, microCont, "Layout", function() layoutMicro() end) end
  else
    micro:SetHeight(((microBtns[1].b:GetHeight()) or 58) + 20)
    for _, f in ipairs({ "UpdateMicroButtons", "MoveMicroButtons", "UpdateMicroButtonsParent" }) do
      if _G[f] then hooksecurefunc(f, function() if not InCombatLockdown() then pcall(function() for _, e in ipairs(microBtns) do e.b:SetParent(micro) end end) end; layoutMicro() end) end
    end
  end
  micro:Show(); layoutMicro()
  movable(micro, "menueleiste")
  addExtra(micro, "menueleiste", "BOTTOMRIGHT", -320, 4)
  if NS.applyLayout then NS.applyLayout() end
end

local BAGBTN = { { "KeyRingButton", nil }, { "CharacterBag3Slot", "TOGGLEBAG1" }, { "CharacterBag2Slot", "TOGGLEBAG2" },
  { "CharacterBag1Slot", "TOGGLEBAG3" }, { "CharacterBag0Slot", "TOGGLEBAG4" }, { "MainMenuBarBackpackButton", "OPENALLBAGS" } }
local bagBar = holder("TobsiikkHelferTaschenleiste", 100, 60); bagBar:Hide()
local bagBtns = {}
local labelOnlyBags = false
local setupBagBar
local function layoutBagBar()
  if not done.bagbar then return end
  if labelOnlyBags or BagsBar or MainMenuBarBagManager then
    for _, e in ipairs(bagBtns) do e.l:SetText(e.cmd == "OPENALLBAGS" and (bindText("OPENALLBAGS") ~= "" and bindText("OPENALLBAGS") or bindText("TOGGLEBACKPACK")) or bindText(e.cmd)) end
    return
  end
  local x = 8
  for _, e in ipairs(bagBtns) do
    local b = e.b
    b:ClearAllPoints(); b:SetPoint("BOTTOMLEFT", bagBar, "BOTTOMLEFT", x, 16)
    x = x + (b:GetWidth() or 30) + 4
    e.l:SetText(e.cmd == "OPENALLBAGS" and (bindText("OPENALLBAGS") ~= "" and bindText("OPENALLBAGS") or bindText("TOGGLEBACKPACK")) or bindText(e.cmd))
  end
  bagBar:SetWidth(x + 6)
end
local bagCont
setupBagBar = function()
  if done.bagbar or not DB.taschenLeiste then return end
  done.bagbar = true
  if editMode() then
    labelOnlyBags = true
    for _, e in ipairs(BAGBTN) do
      local b = _G[e[1]]
      if b then bagBtns[#bagBtns + 1] = { b = b, cmd = e[2], l = onButtonLabel(b) } end
    end
    layoutBagBar()
    decorate("TobsiikkHelferTaschenRahmen", function() local t = {}; for _, e in ipairs(bagBtns) do t[#t + 1] = e.b end; return t end)
    local cont = BagsBar or MainMenuBarBagManager
    if not attachCont(cont, bagBar, "taschenleiste", "Taschenleiste", "BOTTOMRIGHT", -8, 4) then
      attachCont(_G.MainMenuBarBackpackButton, bagBar, "taschenleiste", "Taschenleiste", "BOTTOMRIGHT", -8, 4, "RIGHT", 230, 48)
    end
    return
  end
  bagCont = BagsBar or MainMenuBarBagManager
  if bagCont then
    -- neuere Clients: ganzen Taschen-Behälter verschieben
    for _, e in ipairs(BAGBTN) do
      local b = _G[e[1]]
      if b then
        local l = bagBar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        l:SetPoint("TOP", b, "BOTTOM", 0, -1); l:SetTextColor(GOLD[1] + .1, GOLD[2] + .1, GOLD[3] + .1)
        bagBtns[#bagBtns + 1] = { b = b, cmd = e[2], l = l }
      end
    end
    pcall(bagCont.SetParent, bagCont, bagBar)
    local function anc()
      if bagCont.thAnchoring then return end
      bagCont.thAnchoring = true
      bagCont:ClearAllPoints(); bagCont:SetPoint("BOTTOMLEFT", bagBar, "BOTTOMLEFT", 8, 18)
      bagCont.thAnchoring = nil
      bagBar:SetSize(math.max(120, (bagCont:GetWidth() or 200) + 16), math.max(40, (bagCont:GetHeight() or 40)) + 24)
    end
    pcall(hooksecurefunc, bagCont, "SetPoint", anc)
    if bagCont.Layout then pcall(hooksecurefunc, bagCont, "Layout", anc) end
    anc()
    for _, e in ipairs(bagBtns) do e.l:SetText(e.cmd == "OPENALLBAGS" and (bindText("OPENALLBAGS") ~= "" and bindText("OPENALLBAGS") or bindText("TOGGLEBACKPACK")) or bindText(e.cmd)) end
    bagBar:Show()
    movable(bagBar, "taschenleiste")
    addExtra(bagBar, "taschenleiste", "BOTTOMRIGHT", -8, 4)
    if NS.applyLayout then NS.applyLayout() end
    return
  end
  for _, e in ipairs(BAGBTN) do
    local b = _G[e[1]]
    if b then
      pcall(b.SetParent, b, bagBar)
      local l = bagBar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
      l:SetPoint("TOP", b, "BOTTOM", 0, -1); l:SetTextColor(GOLD[1] + .1, GOLD[2] + .1, GOLD[3] + .1)
      bagBtns[#bagBtns + 1] = { b = b, cmd = e[2], l = l }
    end
  end
  if #bagBtns == 0 then return end
  bagBar:SetHeight(37 + 24)
  bagBar:Show(); layoutBagBar()
  movable(bagBar, "taschenleiste")
  addExtra(bagBar, "taschenleiste", "BOTTOMRIGHT", -8, 4)
  if NS.applyLayout then NS.applyLayout() end
end

---------------------------------------------------------------------------
-- 4) Ein Taschenfenster für alle Taschen
---------------------------------------------------------------------------
local BAGS = { 0, 1, 2, 3, 4 }
local function numSlots(bag)
  if C_Container and C_Container.GetContainerNumSlots then return safe(C_Container.GetContainerNumSlots, bag) or 0 end
  return safe(GetContainerNumSlots, bag) or 0
end
local function itemInfo(bag, slot)
  if C_Container and C_Container.GetContainerItemInfo then
    local t = safe(C_Container.GetContainerItemInfo, bag, slot)
    if type(t) == "table" then return t.iconFileID, t.stackCount, t.isLocked, t.quality, t.hyperlink, t.itemID end
    return nil
  end
  local tex, count, locked, quality, _, _, link, _, _, id = safe(GetContainerItemInfo, bag, slot)
  return tex, count, locked, quality, link, id
end
local function itemCooldown(bag, slot)
  local fn = (C_Container and C_Container.GetContainerItemCooldown) or GetContainerItemCooldown
  return safe(fn, bag, slot)
end
local function freeSlots()
  local free, total = 0, 0
  local fn = (C_Container and C_Container.GetContainerNumFreeSlots) or GetContainerNumFreeSlots
  for _, bag in ipairs(BAGS) do
    local n = numSlots(bag); total = total + n
    local f, fam = safe(fn, bag)
    if (fam or 0) == 0 then free = free + (f or 0) end
  end
  return free, total
end

local bagWin = CreateFrame("Frame", "TobsiikkHelferTaschen", UIParent, "BackdropTemplate")
bagWin:SetSize(420, 300); bagWin:SetFrameStrata("HIGH"); bagWin:Hide()
bagWin:SetToplevel(true)
if bagWin.SetBackdrop then
  bagWin:SetBackdrop({ edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14 })
  bagWin:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
end
bagWin.bg = bagWin:CreateTexture(nil, "BACKGROUND", nil, -8); bagWin.bg:SetColorTexture(0, 0, 0, 0)
bagWin.bg:SetPoint("TOPLEFT", 3, -3); bagWin.bg:SetPoint("BOTTOMRIGHT", -3, 3)
bagWin.bg:Hide() -- kein Bild mehr: schwarz, leicht durchsichtig
bagWin.shade = bagWin:CreateTexture(nil, "BACKGROUND", nil, -7); bagWin.shade:SetColorTexture(0, 0, 0, .6)
bagWin.shade:SetPoint("TOPLEFT", 3, -3); bagWin.shade:SetPoint("BOTTOMRIGHT", -3, 3)
bagWin.title = bagWin:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); bagWin.title:SetPoint("TOPLEFT", 12, -10)
bagWin.title:SetText("Taschen")
bagWin.money = bagWin:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); bagWin.money:SetPoint("BOTTOMRIGHT", -12, 9)
bagWin.free = bagWin:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); bagWin.free:SetPoint("BOTTOMLEFT", 12, 9)
bagWin.close = CreateFrame("Button", nil, bagWin, "UIPanelCloseButton"); bagWin.close:SetPoint("TOPRIGHT", -2, -2)
-- Suchfeld: passende Gegenstände bleiben hell, alles andere wird abgedunkelt
bagWin.search = CreateFrame("EditBox", "TobsiikkHelferTaschenSuche", bagWin, "InputBoxTemplate")
bagWin.search:SetSize(130, 18); bagWin.search:SetPoint("RIGHT", bagWin.close, "LEFT", -6, 0); bagWin.search:SetAutoFocus(false)
bagWin.search.hint = bagWin.search:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); bagWin.search.hint:SetPoint("LEFT", 4, 0); bagWin.search.hint:SetText("Suchen ...")
bagWin.search:SetScript("OnEscapePressed", function(s) s:SetText(""); s:ClearFocus() end)
bagWin.search:SetScript("OnEnterPressed", function(s) s:ClearFocus() end)

local bagHolders, slots = {}, {}
for _, bag in ipairs(BAGS) do local h = CreateFrame("Frame", "TobsiikkHelferTasche" .. bag, bagWin); h:SetID(bag); h:SetAllPoints(); bagHolders[bag] = h end
local function slotButton(bag, slot)
  slots[bag] = slots[bag] or {}
  local b = slots[bag][slot]
  if b then return b end
  local name = "TobsiikkHelferFach" .. bag .. "_" .. slot
  local ok, nb = pcall(CreateFrame, "ItemButton", name, bagHolders[bag], "ContainerFrameItemButtonTemplate")
  if not ok or not nb then ok, nb = pcall(CreateFrame, "Button", name, bagHolders[bag], "ContainerFrameItemButtonTemplate") end
  if not ok or not nb then nb = CreateFrame("Button", name, bagHolders[bag]) end
  b = nb
  b:SetID(slot); b.bag, b.slot = bag, slot
  b:SetSize(36, 36)
  b.thBg = b:CreateTexture(nil, "BACKGROUND", nil, -1); b.thBg:SetAllPoints(); b.thBg:SetColorTexture(0, 0, 0, .45)
  b.thGold = goldEdge(b, 1, .75)
  local n = b.GetNormalTexture and b:GetNormalTexture(); if type(n) == "table" and n.SetAlpha then pcall(n.SetAlpha, n, 0) end
  slots[bag][slot] = b
  return b
end
-- Kein Leuchten/Schimmern in den Feldern (neue Gegenstände, Suche, Qualität-Glanz)
local GLOW = { "NewItemTexture", "BattlepayItemTexture", "ExtendedSlot", "ItemContextOverlay", "SearchOverlay", "UpgradeIcon",
  "IconOverlay", "IconOverlay2", "IconBorder", "flash", "Flash", "NewItemGlow" }
local function noGlow(b)
  local nm = b.GetName and b:GetName()
  for _, k in ipairs(GLOW) do
    local r = rawget(b, k) or (type(nm) == "string" and _G[nm .. k])
    if type(r) == "table" then pcall(r.Hide, r); pcall(r.SetAlpha, r, 0) end
  end
  for _, k in ipairs({ "newitemglowAnim", "flashAnim" }) do local a = rawget(b, k); if type(a) == "table" and a.Stop then pcall(a.Stop, a) end end
end
local suche = ""
local function itemName(link, id)
  local n = type(link) == "string" and link:match("%[(.-)%]")
  if not n and id then n = (C_Item and C_Item.GetItemNameByID and safe(C_Item.GetItemNameByID, id)) or (GetItemInfo and safe(GetItemInfo, id)) end
  return type(n) == "string" and n:lower() or ""
end
local function questInfo(bag, slot)
  if C_Container and C_Container.GetContainerItemQuestInfo then
    local q = safe(C_Container.GetContainerItemQuestInfo, bag, slot)
    if type(q) == "table" then return q.isQuestItem, q.questID, q.isActive end
  end
  if GetContainerItemQuestInfo then return safe(GetContainerItemQuestInfo, bag, slot) end
end
local function sellPrice(link, id)
  local fn = (C_Item and C_Item.GetItemInfo) or GetItemInfo
  if not fn then return 0 end
  local p = select(11, safe(fn, link or id))
  return type(p) == "number" and p or 0
end
local muellWert = 0
local function mark(b, kind)
  if not b.thMark then
    b.thMark = b:CreateTexture(nil, "OVERLAY", nil, 7); b.thMark:SetSize(14, 14); b.thMark:SetPoint("TOPLEFT", 1, -1)
  end
  if kind == "muell" then b.thMark:SetTexture("Interface\\Buttons\\UI-GroupLoot-Coin-Up"); b.thMark:Show()
  elseif kind == "quest" then b.thMark:SetTexture("Interface\\GossipFrame\\AvailableQuestIcon"); b.thMark:Show()
  else b.thMark:Hide() end
end
local function updateSlot(b)
  local icon, count, locked, quality, link, id = itemInfo(b.bag, b.slot)
  if SetItemButtonTexture then pcall(SetItemButtonTexture, b, icon) elseif b.icon then b.icon:SetTexture(icon) end
  if SetItemButtonCount then pcall(SetItemButtonCount, b, count or 0) end
  if SetItemButtonDesaturated then pcall(SetItemButtonDesaturated, b, locked and true or false) end
  -- Qualität nur als dünner farbiger Rand, sonst Gold
  local c = quality and quality >= 2 and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[quality]
  local isQuest, questID, active = questInfo(b.bag, b.slot)
  local junk = icon and quality == 0
  if b.thGold and b.thGold.SetBackdropBorderColor then
    if isQuest or questID then b.thGold:SetBackdropBorderColor(1, .82, 0, 1)            -- Quest: gelb
    elseif junk then b.thGold:SetBackdropBorderColor(.45, .45, .45, .9)                -- Müll: grau
    elseif c then b.thGold:SetBackdropBorderColor(c.r, c.g, c.b, .9) else b.thGold:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .75) end
  end
  if junk then
    mark(b, "muell"); muellWert = muellWert + sellPrice(link, id) * (count or 1)
    if not locked and SetItemButtonDesaturated then pcall(SetItemButtonDesaturated, b, true) end
  elseif questID and not active then mark(b, "quest") -- startet eine Quest
  else mark(b, nil) end
  if suche ~= "" and icon then b:SetAlpha(itemName(link, id):find(suche, 1, true) and 1 or .2)
  elseif suche ~= "" then b:SetAlpha(.2) else b:SetAlpha(1) end
  noGlow(b)
  -- Auktionspreis aus dem siikk-Auktionshaus (falls installiert) klein oben im Feld
  local ahp = rawget(_G, "SiikkAH_FachPreis"); if type(ahp) == "function" then pcall(ahp, b, b.bag, b.slot, id) end
  local cd = b.Cooldown or _G[(b:GetName() or "") .. "Cooldown"]
  if cd and CooldownFrame_Set then local s, d, e = itemCooldown(b.bag, b.slot); pcall(CooldownFrame_Set, cd, s or 0, d or 0, e) end
  local n = b.GetNormalTexture and b:GetNormalTexture(); if type(n) == "table" and n.SetAlpha then pcall(n.SetAlpha, n, 0) end
end
local function layoutBags()
  muellWert = 0
  local cols = math.max(6, math.min(18, DB.taschenSpalten or 10))
  local i = 0
  for _, bag in ipairs(BAGS) do
    local n = numSlots(bag)
    for slot = 1, n do
      local b = slotButton(bag, slot)
      local col, row = i % cols, math.floor(i / cols)
      b:ClearAllPoints(); b:SetPoint("TOPLEFT", bagWin, "TOPLEFT", 12 + col * 39, -38 - row * 39)
      b:Show(); updateSlot(b)
      i = i + 1
    end
    if slots[bag] then for slot = n + 1, #slots[bag] do slots[bag][slot]:Hide() end end
  end
  local rows = math.max(1, math.ceil(i / cols))
  local w, h = 24 + cols * 39 - 3, 38 + rows * 39 + 30
  bagWin:SetSize(w, h)
  -- Hexer-Bild (2:1) mittig zuschneiden, damit es nicht verzerrt
  local a = w / h
  if a < 2 then local u = a / 2; bagWin.bg:SetTexCoord(.5 - u / 2, .5 + u / 2, 0, 1)
  else local v = 2 / a; bagWin.bg:SetTexCoord(0, 1, .5 - v / 2, .5 + v / 2) end
  local free, total = freeSlots()
  bagWin.free:SetText("Frei: |cffffffff" .. free .. "|r / " .. total ..
    ((muellWert > 0 and GetCoinTextureString) and ("   |cff999999Müll:|r " .. (safe(GetCoinTextureString, muellWert) or "")) or ""))
  bagWin.money:SetText((GetCoinTextureString and GetMoney and safe(GetCoinTextureString, GetMoney())) or "")
end
local function refreshBags() if bagWin:IsShown() then layoutBags() end end
SiikkUITaschenNeu = refreshBags -- das siikk-Auktionshaus frischt nach einem Scan die Preise in den Taschen auf
-- Schnellverkauf beim Händler: alles mit Münzsymbol (graue Gegenstände mit Verkaufswert)
do
  local laeuft = false
  local function haendlerOffen() local m = rawget(_G, "MerchantFrame"); return type(m) == "table" and m.IsShown and m:IsShown() end
  local function benutze(bag, slot)
    if C_Container and C_Container.UseContainerItem then return pcall(C_Container.UseContainerItem, bag, slot) end
    if UseContainerItem then return pcall(UseContainerItem, bag, slot) end
  end
  local function muellListe()
    local liste, summe = {}, 0
    for _, bag in ipairs(BAGS) do
      for slot = 1, numSlots(bag) do
        local icon, count, locked, quality, link, id = itemInfo(bag, slot)
        if icon and quality == 0 and not locked then
          local p = sellPrice(link, id)
          if p > 0 then liste[#liste + 1] = { bag, slot }; summe = summe + p * (count or 1) end
        end
      end
    end
    return liste, summe
  end
  NS.muellErloes = function() local l, s = muellListe(); return s, #l end
  NS.muellVerkaufen = function()
    if laeuft then return end
    if not haendlerOffen() then msg("Schnellverkauf: Bitte zuerst einen Händler ansprechen.") return end
    local liste, summe = muellListe()
    if #liste == 0 then msg("Schnellverkauf: Nichts mit Münzsymbol in den Taschen.") return end
    laeuft = true
    local i = 0
    local function weiter()
      i = i + 1
      if i > #liste or not haendlerOffen() then
        laeuft = false
        local txt = (GetCoinTextureString and safe(GetCoinTextureString, summe)) or tostring(summe)
        msg("Schnellverkauf: " .. (i - 1) .. " Gegenstände verkauft für " .. txt .. ".")
        refreshBags(); return
      end
      benutze(liste[i][1], liste[i][2])
      if C_Timer and C_Timer.After then C_Timer.After(.15, weiter) else weiter() end
    end
    weiter()
  end
end
bagWin.search:SetScript("OnTextChanged", function(s)
  suche = (s:GetText() or ""):lower(); if suche ~= "" then s.hint:Hide() else s.hint:Show() end
  refreshBags()
end)
-- Schwarzer, leicht durchsichtiger Hintergrund für Leisten und Taschen
NS.calmFactor = 1
local function updateCalm()
  local fight = (InCombatLockdown and InCombatLockdown()) or (UnitAffectingCombat and safe(UnitAffectingCombat, "player"))
  NS.calmFactor = (DB and DB.ruheTransparent and not fight) and .45 or 1
  if NS.applyBG then NS.applyBG() end
  if NS.applyChat then pcall(NS.applyChat) end
  for _, m in ipairs(NS.meterFrames or {}) do
    if m and m.SetBackdropColor then pcall(m.SetBackdropColor, m, 0, 0, 0, .6 * NS.calmFactor) end
  end
end
NS.updateCalm = updateCalm
NS.applyBG = function()
  local a = (DB and DB.hintergrund or .6) * (NS.calmFactor or 1)
  for _, f in ipairs({ bar, side, petBar }) do if f.SetBackdropColor then pcall(f.SetBackdropColor, f, 0, 0, 0, a) end end
  bagWin.shade:SetColorTexture(0, 0, 0, a)
end

local function blizzBagsOpen()
  for i = 1, math.max(NUM_CONTAINER_FRAMES or 13, 13) do
    local cf = _G["ContainerFrame" .. i]
    if cf and cf:IsShown() then local id = cf:GetID(); if id and id >= 0 and id <= 4 then return true end end
  end
  if ContainerFrameCombinedBags and ContainerFrameCombinedBags:IsShown() then return true end
  return false
end
local function syncBags()
  if not done.bags then return end
  -- Blizzard-Taschen 0–4 bleiben unsichtbar (dafür gibt es unser Fenster); Schlüsselbund und Bankfächer erscheinen normal
  for i = 1, math.max(NUM_CONTAINER_FRAMES or 13, 13) do
    local cf = _G["ContainerFrame" .. i]
    if cf then
      local id = cf:GetID()
      local mine = id and id >= 0 and id <= 4
      local want = (cf:IsShown() and not mine) and UIParent or hidden
      if cf:GetParent() ~= want then pcall(cf.SetParent, cf, want) end
    end
  end
  if ContainerFrameCombinedBags and ContainerFrameCombinedBags:GetParent() ~= hidden then pcall(ContainerFrameCombinedBags.SetParent, ContainerFrameCombinedBags, hidden) end
  if blizzBagsOpen() then
    if not bagWin:IsShown() then bagWin:Show() end
  elseif bagWin:IsShown() and not (NS.isPlacing and NS.isPlacing()) then
    bagWin.syncHide = true; bagWin:Hide(); bagWin.syncHide = nil
  end
end
bagWin:SetScript("OnShow", function() layoutBags(); if PlaySound and SOUNDKIT and SOUNDKIT.IG_BACKPACK_OPEN then pcall(PlaySound, SOUNDKIT.IG_BACKPACK_OPEN) end end)
bagWin:SetScript("OnHide", function(s)
  if not s.syncHide and blizzBagsOpen() and CloseAllBags then pcall(CloseAllBags) end
  if PlaySound and SOUNDKIT and SOUNDKIT.IG_BACKPACK_CLOSE then pcall(PlaySound, SOUNDKIT.IG_BACKPACK_CLOSE) end
end)
local function syncSoon()
  syncBags()
  if C_Timer and C_Timer.After then C_Timer.After(0, syncBags); C_Timer.After(.1, syncBags) end
end
local function guardFrame(cf)
  if type(cf) ~= "table" or cf.thGuard then return end
  cf.thGuard = true
  -- erscheint ein Blizzard-Taschenfenster doch, wird es sofort wieder versteckt
  if cf.HookScript then cf:HookScript("OnShow", function() syncBags() end) end
  -- hängt Blizzard es selbst zurück auf den Bildschirm, korrigieren wir das
  pcall(hooksecurefunc, cf, "SetParent", function(f, p)
    if f.thFixing or p == hidden then return end
    local id = f.GetID and f:GetID()
    if f == ContainerFrameCombinedBags or (id and id >= 0 and id <= 4) then f.thFixing = true; pcall(f.SetParent, f, hidden); f.thFixing = nil; syncBags() end
  end)
end
local function setupBags()
  if done.bags or not DB.taschenFenster then return end
  done.bags = true
  for _, f in ipairs({ "ToggleBackpack", "ToggleBag", "ToggleAllBags", "OpenAllBags", "CloseAllBags", "OpenBackpack", "CloseBackpack", "OpenBag", "CloseBag" }) do
    if _G[f] then hooksecurefunc(f, syncSoon) end
  end
  for i = 1, math.max(NUM_CONTAINER_FRAMES or 13, 13) do guardFrame(_G["ContainerFrame" .. i]) end
  guardFrame(ContainerFrameCombinedBags)
  if UISpecialFrames then tinsert(UISpecialFrames, "TobsiikkHelferTaschen") end
  movable(bagWin, "taschen")
  addExtra(bagWin, "taschen", "BOTTOMRIGHT", -40, 120)
  if NS.applyLayout then NS.applyLayout() end
  syncBags()
end

---------------------------------------------------------------------------
-- 5) Eigene Erfahrungsleiste (lila, Zahl in der Mitte, Abschnitte wie im Original)
---------------------------------------------------------------------------
local XP_LILA, XP_RUHE = { .62, .22, .95 }, { .35, .55, 1 }
local xp = CreateFrame("Frame", "TobsiikkHelferErfahrung", UIParent, "BackdropTemplate")
xp:SetSize(600, 18); xp:Hide()
if xp.SetBackdrop then
  xp:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
  xp:SetBackdropColor(0, 0, 0, .75); xp:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .9)
end
xp.rest = CreateFrame("StatusBar", nil, xp); xp.rest:SetPoint("TOPLEFT", 2, -2); xp.rest:SetPoint("BOTTOMRIGHT", -2, 2)
xp.rest:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); xp.rest:SetStatusBarColor(XP_RUHE[1], XP_RUHE[2], XP_RUHE[3], .45)
xp.rest:SetMinMaxValues(0, 1); xp.rest:SetValue(0)
xp.bar = CreateFrame("StatusBar", nil, xp); xp.bar:SetAllPoints(xp.rest)
xp.bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); xp.bar:SetStatusBarColor(XP_LILA[1], XP_LILA[2], XP_LILA[3])
xp.bar:SetMinMaxValues(0, 1); xp.bar:SetValue(0); xp.bar:SetFrameLevel(xp.rest:GetFrameLevel() + 1)
xp.shine = xp.bar:CreateTexture(nil, "OVERLAY"); xp.shine:SetColorTexture(1, 1, 1, .18); xp.shine:SetBlendMode("ADD")
xp.shine:SetPoint("TOPLEFT", xp.bar:GetStatusBarTexture(), "TOPLEFT"); xp.shine:SetPoint("TOPRIGHT", xp.bar:GetStatusBarTexture(), "TOPRIGHT"); xp.shine:SetHeight(6)
-- 20 Abschnitte wie bei der originalen Leiste
xp.ticks = {}
local tickHolder = CreateFrame("Frame", nil, xp); tickHolder:SetAllPoints(xp.rest); tickHolder:SetFrameLevel(xp.bar:GetFrameLevel() + 1)
for i = 1, 19 do
  local t = tickHolder:CreateTexture(nil, "OVERLAY"); t:SetColorTexture(0, 0, 0, .7); t:SetWidth(1)
  xp.ticks[i] = t
end
local function placeTicks()
  local w = xp.rest:GetWidth() or 596
  for i, t in ipairs(xp.ticks) do t:ClearAllPoints(); t:SetPoint("TOPLEFT", xp.rest, "TOPLEFT", w * i / 20, 0); t:SetPoint("BOTTOMLEFT", xp.rest, "BOTTOMLEFT", w * i / 20, 0) end
end
xp:SetScript("OnSizeChanged", placeTicks)
xp.text = tickHolder:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); xp.text:SetPoint("CENTER", xp.rest, "CENTER", 0, 0)
do local path = xp.text.GetFont and xp.text:GetFont(); if type(path) ~= "string" then path = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF" end; pcall(xp.text.SetFont, xp.text, path, 12, "OUTLINE") end
local function dots(n)
  n = math.floor(tonumber(n) or 0)
  local s = tostring(n)
  local r = s:reverse():gsub("(%d%d%d)", "%1."):reverse()
  if r:sub(1, 1) == "." then r = r:sub(2) end
  return r
end
local function maxLevel()
  return (GetMaxPlayerLevel and safe(GetMaxPlayerLevel)) or MAX_PLAYER_LEVEL or 60
end
local function updateXP()
  if not done.xp then return end
  local lvl = safe(UnitLevel, "player") or 1
  if lvl >= maxLevel() and not (NS.isPlacing and NS.isPlacing()) then xp:Hide() return end
  local cur, mx, rest = safe(UnitXP, "player") or 0, safe(UnitXPMax, "player") or 1, safe(GetXPExhaustion) or 0
  if mx <= 0 then mx = 1 end
  xp.bar:SetMinMaxValues(0, mx); xp.bar:SetValue(cur)
  xp.rest:SetMinMaxValues(0, mx); xp.rest:SetValue(math.min(mx, cur + rest))
  local pct = math.floor(cur / mx * 1000 + .5) / 10
  local t = dots(cur) .. " / " .. dots(mx) .. "  (" .. tostring(pct):gsub("%.", ",") .. " %)"
  if rest > 0 then t = t .. "  |cff8fb4ffErholt: " .. dots(rest) .. "|r" end
  xp.text:SetText(t)
  xp:Show()
end
xp:EnableMouse(true)
xp:SetScript("OnEnter", function(s)
  GameTooltip:SetOwner(s, "ANCHOR_TOP")
  local cur, mx, rest = safe(UnitXP, "player") or 0, safe(UnitXPMax, "player") or 1, safe(GetXPExhaustion) or 0
  GameTooltip:AddLine("Erfahrung – Stufe " .. (safe(UnitLevel, "player") or "?"))
  GameTooltip:AddDoubleLine("Aktuell:", dots(cur) .. " / " .. dots(mx), 1, 1, 1, 1, 1, 1)
  GameTooltip:AddDoubleLine("Bis zur nächsten Stufe:", dots(mx - cur), 1, 1, 1, 1, .85, .3)
  if rest > 0 then GameTooltip:AddDoubleLine("Erholt (doppelte EP):", dots(rest), 1, 1, 1, .55, .7, 1) end
  GameTooltip:Show()
end)
xp:SetScript("OnLeave", function() GameTooltip:Hide() end)
local function hideBlizzXP()
  if not DB.xpBlizzAus then return end
  local list = { MainMenuExpBar, MainMenuBarMaxLevelBar, MainMenuBarExpText }
  if not MainMenuExpBar then list[#list + 1] = MainStatusTrackingBarContainer; list[#list + 1] = StatusTrackingBarManager end
  for _, f in ipairs(list) do if type(f) == "table" then kill(f) end end
end
local function setupXP()
  if done.xp or not DB.xpLeiste then return end
  done.xp = true
  movable(xp, "erfahrung")
  addExtra(xp, "erfahrung", "BOTTOM", 0, 48)
  hideBlizzXP()
  placeTicks(); updateXP()
  if NS.applyLayout then NS.applyLayout() end
end

---------------------------------------------------------------------------
-- 7) Tooltip: verschiebbar, dunkler Hintergrund mit Horde-Emblem
---------------------------------------------------------------------------
local ttAnker = holder("TobsiikkHelferTooltipAnker", 250, 90)
ttAnker:SetFrameStrata("TOOLTIP"); ttAnker:Hide()
ttAnker.logo = ttAnker:CreateTexture(nil, "ARTWORK"); ttAnker.logo:SetTexture(LOGO); if NS.addLogo then NS.addLogo(ttAnker.logo, LOGO) end
ttAnker.logo:SetSize(80, 80); ttAnker.logo:SetPoint("CENTER"); ttAnker.logo:SetAlpha(.25)
ttAnker.t = ttAnker:CreateFontString(nil, "OVERLAY", "GameFontNormal"); ttAnker.t:SetPoint("CENTER")
ttAnker.t:SetText("Tooltip-Position\n|cffffffffziehen = verschieben|r")
local tips = {}
local function ttLogoAlpha() return DB and (DB.tooltipLogo or .15) or .15 end
local function sizeTipLogo(tt)
  local l = tt and tt.thLogo; if not l then return end
  local w, h = safe(tt.GetWidth, tt), safe(tt.GetHeight, tt)
  if type(w) ~= "number" or type(h) ~= "number" then return end
  if issecretvalue and (issecretvalue(w) or issecretvalue(h)) then return end
  pcall(function() local s = math.max(16, math.min(w, h) - 10); l:SetSize(s, s) end)
end
local function skinTip(tt)
  if type(tt) ~= "table" or tt.thLogo or not tt.CreateTexture then return end
  -- Auf das NineSlice legen (falls vorhanden): dann liegt das Logo über Blizzards Hintergrund,
  -- aber sicher unter Rand und Text.
  local host = (type(tt.NineSlice) == "table" and tt.NineSlice.CreateTexture) and tt.NineSlice or tt
  local dark = host:CreateTexture(nil, "BACKGROUND", nil, 6)
  dark:SetColorTexture(0, 0, 0, .72); dark:SetPoint("TOPLEFT", tt, "TOPLEFT", 3, -3); dark:SetPoint("BOTTOMRIGHT", tt, "BOTTOMRIGHT", -3, 3)
  local l = host:CreateTexture(nil, "BACKGROUND", nil, 7)
  l:SetTexture(LOGO); l:SetPoint("CENTER", tt, "CENTER", 0, 0); l:SetAlpha(ttLogoAlpha())
  if NS.addLogo then NS.addLogo(l, LOGO) end
  tt.thLogo, tt.thDark = l, dark
  tt:HookScript("OnSizeChanged", sizeTipLogo)
  tt:HookScript("OnShow", function(s) sizeTipLogo(s); s.thLogo:SetAlpha(ttLogoAlpha()) end)
  sizeTipLogo(tt)
  tips[#tips + 1] = tt
end
local function refreshTips()
  local on = DB and DB.tooltipEigen
  for _, tt in ipairs(tips) do
    if on then tt.thLogo:Show(); tt.thDark:Show(); tt.thLogo:SetAlpha(ttLogoAlpha()) else tt.thLogo:Hide(); tt.thDark:Hide() end
  end
end
---------------------------------------------------------------------------
-- 8c) Beutefenster: öffnet sich immer an deinem Platz (Kasten „Beute“ im Platzier-Modus verschieben
--     oder das Beutefenster selbst an einer freien Stelle ziehen)
---------------------------------------------------------------------------
local lootAnker = holder("TobsiikkHelferBeuteAnker", 190, 250); lootAnker:Hide()
lootAnker.t = lootAnker:CreateFontString(nil, "OVERLAY", "GameFontNormal"); lootAnker.t:SetPoint("CENTER")
lootAnker.t:SetText("Beute-Fenster\n|cffffffffziehen = verschieben|r")
local function placeLoot()
  local lf = rawget(_G, "LootFrame")
  if not (DB and DB.beuteEigen ~= false and done.loot) or type(lf) ~= "table" or not lf.IsShown then return end
  if InCombatLockdown() and lf.IsProtected and lf:IsProtected() then return end
  pcall(function() lf:ClearAllPoints(); lf:SetPoint("TOPLEFT", lootAnker, "TOPLEFT", 0, 0) end)
end
local function setupLoot()
  local lf = rawget(_G, "LootFrame")
  if done.loot or type(lf) ~= "table" or not lf.HookScript then return end
  if InCombatLockdown() and lf.IsProtected and lf:IsProtected() then pendingUI = true return end
  done.loot = true
  movable(lootAnker, "beute")
  addExtra(lootAnker, "beute", "TOPLEFT", 260, -200)
  local w, h = safe(lf.GetWidth, lf), safe(lf.GetHeight, lf)
  if type(w) == "number" and w > 50 and type(h) == "number" and h > 50 then lootAnker:SetSize(w, h) end
  lf:HookScript("OnShow", function() placeLoot(); if C_Timer and C_Timer.After then C_Timer.After(0, placeLoot) end end)
  for _, fn in ipairs({ "LootFrame_Show", "LootFrame_Update", "UpdateUIPanelPositions" }) do
    if type(rawget(_G, fn)) == "function" then pcall(hooksecurefunc, fn, function() if lf:IsShown() then placeLoot() end end) end
  end
  -- direkt am Beutefenster ziehen: der Platzhalter wandert mit und merkt sich die Stelle
  pcall(lf.SetMovable, lf, true); pcall(lf.SetClampedToScreen, lf, true); pcall(lf.EnableMouse, lf, true); pcall(lf.RegisterForDrag, lf, "LeftButton")
  lf:HookScript("OnDragStart", function(x) if not (InCombatLockdown() and x:IsProtected()) then x:StartMoving() end end)
  lf:HookScript("OnDragStop", function(x)
    pcall(x.StopMovingOrSizing, x); if NS.snapFrame then pcall(NS.snapFrame, x) end
    local l, t = x:GetLeft(), x:GetTop()
    if l and t then
      local sc = (x:GetEffectiveScale() or 1) / (lootAnker:GetEffectiveScale() or 1)
      lootAnker:ClearAllPoints(); lootAnker:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", l * sc, t * sc)
      if NS.savePos then NS.savePos(lootAnker, "beute") end
    end
    placeLoot()
  end)
  if NS.applyLayout then NS.applyLayout() end
end
local function setupTooltip()
  if done.tooltip or not DB.tooltipEigen then refreshTips() return end
  done.tooltip = true
  for _, n in ipairs({ "GameTooltip", "ItemRefTooltip", "ShoppingTooltip1", "ShoppingTooltip2", "EmbeddedItemTooltip" }) do skinTip(_G[n]) end
  movable(ttAnker, "tooltip")
  addExtra(ttAnker, "tooltip", "BOTTOMRIGHT", -40, 200)
  if type(GameTooltip_SetDefaultAnchor) == "function" then
    hooksecurefunc("GameTooltip_SetDefaultAnchor", function(tt)
      if tt ~= GameTooltip or not (DB and DB.tooltipEigen) then return end
      pcall(function() tt:ClearAllPoints(); tt:SetPoint("BOTTOMRIGHT", ttAnker, "BOTTOMRIGHT", 0, 0) end)
    end)
  end
  refreshTips()
  if NS.applyLayout then NS.applyLayout() end
end

---------------------------------------------------------------------------
-- 8) Blizzard-Fenster (Charakter, Zauberbuch, Talente, Questlog, Karte, Menü ...)
--    im gleichen Stil wie das Taschenfenster: Hexer-Bild, abgedunkelt, Goldrand
---------------------------------------------------------------------------
local FENSTER = { "CharacterFrame", "SpellBookFrame", "PlayerSpellsFrame", "PlayerTalentFrame", "TalentFrame", "ClassTalentFrame",
  "QuestLogFrame", "QuestLogDetailFrame", "QuestFrame", "GossipFrame", "WorldMapFrame", "GameMenuFrame", "HelpFrame",
  "FriendsFrame", "GuildFrame", "CommunitiesFrame", "LFGParentFrame", "PVEFrame", "LFDParentFrame", "PVPFrame", "PVPParentFrame",
  "HonorFrame", "BattlefieldFrame", "AchievementFrame", "CollectionsJournal", "EncounterJournal", "MerchantFrame", "MailFrame",
  "OpenMailFrame", "BankFrame", "TradeFrame", "TradeSkillFrame", "CraftFrame", "ProfessionsFrame", "ClassTrainerFrame", "MacroFrame",
  "AuctionFrame", "AuctionHouseFrame", "TaxiFrame", "InspectFrame", "DressUpFrame", "ItemTextFrame", "PetStableFrame", "TabardFrame",
  "GuildRegistrarFrame", "PetitionFrame", "TimeManagerFrame", "KeyBindingFrame", "MacroPopupFrame", "LootFrame" }
-- Bei der Karte nur Rahmen und Kopf, nie die Kartenkacheln selbst
-- Karte: Rahmen, Kopfzeile und Auswahl-Leisten im Addon-Stil; die Kartenfläche selbst (ScrollContainer) bleibt unangetastet
local KARTE = { WorldMapFrame = true }
-- Fenster mit viel Text: fast schwarzer Hintergrund, damit die helle Schrift gut lesbar ist
local LESEN = { QuestLogFrame = true, QuestLogDetailFrame = true, QuestFrame = true, GossipFrame = true, ItemTextFrame = true,
  HelpFrame = true, ClassTrainerFrame = true, TradeSkillFrame = true, CraftFrame = true, MailFrame = true, OpenMailFrame = true, PetitionFrame = true }
local ART = { "ui%-character%-", "paperdoll", "ui%-panel", "ui%-dialogbox", "parchment", "questframe", "ui%-questlog", "questbg",
  "spellbook", "talentframe", "ui%-talent", "talents%-background", "friendsframe", "ui%-worldmap%-", "helpframe", "guildframe",
  "lfgframe", "lfg%-", "achievementframe", "ui%-achievement%-parchment", "honorframe", "battlefieldframe", "merchantframe",
  "mailframe", "taxiframe", "auctionframe", "bankframe", "tradeframe", "tradeskill", "classtrainer", "gossip", "macroframe",
  "petstable", "tabardframe", "ui%-frame%-", "uiframe", "frame%-metal", "ui%-background%-rock", "groupfinder%-background",
  "pvpqueue%-bg", "keybinding", "itemtextframe", "timemanager", "dressupframe", "inspectframe", "petitionframe", "ui%-guildregistrar" }
local SKIP_TYPE = { Button = true, CheckButton = true, Slider = true, EditBox = true, Model = true, PlayerModel = true, DressUpModel = true,
  CinematicModel = true, StatusBar = true, ScrollFrame = true, Cooldown = true, MessageFrame = true, ScrollingMessageFrame = true, SimpleHTML = true, GameTooltip = true }
local skinned = {}
local function lower(v) if type(v) == "string" then return v:lower() end return "" end
local function isArt(tex)
  local path = lower(safe(tex.GetTexture, tex)) .. " " .. lower(tex.GetTextureFilePath and safe(tex.GetTextureFilePath, tex))
  local atlas = lower(tex.GetAtlas and safe(tex.GetAtlas, tex))
  for _, p in ipairs(ART) do if path:find(p) or atlas:find(p) then return true end end
  local layer = safe(tex.GetDrawLayer, tex)
  if layer == "HIGHLIGHT" or layer == "OVERLAY" then return false end -- Leuchten, Markierungen
  local w, h = safe(tex.GetWidth, tex), safe(tex.GetHeight, tex)
  if type(w) ~= "number" or type(h) ~= "number" or (issecretvalue and (issecretvalue(w) or issecretvalue(h))) then return false end
  local big, small = math.max(w, h), math.min(w, h)
  if big <= 48 and small >= big * .7 then return false end -- kleine, quadratische Symbole bleiben
  -- alles Große (Pergament, Seiten, Rahmenstücke, Trennlinien) verschwindet – egal wie Blizzard die Datei benennt
  return big >= 64 or layer == "BACKGROUND" or layer == "BORDER"
end
local hiddenCount = {}
local curWin
local function hideTex(t) if not t.thStil then t.thStil = true; if curWin then hiddenCount[curWin] = (hiddenCount[curWin] or 0) + 1 end end; pcall(t.SetAlpha, t, 0) end
local function strip(fr, depth, owner)
  if type(fr) ~= "table" or depth > 4 or not fr.GetRegions then return end
  for _, r in ipairs({ safe(fr.GetRegions, fr) }) do
    if type(r) == "table" and r ~= owner.thSkin and safe(r.GetObjectType, r) == "Texture" and not r.thKeep and isArt(r) then hideTex(r) end
  end
  for _, k in ipairs({ "NineSlice", "Bg", "Background", "TitleBg", "TopTileStreaks", "PortraitContainer", "portrait", "Portrait", "PortraitFrame", "PortraitButton", "Border" }) do
    local c = rawget(fr, k); if type(c) == "table" and c ~= owner.thSkin and c.SetAlpha then pcall(c.SetAlpha, c, 0) end
  end
  local n = safe(fr.GetName, fr)
  if type(n) == "string" then local p = _G[n .. "Portrait"]; if type(p) == "table" and p.SetAlpha then pcall(p.SetAlpha, p, 0) end end
  for _, c in ipairs({ safe(fr.GetChildren, fr) }) do
    if type(c) == "table" and c ~= owner.thSkin and not rawget(c, "thNoStrip") and not SKIP_TYPE[safe(c.GetObjectType, c) or ""] then strip(c, depth + 1, owner) end
  end
end
-- dunkle (braune) Schrift auf hellem Pergament -> hell machen, damit sie auf dem dunklen Hintergrund lesbar ist
-- Rahmen der Blizzard-Fenster und ihrer Kästen folgen der gewählten Rahmenfarbe.
-- Bei sehr dunklen Farben (z. B. Schwarz) leicht gelblich, sonst sieht man auf dem dunklen Fenster keinen Rahmen.
local fensterRahmen = {}
local function fensterFarbe()
  local r, g, b = GOLD[1], GOLD[2], GOLD[3]
  if r + g + b < .45 then return .95, .85, .45 end
  return r, g, b
end
local function merkRahmen(fr, a)
  if type(fr) ~= "table" or not fr.SetBackdropBorderColor then return end
  fensterRahmen[#fensterRahmen + 1] = { fr, a or 1 }
  local r, g, b = fensterFarbe(); pcall(fr.SetBackdropBorderColor, fr, r, g, b, a or 1)
end
do
  local prev = NS.onRahmenFarbe
  NS.onRahmenFarbe = function()
    if prev then pcall(prev) end
    local r, g, b = fensterFarbe()
    for _, e in ipairs(fensterRahmen) do pcall(e[1].SetBackdropBorderColor, e[1], r, g, b, e[2]) end
  end
end
NS.fensterFarbe = fensterFarbe
local function lighten(fr, budget)
  if type(fr) ~= "table" or budget.n <= 0 or not fr.GetRegions then return end
  budget.n = budget.n - 1
  for _, r in ipairs({ safe(fr.GetRegions, fr) }) do
    if type(r) == "table" and safe(r.GetObjectType, r) == "FontString" then
      local cr, cg, cb = safe(r.GetTextColor, r)
      if type(cr) == "number" and not (issecretvalue and issecretvalue(cr)) and cr + cg + cb < 1.05 then pcall(r.SetTextColor, r, .95, .9, .78) end
    end
  end
  -- Auswahl-Knöpfe (Gesprächs-Optionen, Quests beim NPC): Schrift gold statt schwarz – auch wenn Blizzard die Farbe in den Text schreibt
  if safe(fr.GetObjectType, fr) == "Button" then
    local fs = safe(fr.GetFontString, fr)
    if type(fs) == "table" then
      local cr, cg, cb = safe(fs.GetTextColor, fs)
      if type(cr) == "number" and not (issecretvalue and issecretvalue(cr)) and cr + cg + cb < 1.05 then pcall(fs.SetTextColor, fs, 1, .82, 0) end
      local t = safe(fs.GetText, fs)
      if type(t) == "string" and not (issecretvalue and issecretvalue(t)) and t:find("|c", 1, true) then
        local neu = t:gsub("|c(%x%x)(%x%x)(%x%x)(%x%x)", function(a, r, g, b)
          if tonumber(r, 16) + tonumber(g, 16) + tonumber(b, 16) < 270 then return "|cffffd100" end
        end)
        if neu ~= t then pcall(fs.SetText, fs, neu) end
      end
    end
  end
  for _, c in ipairs({ safe(fr.GetChildren, fr) }) do if type(c) == "table" and safe(c.IsShown, c) then lighten(c, budget) end end
end
local function skinWindow(name)
  local f = _G[name]
  if skinned[name] or type(f) ~= "table" or not f.CreateTexture or not f.HookScript then return end
  if InCombatLockdown() then pendingUI = true return end
  skinned[name] = true
  local s = CreateFrame("Frame", nil, f, "BackdropTemplate"); f.thSkin = s
  local l, r, t, b = safe(f.GetHitRectInsets, f)
  l, r, t, b = tonumber(l) or 0, tonumber(r) or 0, tonumber(t) or 0, tonumber(b) or 0
  s:SetPoint("TOPLEFT", f, "TOPLEFT", l, -t); s:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -r, b)
  s:SetFrameLevel(math.max(0, (safe(f.GetFrameLevel, f) or 1) - 1)); s:EnableMouse(false)
  if s.SetBackdrop then
    s:SetBackdrop({ edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14 })
    merkRahmen(s, 1)
  end
  s.bg = s:CreateTexture(nil, "BACKGROUND", nil, -8); s.bg:SetColorTexture(.05, .04, .07, 1); s.bg:SetPoint("TOPLEFT", 3, -3); s.bg:SetPoint("BOTTOMRIGHT", -3, 3)
  -- Fraktions-Logo (Horde/Allianz) mittig im Hintergrund – wechselt mit dem Logo-Schalter in den Einstellungen
  s.logo = s:CreateTexture(nil, "BACKGROUND", nil, -6); s.logo:SetPoint("CENTER", s, "CENTER", 0, -10); s.logo:SetAlpha(.22); s.logo.thKeep = true
  if NS.addLogo then NS.addLogo(s.logo, LOGO) else s.logo:SetTexture(LOGO) end
  s.shade = s:CreateTexture(nil, "BACKGROUND", nil, -7); s.shade:SetAllPoints(s.bg)
  if LESEN[name] then s.shade:SetColorTexture(.03, .02, .05, .9) else s.shade:SetColorTexture(0, 0, 0, .7) end
  if LESEN[name] then s.logo:SetAlpha(.1) end -- bei Lese-Fenstern (Quests, Bücher) zurückhaltender
  s.bg.thKeep, s.shade.thKeep = true, true
  -- Rahmen in Goldoptik, eine Ebene über dem Inhalt, damit er überall sichtbar ist
  local edge = CreateFrame("Frame", nil, f, "BackdropTemplate"); edge:SetAllPoints(s); edge:EnableMouse(false)
  edge:SetFrameLevel((safe(f.GetFrameLevel, f) or 1) + 15)
  if edge.SetBackdrop then edge:SetBackdrop({ edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14 }); merkRahmen(edge, 1) end
  local function fit()
    local w, h = safe(s.GetWidth, s), safe(s.GetHeight, s)
    if type(w) ~= "number" or type(h) ~= "number" or w <= 0 or h <= 0 then return end
    local q = math.min(w, h) * .72; s.logo:SetSize(q, q)
  end
  s:SetScript("OnSizeChanged", fit)
  local function restyle()
    if not (DB and DB.fensterStil) then return end
    if not InCombatLockdown() then
      curWin = name; strip(f, 0, f); curWin = nil
    end
    if not KARTE[name] then lighten(f, { n = 400 }) end
  end
  -- Knöpfe, die unten aus dem Fenster ragen (z. B. „Quest abbrechen“, „Verlassen“), mit in den Rahmen nehmen
  local function knoepfeEinrahmen()
    if InCombatLockdown() then return end
    local sb, sl, sr = safe(s.GetBottom, s), safe(s.GetLeft, s), safe(s.GetRight, s)
    if type(sb) ~= "number" or type(sl) ~= "number" or type(sr) ~= "number" then return end
    local low = sb
    for _, c in ipairs({ safe(f.GetChildren, f) }) do
      if type(c) == "table" and c ~= s and safe(c.GetObjectType, c) == "Button" and safe(c.IsShown, c) then
        local cb, cx = safe(c.GetBottom, c), select(1, safe(c.GetCenter, c))
        if type(cb) == "number" and type(cx) == "number" and cx > sl and cx < sr and cb < low and cb > sb - 60 then low = cb end
      end
    end
    if low < sb then
      local extra = (sb - low) + 5
      s:ClearAllPoints(); s:SetPoint("TOPLEFT", f, "TOPLEFT", l, -t); s:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -r, b - extra)
    end
  end
  f:HookScript("OnShow", function() fit(); restyle(); if C_Timer and C_Timer.After then C_Timer.After(.05, restyle); C_Timer.After(.1, knoepfeEinrahmen) else knoepfeEinrahmen() end end)
  local acc = 0
  if not KARTE[name] then s:SetScript("OnUpdate", function(_, el) acc = acc + (el or 0); if acc > .5 then acc = 0; lighten(f, { n = 400 }) end end) end
  if name == "QuestLogFrame" then
    -- Questliste (oben) in einen eigenen Kasten mit Rahmen setzen, damit sie sich klar von der Beschreibung abhebt
    local list = rawget(_G, "QuestLogListScrollFrame") or rawget(_G, "QuestLogScrollFrame") or rawget(f, "ScrollFrame")
    if type(list) == "table" and list.GetObjectType then
      local bar = rawget(list, "ScrollBar") or rawget(_G, (list:GetName() or "") .. "ScrollBar")
      local box = CreateFrame("Frame", nil, f, "BackdropTemplate"); f.thQuestKasten = box; box.thNoStrip = true
      box:SetPoint("TOPLEFT", list, "TOPLEFT", -8, 6)
      box:SetPoint("BOTTOMRIGHT", (type(bar) == "table" and bar.GetObjectType) and bar or list, "BOTTOMRIGHT", 6, -6)
      box:EnableMouse(false); box:SetFrameLevel(math.max(0, (safe(list.GetFrameLevel, list) or 2) - 1))
      if box.SetBackdrop then
        box:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
        box:SetBackdropColor(0, 0, 0, .55); merkRahmen(box, .9)
      end
      box.t = box:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); box.t:SetPoint("BOTTOMLEFT", box, "TOPLEFT", 6, 2)
    end
  end
  -- Lehrer und Berufe: Liste (oben) und Erklärung mit Bild (unten) je in einen eigenen Kasten mit Goldrahmen
  local KAESTEN = {
    ClassTrainerFrame = { "ClassTrainerExpandButtonFrame", "ClassTrainerListScrollFrame", "ClassTrainerDetailScrollFrame" },
    TradeSkillFrame = { "TradeSkillExpandButtonFrame", "TradeSkillListScrollFrame", "TradeSkillDetailScrollFrame" },
    CraftFrame = { nil, "CraftListScrollFrame", "CraftDetailScrollFrame" },
  }
  local K = KAESTEN[name]
  if K then
    local function kasten(oben, unten, x1, y1, x2, y2)
      if type(oben) ~= "table" or not oben.GetObjectType or type(unten) ~= "table" or not unten.GetObjectType then return nil end
      local box = CreateFrame("Frame", nil, f, "BackdropTemplate"); box.thNoStrip = true
      box:SetPoint("TOPLEFT", oben, "TOPLEFT", x1, y1); box:SetPoint("BOTTOMRIGHT", unten, "BOTTOMRIGHT", x2, y2)
      box:EnableMouse(false); box:SetFrameLevel(math.max(0, (safe(unten.GetFrameLevel, unten) or 2) - 1))
      if box.SetBackdrop then
        box:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
        box:SetBackdropColor(0, 0, 0, .55); merkRahmen(box, .9)
      end
      return box
    end
    local kopf, liste, info = K[1] and rawget(_G, K[1]), rawget(_G, K[2]), rawget(_G, K[3])
    -- Liste samt „Alle“-Zeile oben; rechts Platz für den Rollbalken
    f.thListKasten = kasten((type(kopf) == "table" and kopf.GetObjectType) and kopf or liste, liste, -4, 4, 28, -4)
    -- Erklärung, Bild, Kosten
    f.thInfoKasten = kasten(info, info, -6, 6, 28, -4)
  end
  -- Händler (Kaufen/Rückkauf): jedes Angebot in einem eigenen Kasten, dazu der Schnellverkauf-Knopf
  -- Auktionshaus: Blizzard-Steinbilder weg, flache Knöpfe und Reiter, Bereiche in eigenen Kästen
  if name == "AuctionFrame" then
    local function G(n) local x = rawget(_G, n); if type(x) == "table" and x.GetObjectType then return x end end
    local function weg(r) if type(r) == "table" and r.SetAlpha then pcall(r.SetAlpha, r, 0); r.thStil = true end end
    local function ahKasten(parent, a)
      local box = CreateFrame("Frame", nil, parent, "BackdropTemplate"); box.thNoStrip = true; box:EnableMouse(false)
      box:SetFrameLevel(math.max(0, (safe(parent.GetFrameLevel, parent) or 2)))
      if box.SetBackdrop then
        box:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
        box:SetBackdropColor(0, 0, 0, a or .5); merkRahmen(box, .9)
      end
      return box
    end
    -- flacher Knopf: Blizzard-Teilbilder ausblenden (Pfeil und Leuchten bleiben), dunkler Grund mit Goldrand
    local function flach(b, hell)
      if type(b) ~= "table" or not b.GetRegions or b.thFlach then return end
      b.thFlach = true
      for _, r in ipairs({ safe(b.GetRegions, b) }) do
        if type(r) == "table" and safe(r.GetObjectType, r) == "Texture" then
          local nm = (safe(r.GetName, r) or ""):lower(); local lay = safe(r.GetDrawLayer, r)
          if lay ~= "HIGHLIGHT" and not nm:find("arrow") and not nm:find("icon") then weg(r) end
        end
      end
      for _, k in ipairs({ "GetNormalTexture", "GetPushedTexture", "GetDisabledTexture" }) do local t = b[k] and safe(b[k], b); if type(t) == "table" then weg(t) end end
      local hl = b.GetHighlightTexture and safe(b.GetHighlightTexture, b)
      if type(hl) == "table" and hl.SetColorTexture then pcall(hl.SetColorTexture, hl, 1, .82, 0, .18); pcall(hl.SetBlendMode, hl, "ADD") end
      local bg = CreateFrame("Frame", nil, b, "BackdropTemplate"); bg:SetAllPoints(); bg:EnableMouse(false)
      bg:SetFrameLevel(math.max(0, (safe(b.GetFrameLevel, b) or 1) - 1)); b.thBg = bg
      if bg.SetBackdrop then
        bg:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
        bg:SetBackdropColor(.06, .04, .09, hell and .9 or .75); merkRahmen(bg, .55)
      end
    end
    -- große Hintergrundbilder des Auktionshauses (auch beim Reiterwechsel neu gesetzt → nur unsichtbar machen)
    for _, n in ipairs({ "AuctionFrameTopLeft", "AuctionFrameTop", "AuctionFrameTopRight", "AuctionFrameBotLeft", "AuctionFrameBot", "AuctionFrameBotRight", "AuctionPortraitTexture" }) do weg(G(n)) end
    for _, n in ipairs({ "AuctionFrameBrowse", "AuctionFrameBid", "AuctionFrameAuctions" }) do
      local fr = G(n)
      if fr then for _, r in ipairs({ safe(fr.GetRegions, fr) }) do
        if type(r) == "table" and safe(r.GetObjectType, r) == "Texture" and not r.thKeep then
          local lay = safe(r.GetDrawLayer, r); if lay == "BACKGROUND" or lay == "BORDER" or lay == "ARTWORK" then weg(r) end
        end
      end end
    end
    -- Kategorien links, Spaltenköpfe, Reiter
    for i = 1, 20 do flach(G("AuctionFilterButton" .. i)) end
    for _, n in ipairs({ "BrowseQualitySort", "BrowseLevelSort", "BrowseDurationSort", "BrowseHighBidderSort", "BrowseCurrentBidSort",
      "BidQualitySort", "BidLevelSort", "BidDurationSort", "BidBuyoutSort", "BidStatusSort", "BidBidSort",
      "AuctionsQualitySort", "AuctionsDurationSort", "AuctionsHighBidderSort", "AuctionsBidSort" }) do flach(G(n), true) end
    local function reiterFarbe()
      for i = 1, 6 do
        local t = G("AuctionFrameTab" .. i)
        if t and t.thBg then
          local an = (f.selectedTab == i) or (PanelTemplates_GetSelectedTab and safe(PanelTemplates_GetSelectedTab, f) == i)
          t.thBg:SetBackdropColor(an and .32 or .06, an and .12 or .04, an and .45 or .09, .95)
          local fs = t.GetFontString and safe(t.GetFontString, t); if type(fs) == "table" then pcall(fs.SetTextColor, fs, 1, an and .9 or .82, an and .5 or 0) end
        end
      end
    end
    for i = 1, 6 do local t = G("AuctionFrameTab" .. i); if t then flach(t, true); t:HookScript("OnClick", reiterFarbe) end end
    if type(rawget(_G, "PanelTemplates_SetTab")) == "function" then pcall(hooksecurefunc, "PanelTemplates_SetTab", function(fr) if fr == f then reiterFarbe() end end) end
    f:HookScript("OnShow", function() if C_Timer and C_Timer.After then C_Timer.After(0, reiterFarbe) else reiterFarbe() end end)
    -- Kästen: Kategorien, Ergebnisliste, untere Leiste (je Reiter)
    local function k(parent, a, p1, x1, y1, p2, x2, y2, rechts, rx)
      if not (parent and p1 and p2) then return end
      local b = ahKasten(parent, a); b:SetPoint("TOPLEFT", p1, "TOPLEFT", x1, y1); b:SetPoint("BOTTOMRIGHT", p2, "BOTTOMRIGHT", x2, y2)
      if rechts then b:SetPoint("RIGHT", rechts, "RIGHT", rx or 0, 0) end
      return b
    end
    -- Ergebnisliste: oben an den Spaltenköpfen, rechts innerhalb des Fensters, unten mit Abstand über der unteren Leiste
    local function liste(parent, kopf, unten, links)
      if not (parent and kopf and unten) then return end
      local b = ahKasten(parent, .45)
      b:SetPoint("TOP", kopf, "TOP", 0, 3); b:SetPoint("LEFT", links or kopf, "LEFT", links and 0 or -3, 0)
      b:SetPoint("RIGHT", f, "RIGHT", -12, 0); b:SetPoint("BOTTOM", unten, "TOP", 0, 14)
      return b
    end
    local br, bd, au = G("AuctionFrameBrowse"), G("AuctionFrameBid"), G("AuctionFrameAuctions")
    -- Kategorien links: unten auf gleicher Höhe wie die Ergebnisliste
    local kat = G("AuctionFilterButton1")
    if br and kat and G("BrowseBidPrice") then
      local b = ahKasten(br, .45)
      b:SetPoint("TOPLEFT", kat, "TOPLEFT", -5, 5); b:SetPoint("RIGHT", kat, "RIGHT", 4, 0)
      b:SetPoint("BOTTOM", G("BrowseBidPrice"), "TOP", 0, 14)
    end
    liste(br, G("BrowseQualitySort"), G("BrowseBidPrice"))
    -- untere Leisten: enden über den Reitern, rechts innerhalb des Fensters
    local function leiste(parent, a, p1, x1, y1, p2, y2)
      if not (parent and p1 and p2) then return end
      local b = ahKasten(parent, a); b:SetPoint("TOPLEFT", p1, "TOPLEFT", x1, y1)
      b:SetPoint("BOTTOM", p2, "BOTTOM", 0, y2); b:SetPoint("RIGHT", f, "RIGHT", -12, 0)
      return b
    end
    leiste(br, .55, G("BrowseBidPrice"), -10, 8, G("BrowseCloseButton"), -2)
    liste(bd, G("BidQualitySort"), G("BidBidPrice"))
    leiste(bd, .55, G("BidBidPrice"), -10, 8, G("BidCloseButton"), -2)
    liste(au, G("AuctionsQualitySort"), G("AuctionsCancelAuctionButton"))
    k(au, .45, G("AuctionsItemButton"), -14, 26, G("AuctionsCreateAuctionButton"), 14, -8)
    leiste(au, .55, G("AuctionsCancelAuctionButton"), -6, 6, G("AuctionsCloseButton"), -2)
  end
  if name == "MerchantFrame" then
    local function kastenStil(box, a)
      box.thNoStrip = true; box:EnableMouse(false)
      if box.SetBackdrop then
        box:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
        box:SetBackdropColor(0, 0, 0, a or .55); merkRahmen(box, .9)
      end
    end
    local function feldKasten(it, nameFS)
      if type(it) ~= "table" or not it.GetObjectType or rawget(it, "thKasten") then return end
      local box = CreateFrame("Frame", nil, f, "BackdropTemplate"); it.thKasten = box
      box:SetPoint("TOPLEFT", it, "TOPLEFT", -4, 4); box:SetPoint("BOTTOMRIGHT", it, "BOTTOMRIGHT", 4, -4)
      box:SetFrameLevel(math.max(0, (safe(it.GetFrameLevel, it) or 2) - 1)); kastenStil(box)
      -- leere Plätze (Seite hat weniger Waren) bekommen keinen Kasten
      local function sicht()
        local t = type(nameFS) == "table" and safe(nameFS.GetText, nameFS)
        box:SetShown((safe(it.IsShown, it) and true or false) and (nameFS == nil or (type(t) == "string" and t ~= "")))
      end
      it.thKastenSicht = sicht; sicht()
      if it.HookScript then it:HookScript("OnShow", sicht); it:HookScript("OnHide", sicht) end
    end
    local felder = {}
    for i = 1, 12 do local it = rawget(_G, "MerchantItem" .. i); if it then felder[#felder + 1] = it; feldKasten(it, rawget(_G, "MerchantItem" .. i .. "Name")) end end
    local bb = rawget(_G, "MerchantBuyBackItem"); feldKasten(bb, rawget(_G, "MerchantBuyBackItemName"))
    -- Blizzard-Rahmenstücke unten (Reparatur-/Rückkauf-Bereich) ausblenden – stattdessen ein sauberer Kasten
    for _, n in ipairs({ "MerchantFrameBottomLeftBorder", "MerchantFrameBottomRightBorder", "BuybackBG", "MerchantMoneyBg", "MerchantMoneyInset",
      "MerchantExtraCurrencyBg", "MerchantExtraCurrencyInset", "MerchantFrameInset" }) do
      local r = rawget(_G, n); if type(r) == "table" and r.SetAlpha then pcall(r.SetAlpha, r, 0); r.thStil = true end
    end
    -- Schnellverkaufen: unten rechts, mit Erlös
    local vk = CreateFrame("Button", "TobsiikkHelferSchnellverkauf", f, "UIPanelButtonTemplate"); vk.thNoStrip = true
    vk:SetSize(140, 22); vk:SetPoint("BOTTOMRIGHT", s, "BOTTOMRIGHT", -16, 14); vk:SetFrameLevel((safe(f.GetFrameLevel, f) or 1) + 16)
    vk:SetText("Schnellverkaufen")
    vk.erl = vk:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); vk.erl:SetPoint("BOTTOMRIGHT", vk, "TOPRIGHT", -2, 5); vk.erl:SetJustifyH("RIGHT")
    local function erloesZeigen()
      local summe, n = 0, 0
      if NS.muellErloes then summe, n = NS.muellErloes() end
      if n > 0 then
        vk.erl:SetText("|cffffd100Erlös:|r " .. ((GetCoinTextureString and safe(GetCoinTextureString, summe)) or tostring(summe)) .. " |cff999999(" .. n .. ")|r"); vk:Enable()
      else vk.erl:SetText("|cff999999Nichts mit Münzsymbol|r"); vk:Disable() end
    end
    vk:SetScript("OnClick", function() if NS.muellVerkaufen then NS.muellVerkaufen() end; if C_Timer and C_Timer.After then C_Timer.After(1, erloesZeigen); C_Timer.After(3, erloesZeigen) end end)
    vk:SetScript("OnEnter", function(b)
      GameTooltip:SetOwner(b, "ANCHOR_TOP"); GameTooltip:SetText("Schnellverkaufen")
      GameTooltip:AddLine("Verkauft alles, was in deinen Taschen ein Münzsymbol hat (graue Gegenstände).", 1, 1, 1, true); GameTooltip:Show()
    end)
    vk:SetScript("OnLeave", function() GameTooltip:Hide() end)
    vk:RegisterEvent("BAG_UPDATE"); vk:RegisterEvent("MERCHANT_SHOW")
    vk:SetScript("OnEvent", function() if f:IsShown() then erloesZeigen() end end)
    f:HookScript("OnShow", erloesZeigen)
    -- eigenes Geld links neben den Knopf
    local geld = rawget(_G, "MerchantMoneyFrame")
    local function geldPlatz() if type(geld) == "table" and geld.ClearAllPoints and not InCombatLockdown() then pcall(function() geld:ClearAllPoints(); geld:SetPoint("RIGHT", vk, "LEFT", 4, 0) end) end end
    -- unterer Bereich (Reparatur, Rückkauf, Geld, Schnellverkauf) als ein gemeinsamer Kasten
    local unten = CreateFrame("Frame", nil, f, "BackdropTemplate"); f.thUntenKasten = unten
    unten:SetPoint("LEFT", s, "LEFT", 10, 0); unten:SetPoint("RIGHT", s, "RIGHT", -10, 0)
    if type(bb) == "table" and bb.GetObjectType then unten:SetPoint("TOP", bb, "TOP", 0, 12) end
    unten:SetPoint("BOTTOM", vk, "BOTTOM", 0, -6)
    unten:SetFrameLevel(math.max(0, (safe(f.GetFrameLevel, f) or 2))); kastenStil(unten, .35)
    local function aktualisieren()
      for _, it in ipairs(felder) do if it.thKastenSicht then it.thKastenSicht() end end
      if type(bb) == "table" and bb.thKastenSicht then bb.thKastenSicht() end
      geldPlatz(); erloesZeigen()
    end
    for _, fn in ipairs({ "MerchantFrame_Update", "MerchantFrame_UpdateMerchantInfo", "MerchantFrame_UpdateBuybackInfo" }) do
      if type(rawget(_G, fn)) == "function" then pcall(hooksecurefunc, fn, aktualisieren) end
    end
    f:HookScript("OnShow", function() if C_Timer and C_Timer.After then C_Timer.After(0, aktualisieren) else aktualisieren() end end)
    aktualisieren()
  end
  -- NPC-Gespräch und Quest-Fenster: Textbereich (samt Auswahl) in einen Kasten mit Goldrahmen
  local TEXTE = {
    GossipFrame = { "GossipGreetingScrollFrame" },
    QuestFrame = { "QuestGreetingScrollFrame", "QuestDetailScrollFrame", "QuestProgressScrollFrame", "QuestRewardScrollFrame" },
  }
  local function textKasten(sc, bar)
    if type(sc) ~= "table" or not sc.GetObjectType or rawget(sc, "thKasten") then return end
    local host = safe(sc.GetParent, sc) or f
    local box = CreateFrame("Frame", nil, host, "BackdropTemplate"); box.thNoStrip = true; sc.thKasten = box
    -- links/rechts innerhalb des Fensters bleiben, oben/unten am Textbereich (bzw. Rollbalken) ausrichten
    local hatBar = type(bar) == "table" and bar.GetObjectType
    box:SetPoint("TOP", hatBar and bar or sc, "TOP", 0, 6)
    box:SetPoint("BOTTOM", hatBar and bar or sc, "BOTTOM", 0, -4)
    box:SetPoint("LEFT", s, "LEFT", 10, 0); box:SetPoint("RIGHT", s, "RIGHT", -10, 0)
    box:EnableMouse(false); box:SetFrameLevel(math.max(0, (safe(sc.GetFrameLevel, sc) or 2) - 1))
    if box.SetBackdrop then
      box:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
      box:SetBackdropColor(0, 0, 0, .5); merkRahmen(box, .9)
    end
    -- nur sichtbar, solange der Textbereich zu sehen ist (Quest-Fenster wechselt zwischen Seiten)
    box:SetShown(safe(sc.IsShown, sc) and true or false)
    if sc.HookScript then sc:HookScript("OnShow", function() box:Show() end); sc:HookScript("OnHide", function() box:Hide() end) end
  end
  if TEXTE[name] then
    for _, n in ipairs(TEXTE[name]) do textKasten(rawget(_G, n)) end
    -- neues Gesprächsfenster (Classic 1.15 / Midnight): GreetingPanel mit ScrollBox
    local gp = rawget(f, "GreetingPanel")
    if type(gp) == "table" then textKasten(rawget(gp, "ScrollBox"), rawget(gp, "ScrollBar")) end
  end
  if KARTE[name] then
    -- kein Hexer-Bild hinter der Karte: schwarz, leicht durchsichtig wie Leisten und Taschen, mit Goldrand
    s.bg:Hide(); s.logo:Hide(); s.shade:SetColorTexture(0, 0, 0, .85)
    local cont = rawget(f, "ScrollContainer")
    if type(cont) == "table" and cont.GetObjectType then
      local ce = CreateFrame("Frame", nil, f, "BackdropTemplate"); ce:SetPoint("TOPLEFT", cont, "TOPLEFT", -2, 2); ce:SetPoint("BOTTOMRIGHT", cont, "BOTTOMRIGHT", 2, -2)
      ce:EnableMouse(false); ce:SetFrameLevel((safe(f.GetFrameLevel, f) or 1) + 14)
      if ce.SetBackdrop then ce:SetBackdrop({ edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 }); merkRahmen(ce, .8) end
    end
  end
  -- Charakterfenster: Horde-Emblem hinter der sich bewegenden Figur
  if name == "CharacterFrame" then
    local m = rawget(_G, "CharacterModelScene") or rawget(_G, "CharacterModelFrame")
    local host = type(m) == "table" and safe(m.GetParent, m)
    if type(host) == "table" and host.CreateTexture then
      local lg = host:CreateTexture(nil, "ARTWORK", nil, 7); lg:SetTexture(LOGO); lg.thKeep = true; if NS.addLogo then NS.addLogo(lg, LOGO) end
      lg:SetPoint("CENTER", m, "CENTER", 0, 10); lg:SetAlpha(.7); f.thFigurLogo = lg
      local function sz()
        local w, h = safe(m.GetWidth, m), safe(m.GetHeight, m)
        if type(w) == "number" and type(h) == "number" and w > 0 and h > 0 then local q = math.min(w, h) * .85; lg:SetSize(q, q) end
      end
      sz(); if m.HookScript then m:HookScript("OnSizeChanged", sz); m:HookScript("OnShow", sz) end
    end
  end
  fit(); if safe(f.IsShown, f) then restyle() end
end
-- Quest-Texte sofort hell machen, sobald Blizzard sie neu füllt (sonst kurz dunkel)
local questHooks = false
local function hookQuestText()
  if questHooks then return end
  questHooks = true
  for _, fn in ipairs({ "QuestInfo_Display", "QuestLog_UpdateQuestDetails", "QuestLog_Update", "QuestFrameDetailPanel_OnShow", "QuestFrameProgressPanel_OnShow",
    "QuestFrameRewardPanel_OnShow", "QuestFrameGreetingPanel_OnShow", "GossipFrameUpdate", "ItemTextFrame_OnEvent", "QuestFrame_SetMaterial", "QuestFrame_SetTextColor" }) do
    if type(rawget(_G, fn)) == "function" then
      pcall(hooksecurefunc, fn, function()
        if not (DB and DB.fensterStil) then return end
        for n in pairs(LESEN) do local f = rawget(_G, n); if type(f) == "table" and safe(f.IsShown, f) then lighten(f, { n = 400 }) end end
      end)
    end
  end
end
local function skinAll()
  if not (DB and DB.fensterStil) then return end
  hookQuestText()
  for _, n in ipairs(FENSTER) do local ok, err = pcall(skinWindow, n); if not ok then skinned[n] = true; msg("|cffff5555Fehler beim Fenster " .. n .. ":|r " .. tostring(err)) end end
end
NS.skinAll = skinAll
-- Lehrer, Berufe: die angeklickte Zeile gelb hervorheben (Blizzards eigene Markierung ist auf dem dunklen Hintergrund kaum zu sehen)
do
  local LISTEN = {
    { frame = "ClassTrainerFrame", knopf = "ClassTrainerSkill", sel = "GetTrainerSelectionIndex" },
    { frame = "TradeSkillFrame", knopf = "TradeSkillSkill", sel = "GetTradeSkillSelectionIndex" },
    { frame = "CraftFrame", knopf = "Craft", sel = "GetCraftSelectionIndex" },
  }
  local function markiere(b, an)
    if not b.thSel then
      if not an then return end
      local t = b:CreateTexture(nil, "BACKGROUND", nil, 7); t:SetAllPoints(); t:SetColorTexture(1, .82, 0, .28)
      local l = b:CreateTexture(nil, "ARTWORK", nil, 7); l:SetPoint("TOPLEFT"); l:SetPoint("BOTTOMLEFT"); l:SetWidth(3); l:SetColorTexture(1, .82, 0, 1)
      b.thSel, b.thSelL = t, l
    end
    b.thSel:SetShown(an); b.thSelL:SetShown(an)
  end
  local acc = 0
  local w = CreateFrame("Frame")
  w:SetScript("OnUpdate", function(_, el)
    acc = acc + (el or 0); if acc < .1 then return end; acc = 0
    if not (DB and DB.fensterStil) then return end
    for _, L in ipairs(LISTEN) do
      local f = rawget(_G, L.frame)
      if type(f) == "table" and safe(f.IsShown, f) then
        local sel = safe(rawget(_G, L.sel))
        for i = 1, 40 do
          local b = rawget(_G, L.knopf .. i)
          if type(b) ~= "table" then break end
          if b.CreateTexture then markiere(b, sel ~= nil and safe(b.IsShown, b) and safe(b.GetID, b) == sel) end
        end
      end
    end
  end)
end
-- Sicherheitsnetz: Fenster, die erst später entstehen oder ohne Ereignis aufgehen, beim Öffnen nachträglich gestalten
local SET = {}; for _, n in ipairs(FENSTER) do SET[n] = true end
if type(ShowUIPanel) == "function" then
  hooksecurefunc("ShowUIPanel", function(fr)
    local n = type(fr) == "table" and safe(fr.GetName, fr)
    if n and SET[n] and not skinned[n] and DB and DB.fensterStil then pcall(skinWindow, n); local x = rawget(_G, n); if x and x.thSkin and safe(x.IsShown, x) then pcall(x.GetScript(x, "OnShow") or function() end, x) end end
  end)
end
for _, fn in ipairs({ "ToggleWorldMap", "ToggleSpellBook", "ToggleQuestLog", "ToggleCharacter", "ToggleFriendsFrame", "ToggleGameMenu", "ToggleTalentFrame" }) do
  if type(rawget(_G, fn)) == "function" then pcall(hooksecurefunc, fn, function() if DB and DB.fensterStil then pcall(skinAll) end end) end
end
NS.fensterTest = function()
  msg("Fenster-Test (Stil " .. ((DB and DB.fensterStil) and "|cff55ff55an|r" or "|cffff5555aus|r") .. "):")
  for _, n in ipairs({ "WorldMapFrame", "SpellBookFrame", "QuestLogFrame", "CharacterFrame", "GameMenuFrame" }) do
    local fr = rawget(_G, n)
    local kids = {}
    if type(fr) == "table" and fr.GetChildren then
      for _, c in ipairs({ safe(fr.GetChildren, fr) }) do if type(c) == "table" then
        local cn = safe(c.GetName, c); local key
        for k, v in pairs(fr) do if v == c and type(k) == "string" then key = k break end end
        kids[#kids + 1] = (key or cn or "?") .. ":" .. tostring(safe(c.GetObjectType, c))
        if #kids >= 8 then break end
      end end
    end
    msg(n .. ": " .. (type(fr) == "table" and "da" or "|cffff5555fehlt|r") .. " · gestaltet " .. (skinned[n] and "ja" or "nein") ..
      " · Bilder ausgeblendet " .. (hiddenCount[n] or 0) .. (fr and fr.IsProtected and safe(fr.IsProtected, fr) and " · geschützt" or "") .. (#kids > 0 and (" · " .. table.concat(kids, ", ")) or ""))
  end
end

---------------------------------------------------------------------------
-- 8b) Fenster-Positionen merken: verschieben = sofort gespeichert, nach /reload und Einloggen wieder dort
---------------------------------------------------------------------------
local EIGENE = { "TobsiikkHelferMenue", "TobsiikkHelferOberflaecheMenue", "TobsiikkHelferRahmenMenue", "TobsiikkHelferExport" }
local merkt = {}
local function blocked(f) return InCombatLockdown() and f.IsProtected and safe(f.IsProtected, f) end
local function posPut(name)
  local f = rawget(_G, name); local p = DB and DB.fensterPos and DB.fensterPos[name]
  if type(f) ~= "table" or type(p) ~= "table" or blocked(f) then return end
  pcall(function() f:ClearAllPoints(); f:SetPoint(p[1], UIParent, p[2], p[3], p[4]) end)
end
local function posSave(name)
  local f = rawget(_G, name); if type(f) ~= "table" then return end
  local pt, _, rp, x, y = safe(f.GetPoint, f, 1)
  if type(pt) == "string" and type(x) == "number" then
    DB.fensterPos = DB.fensterPos or {}
    DB.fensterPos[name] = { pt, rp or pt, math.floor(x * 10 + .5) / 10, math.floor((y or 0) * 10 + .5) / 10 }
  end
end
local function merkeFenster(name, eigen)
  if name == "LootFrame" then return end -- das Beutefenster hat einen eigenen Platzhalter (siehe unten)
  local f = rawget(_G, name)
  if merkt[name] or type(f) ~= "table" or not f.HookScript or not f.SetMovable then return end
  if blocked(f) then pendingUI = true return end
  merkt[name] = true
  pcall(f.SetMovable, f, true); pcall(f.SetClampedToScreen, f, true)
  if not eigen then
    -- Blizzard-Fenster: an einer freien Stelle im Fenster mit links ziehen
    pcall(f.EnableMouse, f, true); pcall(f.RegisterForDrag, f, "LeftButton")
    f:HookScript("OnDragStart", function(s) if not blocked(s) then s:StartMoving() end end)
  end
  f:HookScript("OnDragStop", function(s) pcall(s.StopMovingOrSizing, s); if NS.snapFrame then pcall(NS.snapFrame, s) end; if s.SetUserPlaced then pcall(s.SetUserPlaced, s, false) end; posSave(name) end)
  f:HookScript("OnShow", function() posPut(name); if C_Timer and C_Timer.After then C_Timer.After(0, function() posPut(name) end) end end)
  if safe(f.IsShown, f) then posPut(name) end
end
local function merkeAlle()
  if not DB then return end
  for _, n in ipairs(EIGENE) do pcall(merkeFenster, n, true) end
  for _, n in ipairs(FENSTER) do pcall(merkeFenster, n, false) end
end
-- Blizzard ordnet geöffnete Fenster manchmal neu an (z. B. wenn ein zweites aufgeht) – danach zurück an den gemerkten Platz
if type(UpdateUIPanelPositions) == "function" then
  hooksecurefunc("UpdateUIPanelPositions", function()
    if not (DB and DB.fensterPos) then return end
    for n in pairs(DB.fensterPos) do local f = rawget(_G, n); if type(f) == "table" and safe(f.IsShown, f) then posPut(n) end end
  end)
end
NS.resetFensterPos = function() if DB then DB.fensterPos = {} end end

---------------------------------------------------------------------------
-- 9) /kb – Tastenbelegung: Maus über ein Feld halten und Taste drücken
---------------------------------------------------------------------------
local KB_CMD = { { "ActionButton", "ACTIONBUTTON" }, { "MultiBarBottomLeftButton", "MULTIACTIONBAR1BUTTON" },
  { "MultiBarBottomRightButton", "MULTIACTIONBAR2BUTTON" }, { "MultiBarRightButton", "MULTIACTIONBAR3BUTTON" },
  { "MultiBarLeftButton", "MULTIACTIONBAR4BUTTON" }, { "PetActionButton", "BONUSACTIONBUTTON" }, { "StanceButton", "SHAPESHIFTBUTTON" } }
local KB_IGNORE = { LSHIFT = true, RSHIFT = true, LCTRL = true, RCTRL = true, LALT = true, RALT = true, UNKNOWN = true, LMETA = true, RMETA = true }
local kbOn, kbHooked = false, {}
local function kbCommand(b)
  local n = type(b) == "table" and safe(b.GetName, b)
  if type(n) ~= "string" then return end
  local pre, num = n:match("^(%a+)(%d+)$")
  for _, e in ipairs(KB_CMD) do if e[1] == pre then return e[2] .. num end end
end
local kbm = CreateFrame("Button", "TobsiikkHelferKB", UIParent, "BackdropTemplate")
kbm:SetFrameStrata("DIALOG"); kbm:Hide(); kbm:EnableMouse(true); kbm:EnableMouseWheel(true)
if kbm.EnableKeyboard then kbm:EnableKeyboard(true) end
if kbm.SetBackdrop then
  kbm:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 2 })
  kbm:SetBackdropColor(LILA[1], LILA[2], LILA[3], .35); kbm:SetBackdropBorderColor(LILA[1], LILA[2], LILA[3], 1)
end
local kbBar = holder("TobsiikkHelferKBLeiste", 430, 58); kbBar:SetPoint("TOP", 0, -120); kbBar:SetFrameStrata("DIALOG"); kbBar:Hide()
kbBar.t = kbBar:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); kbBar.t:SetPoint("TOP", 0, -10); kbBar.t:SetWidth(400)
kbBar.t:SetText("|cffb36bffTastenbelegung aktiv|r – Maus über ein Feld halten und Taste drücken.\nRechtsklick = Belegung löschen · Esc oder /kb = fertig")
kbBar.ok = CreateFrame("Button", nil, kbBar, "UIPanelButtonTemplate"); kbBar.ok:SetSize(70, 20); kbBar.ok:SetPoint("BOTTOMRIGHT", -8, 6); kbBar.ok:SetText("Fertig")
local function kbTip()
  local cmd = kbm.cmd; if not cmd then return end
  GameTooltip:SetOwner(kbm, "ANCHOR_TOP"); GameTooltip:ClearLines()
  GameTooltip:AddLine("Tastenbelegung", LILA[1] + .2, LILA[2] + .3, 1)
  local keys = { safe(GetBindingKey, cmd) }
  local txt = {}
  for _, k in ipairs(keys) do if type(k) == "string" then txt[#txt + 1] = (GetBindingText and safe(GetBindingText, k)) or k end end
  GameTooltip:AddLine(#txt > 0 and ("Belegt: |cffffffff" .. table.concat(txt, ", ") .. "|r") or "|cff999999Noch keine Taste|r", 1, .82, 0)
  GameTooltip:AddLine("Taste drücken = belegen (auch mit Shift/Strg/Alt)", .8, .8, .8)
  GameTooltip:AddLine("Rechtsklick = löschen · Esc = fertig", .8, .8, .8)
  GameTooltip:Show()
end
local function kbRefresh()
  -- Tastenbeschriftung auf dem Feld sofort neu zeichnen
  local b = kbm.btn
  if type(b) == "table" then
    for _, m in ipairs({ "UpdateHotkeys", "UpdateHotKeys" }) do if type(b[m]) == "function" then pcall(b[m], b, b.buttonType) end end
    if ActionButton_UpdateHotkeys then pcall(ActionButton_UpdateHotkeys, b, b.buttonType) end
  end
  if NS.refreshBindLabels then pcall(NS.refreshBindLabels) end
end
local function kbSave() if SaveBindings then pcall(SaveBindings, (GetCurrentBindingSet and safe(GetCurrentBindingSet)) or 1) end end
local function kbBind(key)
  local cmd = kbm.cmd; if not cmd or not key then return end
  if InCombatLockdown() then msg("Im Kampf kann nichts belegt werden."); return end
  local m = ""
  if IsAltKeyDown and IsAltKeyDown() then m = m .. "ALT-" end
  if IsControlKeyDown and IsControlKeyDown() then m = m .. "CTRL-" end
  if IsShiftKeyDown and IsShiftKeyDown() then m = m .. "SHIFT-" end
  local full = m .. key
  -- alte Taste(n) dieses Feldes zuerst lösen, damit die neue sie ersetzt (sonst bleibt z. B. „E“ stehen)
  local alt = {}
  for _, k in ipairs({ safe(GetBindingKey, cmd) }) do if type(k) == "string" and k ~= full then alt[#alt + 1] = k end end
  for _, k in ipairs(alt) do pcall(SetBinding, k) end
  if SetBinding and safe(SetBinding, full, cmd) ~= false then
    kbSave(); kbRefresh(); msg("|cffffd100" .. ((GetBindingText and safe(GetBindingText, full)) or full) .. "|r liegt jetzt auf diesem Feld.")
  else msg("Diese Taste konnte nicht belegt werden.") end
  kbTip()
end
local function kbClear()
  local cmd = kbm.cmd; if not cmd or InCombatLockdown() then return end
  for _, k in ipairs({ safe(GetBindingKey, cmd) }) do if type(k) == "string" then pcall(SetBinding, k) end end
  kbSave(); kbRefresh(); msg("Belegung gelöscht."); kbTip()
end
local function kbStop()
  kbOn = false; kbm:Hide(); kbBar:Hide(); GameTooltip:Hide(); msg("Tastenbelegung beendet und gespeichert.")
end
kbm:SetScript("OnKeyDown", function(_, key)
  if key == "ESCAPE" then kbStop() return end
  if KB_IGNORE[key] then return end
  kbBind(key)
end)
kbm:SetScript("OnMouseDown", function(_, btn)
  if btn == "RightButton" then kbClear()
  elseif btn == "MiddleButton" then kbBind("BUTTON3")
  elseif btn == "Button4" then kbBind("BUTTON4")
  elseif btn == "Button5" then kbBind("BUTTON5") end
end)
kbm:SetScript("OnMouseWheel", function(_, d) kbBind(d > 0 and "MOUSEWHEELUP" or "MOUSEWHEELDOWN") end)
kbm:SetScript("OnLeave", function() kbm:Hide(); kbm.cmd = nil; GameTooltip:Hide() end)
kbBar.ok:SetScript("OnClick", kbStop)
local function kbCover(b)
  if not kbOn or InCombatLockdown() then return end
  local cmd = kbCommand(b); if not cmd then return end
  kbm.cmd = cmd; kbm.btn = b; kbm:ClearAllPoints(); kbm:SetAllPoints(b); kbm:Show(); kbTip()
end
local function kbToggle()
  if kbOn then kbStop() return end
  if InCombatLockdown() then msg("Bitte erst nach dem Kampf.") return end
  for _, e in ipairs(KB_CMD) do
    for i = 1, 12 do
      local b = rawget(_G, e[1] .. i)
      if type(b) == "table" and b.HookScript and not kbHooked[b] then kbHooked[b] = true; b:HookScript("OnEnter", kbCover) end
    end
  end
  kbOn = true; kbBar:Show()
  msg("Tastenbelegung an: Maus über ein Feld halten und Taste drücken. Fertig mit Esc oder /kb.")
end
NS.kbToggle = kbToggle
SLASH_TOBSIIKKKB1 = "/kb"; SLASH_TOBSIIKKKB2 = "/tastenbelegung"
SlashCmdList.TOBSIIKKKB = function() kbToggle() end

---------------------------------------------------------------------------
-- Einstellungsfenster „Leisten, Minimap & Taschen“
---------------------------------------------------------------------------
local win = CreateFrame("Frame", "TobsiikkHelferOberflaecheMenue", UIParent, "BasicFrameTemplateWithInset")
win:SetSize(560, 620); win:SetPoint("CENTER", 0, 0); win:SetFrameStrata("DIALOG"); win:Hide()
win:SetMovable(true); win:EnableMouse(true); win:RegisterForDrag("LeftButton"); win:SetClampedToScreen(true)
win:SetScript("OnDragStart", win.StartMoving); win:SetScript("OnDragStop", win.StopMovingOrSizing)
if UISpecialFrames then tinsert(UISpecialFrames, "TobsiikkHelferOberflaecheMenue") end
win.title = win:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); win.title:SetPoint("TOP", 0, -5)
win.title:SetText("siikkUI · Leisten, Minimap & Taschen")
if NS.addScaleGrip then NS.addScaleGrip(win, "oberflaeche", 560) end
local wChecks, wSliders = {}, {}
local function wRefresh()
  if not DB then return end
  for _, c in ipairs(wChecks) do c:SetChecked(c.get() and true or false) end
  for _, s in ipairs(wSliders) do s.quiet = true; s:SetValue(s.get()); s.quiet = false end
end
local function wCheck(y, text, get, set, x)
  local c = CreateFrame("CheckButton", nil, win, "UICheckButtonTemplate")
  c:SetSize(26, 26); c:SetPoint("TOPLEFT", x or 16, y)
  for _, k in ipairs({ "text", "Text" }) do local t = rawget(c, k); if type(t) == "table" and t.SetText then t:SetText("") end end
  local fs = c:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); fs:SetPoint("LEFT", c, "RIGHT", 2, 1); fs:SetText(text)
  c:SetScript("OnClick", function(s) set(s:GetChecked() and true or false); wRefresh() end)
  c.get = get; table.insert(wChecks, c); return c
end
local function wSlider(y, label, minv, maxv, step, get, set, fmt, x, w)
  local t = win:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); t:SetPoint("TOPLEFT", x or 22, y)
  local s = CreateFrame("Slider", nil, win)
  s:SetOrientation("HORIZONTAL"); s:SetSize(w or 360, 18); s:SetPoint("TOPLEFT", x or 22, y - 18)
  local bg = s:CreateTexture(nil, "BACKGROUND"); bg:SetColorTexture(0, 0, 0, .7); bg:SetPoint("LEFT"); bg:SetPoint("RIGHT"); bg:SetHeight(6)
  s:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
  s:SetMinMaxValues(minv, maxv); s:SetValueStep(step); if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
  s:EnableMouse(true)
  s:SetScript("OnValueChanged", function(self, v)
    v = math.floor(v / step + .5) * step
    t:SetText(label .. ": |cffffd100" .. fmt(v) .. "|r")
    if not self.quiet then set(v) end
  end)
  s.get = get; table.insert(wSliders, s); return s
end
local function wButton(x, y, w, text, fn)
  local b = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
  b:SetSize(w, 24); b:SetPoint("TOPLEFT", x, y); b:SetText(text)
  b:SetScript("OnClick", function() fn(); wRefresh() end)
  return b
end
local function reloadHint(v, setup)
  if v then
    if InCombatLockdown() then msg("Wird nach dem Kampf übernommen."); pendingUI = true else setup() end
  else msg("Ausgeschaltet – ganz zurück zum Blizzard-Aussehen kommst du mit |cffffd100/reload|r.") end
end
local function regrid() if InCombatLockdown() then msg("Wird nach dem Kampf übernommen."); done.gridDirty = true; done.sideDirty = true; pendingUI = true; return end
  if NS.placeGrid then pcall(NS.placeGrid) end; if NS.placeSide then pcall(NS.placeSide) end end
local function n0(v) return tostring(math.floor(v + .5)) end
local h1 = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); h1:SetPoint("TOPLEFT", 18, -34); h1:SetText("Aktionsleisten")
wCheck(-56, "Aktionsleiste 4×8", function() return DB.leiste end, function(v) DB.leiste = v; reloadHint(v, setupBars) end, 16)
wCheck(-56, "Seitenleisten als 2×12", function() return DB.seitenLeiste end, function(v) DB.seitenLeiste = v; reloadHint(v, setupSide) end, 290)
wCheck(-80, "Menüleiste mit Tastenbelegung", function() return DB.menueLeiste end, function(v) DB.menueLeiste = v; reloadHint(v, setupMicro) end, 16)
wCheck(-80, "Taschenleiste mit Tastenbelegung", function() return DB.taschenLeiste end, function(v) DB.taschenLeiste = v; reloadHint(v, setupBagBar) end, 290)
wCheck(-104, "Eigene Erfahrungsleiste", function() return DB.xpLeiste end, function(v) DB.xpLeiste = v; if v then reloadHint(v, setupXP) else xp:Hide(); reloadHint(v) end end, 16)
wCheck(-104, "Blizzard-Erfahrungsleiste aus", function() return DB.xpBlizzAus end, function(v) DB.xpBlizzAus = v; if v then hideBlizzXP() else reloadHint(v) end end, 290)
wSlider(-136, "Hauptleiste: Spalten", 1, 12, 1, function() return DB.leisteSpalten or 8 end, function(v) DB.leisteSpalten = v; regrid() end, n0, 22, 240)
wSlider(-136, "Hauptleiste: Felder", 1, 36, 1, function() return DB.leisteAnzahl or 32 end, function(v) DB.leisteAnzahl = v; regrid() end, n0, 292, 240)
wSlider(-188, "Seitenleiste: Spalten", 1, 12, 1, function() return DB.seiteSpalten or 2 end, function(v) DB.seiteSpalten = v; regrid() end, n0, 22, 240)
wSlider(-188, "Seitenleiste: Felder", 1, 24, 1, function() return DB.seiteAnzahl or 24 end, function(v) DB.seiteAnzahl = v; regrid() end, n0, 292, 240)
local h2 = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); h2:SetPoint("TOPLEFT", 18, -240); h2:SetText("Taschen")
wCheck(-262, "Alle Taschen in einem Fenster", function() return DB.taschenFenster end, function(v) DB.taschenFenster = v; reloadHint(v, setupBags) end, 16)
wSlider(-294, "Spalten im Taschenfenster", 6, 18, 1, function() return DB.taschenSpalten or 10 end,
  function(v) DB.taschenSpalten = v; refreshBags() end, function(v) return tostring(math.floor(v)) end, 22, 240)
wSlider(-294, "Hintergrund Leisten & Taschen", 0, 1, .05, function() return DB.hintergrund or .6 end,
  function(v) DB.hintergrund = v; NS.applyBG() end, function(v) return math.floor(v * 100 + .5) .. " %" end, 292, 240)
local h3 = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); h3:SetPoint("TOPLEFT", 18, -348); h3:SetText("Minimap & Tooltip")
wCheck(-370, "Eckige Minimap mit Rahmen und Uhr", function() return DB.minimapEckig end, function(v) DB.minimapEckig = v; reloadHint(v, setupMinimap) end, 16)
wCheck(-394, "Tooltip verschiebbar, mit Fraktions-Logo im Hintergrund", function() return DB.tooltipEigen end, function(v) DB.tooltipEigen = v; if v then reloadHint(v, setupTooltip) else refreshTips(); reloadHint(v) end end, 16)
wSlider(-426, "Logo im Tooltip (Text bleibt gut lesbar)", 0, .4, .01, function() return DB.tooltipLogo or .15 end,
  function(v) DB.tooltipLogo = v; refreshTips() end, function(v) return math.floor(v * 100 + .5) .. " %" end, 22, 510)
local h4 = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); h4:SetPoint("TOPLEFT", 18, -478); h4:SetText("Aussehen")
wCheck(-500, "Blizzard-Fenster (C, P, N, L, M, Esc …) im siikkUI-Stil", function() return DB.fensterStil end, function(v) DB.fensterStil = v; reloadHint(v, skinAll) end, 16)
wCheck(-524, "Ruhe-Modus: außerhalb des Kampfes Hintergründe durchsichtiger", function() return DB.ruheTransparent end, function(v) DB.ruheTransparent = v; updateCalm() end, 16)
local tip = win:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
tip:SetPoint("TOPLEFT", 20, -560); tip:SetWidth(520); tip:SetJustifyH("LEFT")
tip:SetText("Verschieben & Größe: lila Knopf „Platzieren starten“ oben rechts. Menü- und Taschenleiste in Midnight über Blizzards Bearbeitungsmodus (Esc > Bearbeitungsmodus). Tasten belegen: |cffffd100/kb|r.")
win:SetScript("OnShow", function() if win.applySavedScale then win.applySavedScale() end; wRefresh() end)
NS.openUI = function() if NS.showTab then NS.showTab(5) else if NS.mainPanel then NS.mainPanel:Hide() end; win:Show() end end
if NS.attachTabs then NS.attachTabs(win, 5) end

---------------------------------------------------------------------------
-- Start, Ereignisse, Befehle
---------------------------------------------------------------------------
local function setupAll()
  if not DB then return end
  if InCombatLockdown() then pendingUI = true return end
  for _, e in ipairs({ { setupMinimap, "Minimap" }, { setupBars, "4×8-Leiste" }, { setupSide, "2×12-Seitenleiste" }, { setupMicro, "Menüleiste" }, { setupBagBar, "Taschenleiste" }, { setupBags, "Taschenfenster" }, { setupXP, "Erfahrungsleiste" }, { setupTooltip, "Tooltip" }, { setupLoot, "Beutefenster" }, { skinAll, "Fenster-Stil" }, { merkeAlle, "Fenster-Positionen" } }) do
    local ok, err = pcall(e[1])
    if not ok then msg("|cffff5555Fehler bei " .. e[2] .. ":|r " .. tostring(err) .. " – bitte Screenshot machen.") end
  end
  if NS.applyBG then pcall(NS.applyBG) end
end
local prevLayout = NS.onLayout
NS.onLayout = function(placing)
  if prevLayout then pcall(prevLayout, placing) end
  if done.minimap and Minimap then Minimap:EnableMouseWheel(true) end
  if done.xp then if placing then xp:Show() else updateXP() end end
  if done.tooltip then if (placing or not DB.gesperrt) and DB.tooltipEigen then ttAnker:Show() else ttAnker:Hide() end end
  if done.loot then if (placing or not DB.gesperrt) and DB.beuteEigen ~= false then lootAnker:Show() else lootAnker:Hide() end end
  updateHandles() -- Zoom per Mausrad auch im gesperrten Zustand
  if done.bags then
    if placing then bagWin:Show() elseif not blizzBagsOpen() and bagWin:IsShown() then bagWin.syncHide = true; bagWin:Hide(); bagWin.syncHide = nil end
  end
end

local ev = CreateFrame("Frame")
for _, e in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "PLAYER_ENTERING_WORLD", "PLAYER_REGEN_ENABLED", "UPDATE_BINDINGS",
  "PLAYER_REGEN_DISABLED", "PLAYER_XP_UPDATE", "PLAYER_LEVEL_UP", "UPDATE_EXHAUSTION", "BAG_UPDATE", "BAG_UPDATE_DELAYED", "ITEM_LOCK_CHANGED", "BAG_UPDATE_COOLDOWN", "PLAYER_MONEY", "UNIT_INVENTORY_CHANGED" }) do
  pcall(ev.RegisterEvent, ev, e)
end
ev:SetScript("OnEvent", function(_, e, a1)
  if e == "ADDON_LOADED" then
    if a1 == ADDON then
      TobsiikkHelferDB = TobsiikkHelferDB or {}
      for k, v in pairs(UDEF) do if TobsiikkHelferDB[k] == nil then TobsiikkHelferDB[k] = v end end
      DB = TobsiikkHelferDB
      if type(DB.minimapIcons) ~= "table" then DB.minimapIcons = {} end
      if type(DB.fensterPos) ~= "table" then DB.fensterPos = {} end
    elseif a1 == "Blizzard_TimeManager" and done.minimap then hideBlizzClock() end
    if DB and type(a1) == "string" and a1:find("^Blizzard_") then pcall(skinAll); pcall(merkeAlle) end
    return
  end
  if not DB then return end
  if e == "PLAYER_LOGIN" or e == "PLAYER_ENTERING_WORLD" then setupAll(); updateXP(); updateCalm()
  elseif e == "PLAYER_REGEN_DISABLED" then updateCalm()
  elseif e == "PLAYER_REGEN_ENABLED" then
    updateCalm()
    if pendingUI then pendingUI = false; setupAll() end
    if done.gridDirty and NS.placeGrid then done.gridDirty = nil; pcall(NS.placeGrid) end
    if done.sideDirty and NS.placeSide then done.sideDirty = nil; pcall(NS.placeSide) end
  elseif e == "UPDATE_BINDINGS" then layoutMicro(); layoutBagBar()
  elseif e == "PLAYER_XP_UPDATE" or e == "PLAYER_LEVEL_UP" or e == "UPDATE_EXHAUSTION" then updateXP()
  else refreshBags() end
end)

local baseSlash = SlashCmdList.TOBSIIKKHELFER
SlashCmdList.TOBSIIKKHELFER = function(input)
  local c, arg = (input or ""):lower():match("^(%S*)%s*(.-)$")
  if c == "oberflaeche" or c == "oberfläche" or c == "leisten" or c == "ui" then NS.openUI()
  elseif c == "kb" or c == "tasten" then kbToggle()
  elseif c == "beute" or c == "loot" then
    DB.beuteEigen = (arg ~= "aus"); msg("Beutefenster an eigener Stelle: " .. (DB.beuteEigen and "an – im Platzier-Modus den Kasten „Beute-Fenster“ verschieben." or "aus (Blizzard-Platz)."))
  elseif c == "fenster" and arg == "test" then NS.fensterTest()
  elseif c == "fenster" and (arg == "reset" or arg == "zurueck" or arg == "zurück") then NS.resetFensterPos(); msg("Fenster-Positionen zurückgesetzt – nach /reload sind alle Fenster wieder an Blizzards Platz.")
  elseif c == "taschen" then
    local n = tonumber(arg)
    if n then DB.taschenSpalten = math.max(6, math.min(18, n)); refreshBags(); msg("Taschenfenster: " .. DB.taschenSpalten .. " Spalten.")
    elseif ToggleAllBags then ToggleAllBags() end
  else
    baseSlash(input)
    if c == "hilfe" or c == "help" or c == "?" then
      msg("/th leisten – Einstellungen für Minimap, 4×8-Leiste, Menü-/Taschenleiste und Taschenfenster")
      msg("/th taschen 12 – Spalten im Taschenfenster")
      msg("/th fenster reset – alle gemerkten Fenster-Positionen löschen")
      msg("/kb – Tastenbelegung: Maus über ein Feld halten und Taste drücken")
    end
  end
end
NS.uiDebug = { side = side, xp = xp, updateXP = updateXP, bar = bar, petBar = petBar, micro = micro, bagBar = bagBar, bagWin = bagWin, slots = slots, done = done, clock = function() return clock end,
  layoutBags = layoutBags, syncBags = syncBags, edgePlace = edgePlace, win = win, setupAll = setupAll }
