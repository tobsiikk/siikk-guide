-- siikkUI · Questanzeige
-- Eigene, durchsichtige Questliste auf dem Hauptbildschirm:
--  · verschiebbar (an der Kopfzeile ziehen, Shift = einrasten), Größe per Griff unten rechts, Strg + Mausrad = Schriftgröße
--  · angenommene Quests mit gelbem Ausrufezeichen, neu angenommene zusätzlich mit „NEU“
--  · fertige Quests mit grünem Haken, erledigte Ziele grün
--  · Linksklick öffnet die Quest im Questbuch, Rechtsklick klappt die Ziele ein/aus, Mausrad blättert
-- Funktioniert in Classic/TBC/Forever (GetQuestLogTitle) und Midnight (C_QuestLog).
local ADDON, NS = ...
NS = NS or {}
local DB, Q
local function msg(t) if NS.msg then NS.msg(t) else DEFAULT_CHAT_FRAME:AddMessage("|cffe03030siikk|r|cffffd100UI|r: " .. t) end end
local function pass(ok, ...) if ok then return ... end end
local function safe(fn, ...) if type(fn) ~= "function" then return nil end return pass(pcall(fn, ...)) end
local function secret(v) return issecretvalue and issecretvalue(v) end
local function str(v) return type(v) == "string" and not secret(v) and v or nil end
local GOLD = NS.GOLD or { .85, .65, .15 }
local FONT = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
local ICON_OFFEN = "Interface\\GossipFrame\\AvailableQuestIcon"
local ICON_FERTIG = "Interface\\RaidFrame\\ReadyCheck-Ready"
local ICON_FEHL = "Interface\\RaidFrame\\ReadyCheck-NotReady"
local HEAD_H, ROW_H = 20, { zone = 15, quest = 17, ziel = 14, leer = 16 }
local NEU_DAUER = 180 -- Sekunden, so lange steht „NEU“ hinter einer frisch angenommenen Quest
local neu = {}        -- [questKey] = Zeitpunkt der Annahme

local function cfg()
  if not DB then return {} end
  if type(DB.quest) ~= "table" then DB.quest = { an = true, w = 237.6, h = 471.6, bg = .25, scale = 1, zu = {}, blizzAus = true, pos = { "RIGHT", "RIGHT", -90.4, -19.8 } } end
  local c = DB.quest
  if type(c.zu) ~= "table" then c.zu = {} end
  if c.an == nil then c.an = true end
  return c
end

---------------------------------------------------------------------------
-- Quests auslesen (Classic/TBC/Forever bzw. Midnight)
---------------------------------------------------------------------------
local function readQuests()
  local out, nQ = {}, 0
  if type(rawget(_G, "GetQuestLogTitle")) == "function" then
    local n = safe(GetNumQuestLogEntries) or 0; if type(n) ~= "number" then n = 0 end
    for i = 1, n do
      local title, level, _, isHeader, isCollapsed, isComplete, _, qid = safe(GetQuestLogTitle, i)
      title = str(title)
      if title then
        if isHeader then out[#out + 1] = { zone = true, title = title, collapsed = isCollapsed }
        else
          local q = { idx = i, id = type(qid) == "number" and qid or nil, title = title, level = type(level) == "number" and level or nil, objs = {} }
          q.done = (isComplete == 1 or isComplete == true); q.failed = (isComplete == -1)
          local no = safe(GetNumQuestLeaderBoards, i) or 0; if type(no) ~= "number" then no = 0 end
          for j = 1, no do
            local text, _, fin = safe(GetQuestLogLeaderBoard, j, i)
            text = str(text); if text then q.objs[#q.objs + 1] = { text = text, done = fin and true or false } end
          end
          out[#out + 1] = q; nQ = nQ + 1
        end
      end
    end
  elseif type(C_QuestLog) == "table" and C_QuestLog.GetInfo then
    local n = safe(C_QuestLog.GetNumQuestLogEntries) or 0; if type(n) ~= "number" then n = 0 end
    for i = 1, n do
      local info = safe(C_QuestLog.GetInfo, i)
      if type(info) == "table" and str(info.title) then
        if info.isHeader then out[#out + 1] = { zone = true, title = info.title, collapsed = info.isCollapsed }
        elseif not info.isHidden and not info.isTask and not info.isBounty then
          local id = info.questID
          local q = { idx = i, id = id, title = info.title, level = info.level, objs = {} }
          q.done = id and (safe(C_QuestLog.IsComplete, id) or safe(C_QuestLog.ReadyForTurnIn, id)) and true or false
          q.failed = id and safe(C_QuestLog.IsFailed, id) and true or false
          local ob = id and safe(C_QuestLog.GetQuestObjectives, id)
          if type(ob) == "table" then for _, o in ipairs(ob) do if str(o.text) and o.text ~= "" then q.objs[#q.objs + 1] = { text = o.text, done = o.finished and true or false } end end end
          out[#out + 1] = q; nQ = nQ + 1
        end
      end
    end
  end
  -- Zonen ohne sichtbare Quests weglassen (außer eingeklappte – die zeigen, dass da noch was ist)
  local clean = {}
  for i, e in ipairs(out) do
    if e.zone then
      local nxt = out[i + 1]
      if e.collapsed or (nxt and not nxt.zone) then clean[#clean + 1] = e end
    else clean[#clean + 1] = e end
  end
  local max = (C_QuestLog and safe(C_QuestLog.GetMaxNumQuestsCanAccept)) or rawget(_G, "MAX_QUESTLOG_QUESTS") or rawget(_G, "MAX_QUESTS") or 25
  return clean, nQ, type(max) == "number" and max or 25
end
local function keyOf(q) return q.id and ("id" .. q.id) or ("t" .. q.title) end
NS.questLesen = readQuests

---------------------------------------------------------------------------
-- Fenster
---------------------------------------------------------------------------
local f = CreateFrame("Frame", "TobsiikkHelferQuests", UIParent, "BackdropTemplate")
f:SetSize(270, 320); f:SetPoint("RIGHT", UIParent, "RIGHT", -40, 140); f:Hide()
f:SetFrameStrata("LOW"); f:SetClampedToScreen(true); f:SetMovable(true); f:SetResizable(true); f:EnableMouse(false)
if f.SetResizeBounds then f:SetResizeBounds(170, 60, 700, 1000) elseif f.SetMinResize then f:SetMinResize(170, 60); if f.SetMaxResize then f:SetMaxResize(700, 1000) end end
if f.SetBackdrop then
  f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
end
local head = CreateFrame("Frame", nil, f)
head:SetPoint("TOPLEFT", 0, 0); head:SetPoint("TOPRIGHT", 0, 0); head:SetHeight(HEAD_H)
head.bg = head:CreateTexture(nil, "BACKGROUND"); head.bg:SetAllPoints(); head.bg:SetColorTexture(.25, .02, .03, .5)
head.t = head:CreateFontString(nil, "OVERLAY", "GameFontNormal"); head.t:SetPoint("LEFT", 6, 0); head.t:SetJustifyH("LEFT")
head:EnableMouse(true); head:RegisterForDrag("LeftButton")
local function savePos()
  if not DB then return end
  local c = cfg(); local p, _, rp, x, y = f:GetPoint(1)
  c.pos = { p, rp, x, y }; c.w = f:GetWidth(); if not c.klein then c.h = f:GetHeight() end
end
head:SetScript("OnDragStart", function() f:StartMoving() end)
head:SetScript("OnDragStop", function() f:StopMovingOrSizing(); if NS.snapFrame then pcall(NS.snapFrame, f) end; savePos() end)

local function headButton(text, w, tip)
  local b = CreateFrame("Button", nil, head, "BackdropTemplate"); b:SetSize(w, 15)
  if b.SetBackdrop then b:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 }); b:SetBackdropColor(0, 0, 0, .7); b:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .9) end
  b.t = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); b.t:SetPoint("CENTER"); b.t:SetText(text)
  b:SetScript("OnEnter", function(s) GameTooltip:SetOwner(s, "ANCHOR_TOP"); GameTooltip:AddLine(tip, 1, 1, 1, true); GameTooltip:Show() end)
  b:SetScript("OnLeave", function() GameTooltip:Hide() end)
  return b
end
local bClose = headButton("x", 15, "Questanzeige ausblenden (/th quests zeigt sie wieder)"); bClose:SetPoint("RIGHT", -2, 0)
local bMin = headButton("-", 15, "Einklappen / Ausklappen (nur Kopfzeile)"); bMin:SetPoint("RIGHT", bClose, "LEFT", -2, 0)
local bBg = headButton("%", 18, "Hintergrund durchsichtiger / deckender (0 · 15 · 25 · 40 · 60 %)"); bBg:SetPoint("RIGHT", bMin, "LEFT", -2, 0)
local bPfeil = headButton("Pfeil", 46, "Questpfeil an/aus – ein Pfeil führt dich zum Questziel bzw. zum Abgabe-NPC (/th pfeil)"); bPfeil:SetPoint("RIGHT", bBg, "LEFT", -2, 0)
local function pfeilAn() local c = DB and DB.questPfeil; return not (type(c) == "table" and c.an == false) end
local function pfeilKnopf() bPfeil.t:SetText((pfeilAn() and "|TInterface\\Buttons\\UI-CheckBox-Check:12:12|t" or "|cff777777[ ]|r ") .. "Pfeil") end
bPfeil:SetScript("OnClick", function() if SlashCmdList.TOBSIIKKHELFER then SlashCmdList.TOBSIIKKHELFER(pfeilAn() and "pfeil aus" or "pfeil an") end; pfeilKnopf() end)
head.t:SetPoint("RIGHT", bPfeil, "LEFT", -4, 0)
local headBtns = { bClose, bMin, bBg, bPfeil }

local body = CreateFrame("Frame", nil, f)
body:SetPoint("TOPLEFT", 4, -HEAD_H - 2); body:SetPoint("BOTTOMRIGHT", -4, 4)
if body.SetClipsChildren then body:SetClipsChildren(true) end

local grip = CreateFrame("Button", nil, f); grip:SetSize(14, 14); grip:SetPoint("BOTTOMRIGHT", -1, 1); grip:SetFrameLevel(f:GetFrameLevel() + 10)
grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up"); grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight"); grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
grip:SetScript("OnMouseDown", function() if cfg().klein then return end f:StartSizing("BOTTOMRIGHT") end)
grip:SetScript("OnMouseUp", function() f:StopMovingOrSizing(); savePos(); if NS.questUpdate then NS.questUpdate() end end)

---------------------------------------------------------------------------
-- Zeilen
---------------------------------------------------------------------------
local rows, lines, offset = {}, {}, 0
local function openQuest(L)
  if type(rawget(_G, "GetQuestLogTitle")) == "function" then
    local qlf = rawget(_G, "QuestLogFrame")
    if qlf and not qlf:IsShown() then if ShowUIPanel then safe(ShowUIPanel, qlf) else qlf:Show() end end
    safe(rawget(_G, "SelectQuestLogEntry"), L.idx); safe(rawget(_G, "QuestLog_SetSelection"), L.idx); safe(rawget(_G, "QuestLog_Update"))
  elseif L.id then
    if type(rawget(_G, "QuestMapFrame_OpenToQuestDetails")) == "function" then safe(QuestMapFrame_OpenToQuestDetails, L.id)
    else safe(rawget(_G, "ToggleQuestLog")) end
  end
end
local function getRow(n)
  local r = rows[n]; if r then return r end
  r = CreateFrame("Button", nil, body); r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  r.glow = r:CreateTexture(nil, "BACKGROUND"); r.glow:SetAllPoints(); r.glow:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], .18); r.glow:Hide()
  r.icon = r:CreateTexture(nil, "ARTWORK")
  r.t = r:CreateFontString(nil, "OVERLAY"); r.t:SetFont(FONT, 12, ""); r.t:SetShadowOffset(1, -1); r.t:SetShadowColor(0, 0, 0, 1)
  r.t:SetJustifyH("LEFT"); if r.t.SetWordWrap then r.t:SetWordWrap(false) end
  r.tag = r:CreateFontString(nil, "OVERLAY"); r.tag:SetFont(FONT, 10, "OUTLINE"); r.tag:SetPoint("RIGHT", -2, 0); r.tag:SetTextColor(1, .82, 0)
  r:SetScript("OnClick", function(s, btn)
    local L = s.L; if not L or L.kind ~= "quest" then return end
    if btn == "RightButton" then local c = cfg(); c.zu[L.key] = not c.zu[L.key] or nil; NS.questUpdate()
    elseif IsShiftKeyDown and IsShiftKeyDown() and NS.questPfeilFolge and L.id then NS.questPfeilFolge(L.id)
    else openQuest(L) end
  end)
  r:SetScript("OnEnter", function(s)
    local L = s.L; if not L or L.kind ~= "quest" then return end
    GameTooltip:SetOwner(s, "ANCHOR_LEFT"); GameTooltip:AddLine(L.title, 1, .82, 0)
    if L.done then GameTooltip:AddLine("Fertig – zum Questgeber zurückkehren", .2, 1, .2) end
    for _, o in ipairs(L.objs or {}) do GameTooltip:AddLine((o.done and "|TInterface\\RaidFrame\\ReadyCheck-Ready:0|t " or "- ") .. o.text, 1, 1, 1, true) end
    GameTooltip:AddLine("Linksklick: im Questbuch öffnen · Rechtsklick: Ziele ein-/ausklappen", .6, .6, .6, true)
    if NS.questPfeilFolge then GameTooltip:AddLine("Shift+Klick: Questpfeil führt dich zu dieser Quest", .7, .42, 1, true) end
    GameTooltip:Show()
  end)
  r:SetScript("OnLeave", function() GameTooltip:Hide() end)
  rows[n] = r; return r
end

local function diffColor(level)
  if level and type(rawget(_G, "GetQuestDifficultyColor")) == "function" then
    local c = safe(GetQuestDifficultyColor, level); if type(c) == "table" and c.r then return c.r, c.g, c.b end
  end
  return 1, .82, 0
end

local function buildLines()
  local list, nQ, max = readQuests()
  local c = cfg(); local now = GetTime()
  lines = {}
  for _, e in ipairs(list) do
    if e.zone then lines[#lines + 1] = { kind = "zone", text = e.title .. (e.collapsed and "  (+)" or "") }
    else
      local k = keyOf(e)
      local L = { kind = "quest", key = k, idx = e.idx, id = e.id, title = e.title, objs = e.objs, done = e.done, failed = e.failed, level = e.level }
      L.neu = neu[k] and (now - neu[k] < NEU_DAUER)
      lines[#lines + 1] = L
      if not c.zu[k] then
        if e.done then lines[#lines + 1] = { kind = "ziel", text = "Fertig – zum Questgeber zurückkehren", done = true, parent = L }
        elseif not e.failed then for _, o in ipairs(e.objs) do lines[#lines + 1] = { kind = "ziel", text = o.text, done = o.done, parent = L } end end
      end
    end
  end
  if nQ == 0 then lines[1] = { kind = "leer", text = "Keine Quests – nimm eine an!" } end
  return nQ, max
end

local function render()
  local c = cfg()
  local sc = c.scale or 1
  local W = (body:GetWidth() or 0); if type(W) ~= "number" or W <= 0 then W = (c.w or 270) - 8 end
  local H = (body:GetHeight() or 0); if type(H) ~= "number" or H <= 0 then H = (c.h or 320) - HEAD_H - 6 end
  if offset > #lines - 1 then offset = math.max(0, #lines - 1) end
  local y, n = 0, 0
  if not c.klein then
    for i = offset + 1, #lines do
      local L = lines[i]; local h = math.floor(ROW_H[L.kind] * sc + .5)
      if y + h > H + 1 then break end
      n = n + 1; local r = getRow(n); r.L = L
      r:ClearAllPoints(); r:SetPoint("TOPLEFT", body, "TOPLEFT", 0, -y); r:SetSize(W, h)
      r.t:ClearAllPoints(); r.icon:ClearAllPoints(); r.glow:Hide(); r.tag:SetText("")
      local fs = math.floor(({ zone = 11, quest = 12.5, ziel = 11, leer = 12 })[L.kind] * sc + .5)
      r.t:SetFont(FONT, fs, ""); r:EnableMouse(L.kind == "quest")
      if L.kind == "zone" then
        r.icon:Hide(); r.t:SetPoint("LEFT", 0, 0); r.t:SetPoint("RIGHT", 0, 0); r.t:SetText(L.text); r.t:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
      elseif L.kind == "quest" then
        local is = h - 2
        r.icon:SetSize(is, is); r.icon:SetPoint("LEFT", 2, 0); r.icon:Show()
        r.icon:SetTexture(L.done and ICON_FERTIG or (L.failed and ICON_FEHL or ICON_OFFEN))
        r.t:SetPoint("LEFT", r.icon, "RIGHT", 4, 0); r.t:SetPoint("RIGHT", r.tag, "LEFT", -2, 0)
        r.t:SetText((L.level and L.level > 0 and ("[" .. L.level .. "] ") or "") .. L.title)
        if L.done then r.t:SetTextColor(.25, 1, .25) elseif L.failed then r.t:SetTextColor(1, .25, .25) else r.t:SetTextColor(diffColor(L.level)) end
        r.tag:SetTextColor(1, .82, 0)
        if L.neu then r.tag:SetText("NEU"); r.glow:Show() end
        if NS.questPfeilAktuell and L.id and NS.questPfeilAktuell() == L.id then r.tag:SetText("PFEIL"); r.tag:SetTextColor(.7, .42, 1) end
        if c.zu[L.key] and not L.done then r.tag:SetText((L.neu and "NEU  " or "") .. "+") end
      elseif L.kind == "ziel" then
        local is = h - 3
        if L.done then r.icon:SetTexture(ICON_FERTIG); r.icon:SetSize(is, is); r.icon:SetPoint("LEFT", 18, 0); r.icon:Show()
        else r.icon:Hide() end
        r.t:SetPoint("LEFT", 20 + (L.done and is or 0) + 2, 0); r.t:SetPoint("RIGHT", -2, 0)
        r.t:SetText(L.done and L.text or ("- " .. L.text))
        if L.done then r.t:SetTextColor(.3, 1, .3) else r.t:SetTextColor(.92, .92, .92) end
      else
        r.icon:Hide(); r.t:SetPoint("LEFT", 4, 0); r.t:SetPoint("RIGHT", 0, 0); r.t:SetText(L.text); r.t:SetTextColor(.7, .7, .7)
      end
      r:Show(); y = y + h
    end
  end
  for i = n + 1, #rows do rows[i]:Hide(); rows[i].L = nil end
  f.mehr = (offset + n < #lines) -- unten geht's noch weiter
end

local hover, inCombat = false, false
local function applyLook()
  local c = cfg(); local bg = c.bg or .25
  if f.SetBackdropColor then
    f:SetBackdropColor(0, 0, 0, hover and math.max(bg, .55) or bg)
    f:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], hover and .9 or (bg > 0 and .25 or 0))
  end
  head.bg:SetAlpha(hover and 1 or (bg > 0 and .6 or 0))
  for _, b in ipairs(headBtns) do b:SetShown(hover) end
  grip:SetShown(hover and not c.klein)
  f:SetAlpha((inCombat and not hover) and .55 or 1)
end

local dirty = true
NS.questUpdate = function() dirty = true end
local function update()
  dirty = false
  if not DB then return end
  local c = cfg()
  local nQ, max = buildLines()
  head.t:SetText("Quests  |cffffffff" .. nQ .. "/" .. max .. "|r" .. (offset > 0 and "  |cff999999(hoch: Mausrad)|r" or ""))
  render()
  if f.mehr and not c.klein then head.t:SetText(head.t:GetText() .. "  |cff999999(mehr: Mausrad)|r") end
end

local tick = 0
f:SetScript("OnUpdate", function(_, el)
  tick = tick + el; if tick < .15 then return end; tick = 0
  local h = f:IsMouseOver() and true or false
  if h ~= hover then hover = h; applyLook() end
  local pa = NS.questPfeilAktuell and NS.questPfeilAktuell() or nil
  if pa ~= f.pfeilZiel then f.pfeilZiel = pa; dirty = true end
  if dirty then pfeilKnopf(); update() end
end)
f:SetScript("OnSizeChanged", function() dirty = true end)
f:EnableMouseWheel(true)
f:SetScript("OnMouseWheel", function(_, d)
  local c = cfg()
  if IsControlKeyDown and IsControlKeyDown() then
    c.scale = math.max(.7, math.min(1.6, (c.scale or 1) + d * .05)); msg(("Questanzeige Schriftgröße: %d %%"):format(math.floor(c.scale * 100 + .5)))
  else
    offset = math.max(0, offset - d * 3)
  end
  update()
end)

local function applyPos()
  local c = cfg()
  f:ClearAllPoints()
  local p = c.pos
  if type(p) == "table" and p[1] then f:SetPoint(p[1], UIParent, p[2] or p[1], p[3] or 0, p[4] or 0) else f:SetPoint("RIGHT", UIParent, "RIGHT", -40, 140) end
  f:SetWidth(c.w or 270); f:SetHeight(c.klein and HEAD_H or (c.h or 320))
  bMin.t:SetText(c.klein and "+" or "-")
  body:SetShown(not c.klein)
end

-- Blizzards eigene Quest-Verfolgung (Classic/TBC) ausblenden, solange unsere an ist – sonst stehen die Quests doppelt da
local function blizzWatch()
  local c = cfg()
  local w = rawget(_G, "QuestWatchFrame")
  if type(w) == "table" and w.Hide and not (w.IsProtected and w:IsProtected()) then
    if not w.thHook and hooksecurefunc then
      w.thHook = true
      hooksecurefunc(w, "Show", function(s) local cc = cfg(); if cc.an and cc.blizzAus then s:Hide() end end)
    end
    if c.an and c.blizzAus then w:Hide() elseif safe(rawget(_G, "GetNumQuestWatches")) and (GetNumQuestWatches() or 0) > 0 then w:Show() end
  end
end

local function show(on)
  local c = cfg(); c.an = on and true or false
  if on and NS.questModus and NS.questModus() == "hilfe" then f:Hide(); blizzWatch() return end
  if on then applyPos(); applyLook(); f:Show(); update() else f:Hide() end
  blizzWatch()
end
NS.questShow = show
-- Auswahl der Questanzeige: siikk-Questhilfe (mit Pfeil) oder siikkUI-Standard (ohne Hilfe) – immer nur eine
local function qhAPI() local q = rawget(_G, "SiikkQuesthilfe"); return type(q) == "table" and q or nil end
NS.questModus = function()
  if not qhAPI() then return "standard" end
  return (DB and DB.questFenster == "standard") and "standard" or "hilfe"
end
NS.questFensterAnwenden = function(meldung)
  if not DB then return end
  local m, q = NS.questModus(), qhAPI()
  if q and q.SetTracker then pcall(q.SetTracker, m == "hilfe") end
  local c = cfg()
  if m == "hilfe" then if f:IsShown() then f:Hide() end; blizzWatch()
  elseif c.an ~= false then show(true) end
  if NS.questPfeilAnwenden then pcall(NS.questPfeilAnwenden) end
  if meldung then msg("Questanzeige: " .. (m == "hilfe" and "|cffb266ffsiikk-Questhilfe|r mit Questpfeil." or "siikkUI-Standard ohne Hilfe.")) end
end
SiikkUIQuestFenster = function(modus)
  if not DB then return end
  if modus == "hilfe" and not qhAPI() then msg("Die siikk-Questhilfe ist nicht installiert oder nicht aktiv.") return end
  DB.questFenster = (modus == "standard") and "standard" or "hilfe"
  NS.questFensterAnwenden(true)
end
SiikkUIQuestFensterModus = function() return NS.questModus() end
-- Standard-Platz der Questanzeige (rechts unter der Minimap)
NS.questStandard = function() local cc = cfg(); cc.pos, cc.w, cc.h, cc.scale, cc.klein = { "RIGHT", "RIGHT", -90.4, -19.8 }, 237.6, 471.6, 1, nil; if cc.an then applyPos() end end

bClose:SetScript("OnClick", function() show(false); msg("Questanzeige aus – |cffffd100/th quests|r zeigt sie wieder.") end)
bMin:SetScript("OnClick", function() local c = cfg(); c.klein = not c.klein or nil; applyPos(); applyLook(); update() end)
bBg:SetScript("OnClick", function()
  local c = cfg(); local steps = { 0, .15, .25, .4, .6 }; local nxt = steps[1]
  for i, v in ipairs(steps) do if math.abs((c.bg or .25) - v) < .01 then nxt = steps[i % #steps + 1] end end
  c.bg = nxt; applyLook(); msg(("Questanzeige Hintergrund: %d %%"):format(math.floor(nxt * 100 + .5)))
end)

---------------------------------------------------------------------------
-- Ereignisse und Befehle
---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
for _, e in ipairs({ "ADDON_LOADED", "PLAYER_ENTERING_WORLD", "QUEST_LOG_UPDATE", "QUEST_ACCEPTED", "QUEST_REMOVED", "QUEST_TURNED_IN", "UNIT_QUEST_LOG_CHANGED", "QUEST_WATCH_LIST_CHANGED", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED" }) do pcall(ev.RegisterEvent, ev, e) end
ev:SetScript("OnEvent", function(_, e, a, b)
  if e == "ADDON_LOADED" then
    if a ~= ADDON then return end
    TobsiikkHelferDB = TobsiikkHelferDB or {}; DB = TobsiikkHelferDB; Q = cfg()
    show(Q.an)
    return
  end
  if not DB then return end
  if e == "QUEST_ACCEPTED" then
    -- Classic: (Index, QuestID) · Midnight: (QuestID)
    local id = type(b) == "number" and b or a
    if type(id) == "number" then neu["id" .. id] = GetTime() end
    if type(a) == "number" and type(b) ~= "number" and type(rawget(_G, "GetQuestLogTitle")) == "function" then
      local t = str((safe(GetQuestLogTitle, a))); if t then neu["t" .. t] = GetTime() end
    end
    if C_Timer and C_Timer.After then C_Timer.After(NEU_DAUER + 1, function() dirty = true end) end
  elseif e == "PLAYER_REGEN_DISABLED" then inCombat = true; applyLook() return
  elseif e == "PLAYER_REGEN_ENABLED" then inCombat = false; applyLook()
  elseif e == "PLAYER_ENTERING_WORLD" then
    blizzWatch()
    -- die Questhilfe startet ihren Tracker erst nach einigen Sekunden – danach die gewählte Anzeige durchsetzen
    if C_Timer and C_Timer.After then C_Timer.After(1, function() NS.questFensterAnwenden() end); C_Timer.After(8, function() NS.questFensterAnwenden() end) end
  end
  dirty = true
end)

local baseSlash = SlashCmdList.TOBSIIKKHELFER
if baseSlash then
  SlashCmdList.TOBSIIKKHELFER = function(input)
    local c, arg = (input or ""):lower():match("^(%S*)%s*(.-)$")
    if c == "level" or c == "levelzeit" then
      if arg == "reset" then NS.levelZeitReset(); msg("Level-Zeit: Messung neu gestartet.")
      else DB.levelZeit = (arg == "an") or (arg ~= "aus" and DB.levelZeit == false); NS.levelZeitAnwenden(); msg("Level-Zeit-Fenster " .. (DB.levelZeit and "an." or "aus.")) end
    elseif c == "fps" or c == "latenz" or c == "leistung" then
      DB.leistung = (arg == "an") or (arg ~= "aus" and DB.leistung == false)
      NS.leistungAnwenden(); msg("FPS- und Latenz-Anzeige " .. (DB.leistung and "an (Blizzards Latenz-Balken aus)." or "aus (Blizzards Latenz-Balken wieder da)."))
    elseif (c == "quests" or c == "quest") and (arg == "hilfe" or arg == "standard") then
      SiikkUIQuestFenster(arg)
    elseif c == "quests" or c == "quest" then
      local cc = cfg()
      if arg == "blizzard" or arg == "blizzard an" then cc.blizzAus = false; blizzWatch(); msg("Blizzard-Questverfolgung wieder sichtbar.")
      elseif arg == "blizzard aus" then cc.blizzAus = true; blizzWatch(); msg("Blizzard-Questverfolgung ausgeblendet.")
      elseif arg == "reset" then NS.questStandard(); show(true); msg("Questanzeige zurückgesetzt.")
      elseif arg == "an" then show(true) elseif arg == "aus" then show(false)
      else show(not cc.an) end
      if cc.an and arg == "" then msg("Questanzeige an · ziehen an der Kopfzeile · Griff unten rechts = Größe · Strg+Mausrad = Schrift · |cffffd100/th quests reset|r") end
    else
      baseSlash(input)
      if c == "hilfe" or c == "help" or c == "?" then msg("/th level an|aus|reset – Zeit bis zum nächsten Level · /th fps an|aus – FPS- und Latenz-Anzeige · /th quests – Questanzeige an/aus · /th quests reset · /th quests blizzard an|aus") end
    end
  end
end
SLASH_TOBSIIKKQUESTS1 = "/quests"
SlashCmdList.TOBSIIKKQUESTS = function(a) SlashCmdList.TOBSIIKKHELFER("quests " .. (a or "")) end

---------------------------------------------------------------------------
-- Leistungsanzeige: eigene FPS- und Latenz-Anzeige mit Zahlen (ersetzt Blizzards Latenz-Balken)
---------------------------------------------------------------------------
do
  local lf = CreateFrame("Frame", "TobsiikkHelferLeistung", UIParent, "BackdropTemplate")
  lf:SetSize(150, 22); lf:SetFrameStrata("MEDIUM"); lf:SetClampedToScreen(true); lf:SetMovable(true); lf:EnableMouse(true); lf:RegisterForDrag("LeftButton")
  if lf.SetBackdrop then
    lf:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    lf:SetBackdropColor(0, 0, 0, .55); lf:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .8)
  end
  lf.t = lf:CreateFontString(nil, "OVERLAY"); lf.t:SetFont(FONT, 12, "OUTLINE"); lf.t:SetPoint("CENTER", 0, 0)
  lf:SetScript("OnDragStart", function(s) if DB and not DB.gesperrt then s:StartMoving() end end)
  lf:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); if NS.savePos then NS.savePos(s, "leistung") end end)
  if NS.makeScalable then NS.makeScalable(lf, "leistung") end
  if NS.extraFrames then table.insert(NS.extraFrames, { frame = lf, key = "leistung", point = "BOTTOMRIGHT", x = -20, y = 200 }) end
  lf:Hide()
  local function farbeMs(ms) if ms < 100 then return "|cff33ff33" elseif ms < 200 then return "|cffffd100" end return "|cffff3333" end
  local function farbeFps(f) if f >= 60 then return "|cff33ff33" elseif f >= 30 then return "|cffffd100" end return "|cffff3333" end
  local function werte()
    local fps = safe(GetFramerate) or 0
    local _, _, home, world = safe(GetNetStats)
    home = (type(home) == "number" and not secret(home)) and home or 0
    world = (type(world) == "number" and not secret(world)) and world or home
    return (type(fps) == "number" and not secret(fps)) and fps or 0, home, world
  end
  local function zeichne()
    local fps, home, world = werte()
    local ms = math.max(home, world)
    lf.t:SetText(farbeFps(fps) .. math.floor(fps + .5) .. "|r |cffaaaaaaFPS|r   " .. farbeMs(ms) .. ms .. "|r |cffaaaaaams|r")
    lf:SetWidth(math.max(110, (lf.t:GetStringWidth() or 100) + 16))
  end
  local acc = 1
  lf:SetScript("OnUpdate", function(_, el) acc = acc + el; if acc < 1 then return end; acc = 0; zeichne() end)
  lf:SetScript("OnEnter", function(s)
    local fps, home, world = werte()
    local inK, outK = safe(GetNetStats)
    GameTooltip:SetOwner(s, "ANCHOR_TOP"); GameTooltip:AddLine("Leistung")
    GameTooltip:AddDoubleLine("Bilder pro Sekunde", farbeFps(fps) .. math.floor(fps + .5) .. "|r", 1, 1, 1)
    GameTooltip:AddDoubleLine("Latenz Zuhause (Chat, Handel)", farbeMs(home) .. home .. " ms|r", 1, 1, 1)
    GameTooltip:AddDoubleLine("Latenz Welt (Kampf, Bewegung)", farbeMs(world) .. world .. " ms|r", 1, 1, 1)
    if type(inK) == "number" and not secret(inK) then GameTooltip:AddDoubleLine("Bandbreite ein / aus", string.format("%.1f / %.1f KB/s", inK, outK or 0), 1, 1, 1, 1, 1, 1) end
    GameTooltip:AddLine("Ziehen im Platzier-Modus · /th fps an|aus", .6, .6, .6)
    GameTooltip:Show()
  end)
  lf:SetScript("OnLeave", function() GameTooltip:Hide() end)

  -- Blizzards Latenz-Anzeige ausblenden (Classic/TBC: Balken neben dem Menü · Midnight: Balken am Hauptmenü-Knopf)
  local function blizzAus(aus)
    local fr = rawget(_G, "MainMenuBarPerformanceBarFrame")
    if type(fr) == "table" and fr.SetAlpha then
      fr:SetAlpha(aus and 0 or 1); if fr.EnableMouse and not (fr.IsProtected and fr:IsProtected()) then pcall(fr.EnableMouse, fr, not aus) end
    end
    local mm = rawget(_G, "MainMenuMicroButton")
    local bar = (type(mm) == "table" and rawget(mm, "MainMenuBarPerformanceBar")) or rawget(_G, "MainMenuBarPerformanceBar")
    if type(bar) == "table" and bar.SetAlpha then bar:SetAlpha(aus and 0 or 1) end
  end
  NS.leistungAnwenden = function()
    if not DB then return end
    local an = DB.leistung ~= false
    if an then lf:Show(); zeichne() elseif not (NS.isPlacing and NS.isPlacing()) then lf:Hide() end
    blizzAus(an)
  end
  local lev = CreateFrame("Frame")
  lev:RegisterEvent("PLAYER_LOGIN"); lev:RegisterEvent("PLAYER_ENTERING_WORLD")
  lev:SetScript("OnEvent", function() if DB then NS.leistungAnwenden() end end)
  local prev = NS.onLayout
  NS.onLayout = function(placing)
    if prev then pcall(prev, placing) end
    if placing then lf:Show() elseif NS.leistungAnwenden then NS.leistungAnwenden() end
  end
  NS.leistungDebug = { frame = lf, draw = zeichne }
end
---------------------------------------------------------------------------
-- Platzier-Modus: lila Start-Knopf über jedem Einstellungs-Reiter + eigenes Fenster mit „Platzieren beenden“
---------------------------------------------------------------------------
do
  local LILA = { .48, .16, .82 }
  local function lilaKnopf(parent, w, h, text, size)
    local b = CreateFrame("Button", nil, parent, "BackdropTemplate"); b:SetSize(w, h)
    if b.SetBackdrop then
      b:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 2 })
      b:SetBackdropColor(LILA[1], LILA[2], LILA[3], .95); b:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
    end
    b.t = b:CreateFontString(nil, "OVERLAY"); b.t:SetFont(FONT, size or 13, "OUTLINE"); b.t:SetPoint("CENTER"); b.t:SetText(text); b.t:SetTextColor(1, 1, 1)
    b:SetScript("OnEnter", function(s) if s.SetBackdropColor then s:SetBackdropColor(LILA[1] + .15, LILA[2] + .12, math.min(1, LILA[3] + .15), 1) end end)
    b:SetScript("OnLeave", function(s) if s.SetBackdropColor then s:SetBackdropColor(LILA[1], LILA[2], LILA[3], .95) end end)
    return b
  end
  local function placing() return NS.isPlacing and NS.isPlacing() end
  local function umschalten() if InCombatLockdown() then msg("Im Kampf kann nicht platziert werden.") return end; SlashCmdList.TOBSIIKKHELFER("verschieben") end

  -- 1) Start-Knopf: sitzt gut sichtbar oben rechts ÜBER dem jeweils offenen Einstellungsfenster (jeder Reiter)
  local start = lilaKnopf(UIParent, 210, 28, "Platzieren starten", 14); start:Hide()
  start:SetScript("OnClick", function()
    local w = start:GetParent()
    if not placing() then if w and w ~= UIParent and w.Hide then w:Hide() end end -- Einstellungen zu, damit man alles sieht
    umschalten()
  end)
  NS.onTabWin = function(win)
    start:SetParent(win); start:ClearAllPoints(); start:SetPoint("BOTTOMRIGHT", win, "TOPRIGHT", -4, 3)
    start:SetFrameLevel((win:GetFrameLevel() or 1) + 6)
    start.t:SetText(placing() and "Platzieren beenden" or "Platzieren starten"); start:Show()
  end

  -- 2) Eigenes Fenster, solange der Platzier-Modus läuft
  local pw = CreateFrame("Frame", "TobsiikkHelferPlatzieren", UIParent, "BackdropTemplate")
  pw:SetSize(330, 74); pw:SetPoint("TOP", UIParent, "TOP", 0, -96); pw:SetFrameStrata("FULLSCREEN_DIALOG"); pw:Hide()
  pw:SetMovable(true); pw:EnableMouse(true); pw:RegisterForDrag("LeftButton"); pw:SetClampedToScreen(true)
  pw:SetScript("OnDragStart", pw.StartMoving)
  pw:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); if DB then local p, _, rp, x, y = s:GetPoint(1); DB.platzFenster = { p, rp, x, y } end end)
  if pw.SetBackdrop then
    pw:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 2 })
    pw:SetBackdropColor(.04, .02, .07, .92); pw:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
  end
  pw.title = pw:CreateFontString(nil, "OVERLAY", "GameFontNormal"); pw.title:SetPoint("TOP", 0, -6); pw.title:SetText("Platzier-Modus")
  pw.info = pw:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); pw.info:SetPoint("TOP", pw.title, "BOTTOM", 0, -3); pw.info:SetWidth(320)
  pw.info:SetText("Ziehen · |cffffd100Shift|r = einrasten · |cffffd100Mausrad|r = Größe")
  pw.ende = lilaKnopf(pw, 132, 22, "Platzieren beenden", 11); pw.ende:SetPoint("BOTTOMLEFT", 8, 8)
  pw.ende:SetScript("OnClick", function() if placing() then umschalten() end end)
  pw.menue = CreateFrame("Button", nil, pw, "UIPanelButtonTemplate"); pw.menue:SetSize(84, 22); pw.menue:SetPoint("BOTTOMRIGHT", -8, 8); pw.menue:SetText("Optionen")
  pcall(function() pw.menue:GetFontString():SetFontObject("GameFontNormalSmall") end)
  pw.menue:SetScript("OnClick", function() if NS.mainPanel then NS.mainPanel:Show() end end)
  pw.elem = CreateFrame("Button", nil, pw, "UIPanelButtonTemplate"); pw.elem:SetSize(92, 22); pw.elem:SetPoint("RIGHT", pw.menue, "LEFT", -4, 0); pw.elem:SetText("Einzeln")
  pcall(function() pw.elem:GetFontString():SetFontObject("GameFontNormalSmall") end)
  pw.elem:SetScript("OnClick", function() if NS.showTab then NS.showTab(7) end end)
  local prev = NS.onLayout
  NS.onLayout = function(on)
    if prev then pcall(prev, on) end
    if on then
      local p = DB and DB.platzFenster
      if type(p) == "table" and p[1] then pw:ClearAllPoints(); pw:SetPoint(p[1], UIParent, p[2], p[3], p[4]) end
      pw:Show()
    else pw:Hide() end
    start.t:SetText(on and "Platzieren beenden" or "Platzieren starten")
  end
  NS.platzDebug = { start = start, fenster = pw }
end
---------------------------------------------------------------------------
-- Reiter „Elemente“: jedes verschiebbare Feld einzeln hervorheben (liegt oben, Rest wird blass)
-- – so lassen sich auch Felder greifen, die unter anderen liegen.
---------------------------------------------------------------------------
do
  local NAMEN = {
    aktionsleiste = "Aktionsleiste", begleiterleiste = "Begleiterleiste", seitenleiste = "Seitenleiste", menueleiste = "Menüleiste",
    taschenleiste = "Taschenleiste", taschen = "Taschenfenster", erfahrung = "Erfahrungsleiste", beute = "Beutefenster", tooltip = "Tooltip-Position",
    minimap = "Minimap", rahmen_spieler = "Spielerfenster", rahmen_ziel = "Zielfenster", rahmen_begleiter = "Begleiter-Fenster",
    rahmen_zielziel = "Ziel des Ziels", gruppe = "Gruppe", raid = "Schlachtzug", zauberleiste = "Zauberleiste", leistung = "FPS & Latenz", levelzeit = "Zeit bis Level", questpfeil = "Questpfeil",
    klassen_cooldowns = "Cooldown-Leiste", klassen_debuffs = "Meine Schwächungen am Ziel", klassen_erinnerung = "Buff-Erinnerungen",
    erinnerung = "Hexer: Rüstung/Dämon-Erinnerung", gesundheitsstein = "Hexer: Gesundheitsstein", nacht = "Hexer: Einbruch der Nacht",
    seelendieb = "Hexer: Seelendieb", aggro = "Aggro-Warnung", furcht = "Hexer: Furcht-Timer", verbannen = "Hexer: Verbannen-Timer",
  }
  local HEXER = { erinnerung = true, gesundheitsstein = true, nacht = true, seelendieb = true, furcht = true, verbannen = true, splitter = true, stein = true }
  local function liste()
    local out, seen = {}, {}
    local hexer = not (NS.tab1Win and NS.tab1Win())
    local function add(frame, key, name)
      if type(frame) ~= "table" or seen[frame] or not frame.GetObjectType then return end
      if key and HEXER[key] and not hexer then return end
      if key and key:find("^dot_") and not hexer then return end
      seen[frame] = true; out[#out + 1] = { frame = frame, key = key, name = name or NAMEN[key] or key or "?" }
    end
    local more = NS.snapMore and NS.snapMore() or {}
    add(more[1], "splitter", "Hexer: Seelensplitter"); add(more[2], "stein", "Hexer: Seelenstein")
    for i = 3, #more do local b = more[i]; local d = type(b) == "table" and rawget(b, "d"); add(b, d and ("dot_" .. tostring(d.key)), "Hexer-DoT: " .. tostring(d and (d.name or d.key) or i)) end
    for _, e in ipairs(NS.extraFrames or {}) do add(e.frame, e.key) end
    add(rawget(_G, "TobsiikkHelferQuests"), nil, "Questanzeige")
    for i = 1, 4 do add(rawget(_G, i == 1 and "TobsiikkHelferSchaden" or ("TobsiikkHelferSchaden" .. i)), nil, "Schadensmesser " .. i) end
    table.sort(out, function(a, b) return a.name < b.name end)
    return out
  end

  -- Hervorheben
  local glow = CreateFrame("Frame", nil, UIParent, "BackdropTemplate"); glow:SetFrameStrata("TOOLTIP"); glow:EnableMouse(false); glow:Hide()
  if glow.SetBackdrop then glow:SetBackdrop({ edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 3 }); glow:SetBackdropBorderColor(.75, .3, 1, 1) end
  glow.t = glow:CreateFontString(nil, "OVERLAY"); glow.t:SetFont(FONT, 13, "OUTLINE"); glow.t:SetPoint("BOTTOM", glow, "TOP", 0, 4); glow.t:SetTextColor(.85, .55, 1)
  glow:SetScript("OnUpdate", function(s) s:SetAlpha(.55 + .45 * math.abs(math.sin(GetTime() * 3))) end)
  local aktiv, alt, blass = nil, nil, {}
  local function normal()
    if aktiv and alt then
      local f = aktiv.frame
      if not (InCombatLockdown() and f.IsProtected and f:IsProtected()) then
        pcall(f.SetFrameStrata, f, alt.strata); if alt.level then pcall(f.SetFrameLevel, f, alt.level) end
        if alt.warZu then pcall(f.Hide, f) end
      end
    end
    for f, a in pairs(blass) do pcall(f.SetAlpha, f, a) end
    blass = {}; aktiv, alt = nil, nil; glow:Hide()
    if NS.elementeFill then NS.elementeFill() end
  end
  local function hervorheben(e)
    if InCombatLockdown() then msg("Im Kampf geht das nicht – bitte nach dem Kampf.") return end
    local war = aktiv and aktiv.frame
    normal()
    if war == e.frame then return end -- zweiter Klick = wieder normal
    if not (NS.isPlacing and NS.isPlacing()) then SlashCmdList.TOBSIIKKHELFER("verschieben") end
    local f = e.frame
    alt = { strata = f:GetFrameStrata(), level = f:GetFrameLevel(), warZu = not f:IsShown() }
    if alt.warZu then pcall(f.Show, f) end
    pcall(f.SetFrameStrata, f, "FULLSCREEN"); pcall(f.Raise, f)
    for _, o in ipairs(liste()) do
      if o.frame ~= f and o.frame:IsShown() then blass[o.frame] = o.frame:GetAlpha(); pcall(o.frame.SetAlpha, o.frame, .2) end
    end
    aktiv = e
    glow:ClearAllPoints(); glow:SetPoint("TOPLEFT", f, "TOPLEFT", -4, 4); glow:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 4, -4)
    glow.t:SetText(e.name); glow:Show()
    if NS.elementeFill then NS.elementeFill() end
  end
  local prev = NS.onLayout
  NS.onLayout = function(on) if prev then pcall(prev, on) end; if not on and aktiv then normal() end end

  -- Fenster (Reiter 7)
  local ew = CreateFrame("Frame", "TobsiikkHelferElementeMenue", UIParent, "BasicFrameTemplateWithInset")
  ew:SetSize(560, 620); ew:SetPoint("CENTER", 0, 20); ew:SetFrameStrata("DIALOG"); ew:Hide()
  ew:SetMovable(true); ew:EnableMouse(true); ew:RegisterForDrag("LeftButton"); ew:SetClampedToScreen(true)
  ew:SetScript("OnDragStart", ew.StartMoving); ew:SetScript("OnDragStop", ew.StopMovingOrSizing)
  if tinsert and UISpecialFrames then tinsert(UISpecialFrames, "TobsiikkHelferElementeMenue") end
  ew.title = ew:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); ew.title:SetPoint("TOP", 0, -5); ew.title:SetText("siikkUI · Positionen")
  ew.head = ew:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); ew.head:SetPoint("TOPLEFT", 18, -34); ew.head:SetText("Einzelne Felder hervorheben")
  ew.info = ew:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); ew.info:SetPoint("TOPLEFT", 18, -58); ew.info:SetWidth(524); ew.info:SetJustifyH("LEFT")
  ew.info:SetText("Liegen mehrere Felder übereinander, klicke hier auf „Hervorheben“: Das Feld kommt ganz nach oben und leuchtet lila, alle anderen werden blass – " ..
    "so greifst du genau dieses Feld. Der Platzier-Modus startet dabei von selbst. Nochmal klicken = wieder normal. „Zurück“ setzt Position und Größe des Feldes auf Standard.")
  local scroll = CreateFrame("ScrollFrame", "TobsiikkHelferElementeScroll", ew, "UIPanelScrollFrameTemplate")
  scroll:SetPoint("TOPLEFT", 14, -100); scroll:SetPoint("BOTTOMRIGHT", -34, 50)
  local content = CreateFrame("Frame", nil, scroll); content:SetSize(500, 10); scroll:SetScrollChild(content)
  local rows = {}
  local function fill()
    local l = liste()
    for i, e in ipairs(l) do
      local r = rows[i]
      if not r then
        r = CreateFrame("Frame", nil, content); r:SetSize(500, 26)
        r.bg = r:CreateTexture(nil, "BACKGROUND"); r.bg:SetAllPoints(); r.bg:SetColorTexture(1, 1, 1, (i % 2 == 0) and .05 or 0)
        r.t = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); r.t:SetPoint("LEFT", 6, 0); r.t:SetWidth(250); r.t:SetJustifyH("LEFT")
        r.hl = CreateFrame("Button", nil, r, "BackdropTemplate"); r.hl:SetSize(130, 22); r.hl:SetPoint("RIGHT", -78, 0)
        if r.hl.SetBackdrop then r.hl:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 }) end
        r.hl.t = r.hl:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); r.hl.t:SetPoint("CENTER")
        r.hl:SetScript("OnClick", function(s) hervorheben(s.e) end)
        r.rs = CreateFrame("Button", nil, r, "UIPanelButtonTemplate"); r.rs:SetSize(70, 22); r.rs:SetPoint("RIGHT", -4, 0); r.rs:SetText("Zurück")
        r.rs:SetScript("OnClick", function(s)
          local k = s.e.key; if not (k and DB) then return end
          if DB.pos then DB.pos[k] = nil end; if DB.scale then DB.scale[k] = nil end
          if NS.applyLayout then NS.applyLayout() end; msg(s.e.name .. ": Position und Größe zurückgesetzt.")
        end)
        rows[i] = r
      end
      r.e = e; r.hl.e = e; r.rs.e = e
      r:ClearAllPoints(); r:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -(i - 1) * 27)
      r.t:SetText(e.name)
      local on = aktiv and aktiv.frame == e.frame
      r.hl.t:SetText(on and "Hervorgehoben (aus)" or "Hervorheben")
      if r.hl.SetBackdropColor then
        r.hl:SetBackdropColor(on and .62 or .35, on and .25 or .12, on and .95 or .6, .95); r.hl:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], on and 1 or .6)
      end
      r.rs:SetShown(e.key ~= nil)
      r:Show()
    end
    for i = #l + 1, #rows do rows[i]:Hide() end
    content:SetHeight(math.max(10, #l * 27))
  end
  NS.elementeFill = function() if ew:IsShown() then fill() end end
  local bAlle = CreateFrame("Button", nil, ew, "UIPanelButtonTemplate"); bAlle:SetSize(200, 24); bAlle:SetPoint("BOTTOMLEFT", 16, 16); bAlle:SetText("Alle wieder normal")
  bAlle:SetScript("OnClick", function() normal() end)
  ew:SetScript("OnShow", fill)
  if NS.attachTabs then NS.attachTabs(ew, 7) end
  NS.elementeDebug = { liste = liste, hervorheben = hervorheben, normal = normal, fenster = ew, rows = rows, glow = glow }
end
---------------------------------------------------------------------------
-- Einheitliches Aussehen aller Einstellungsfenster (dunkel, Kopfleiste in Lila, Rahmen in der Rahmenfarbe,
-- Logo als Wasserzeichen, Überschriften mit Trennlinie) + Kopfzeile sagt, was im Reiter zu finden ist
---------------------------------------------------------------------------
do
  local MEDIA = "Interface\\AddOns\\siikkUI\\Media\\"
  local NAMEN = { "Klasse", "Hinweise", "Allgemein", "Rahmen & Chat", "Leisten", "Cooldowns", "Positionen" }
  local INFO = {
    "Seelensplitter, Seelenstein, DoT-Symbole", "Warnungen, Töne und Aggro", "Platzieren, Zauberleiste, Logo, Profile",
    "Spieler-, Ziel-, Gruppenfenster, Chat, Rahmenfarbe", "Aktionsleisten, Taschen, Minimap, Tooltip", "Abklingzeiten auswählen",
    "Einzelne Felder hervorheben & zurücksetzen",
  }
  local FENSTER = { "TobsiikkHelferMenue", "TobsiikkHelferRahmenMenue", "TobsiikkHelferOberflaecheMenue", "TobsiikkHelferCooldownMenue", "TobsiikkHelferElementeMenue" }
  local function versteckeVorlage(win)
    pcall(function() for _, r in ipairs({ win:GetRegions() }) do if r:GetObjectType() == "Texture" then r:SetAlpha(0) end end end)
    local nm = win:GetName()
    for _, k in ipairs({ "NineSlice", "Inset", "Bg", "TitleBg", "TopTileStreaks", "InsetBg" }) do
      local c = rawget(win, k) or (nm and rawget(_G, nm .. k))
      if type(c) == "table" and c.SetAlpha then pcall(c.SetAlpha, c, 0) end
    end
  end
  local function linie(parent, fs, win)
    local l = parent:CreateTexture(nil, "ARTWORK"); l:SetHeight(1)
    l:SetPoint("LEFT", fs, "RIGHT", 10, -1); l:SetPoint("RIGHT", win, "RIGHT", -18, 0)
    l:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], .45); return l
  end
  local function ueberschriften(container, win)
    pcall(function()
      for _, r in ipairs({ container:GetRegions() }) do
        if r:GetObjectType() == "FontString" and r:GetFontObject() == GameFontNormalLarge and not r.siikkLinie then
          r.siikkLinie = linie(container, r, win); r:SetTextColor(1, .78, .25)
        end
      end
    end)
  end
  local function skin(win)
    if type(win) ~= "table" or win.siikkSkin then return end
    win.siikkSkin = true
    versteckeVorlage(win)
    local bg = win:CreateTexture(nil, "BACKGROUND", nil, -8); bg:SetAllPoints(); bg:SetColorTexture(.045, .035, .06, .97)
    local wm = win:CreateTexture(nil, "BACKGROUND", nil, -7); wm:SetSize(230, 230); wm:SetPoint("CENTER", 0, -20)
    wm:SetTexture(MEDIA .. "siikkui_logo"); wm:SetAlpha(.09)
    local kopf = win:CreateTexture(nil, "BACKGROUND", nil, -6); kopf:SetPoint("TOPLEFT", 2, -2); kopf:SetPoint("TOPRIGHT", -2, -2); kopf:SetHeight(24)
    kopf:SetColorTexture(.26, .07, .40, .95)
    local kl = win:CreateTexture(nil, "BACKGROUND", nil, -5); kl:SetPoint("TOPLEFT", kopf, "BOTTOMLEFT"); kl:SetPoint("TOPRIGHT", kopf, "BOTTOMRIGHT"); kl:SetHeight(1)
    kl:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], .8)
    local rand = CreateFrame("Frame", nil, win, "BackdropTemplate"); rand:SetAllPoints(); rand:EnableMouse(false); rand:SetFrameLevel(win:GetFrameLevel() + 30)
    if rand.SetBackdrop then rand:SetBackdrop({ edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 2 }); rand:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1) end
    if win.title then win.title:ClearAllPoints(); win.title:SetPoint("TOPLEFT", 12, -7); win.title:SetPoint("RIGHT", win, "RIGHT", -34, 0); win.title:SetJustifyH("LEFT") end
    ueberschriften(win, win)
    pcall(function() for _, c in ipairs({ win:GetChildren() }) do if c.GetRegions then ueberschriften(c, win) end end end)
  end
  local function titel(win, i)
    if not (win and win.title) then return end
    local name = NAMEN[i] or ""
    if i == 1 then name = (NS.klassenName and NS.tab1Win and NS.tab1Win()) and NS.klassenName() or "Hexer" end
    local info = INFO[i] or ""
    if i == 1 and NS.tab1Win and NS.tab1Win() then info = "Cooldowns, Schwächungen & Buff-Erinnerungen deiner Klasse" end
    win.title:SetText("|cffe03030siikk|r|cffffd100UI|r  ·  |cffffffff" .. name .. "|r   |cffb9a8c8" .. info .. "|r")
  end
  local prevTab = NS.onTabWin
  NS.onTabWin = function(win, i)
    if prevTab then pcall(prevTab, win, i) end
    skin(win); titel(win, i)
  end
  local sev = CreateFrame("Frame"); sev:RegisterEvent("PLAYER_LOGIN")
  sev:SetScript("OnEvent", function() for _, n in ipairs(FENSTER) do skin(rawget(_G, n)) end end)
  NS.skinDebug = { skin = skin, titel = titel }
end
---------------------------------------------------------------------------
-- Level-Zeit: ungefähre Zeit bis zum nächsten Level (aus deinen EP pro Stunde)
---------------------------------------------------------------------------
do
  local lz = CreateFrame("Frame", "TobsiikkHelferLevelZeit", UIParent, "BackdropTemplate")
  lz:SetSize(200, 62); lz:SetFrameStrata("MEDIUM"); lz:SetClampedToScreen(true); lz:SetMovable(true); lz:EnableMouse(true); lz:RegisterForDrag("LeftButton")
  if lz.SetBackdrop then
    lz:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    lz:SetBackdropColor(0, 0, 0, .6); lz:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .85)
  end
  local function zeile(y, size)
    local fs = lz:CreateFontString(nil, "OVERLAY"); fs:SetFont(FONT, size, "OUTLINE"); fs:SetPoint("TOPLEFT", 8, y); fs:SetPoint("RIGHT", lz, "RIGHT", -8, 0); fs:SetJustifyH("LEFT")
    return fs
  end
  lz.kopf = zeile(-6, 11); lz.zeit = zeile(-21, 14); lz.info = zeile(-41, 10)
  lz:SetScript("OnDragStart", function(s) if DB and not DB.gesperrt then s:StartMoving() end end)
  lz:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); if NS.savePos then NS.savePos(s, "levelzeit") end end)
  if NS.makeScalable then NS.makeScalable(lz, "levelzeit") end
  if NS.extraFrames then table.insert(NS.extraFrames, { frame = lz, key = "levelzeit", point = "TOPRIGHT", x = -240, y = -210 }) end
  lz:Hide()

  local start, gesamt, letzteEP, letzteMax, letzterKill = nil, 0, nil, nil, nil
  local verlauf = {} -- { Zeit, EP } der letzten Gewinne (für einen „frischen“ Schnitt der letzten 15 Minuten)
  local function zahl(n)
    n = math.floor(n + .5); local s = tostring(n)
    while true do local k; s, k = s:gsub("^(-?%d+)(%d%d%d)", "%1.%2"); if k == 0 then break end end
    return s
  end
  local function dauer(sek)
    if sek >= 3600 then return string.format("%d Std. %02d Min.", math.floor(sek / 3600), math.floor(sek % 3600 / 60)) end
    if sek >= 60 then return math.floor(sek / 60 + .5) .. " Min." end
    return "unter 1 Min."
  end
  local function maxLevel()
    local m = safe(rawget(_G, "GetMaxPlayerLevel")) or safe(rawget(_G, "GetMaxLevelForPlayerExpansion")) or rawget(_G, "MAX_PLAYER_LEVEL")
    return type(m) == "number" and m or 999
  end
  local function epNow()
    local cur, max = safe(UnitXP, "player"), safe(UnitXPMax, "player")
    if type(cur) ~= "number" or secret(cur) or type(max) ~= "number" or secret(max) or max <= 0 then return nil end
    return cur, max
  end
  local function rate()
    local now = GetTime()
    while verlauf[1] and now - verlauf[1][1] > 900 do table.remove(verlauf, 1) end
    local frisch = 0; for _, v in ipairs(verlauf) do frisch = frisch + v[2] end
    local dt = start and (now - start) or 0
    if dt >= 900 and frisch > 0 then return frisch / 900 * 3600 end -- letzte 15 Minuten
    if dt >= 60 and gesamt > 0 then return gesamt / dt * 3600 end   -- ganze Sitzung
    return nil
  end
  local function zeichne()
    local cur, max = epNow()
    local lvl = safe(UnitLevel, "player") or 0
    if not cur or lvl >= maxLevel() then if not (NS.isPlacing and NS.isPlacing()) then lz:Hide() end return end
    local rest = max - cur
    local erholt = safe(rawget(_G, "GetXPExhaustion"))
    lz.kopf:SetText("|cffb266ffLevel " .. lvl .. " → " .. (lvl + 1) .. "|r   |cffaaaaaa" .. string.format("%.1f", cur / max * 100) .. " %|r")
    local r = rate()
    if r and r > 0 then
      lz.zeit:SetText("|cffffd100~ " .. dauer(rest / r * 3600) .. "|r")
      local mobs = (letzterKill and letzterKill > 0) and (" · ~" .. math.ceil(rest / letzterKill) .. "× wie zuletzt") or ""
      lz.info:SetText("|cffdddddd" .. zahl(r) .. " EP/Std. · noch " .. zahl(rest) .. " EP|r" .. "|cff999999" .. mobs .. "|r")
    else
      lz.zeit:SetText("|cffaaaaaa wird berechnet …|r")
      lz.info:SetText("|cffdddddd noch " .. zahl(rest) .. " EP|r" .. ((type(erholt) == "number" and erholt > 0) and ("  |cff4fa3ff(+" .. zahl(erholt) .. " erholt)|r") or ""))
    end
  end
  local function epGewinn()
    local cur, max = epNow(); if not cur then return end
    if letzteEP then
      local diff = cur - letzteEP
      if diff < 0 and letzteMax then diff = (letzteMax - letzteEP) + cur end -- Level-Aufstieg dazwischen
      if diff > 0 then gesamt = gesamt + diff; letzterKill = diff; verlauf[#verlauf + 1] = { GetTime(), diff } end
    end
    letzteEP, letzteMax = cur, max
    zeichne()
  end
  NS.levelZeitAnwenden = function()
    if not DB then return end
    if DB.levelZeit ~= false then lz:Show(); zeichne() elseif not (NS.isPlacing and NS.isPlacing()) then lz:Hide() end
  end
  local acc = 0
  lz:SetScript("OnUpdate", function(_, el) acc = acc + el; if acc >= 1 then acc = 0; zeichne() end end)
  lz:SetScript("OnEnter", function(s)
    GameTooltip:SetOwner(s, "ANCHOR_LEFT"); GameTooltip:AddLine("Zeit bis zum nächsten Level")
    GameTooltip:AddLine("Berechnet aus deinen EP pro Stunde: erst über die ganze Sitzung, nach 15 Minuten aus den letzten 15 Minuten (passt sich an, wenn du schneller oder langsamer levelst).", 1, 1, 1, true)
    if start then GameTooltip:AddDoubleLine("Diese Sitzung", zahl(gesamt) .. " EP in " .. dauer(GetTime() - start), .8, .8, .8, 1, 1, 1) end
    local erholt = safe(rawget(_G, "GetXPExhaustion"))
    if type(erholt) == "number" and erholt > 0 then GameTooltip:AddDoubleLine("Erholt (doppelte EP)", zahl(erholt) .. " EP", .3, .65, 1, 1, 1, 1) end
    GameTooltip:AddLine("/th level an|aus · /th level reset", .6, .6, .6)
    GameTooltip:Show()
  end)
  lz:SetScript("OnLeave", function() GameTooltip:Hide() end)
  local ev2 = CreateFrame("Frame")
  for _, e in ipairs({ "PLAYER_ENTERING_WORLD", "PLAYER_XP_UPDATE", "PLAYER_LEVEL_UP" }) do pcall(ev2.RegisterEvent, ev2, e) end
  ev2:SetScript("OnEvent", function(_, e)
    if not DB then return end
    if e == "PLAYER_ENTERING_WORLD" then
      if not start then start = GetTime(); letzteEP, letzteMax = epNow() end
      NS.levelZeitAnwenden()
    else epGewinn() end
  end)
  NS.levelZeitReset = function() start, gesamt, letzterKill, verlauf = GetTime(), 0, nil, {}; letzteEP, letzteMax = epNow(); zeichne() end
  local prev = NS.onLayout
  NS.onLayout = function(on) if prev then pcall(prev, on) end; if on then lz:Show() elseif NS.levelZeitAnwenden then NS.levelZeitAnwenden() end end
  NS.levelDebug = { frame = lz, gewinn = epGewinn, draw = zeichne, setStart = function(t) start = t end, stat = function() return start, gesamt, GetTime() end }
end
NS.questDebug = { frame = f, rows = function() return rows end, lines = function() return lines end, update = update, hover = function(v) hover = v; applyLook() end, neu = neu }
