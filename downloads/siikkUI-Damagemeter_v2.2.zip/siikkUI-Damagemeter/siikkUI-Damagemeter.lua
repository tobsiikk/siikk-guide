-- siikkUI-Damagemeter
-- Schaden, Heilung und Aggro für dich, deine Gruppe und deinen Schlachtzug (Begleiter zählen zum Besitzer).
-- Bis zu 4 Fenster, Fähigkeiten-Aufschlüsselung im Tooltip, Aggro-Reiter mit Anklicken zum Anvisieren.
-- Befehle: /meter oder /sdm  (hilfe zeigt alle)
local ADDON, NS = ...
NS = NS or {}
local DB
local function msg(t) DEFAULT_CHAT_FRAME:AddMessage("|cffe03030siikk|r|cffffd100UI|r-Damagemeter: " .. t) end
local function pass(ok, ...) if ok then return ... end end
local function safe(fn, ...) if not fn then return nil end return pass(pcall(fn, ...)) end
local function secret(v) return issecretvalue and issecretvalue(v) end
local band = (bit and bit.band) or function(a, b) -- Ersatz ohne Lua-5.3-Zeichen (WoW nutzt Lua 5.1)
  local r, p = 0, 1
  while a > 0 and b > 0 do
    local x, y = a % 2, b % 2
    if x == 1 and y == 1 then r = r + p end
    a, b, p = (a - x) / 2, (b - y) / 2, p * 2
  end
  return r
end

local GOLD, LILA = NS.GOLD or { .85, .65, .15 }, { .62, .22, .95 }
local ROW_H, HEAD_H, TAB_H = 18, 22, 20 -- TAB_H: Reiterzeile unter der Kopfzeile
local MINE_PARTY_RAID = 0x7            -- COMBATLOG_OBJECT_AFFILIATION_MINE/PARTY/RAID
local FRIENDLY = 0x10                  -- COMBATLOG_OBJECT_REACTION_FRIENDLY
local PET_OR_GUARDIAN = 0x3000         -- COMBATLOG_OBJECT_TYPE_PET + GUARDIAN
local PLAYER_TYPE = 0x400              -- COMBATLOG_OBJECT_TYPE_PLAYER
local HEAL = { SPELL_HEAL = 15, SPELL_PERIODIC_HEAL = 15 } -- Betrag an Stelle 15, Überheilung an Stelle 16
local DMG = { SWING_DAMAGE = 12, RANGE_DAMAGE = 15, SPELL_DAMAGE = 15, SPELL_PERIODIC_DAMAGE = 15, DAMAGE_SHIELD = 15, DAMAGE_SPLIT = 15, SPELL_BUILDING_DAMAGE = 15 }

---------------------------------------------------------------------------
-- Daten: aktueller Kampf und Gesamt
---------------------------------------------------------------------------
local function newSeg() return { list = {}, start = nil, last = nil, dur = 0 } end
local cur, total = newSeg(), newSeg()
local hcur, htotal = newSeg(), newSeg() -- Heilung (eigene Abschnitte)
local fighting = false
local owner = {}       -- Begleiter-GUID -> Besitzer-GUID
local ownerName = {}   -- Besitzer-GUID -> Name
local gekapselt = false -- Blizzard gibt in diesem Spiel keine Kampfdaten heraus
local logOn, logEvents, logHits = false, 0, 0 -- für /meter test

local function shortName(n) if type(n) ~= "string" then return "?" end return (n:gsub("%-.*$", "")) end
local function classOf(guid)
  local _, cls = safe(GetPlayerInfoByGUID, guid)
  return cls
end
local function scanPets()
  owner = {}
  local function add(unit, petUnit)
    local g, pg = safe(UnitGUID, unit), safe(UnitGUID, petUnit)
    if g and pg and not secret(g) and not secret(pg) then owner[pg] = g; ownerName[g] = shortName(safe(UnitName, unit)) end
  end
  add("player", "pet")
  for i = 1, 4 do add("party" .. i, "partypet" .. i) end
  for i = 1, 40 do add("raid" .. i, "raidpet" .. i) end
end
local function addDamage(seg, guid, name, amount, now, sid, sname)
  local e = seg.list[guid]
  if not e then e = { name = name, class = classOf(guid), dmg = 0, guid = guid }; seg.list[guid] = e end
  if not e.class then e.class = classOf(guid) end
  e.dmg = e.dmg + amount
  if sname then -- pro Fähigkeit mitzählen (für die Aufschlüsselung im Tooltip)
    e.spells = e.spells or {}
    local sp = e.spells[sname]
    if not sp then sp = { name = sname, id = sid, a = 0, h = 0 }; e.spells[sname] = sp end
    sp.a = sp.a + amount; sp.h = sp.h + 1
  end
  seg.start = seg.start or now; seg.last = now
end
local function segDuration(seg)
  local d = seg.dur or 0
  if seg.start and seg.last then d = d + math.max(1, seg.last - seg.start) end
  return math.max(1, d)
end
local function startFight(now)
  if fighting then return end
  fighting = true
  cur, hcur = newSeg(), newSeg()
  total.start, total.last = nil, nil; htotal.start, htotal.last = nil, nil
end
local function endFight()
  if not fighting then return end
  fighting = false
  for _, t in ipairs({ total, htotal }) do
    if t.start and t.last then t.dur = (t.dur or 0) + math.max(1, t.last - t.start) end
    t.start, t.last = nil, nil
  end
end

local function onCombatLog()
  logEvents = logEvents + 1
  local t = { safe(CombatLogGetCurrentEventInfo) }
  local ev = t[2]
  if ev == "SPELL_SUMMON" then
    local sg, dg = t[4], t[8]
    if sg and dg and not secret(sg) then owner[dg] = owner[sg] or sg; ownerName[owner[dg]] = ownerName[owner[dg]] or shortName(t[5]) end
    return
  end
  local idx, heal = DMG[ev], false
  if not idx then idx = HEAL[ev]; heal = idx ~= nil end
  if not idx then return end
  local sg, sname, sflags, dflags, amount = t[4], t[5], t[6], t[10], t[idx]
  if type(sflags) ~= "number" or type(amount) ~= "number" or secret(amount) or secret(sflags) then return end
  if band(sflags, MINE_PARTY_RAID) == 0 then return end
  if heal then
    local over = t[16]; if type(over) == "number" and not secret(over) then amount = math.max(0, amount - over) end -- nur echte Heilung zählt
  elseif type(dflags) == "number" and band(dflags, FRIENDLY) ~= 0 then return end -- kein Schaden an Freunden
  local guid, name = sg, shortName(sname)
  local sid, spn
  if ev == "SWING_DAMAGE" then sid, spn = 6603, "Nahkampf" else sid, spn = t[12], t[13] end
  if secret(spn) or type(spn) ~= "string" then spn = nil end
  if band(sflags, PET_OR_GUARDIAN) ~= 0 and spn then spn = shortName(sname) .. ": " .. spn end -- Begleiter-Fähigkeiten kennzeichnen
  if band(sflags, PET_OR_GUARDIAN) ~= 0 then
    local o = owner[sg]
    if not o and band(sflags, 0x1) ~= 0 then o = safe(UnitGUID, "player") end -- eigener Begleiter
    if not o then return end
    guid, name = o, ownerName[o] or shortName(safe(UnitName, "player"))
  elseif band(sflags, PLAYER_TYPE) == 0 then return end
  if not guid then return end
  local now = GetTime()
  logHits = logHits + 1
  if not fighting then startFight(now) end
  if heal then addDamage(hcur, guid, name, amount, now, sid, spn); addDamage(htotal, guid, name, amount, now, sid, spn)
  else addDamage(cur, guid, name, amount, now, sid, spn); addDamage(total, guid, name, amount, now, sid, spn) end
end

---------------------------------------------------------------------------
-- Fenster
---------------------------------------------------------------------------
local DM = rawget(_G, "C_DamageMeter")
local useBlizz = type(DM) == "table" and type(DM.GetCombatSessionFromType) == "function"
local function enumv(group, key, def) local e = rawget(_G, "Enum"); local g = type(e) == "table" and e[group]; local v = type(g) == "table" and g[key]; return v ~= nil and v or def end
local meters = {}
local function art() return "schaden" end -- wird in jedem Fenster durch die eigene Einstellung ersetzt
local function makeMeter(id)
local function cfg()
  if not DB then return nil end
  local k = id == 1 and "meter" or ("meter" .. id)
  if type(DB[k]) ~= "table" then
    DB[k] = { an = false, mode = "kampf", art = ({ "schaden", "heilung", "aggro", "schaden" })[id] or "schaden" }
    -- Standard-Anordnung: erster Messer unten links neben dem Chat
    if id == 1 then DB[k].an, DB[k].pos, DB[k].w, DB[k].h = true, { "BOTTOMLEFT", "BOTTOMLEFT", 292.9, 22.8 }, 260, 190 end
  end
  return DB[k]
end
local function art() local c = cfg(); local a = c and c.art; return (a == "heilung" or a == "aggro") and a or "schaden" end
local f = CreateFrame("Frame", id == 1 and "siikkUIDamagemeter" or ("siikkUIDamagemeter" .. id), UIParent, "BackdropTemplate")
f:SetSize(260, 190); f:SetPoint("RIGHT", UIParent, "RIGHT", -60 - ((id - 1) % 2) * 270, -120 + math.floor((id - 1) / 2) * 210); f:Hide()
f:SetFrameStrata("MEDIUM"); f:SetClampedToScreen(true); f:SetMovable(true); f:SetResizable(true); f:EnableMouse(true)
if f.SetResizeBounds then f:SetResizeBounds(160, 100, 600, 700) elseif f.SetMinResize then f:SetMinResize(160, 100); if f.SetMaxResize then f:SetMaxResize(600, 700) end end
if f.SetBackdrop then
  f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
  f:SetBackdropColor(0, 0, 0, .6); f:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
end
local head = CreateFrame("Frame", nil, f, "BackdropTemplate")
head:SetPoint("TOPLEFT", 3, -3); head:SetPoint("TOPRIGHT", -3, -3); head:SetHeight(HEAD_H)
local hbg = head:CreateTexture(nil, "BACKGROUND"); hbg:SetAllPoints(); hbg:SetColorTexture(LILA[1] * .45, LILA[2] * .45, LILA[3] * .45, .9)
head.t = head:CreateFontString(nil, "OVERLAY", "GameFontNormal"); head.t:SetPoint("LEFT", 6, 0); head.t:SetJustifyH("LEFT")
head:EnableMouse(true); head:RegisterForDrag("LeftButton")
head:SetScript("OnDragStart", function() if not InCombatLockdown() or not f:IsProtected() then f:StartMoving() end end)
local function savePos()
  if not DB then return end
  local p, _, rp, x, y = f:GetPoint(1)
    cfg().pos = { p, rp, x, y }; cfg().w, cfg().h = f:GetWidth(), f:GetHeight()
end
head:SetScript("OnDragStop", function() f:StopMovingOrSizing(); if NS.snapFrame then pcall(NS.snapFrame, f) end; savePos() end)
-- kleines Namensschild „siikkUI“ oben mittig auf dem Rand – wie an der Minimap (Klicks gehen durch)
do
  local tag = CreateFrame("Frame", nil, f, "BackdropTemplate")
  tag:SetPoint("CENTER", f, "TOP", 0, 1); tag:SetHeight(13); tag:EnableMouse(false)
  tag:SetFrameLevel((head:GetFrameLevel() or f:GetFrameLevel() or 1) + 5)
  if tag.SetBackdrop then
    tag:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    tag:SetBackdropColor(0, 0, 0, .9); tag:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], 1)
  end
  tag.t = tag:CreateFontString(nil, "OVERLAY"); tag.t:SetPoint("CENTER", 0, 0)
  pcall(tag.t.SetFont, tag.t, STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", 9, "OUTLINE")
  tag.t:SetText("|cffe03030siikk|r|cffffd100UI|r")
  local w = tag.t:GetStringWidth(); tag:SetWidth(((type(w) == "number" and w > 0) and w or 36) + 10)
  f.thSchild = tag
end

local function headButton(text, w, tip)
  local b = CreateFrame("Button", nil, head, "BackdropTemplate"); b:SetSize(w, 16)
  if b.SetBackdrop then b:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 }); b:SetBackdropColor(0, 0, 0, .7); b:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], .9) end
  b.t = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); b.t:SetPoint("CENTER"); b.t:SetText(text)
  b:SetScript("OnEnter", function(s) GameTooltip:SetOwner(s, "ANCHOR_TOP"); GameTooltip:AddLine(tip); GameTooltip:Show() end)
  b:SetScript("OnLeave", function() GameTooltip:Hide() end)
  return b
end
local bClose = headButton("x", 16, "Schadensmesser ausblenden (/meter)"); bClose:SetPoint("RIGHT", -3, 0)
local bReset = headButton("Reset", 40, "Alle Zahlen auf 0 setzen"); bReset:SetPoint("RIGHT", bClose, "LEFT", -3, 0)
local bMode = headButton("Kampf", 50, "Umschalten: aktueller Kampf / Gesamt"); bMode:SetPoint("RIGHT", bReset, "LEFT", -3, 0)
local bDup = headButton(id == 1 and "+" or "", 16, "Weiteren Schadensmesser öffnen (bis zu 3 zusätzliche, z. B. Schaden, Heilung und Aggro nebeneinander)")
bDup:SetPoint("RIGHT", bMode, "LEFT", -3, 0)
bDup:SetScript("OnClick", function() if NS.meterToggle2 then NS.meterToggle2() end end)
if id ~= 1 then bDup:Hide() end
head.t:SetPoint("RIGHT", id == 1 and bDup or bMode, "LEFT", -4, 0)

-- Größe ziehen (unten rechts)
local grip = CreateFrame("Button", nil, f); grip:SetSize(16, 16); grip:SetPoint("BOTTOMRIGHT", -2, 2); grip:SetFrameLevel(f:GetFrameLevel() + 10)
grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up"); grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight"); grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
grip:SetScript("OnMouseDown", function() if InCombatLockdown() and f:IsProtected() then return end; f:StartSizing("BOTTOMRIGHT") end)
grip:SetScript("OnMouseUp", function() f:StopMovingOrSizing(); savePos(); if NS.meterUpdate then NS.meterUpdate() end end)

-- Laufleiste rechts (nur sichtbar, wenn mehr Spieler als Platz)
local track = f:CreateTexture(nil, "ARTWORK"); track:SetColorTexture(1, 1, 1, .08); track:SetWidth(4)
track:SetPoint("TOPRIGHT", -5, -(HEAD_H + TAB_H + 6)); track:SetPoint("BOTTOMRIGHT", -5, 20)
local thumb = f:CreateTexture(nil, "OVERLAY"); thumb:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], .9); thumb:SetWidth(4)
local info = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); info:SetPoint("BOTTOMLEFT", 8, 6); info:SetJustifyH("LEFT")

local rows, offset = {}, 0
local function fmt(n)
  n = math.floor((n or 0) + .5)
  local s = tostring(n)
  local r = s:reverse():gsub("(%d%d%d)", "%1."):reverse()
  return (r:gsub("^%.", ""))
end
-- Fähigkeiten-Aufschlüsselung: größter Wert oben
local function spellIcon(id)
  if not id or secret(id) then return nil end
  return (C_Spell and C_Spell.GetSpellTexture and safe(C_Spell.GetSpellTexture, id)) or (GetSpellTexture and safe(GetSpellTexture, id))
end
local function addSpellLines(spells, gesamt, wort)
  local list = {}
  for _, sp in pairs(spells or {}) do list[#list + 1] = sp end
  if #list == 0 then return end
  table.sort(list, function(a, b) return a.a > b.a end)
  GameTooltip:AddLine(" ")
  GameTooltip:AddLine(wort .. " je Fähigkeit:", 1, .82, 0)
  for i = 1, math.min(15, #list) do
    local sp = list[i]
    local ic = spellIcon(sp.id)
    local left = (ic and ("|T" .. ic .. ":14:14:0:0:64:64:5:59:5:59|t ") or "") .. sp.name
    local pct = (gesamt and gesamt > 0) and (" (" .. string.format("%.0f", sp.a / gesamt * 100) .. " %)") or ""
    GameTooltip:AddDoubleLine(left, fmt(sp.a) .. pct .. "  |cff999999" .. sp.h .. "x|r", 1, 1, 1, 1, 1, 1)
  end
  if #list > 15 then GameTooltip:AddLine("… und " .. (#list - 15) .. " weitere", .6, .6, .6) end
end
-- Klassensymbol (gleiches Bild wie bei der Charaktererstellung), für Begleiter eine Pfote
local CLASS_TEX = "Interface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes"
local function setRowLabel(r, rank, name, cls, isPet)
  r.rank:SetText(rank == "T" and "|cff6699ffT|r" or (rank .. "."))
  local tc = cls and CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[cls]
  if tc then r.icon:SetTexture(CLASS_TEX); r.icon:SetTexCoord(tc[1], tc[2], tc[3], tc[4]); r.icon:Show()
  elseif isPet then r.icon:SetTexture("Interface\\Icons\\Ability_Hunter_Pet_Bear"); r.icon:SetTexCoord(.08, .92, .08, .92); r.icon:Show()
  else r.icon:SetTexture(nil); r.icon:Hide() end
  r.icon:SetWidth(r.icon:IsShown() and (ROW_H - 4) or 1)
  if not pcall(r.l.SetText, r.l, name) then r.l:SetText("") end
end
local function getRow(i)
  if rows[i] then return rows[i] end
  local r = CreateFrame("StatusBar", nil, f)
  r:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); r:SetMinMaxValues(0, 1); r:SetHeight(ROW_H)
  r.bg = r:CreateTexture(nil, "BACKGROUND"); r.bg:SetAllPoints(); r.bg:SetColorTexture(1, 1, 1, .06)
  local path = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
  -- Klassensymbol ganz links · Platz · Name
  r.icon = r:CreateTexture(nil, "OVERLAY"); r.icon:SetSize(ROW_H - 4, ROW_H - 4); r.icon:SetPoint("LEFT", 2, 0)
  r.rank = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); r.rank:SetPoint("LEFT", r.icon, "RIGHT", 3, 0); r.rank:SetJustifyH("LEFT")
  r.l = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); r.l:SetPoint("LEFT", r.rank, "RIGHT", 3, 0); r.l:SetJustifyH("LEFT")
  r.r = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); r.r:SetPoint("RIGHT", -4, 0); r.r:SetJustifyH("RIGHT")
  pcall(r.l.SetFont, r.l, path, 11, "OUTLINE"); pcall(r.r.SetFont, r.r, path, 11, "OUTLINE"); pcall(r.rank.SetFont, r.rank, path, 11, "OUTLINE")
  -- Bedrohung in % (ganz rechts), Schaden davor
  r.th = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); r.th:SetPoint("RIGHT", -4, 0); r.th:SetJustifyH("RIGHT"); pcall(r.th.SetFont, r.th, path, 11, "OUTLINE")
  r.r:ClearAllPoints(); r.r:SetPoint("RIGHT", r.th, "LEFT", -4, 0)
  r.l:SetPoint("RIGHT", r.r, "LEFT", -4, 0); if r.l.SetWordWrap then r.l:SetWordWrap(false) end
  r:EnableMouse(true)
  r:SetScript("OnEnter", function(s)
    if s.blizz then
      local b = s.blizz
      GameTooltip:SetOwner(s, "ANCHOR_LEFT")
      if not pcall(GameTooltip.AddLine, GameTooltip, b.name, s.cr, s.cg, s.cb) then GameTooltip:AddLine("Spieler", s.cr, s.cg, s.cb) end
      local w = art() == "heilung" and "Heilung" or "Schaden"
      pcall(GameTooltip.AddDoubleLine, GameTooltip, w, b.totalAmount, 1, .82, 0, 1, 1, 1)
      pcall(GameTooltip.AddDoubleLine, GameTooltip, w .. " pro Sekunde", b.amountPerSecond, 1, .82, 0, 1, 1, 1)
      if s.thTxt then GameTooltip:AddDoubleLine("Bedrohung am Ziel", s.thTxt, 1, .82, 0, 1, 1, 1) end
      -- Aufschlüsselung: zuerst Blizzards Daten, sonst die eigene Zählung
      local shown = false
      if DM and DM.GetCombatSessionSourceFromType and b.sourceGUID ~= nil then
        local src = safe(DM.GetCombatSessionSourceFromType, s.blizzSt, s.blizzTy, b.sourceGUID)
        local cs = type(src) == "table" and (src.combatSpells or src.spells)
        if type(cs) == "table" and #cs > 0 then
          GameTooltip:AddLine(" "); GameTooltip:AddLine(w .. " je Fähigkeit:", 1, .82, 0)
          for i = 1, math.min(15, #cs) do
            local c = cs[i]
            if type(c) == "table" then
              local ic = spellIcon(c.spellID)
              local nm = (c.spellID and not secret(c.spellID) and ((C_Spell and C_Spell.GetSpellName and safe(C_Spell.GetSpellName, c.spellID)) or (GetSpellInfo and safe(GetSpellInfo, c.spellID)))) or "?"
              pcall(GameTooltip.AddDoubleLine, GameTooltip, (ic and ("|T" .. ic .. ":14:14:0:0:64:64:5:59:5:59|t ") or "") .. nm, c.totalAmount, 1, 1, 1, 1, 1, 1)
            end
          end
          shown = true
        end
      end
      if not shown and b.sourceGUID and not secret(b.sourceGUID) then
        local own = (art() == "heilung" and (s.blizzSt == 0 and htotal or hcur) or (s.blizzSt == 0 and total or cur)).list[b.sourceGUID]
        if own then addSpellLines(own.spells, own.dmg, w) end
      end
      GameTooltip:Show(); return
    end
    if not s.e then return end
    GameTooltip:SetOwner(s, "ANCHOR_LEFT"); GameTooltip:AddLine(s.e.name, s.cr, s.cg, s.cb)
    local w = art() == "heilung" and "Heilung" or "Schaden"
    GameTooltip:AddDoubleLine(w, fmt(s.e.dmg), 1, .82, 0, 1, 1, 1)
    GameTooltip:AddDoubleLine(w .. " pro Sekunde", fmt(s.dps), 1, .82, 0, 1, 1, 1)
    if s.thTxt then GameTooltip:AddDoubleLine("Bedrohung am Ziel", s.thTxt, 1, .82, 0, 1, 1, 1) end
    GameTooltip:AddDoubleLine("Anteil", string.format("%.1f %%", s.share * 100), 1, .82, 0, 1, 1, 1)
    addSpellLines(s.e.spells, s.e.dmg, w)
    GameTooltip:Show()
  end)
  r:SetScript("OnLeave", function() GameTooltip:Hide() end)
  r:SetScript("OnMouseWheel", function(_, d) if f:GetScript("OnMouseWheel") then f:GetScript("OnMouseWheel")(f, d) end end)
  r:EnableMouseWheel(true)
  rows[i] = r
  return r
end

---------------------------------------------------------------------------
-- Blizzards offizielle Schadensdaten (Midnight, Forever, TBC 2.5.6): C_DamageMeter
-- Im Kampf sind die Zahlen „geheim“ – wir dürfen sie anzeigen, aber nicht damit rechnen.
---------------------------------------------------------------------------
local function showNum(fs, fmtPattern, ...)
  -- normale Zahlen schön mit Punkten, geheime Zahlen direkt an die Schrift weiterreichen
  local args, plain = { ... }, true
  for i = 1, select("#", ...) do if secret(args[i]) then plain = false end end
  if plain then
    local out = {}
    for i = 1, select("#", ...) do out[i] = fmt(args[i]) end
    fs:SetText((fmtPattern:gsub("%%s", function() return table.remove(out, 1) or "" end)))
    return
  end
  local conv = {}
  for i = 1, select("#", ...) do
    local v = args[i]
    local ok, t = pcall(BreakUpLargeNumbers or tostring, v)
    if ok and t ~= nil then conv[i] = t else conv[i] = v end
  end
  if not pcall(fs.SetFormattedText, fs, fmtPattern, (unpack or table.unpack)(conv)) then
    if not pcall(fs.SetText, fs, conv[1]) then fs:SetText("") end
  end
end
-- Bedrohung: wie nah ist der Spieler daran, dem Tank die Aggro zu nehmen? (100 % = er zieht)
local unitOf = {}
local function scanUnits()
  unitOf = {}
  local function add(u) local g = safe(UnitGUID, u); if g and not secret(g) then unitOf[g] = u end end
  add("player")
  for i = 1, 4 do add("party" .. i) end
  for i = 1, 40 do add("raid" .. i) end
end
local function showThreat(r, unit)
  r.thTxt = nil
  if art() ~= "schaden" or not unit or not safe(UnitExists, "target") or not safe(UnitCanAttack, "player", "target") then r.th:SetText(""); return end
  local tanking, _, pct = safe(UnitDetailedThreatSituation, unit, "target")
  if pct == nil then r.th:SetText(""); return end
  if secret(pct) then
    r.th:SetTextColor(1, 1, 1); if not pcall(r.th.SetFormattedText, r.th, "Aggro %d%%", pct) then r.th:SetText("") end; return
  end
  local p = math.floor(pct + .5)
  if tanking == true then
    p = math.max(p, 100)
    r.th:SetText("Aggro " .. p .. "%"); r.thTxt = p .. " % – hält die Aggro"
    -- echter Tank (Rolle) blau, sonst hat jemand dem Tank die Aggro genommen: rot
    local role = UnitGroupRolesAssigned and safe(UnitGroupRolesAssigned, unit)
    local solo = not (IsInGroup and safe(IsInGroup))
    if role == "TANK" or solo then r.th:SetTextColor(.4, .7, 1) else r.th:SetTextColor(1, .2, .2) end
    return
  end
  r.th:SetText("Aggro " .. p .. "%"); r.thTxt = p .. " %"
  if p >= 90 then r.th:SetTextColor(1, .2, .2) elseif p >= 70 then r.th:SetTextColor(1, .6, .1) elseif p >= 50 then r.th:SetTextColor(1, .9, .3) else r.th:SetTextColor(.8, .8, .8) end
end
local function updateBlizz()
  for _, r in ipairs(rows) do r:SetAlpha(1); r.r:SetTextColor(1, 1, 1) end
  local gesamt = cfg() and cfg().mode == "gesamt"
  bMode.t:SetText(gesamt and "Gesamt" or "Kampf")
  if DM.IsDamageMeterAvailable and safe(DM.IsDamageMeterAvailable) == false then
    for _, r in ipairs(rows) do r:Hide(); r.e = nil end
    head.t:SetText("Schaden"); thumb:Hide(); track:Hide()
    info:SetText("|cffff7777Blizzards Schadensmesser ist aus:|r Esc > Optionen > Schadensmesser einschalten.")
    return
  end
  local st = gesamt and enumv("DamageMeterSessionType", "Overall", 0) or enumv("DamageMeterSessionType", "Current", 1)
  local heil = art() == "heilung"
  local sess = safe(DM.GetCombatSessionFromType, st, heil and enumv("DamageMeterType", "HealingDone", 2) or enumv("DamageMeterType", "DamageDone", 0))
  scanUnits()
  local list = (type(sess) == "table" and type(sess.combatSources) == "table") and sess.combatSources or {}
  if #list == 0 and logOn then return false end -- Blizzard zeichnet nichts auf -> eigene Zählung zeigen
  head.t:SetText((heil and "Heilung" or "Schaden") .. (gesamt and " gesamt" or ""))
  local h = f:GetHeight() or 190
  local fit = math.max(1, math.floor((h - HEAD_H - TAB_H - 28) / (ROW_H + 1)))
  offset = math.max(0, math.min(offset, #list - fit))
  local scroll = #list > fit
  local maxA = type(sess) == "table" and sess.maxAmount or 1
  for i = 1, math.max(#rows, fit) do
    local r = (i <= fit) and getRow(i) or rows[i]
    local e = list[i + offset]
    if r and i <= fit and type(e) == "table" then
      r:ClearAllPoints(); r:SetPoint("TOPLEFT", f, "TOPLEFT", 5, -(HEAD_H + TAB_H + 5) - (i - 1) * (ROW_H + 1)); r:SetPoint("RIGHT", f, "RIGHT", scroll and -12 or -5, 0)
      local c = e.classFilename and RAID_CLASS_COLORS and RAID_CLASS_COLORS[e.classFilename]
      local cr, cg, cb = (c and c.r) or .6, (c and c.g) or .6, (c and c.b) or .6
      r:SetStatusBarColor(cr, cg, cb, .85)
      if not pcall(r.SetMinMaxValues, r, 0, maxA) then r:SetMinMaxValues(0, 1) end
      if not pcall(r.SetValue, r, e.totalAmount) then r:SetValue(0) end
      r.cr, r.cg, r.cb = cr, cg, cb
      r.e = nil; r.blizz = e; r.blizzSt, r.blizzTy = st, heil and enumv("DamageMeterType", "HealingDone", 2) or enumv("DamageMeterType", "DamageDone", 0)
      setRowLabel(r, i + offset, e.name, e.classFilename)
      showNum(r.r, heil and "%s · %s HPS" or "%s · %s DPS", e.totalAmount, e.amountPerSecond)
      local u
      if e.isLocalPlayer == true then u = "player" elseif e.sourceGUID and not secret(e.sourceGUID) then u = unitOf[e.sourceGUID] end
      showThreat(r, u)
      r:Show()
    elseif r then r:Hide(); r.e = nil; r.blizz = nil end
  end
  if scroll then
    local th = track:GetHeight() or 100
    local size = math.max(12, th * fit / #list)
    local pos = (th - size) * (offset / math.max(1, #list - fit))
    thumb:ClearAllPoints(); thumb:SetPoint("TOP", track, "TOP", 0, -pos); thumb:SetHeight(size); thumb:Show(); track:Show()
  else thumb:Hide(); track:Hide() end
  if #list == 0 then info:SetText(heil and "Noch keine Heilung." or "Noch kein Schaden – auf in den Kampf!")
  else info:SetText(#list .. " Spieler · Blizzard-Daten" .. (scroll and " · Mausrad = blättern" or "")) end
  return true
end
-- Klick auf einen Namen im Aggro-Reiter = diesen Spieler anvisieren (sichere Blizzard-Knöpfe, funktionieren auch im Kampf).
-- Weil WoW im Kampf nicht erlaubt umzustellen, wen ein Knopf anvisiert, bleiben die Zeilen im Kampf an ihrem Platz;
-- die Platzierungsnummer (wer am nächsten an der Aggro ist = 1.) läuft trotzdem live mit.
local MAXO = 20
local overlays, overlaysOn = {}, false
local frozen -- Reihenfolge (Einheiten) seit Kampfbeginn
for i = 1, MAXO do
  local ov = CreateFrame("Button", nil, UIParent, "SecureActionButtonTemplate")
  ov:SetFrameStrata("MEDIUM"); ov:SetFrameLevel(60); ov:SetHeight(ROW_H); ov:Hide()
  if ov.RegisterForClicks then ov:RegisterForClicks("AnyUp", "AnyDown") end
  ov:SetAttribute("type1", "target"); ov:SetAttribute("type2", "target")
  ov:HookScript("OnEnter", function() local r = rows[i]; if r and r:IsShown() then local fn = r:GetScript("OnEnter"); if fn then fn(r) end end end)
  ov:HookScript("OnLeave", function() GameTooltip:Hide() end)
  overlays[i] = ov
end
local function syncOverlays(list, fit, on)
  if InCombatLockdown() then return end
  overlaysOn = on and f:IsShown()
  for i = 1, MAXO do
    local ov, e = overlays[i], on and list[i]
    if e and i <= fit and f:IsShown() then
      ov:ClearAllPoints(); ov:SetPoint("TOPLEFT", f, "TOPLEFT", 5, -(HEAD_H + TAB_H + 5) - (i - 1) * (ROW_H + 1)); ov:SetPoint("RIGHT", f, "RIGHT", -5, 0)
      ov:SetAttribute("unit", e.unit); ov:Show()
    else ov:Hide() end
  end
end
-- Reiter „Aggro“: alle aus Gruppe/Schlachtzug am aktuellen Ziel, voller Balken = 100 % (zieht Aggro)
local function updateAggro()
  head.t:SetText("Aggro am Ziel"); bMode.t:SetText(cfg() and cfg().mode == "gesamt" and "Gesamt" or "Kampf")
  local list = {}
  local hasTarget = safe(UnitExists, "target") and safe(UnitCanAttack, "player", "target")
  if hasTarget then
    -- alle Spieler und ihre Begleiter (Jäger-Tiere, Hexer-Dämonen, Wasserelementare …)
    local units, owners = { "player", "pet" }, { pet = "player" }
    if IsInRaid and safe(IsInRaid) then
      for i = 1, 40 do units[#units + 1] = "raid" .. i; units[#units + 1] = "raidpet" .. i; owners["raidpet" .. i] = "raid" .. i end
    else
      for i = 1, 4 do units[#units + 1] = "party" .. i; units[#units + 1] = "partypet" .. i; owners["partypet" .. i] = "party" .. i end
    end
    local seen = {}
    for _, u in ipairs(units) do
      if safe(UnitExists, u) then
        local g = safe(UnitGUID, u)
        if not (g and not secret(g) and seen[g]) then
          if g and not secret(g) then seen[g] = true end
          local tanking, _, pct = safe(UnitDetailedThreatSituation, u, "target")
          if pct ~= nil then
            local own = owners[u]
            local _, cls = safe(UnitClass, own or u)              -- Begleiter in der Klassenfarbe des Besitzers
            local nm = safe(UnitName, u)
            if own and own ~= "player" then
              local on = safe(UnitName, own)
              if type(nm) == "string" and type(on) == "string" and not secret(nm) and not secret(on) then nm = nm .. " (" .. on .. ")" end
            end
            list[#list + 1] = { unit = u, name = nm, class = cls, pct = pct, tank = tanking == true, pet = own ~= nil, mine = (u == "pet") }
          end
        end
      end
    end
    -- Platzierung live: wer (außer dem Tank) am meisten Aggro hat, ist die 1.
    local sortable = true
    for _, e in ipairs(list) do if secret(e.pct) then sortable = false end end
    if sortable then
      local byThreat = {}
      for _, e in ipairs(list) do byThreat[#byThreat + 1] = e end
      table.sort(byThreat, function(a, b) if a.tank ~= b.tank then return b.tank end return a.pct > b.pct end)
      for k, e in ipairs(byThreat) do e.rank = k end
    end
    if InCombatLockdown() and frozen then
      -- im Kampf: Zeilen bleiben an ihrem Platz (damit der Klick den richtigen Spieler trifft)
      local pos = {}; for k, u in ipairs(frozen) do pos[u] = k end
      table.sort(list, function(a, b) return (pos[a.unit] or 99) < (pos[b.unit] or 99) end)
    else
      table.sort(list, function(a, b) return (a.rank or 99) < (b.rank or 99) end)
      frozen = {}; for k, e in ipairs(list) do frozen[k] = e.unit end
    end
  end
  local h = f:GetHeight() or 190
  local fit = math.max(1, math.floor((h - HEAD_H - TAB_H - 28) / (ROW_H + 1)))
  offset = math.max(0, math.min(offset, #list - fit))
  if InCombatLockdown() then offset = 0 end -- im Kampf nicht blättern (Klick-Zuordnung bleibt gleich)
  local scroll = #list > fit
  local blinkOn = math.floor(GetTime() * 4) % 2 == 0
  local solo = not (IsInGroup and safe(IsInGroup))
  for i = 1, math.max(#rows, fit) do
    local r = (i <= fit) and getRow(i) or rows[i]
    local e = list[i + offset]
    if r and i <= fit and e then
      r:ClearAllPoints(); r:SetPoint("TOPLEFT", f, "TOPLEFT", 5, -(HEAD_H + TAB_H + 5) - (i - 1) * (ROW_H + 1)); r:SetPoint("RIGHT", f, "RIGHT", scroll and -12 or -5, 0)
      local c = e.class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[e.class]
      local cr, cg, cb = (c and c.r) or .6, (c and c.g) or .6, (c and c.b) or .6
      r.e, r.blizz, r.cr, r.cg, r.cb = nil, nil, cr, cg, cb
      r:SetMinMaxValues(0, 100)
      r.th:SetText("")
      if secret(e.pct) then
        pcall(r.SetValue, r, e.pct); r:SetStatusBarColor(cr, cg, cb, .85); r:SetAlpha(1)
        if not pcall(r.r.SetFormattedText, r.r, "Aggro %d%%", e.pct) then r.r:SetText("") end
      else
        local p = math.floor(e.pct + .5)
        local role = UnitGroupRolesAssigned and safe(UnitGroupRolesAssigned, e.unit)
        local echterTank = e.tank and (role == "TANK" or solo)
        r:SetValue(math.min(100, math.max(p, e.tank and 100 or 0)))
        r.r:SetText("Aggro " .. (e.tank and math.max(p, 100) or p) .. "%")
        if echterTank then r:SetStatusBarColor(.25, .55, 1, .9); r:SetAlpha(1); r.r:SetTextColor(.6, .8, 1)
        elseif p > 80 or e.tank then
          -- über 80 %: Balken rot und blinkend
          r:SetStatusBarColor(1, .1, .1, .95); r:SetAlpha(blinkOn and 1 or .35); r.r:SetTextColor(1, .3, .3)
        else r:SetStatusBarColor(cr, cg, cb, .85); r:SetAlpha(1); r.r:SetTextColor(1, 1, 1) end
        r.thTxt = p .. " %"
      end
      setRowLabel(r, e.tank and "T" or (e.rank or (i + offset)), (e.name or "?") .. (e.mine and " (Begleiter)" or ""), e.pet and nil or e.class, e.pet)
      r:Show()
    elseif r then r:Hide(); r:SetAlpha(1); r.e = nil; r.blizz = nil end
  end
  if scroll then
    local th = track:GetHeight() or 100
    local size = math.max(12, th * fit / #list)
    local pos = (th - size) * (offset / math.max(1, #list - fit))
    thumb:ClearAllPoints(); thumb:SetPoint("TOP", track, "TOP", 0, -pos); thumb:SetHeight(size); thumb:Show(); track:Show()
  else thumb:Hide(); track:Hide() end
  local vis = {}; for k = 1, fit do vis[k] = list[k + offset] end
  syncOverlays(vis, fit, true)
  if not hasTarget then info:SetText("Keinen Gegner im Ziel.")
  elseif #list == 0 then info:SetText("Noch keine Bedrohung am Ziel.")
  else
    local tn = safe(UnitName, "target")
    if not pcall(info.SetFormattedText, info, "Ziel: %s · ab 80 %% blinkt es rot", tn or "?") then info:SetText("ab 80 % blinkt es rot") end
  end
end
local function update()
  if not f:IsShown() then return end
  if art() == "aggro" then return updateAggro() end
  if overlaysOn then syncOverlays({}, 0, false) end
  for _, r in ipairs(rows) do r:SetAlpha(1); r.r:SetTextColor(1, 1, 1); r:SetMinMaxValues(0, 1) end
  if useBlizz and updateBlizz() ~= false then return end
  local gesamt = cfg() and cfg().mode == "gesamt"
  local heil = art() == "heilung"
  local seg = heil and (gesamt and htotal or hcur) or (gesamt and total or cur)
  bMode.t:SetText(gesamt and "Gesamt" or "Kampf")
  scanUnits()
  local list, sum = {}, 0
  for _, e in pairs(seg.list) do list[#list + 1] = e; sum = sum + e.dmg end
  table.sort(list, function(a, b) return a.dmg > b.dmg end)
  local dur = segDuration(seg)
  head.t:SetText((heil and "Heilung" or "Schaden") .. (gesamt and " gesamt" or "") .. "  |cffffffff" .. fmt(sum / dur) .. (heil and " HPS|r" or " DPS|r"))
  local h = f:GetHeight() or 190
  local fit = math.max(1, math.floor((h - HEAD_H - TAB_H - 28) / (ROW_H + 1)))
  offset = math.max(0, math.min(offset, #list - fit))
  local top = list[1] and list[1].dmg or 1
  local scroll = #list > fit
  for i = 1, math.max(#rows, fit) do
    local r = (i <= fit) and getRow(i) or rows[i]
    local e = list[i + offset]
    if r and i <= fit and e then
      r:ClearAllPoints(); r:SetPoint("TOPLEFT", f, "TOPLEFT", 5, -(HEAD_H + TAB_H + 5) - (i - 1) * (ROW_H + 1)); r:SetPoint("RIGHT", f, "RIGHT", scroll and -12 or -5, 0)
      local c = e.class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[e.class]
      local cr, cg, cb = (c and c.r) or .6, (c and c.g) or .6, (c and c.b) or .6
      r:SetStatusBarColor(cr, cg, cb, .85); r:SetValue(e.dmg / math.max(1, top))
      r.e, r.cr, r.cg, r.cb = e, cr, cg, cb
      r.dps = e.dmg / dur; r.share = sum > 0 and e.dmg / sum or 0
      setRowLabel(r, i + offset, e.name, e.class)
      r.r:SetText(fmt(e.dmg) .. " · " .. fmt(r.dps) .. (heil and " HPS" or " DPS"))
      showThreat(r, e.guid and unitOf[e.guid])
      r:Show()
    elseif r then r:Hide(); r.e = nil end
  end
  if scroll then
    local th = track:GetHeight() or 100
    local size = math.max(12, th * fit / #list)
    local pos = (th - size) * (offset / math.max(1, #list - fit))
    thumb:ClearAllPoints(); thumb:SetPoint("TOP", track, "TOP", 0, -pos); thumb:SetHeight(size); thumb:Show(); track:Show()
  else thumb:Hide(); track:Hide() end
  if gekapselt then info:SetText("|cffff7777Blizzard gibt hier keine Kampfdaten frei.|r")
  elseif #list == 0 then info:SetText(heil and "Noch keine Heilung." or "Noch kein Schaden – auf in den Kampf!")
  else info:SetText(#list .. " Spieler · " .. math.floor(dur + .5) .. " Sek." .. (scroll and " · Mausrad = blättern" or "")) end
end
f:EnableMouseWheel(true)
f:SetScript("OnMouseWheel", function(_, d) offset = offset - d; update() end)
f:SetScript("OnSizeChanged", function() update() end)
f:SetScript("OnShow", update)
local acc = 0
f:SetScript("OnUpdate", function(_, el) acc = acc + (el or 0); if acc >= (art() == "aggro" and .15 or .5) then acc = 0; update() end end)

local function reset()
  if useBlizz and DM.ResetAllCombatSessions then
    if InCombatLockdown() then msg("Zurücksetzen geht erst nach dem Kampf.") return end
    pcall(DM.ResetAllCombatSessions)
  end
  cur, total = newSeg(), newSeg(); hcur, htotal = newSeg(), newSeg(); fighting = false; offset = 0
  if InCombatLockdown() then startFight(GetTime()) end
  for _, mm in ipairs(meters) do mm.update() end; msg("Schadens- und Heilungsmesser zurückgesetzt.")
end
local function toggleMode()
    cfg().mode = (cfg().mode == "gesamt") and "kampf" or "gesamt"; offset = 0; update()
end
-- Reiter unter dem Messer: Schaden | Heilung
local tabs = {}
local function paintMeterTabs()
  local a = art()
  for k, b in pairs(tabs) do
    local on = k == a
    if b.SetBackdropColor then b:SetBackdropColor(on and .32 or .05, on and .12 or .04, on and .45 or .07, .95); b:SetBackdropBorderColor(GOLD[1], GOLD[2], GOLD[3], on and 1 or .6) end
    b.t:SetTextColor(on and 1 or .85, on and .85 or .75, on and .3 or .55)
  end
end
local TABNAMES = { schaden = "Schaden", heilung = "Heilung", aggro = "Aggro" }
local tabOrder = { "schaden", "heilung", "aggro" }
local function placeTabs()
  local w = ((f:GetWidth() or 260) - 10 - 4) / 3
  for i, k in ipairs(tabOrder) do
    local b = tabs[k]
    if b then b:ClearAllPoints(); b:SetPoint("TOPLEFT", f, "TOPLEFT", 5 + (i - 1) * (w + 2), -(HEAD_H + 4)); b:SetWidth(w) end
  end
end
for i, k in ipairs(tabOrder) do
  local b = CreateFrame("Button", nil, f, "BackdropTemplate"); b:SetHeight(TAB_H - 3)
  -- Reiter im Fenster direkt unter der Kopfzeile (außen würden Chat/Leisten sie verdecken)
  b:SetFrameLevel(f:GetFrameLevel() + 8); b:EnableMouse(true); if b.RegisterForClicks then b:RegisterForClicks("LeftButtonUp") end
  if b.SetBackdrop then b:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 }) end
  b.t = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); b.t:SetPoint("CENTER"); b.t:SetText(TABNAMES[k])
  b:SetScript("OnClick", function()
    if InCombatLockdown() and (overlaysOn or k == "aggro") and art() ~= k then msg("Den Aggro-Reiter kannst du erst nach dem Kampf wechseln (wegen der Anklick-Funktion)."); return end
    cfg().art = k; offset = 0; paintMeterTabs(); update()
  end)
  b:SetScript("OnEnter", function(x) if x.SetBackdropBorderColor then x:SetBackdropBorderColor(1, .9, .4, 1) end end)
  b:SetScript("OnLeave", function() paintMeterTabs() end)
  tabs[k] = b
end
placeTabs()
f:HookScript("OnShow", paintMeterTabs)
f:HookScript("OnSizeChanged", placeTabs)
local function setShown(v)
  if not v and overlaysOn and InCombatLockdown() then msg("Bitte erst nach dem Kampf schließen (Aggro-Reiter mit Anklick-Funktion)."); return end
  cfg().an = v
  if v then f:Show() else f:Hide(); syncOverlays({}, 0, false) end
end
bReset:SetScript("OnClick", reset)
bMode:SetScript("OnClick", toggleMode)
bClose:SetScript("OnClick", function() setShown(false); msg(id == 1 and "Schadensmesser aus – wieder an mit |cffffd100/meter|r." or "Zusätzlicher Messer geschlossen – wieder öffnen mit dem |cffffd100+|r-Knopf.") end)
return { f = f, update = update, setShown = setShown, paintTabs = paintMeterTabs, rows = rows, cfg = cfg, reset = reset }
end
for i = 1, 4 do meters[i] = makeMeter(i) end -- Hauptmesser + bis zu 3 zusätzliche
local f, update, rows, reset = meters[1].f, meters[1].update, meters[1].rows, meters[1].reset
local function paintMeterTabs() for _, mm in ipairs(meters) do mm.paintTabs() end end
-- Standard-Platz des ersten Messers (für „Plätze zurücksetzen“)
NS.meterStandard = function()
  local m = meters[1]; local c = m.cfg(); if not c then return end
  c.pos, c.w, c.h = { "BOTTOMLEFT", "BOTTOMLEFT", 292.9, 22.8 }, 260, 190
  if not (InCombatLockdown() and m.f:IsProtected()) then m.f:ClearAllPoints(); m.f:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 292.9, 22.8); m.f:SetSize(260, 190) end
end
local function updateAll() for _, mm in ipairs(meters) do mm.update() end end
NS.meterUpdate = updateAll
NS.meterToggle = function() meters[1].setShown(not meters[1].f:IsShown()) end
-- „+“: das nächste geschlossene Zusatzfenster öffnen
NS.meterToggle2 = function()
  for i = 2, #meters do if not meters[i].f:IsShown() then meters[i].setShown(true); return end end
  msg("Alle 3 zusätzlichen Schadensmesser sind schon offen – schließen mit dem |cffffd100x|r im jeweiligen Fenster.")
end
NS.meterReset = reset
NS.meterFrames = {}; for i = 1, #meters do NS.meterFrames[i] = meters[i].f end

---------------------------------------------------------------------------
-- Ereignisse
---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
for _, e in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "GROUP_ROSTER_UPDATE", "UNIT_PET", "PLAYER_ENTERING_WORLD" }) do pcall(ev.RegisterEvent, ev, e) end
-- Midnight (ab 12.0) sperrt das Kampflog für Addons – schon der Versuch löst Blizzards „geblockt“-Meldung aus
local build = select(4, GetBuildInfo())
local midnight = type(build) == "number" and (build >= 120000 or (build >= 16000 and build < 20000))
-- Eigenes Mitzählen überall, wo Blizzard das Kampflog erlaubt (TBC, Classic); Blizzard-Daten nur zusätzlich
if midnight or type(CombatLogGetCurrentEventInfo) ~= "function" then gekapselt = not useBlizz
else logOn = pcall(ev.RegisterEvent, ev, "COMBAT_LOG_EVENT_UNFILTERED"); if not logOn then gekapselt = not useBlizz end end
-- Falls Blizzard trotzdem etwas blockiert: genau sagen, was – für die Fehlersuche
pcall(ev.RegisterEvent, ev, "ADDON_ACTION_FORBIDDEN"); pcall(ev.RegisterEvent, ev, "ADDON_ACTION_BLOCKED")
ev:SetScript("OnEvent", function(_, e, a1, ...)
  if e == "COMBAT_LOG_EVENT_UNFILTERED" then pcall(onCombatLog) return end
  if e == "ADDON_ACTION_FORBIDDEN" or e == "ADDON_ACTION_BLOCKED" then
    local fn = select(2, ...)
    if a1 == ADDON then msg("|cffff5555Blizzard hat geblockt:|r " .. tostring(fn) .. (e == "ADDON_ACTION_BLOCKED" and " (im Kampf)" or "") .. " – bitte Screenshot machen.") end
    return
  end
  if e == "ADDON_LOADED" then
    if a1 == ADDON then
      DamagemeterTobsiikkDB = DamagemeterTobsiikkDB or {}
      DB = DamagemeterTobsiikkDB
      DB.meter = DB.meter or { an = true, mode = "kampf" }
      if DB.meter.an == nil then DB.meter.an = true end
    end
    return
  end
  if not DB then return end
  if e == "PLAYER_LOGIN" then
    for _, mm in ipairs(meters) do
      local m, fr = mm.cfg(), mm.f
      if m.w and m.h then fr:SetSize(m.w, m.h) end
      if type(m.pos) == "table" and m.pos[1] then fr:ClearAllPoints(); fr:SetPoint(m.pos[1], UIParent, m.pos[2] or m.pos[1], m.pos[3] or 0, m.pos[4] or 0) end
      if m.an then fr:Show() end
    end
    scanPets()
  elseif e == "PLAYER_REGEN_DISABLED" then startFight(GetTime())
  elseif e == "PLAYER_REGEN_ENABLED" then endFight()
  else scanPets() end
end)

-- Befehle: /meter …, /meter …
local function meterCmd(arg)
  arg = arg or ""
  if arg == "test" then
    local sess = useBlizz and safe(DM.GetCombatSessionFromType, enumv("DamageMeterSessionType", "Overall", 0), enumv("DamageMeterType", "DamageDone", 0))
    local nb = (type(sess) == "table" and type(sess.combatSources) == "table") and #sess.combatSources or 0
    local nc = 0; for _ in pairs(total.list) do nc = nc + 1 end
    msg("Messer-Test · Spielversion " .. tostring(build) .. " · Blizzard-Schnittstelle: " .. (useBlizz and "ja" or "nein") ..
      (useBlizz and (" (an: " .. tostring(DM.IsDamageMeterAvailable and safe(DM.IsDamageMeterAvailable)) .. ", Spieler: " .. nb .. ")") or ""))
    msg("Eigenes Kampflog: " .. (logOn and "|cff55ff55an|r" or "|cffff5555aus|r") .. " · Ereignisse: " .. logEvents .. " · gezählte Treffer: " .. logHits .. " · Spieler: " .. nc)
  elseif arg == "reset" then reset() elseif arg == "gesamt" or arg == "kampf" then meters[1].cfg().mode = arg; updateAll()
  elseif arg == "heilung" or arg == "schaden" or arg == "aggro" then meters[1].cfg().art = arg; paintMeterTabs(); updateAll()
  elseif tonumber(arg) and meters[tonumber(arg)] then local m = meters[tonumber(arg)]; m.setShown(not m.f:IsShown())
  elseif arg == "hilfe" or arg == "help" or arg == "?" then
    msg("/meter – an/aus · /meter 2|3|4 – zusätzliche Fenster · /meter reset – zurücksetzen · /meter schaden|heilung|aggro · /meter kampf|gesamt · /meter test")
  else NS.meterToggle() end
end
local baseSlash = SlashCmdList.TOBSIIKKHELFER
if baseSlash then
  SlashCmdList.TOBSIIKKHELFER = function(input)
    local c, arg = (input or ""):lower():match("^(%S*)%s*(.-)$")
    if c == "meter" or c == "schaden" or c == "dmg" then meterCmd(arg)
    else
      baseSlash(input)
      if c == "hilfe" or c == "help" or c == "?" then msg("/meter – Schadensmesser an/aus · /meter 2|3|4 – zusätzliche Messer · /meter reset – zurücksetzen") end
    end
  end
end
SLASH_SIIKKUIDM1 = "/meter"; SLASH_SIIKKUIDM2 = "/sdm"
SlashCmdList.SIIKKUIDM = function(input) meterCmd(((input or ""):lower():match("^%s*(.-)%s*$"))) end
NS.meterDebug = { frame = f, frame2 = meters[2].f, rows2 = meters[2].rows, frame3 = meters[3].f, frame4 = meters[4].f, cur = function() return cur end, total = function() return total end, rows = rows }
